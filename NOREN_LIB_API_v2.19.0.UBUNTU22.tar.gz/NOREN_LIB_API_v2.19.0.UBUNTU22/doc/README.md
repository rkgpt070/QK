//*************************************************************************************************
// Copyright © Kambala Solutions Private Limited All rights reserved.
//
//*************************************************************************************************


export LD_LIBRARY_PATH=/home/user/path_to_folder/Library:$LD_LIBRARY_PATH


//for AppMain.cpp 
g++ -O3 -o AppExe reference_code/AppMain.cpp reference_code/cxxapi_client.cpp -L lib/ -lNorenApi_cxxC_o -pthread -lcurl -lcrypto -lprotobuf -lcryptopp -I include/
