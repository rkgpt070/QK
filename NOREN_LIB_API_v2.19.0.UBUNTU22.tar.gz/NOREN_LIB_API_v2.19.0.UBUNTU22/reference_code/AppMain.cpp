//*************************************************************************************************
// Copyright © Kambala Solutions Private Limited All rights reserved.
//
//*************************************************************************************************
#include "cxxapi_client.hpp"
#include <unistd.h>
int main(int argc,
         char* argv[])
{
     /*---------------------------------------VARIABLE DECLARATIONS-------------------------------*/

     char* xml_file = (char*)"/home/xxx/config.xml";

     if (argc > 1)
          xml_file = argv[1];

     CXXAPINorenClient oCMyNorenClient;
     CNorenControl* pNorenControl = new CNorenControl(&oCMyNorenClient,
                                                       xml_file /* pass xml file path*/, true);

     if (pNorenControl->IsValid())
     {
          char* AdminUserID = (char*)"SHRAMITH";
          char* AdminPassword = (char*)"Shrami#97";

          char* userID = (char*)"JYOTHI";
          char* accountID = (char*)"JYOTHI";

          char* ClientData = (char*)"ClientData";
          //          char* ClientData2 = (char*)"ClientData2";

          if(argc > 2)
          {
               AdminUserID = argv[2];
          }
          if(argc > 3)
               AdminPassword = argv[3];
          if(argc > 4)
          {
               //investor
               accountID = argv[4];
               userID = argv[4];
          }
          if(argc > 5)
               ClientData = argv[5];

          //login
          pNorenControl->Admin_Login(ClientData, AdminUserID, AdminPassword);

          bool bRun = false;
          int iCount = 3;
          while (!pNorenControl->IsLogged() && iCount--)
          {
               sleep(1);
          }
          if(pNorenControl->IsLogged())
               bRun = true;
          else
               printf("Login failed\n");

          while(bRun)
          {
               char Product[10];
               char TrdSymbl[20];
               char ExchSeg[10];
               char TransType[10];
               char OrdType[10];
               char OrdSrc[10];
               char OrdSrc2[10];
               char Pan[10];
               char GuiOrdId[20];
               char acGuiOrgOrdId[20];
               char OrdNum[20];
               char TrdSymbl2[10];
               char TransType2[10];
               char Token[10];
               char BrokerId[10];
               char Segment[10];
               char ExchSegment[10];
               char Periodicity[10];
               char PriceType[10];
               char InterOPKey[10];
               char InterOPExchSeg[10];
               char acExternalRemarks[30];
               char acAlgoName[10];
               char acUid[10];
               char acPwd[10];
               char acInstName[10];
               char Isin[10];
               char GrpId[10];
               char ExchUsrId[10];
               char acAcct[12];
               char acUser[12];
               char input[10];

               long Qty;
               double Price;
               long Qty2;
               double Price2;
               double Amt;
               long startTime;
               long lPrice;
               int AuNum;
               long UpdateTime;
               long UpdateTimeSec;
               long UpdateTimeNanoSec;
               long AQ_ID;
               long Iceberg_leg;
               // long LineID;
               // long UnderLineID;

               char AlName[20];
               char GTTVarName[20];
               long GTTVarVal;
               char GTTVarName2[20];
               long GTTVarVal2;
               char GTTValidity[20];
               char GTTRemarks[20];
               char GTTId[20];
               char RmsProduct[10];
               char RmsSegment[10];
               char RmsExchSeg[10];

               char* pSegment;
               char* pExchSegment;
               char* pProduct;
               long SIPid;
               char acSipState[10];
               char acSipName[10];

               int MWsize = 3;
               int c;
               char** pMWGroups = new char*[MWsize];

               long BpPrice;
               long TrailingPrice;
               
               bool enabaleLogs = false;
               bool enableTimestamp = false;
               printf("Enter a digit\t [1 --> Help to display menu options]\t");
               scanf("%d",&c);
               switch(c)
               {

                    case 1: printf("Integer and corresponding features are given below\n"
                                   "1 -> Help\n"
                                   "2 -> OrderAdminSubscribe\n"
                                   "3 -> PlaceOrder\n"
                                   "4 -> ModifyOrder\n"
                                   "5 -> CancelOrder\n"
                                   "6 -> GetOrders\n"
                                   "7 -> GetOrdersAcct\n"
                                   "8 -> TradeHistory\n"
                                   "9 -> TradeHistoryAcct\n"
                                   "10 -> GetAllClients\n"
                                   "11 -> GetPositions\n"
                                   "12 -> GetAllSymbols\n"
                                   "13 -> PlaceMultiLegOrder\n"
                                   "14 -> GetGroupSettings\n"
                                   "15 -> SetGroupSettings\n"
                                   "16 -> ValidateUidPwd\n"
                                   "17 -> ExitCoverOrder\n"
                                   "18 -> ExitBracketOrder\n"
                                   "19 -> Subscribe\n"
                                   "20 -> PartialPosConv\n"
                                   "21 -> GetRmsLimits\n"
                                   "22 -> PlaceAfterMktOrder\n"
                                   "23 -> AfterMktModifyOrder\n"
                                   "24 -> PlaceAfterMktMultiLegOrder\n"
                                   "25 -> GetIndexNames\n"
                                   "26 -> GetProductList\n"
                                   "27 -> GetUserProfile\n"
                                   "28 -> SecurityInfo\n"
                                   "29 -> OrderHistory\n"
                                   "30 -> ViewHoldings\n"
                                   "31 -> GetTopnKeys\n"
                                   "32 -> GetTopnValues\n"
                                   "33 -> GetAllVwapData\n"  /*ND*/
                                   "34 -> GetScripDetails\n"
                                   "35 -> GetMarketStatus\n"
                                   "36 -> GetExchangeMessages\n"
                                   "37 -> AddFunds\n"
                                   "38 -> WithdrawFunds\n"
                                   "39 -> GetWithdrawalAmt\n"
                                   "40 -> IpoList\n"
                                   "41 -> IpoOrderAdminSubscribe\n"
                                   "42 -> IpoPlaceOrder\n"
                                   "43 -> IpoModifyOrder\n"  /*ND*/
                                   "44 -> IpoCancelOrder\n"  /*ND*/
                                   "45 -> IpoOrderBook\n"
                                   "46 -> MfPlaceOrder\n"
                                   "47 -> MfModifyOrder\n"  /*ND*/
                                   "48 -> MfCancelOrder\n"  /*ND*/
                                   "49 -> MfOrderBook\n"
                                   "50 -> AddHoldings\n"
                                   "51 -> PlaceGTT\n"
                                   "52 -> ModifyGTT\n"
                                   "53 -> CancelGTT\n"
                                   "54 -> GetGTTOrders\n"
                                   "55 -> PlaceOCO\n"
                                   "56 -> ModifyOCO\n"
                                   "57 -> CancelOCO\n"
                                   "58 -> GetOCOOrders\n"
                                   "59 -> MktStatusSubscribe\n"
                                   "60 -> ModifyUserSubscribe\n"
                                   "61 -> AddT1Holdings\n"
                                   "62 -> PositionSubscribe\n"
                                   "63 -> PeakMarginSubscribe\n"
                                   "64 -> ExpiryMarginSubscribe\n"
                                   "65 -> RiskDashBoardSubscribe\n"
                                   "66 -> GetOrderMargin\n"
                                   "67 -> GetAllOrders\n"  /*ND*/
                                   "68 -> AllTradeHistory\n"
                                   "69 -> GetAllPositions\n"
                                   "70 -> ChangePassword\n"
                                   "71 -> M2MAlertSubscribe\n"
                                   "72 -> GTTUpdatesSubscribe\n"
                                   "73 -> GetGTTOrdersAcct\n"
                                   "74 -> GetAllGTTOrders\n"
                                   "75 -> GetOCOOrdersAcct\n"
                                   "76 -> GetAllOCOOrders\n"
                                   "77 -> GetBasketMargin\n"
                                   "78 -> SqroffAlertsSubscribe\n"
                                   "79 -> OrderAdminUnSubscribe\n"
                                   "80 -> PositionAdminUnSubscribe\n"
                                   "81 -> UnSubscribeFeed\n"
                                   "82 -> MktStatusUnSubscribe\n"
                                   "83 -> IpoOrderAdminUnSubscribe\n"
                                   "84 -> ModifyUserUnSubscribe\n"
                                   "85 -> PeakMarginUnSubscribe\n"
                                   "86 -> ExpiryMarginUnSubscribe\n"
                                   "87 -> RiskDashBoardUnSubscribe\n"
                                   "88 -> GTTUpdatesUnSubscribe\n"
                                   "89 -> M2MAlertUnSubscribe\n"
                                   "90 -> SqroffAlertsUnSubscribe\n"
                                   "91 -> ModifyHoldings\n"
                                   "92 -> GetGTTOCOOrders\n"
                                   "93 -> LimitsUpdateSubscribe\n"
                                   "94 -> HoldingsUpdateSubscribe\n"
                                   "95 -> FundsUpdateSubscribe\n"
                                   "96 -> PlaceSIP\n"
                                   "97 -> ModifySIP\n"
                                   "98 -> CancelSIP\n"
                                   "99 -> GetSIPOrder\n"
                                   "101 -> GetTriggeredGTTOrders\n"
                                   "102 -> GetAllTriggeredGTTOrders\n"
                                   "103 -> GetTriggeredOCOOrders\n"
                                   "104 -> GetAllTriggeredOCOOrders\n"
                                   "105 -> GetTriggeredGTTOCOOrders\n"
                                   "106 -> SubscribeMsgToMaster\n"
                                   "107 -> UnSubscribeMsgToMaster\n"
                                   "108 -> PosConvSubscribe\n"
                                   "109 -> PosConvUnSubscribe\n"
                                   "110 -> AddMfHoldings\n"
                                   "111 -> ViewMfHoldings\n"
                                   "112 -> GetBrokerage\n"
                                   "113 -> BlockAmtUpdateSubscribe\n"
                                   "114 -> BlockAmtUpdateUnSubscribe\n"
                                   "115 -> PayInUpdateSubscribe\n"
                                   "116 -> PayInUpdateUnSubscribe\n"
                                   "117 -> PayOutUpdateSubscribe\n"
                                   "118 -> PayOutUpdateUnSubscribe\n"
                                   "119 -> IncrCashUpdateSubscribe\n"
                                   "120 -> IncrCashUpdateUnSubscribe\n"
                                   "121 -> GetAmoStatus\n"
                                   "122 -> ExchangeMessageSubscribe\n"
                                   "123 -> ExchangeMessageUnSubscribe\n"
                                   "124 -> DPRSubscribe\n"
                                   "125 -> DPRUnSubscribe\n"
                                   "126 -> GetAllRmsLimits\n"
                                   "127 -> PayinStatusVerify\n"
                                   "128 -> GetEquitySipOrderAcct\n"
                                   "129 -> GetHSToken\n"
                                   "130 -> RegenerateCoverOrder\n"
                                   "131 -> RegenerateBracketOrder\n"
                                   "132 -> UpdateBlockAmount\n"
                                   "133 -> GetOptimizedBasketSequence\n"
                                   "134 -> WithdrawFunds2\n"
                                   "135 -> FreezeAccount\n"
                                   "136 -> GetResolutionTime\n"
                                   "137 -> GetQueueLoad\n"
                                   "138 -> DeFreezeAccount\n"
                                   "139 -> GetMasterMsg\n"
                                   "140 -> GetPositionConv\n"
                                   "141 -> PublishAbsIsinHoldings\n"
                                   "142 -> GetOrderMargin2\n"
                                   "143 -> TradeEnhancementSubscribe\n"
                                   "144 -> TradeEnhancementUnSubscribe\n"
                                   "145 -> GetExternalRemarks\n"
                                   "146 -> GetOrderNumber\n"
                                   "147 -> PlaceTrailingOrder\n"
                                   "148 -> PlaceIceBergOrder\n"
                                   "149 -> ModifyIceBergOrder\n"
                                   "150 -> CancelIceBergOrder\n"
                                   "151 -> GetTrailingOrdersAcct\n"
                                   "152 -> GetIceBergOrdersAcct\n"
                                   "153 -> OrderAdminGroupSubscribe\n"
                                   "154 -> OrderAdminGroupUnSubscribe\n"
                                   "155 -> PositionAdminGroupSubscribe\n"
                                   "156 -> PositionAdminGroupUnSubscribe\n"
                                   "157 -> GetGroupPositionConv\n"
                                   "158 -> GetAllGroupOrders\n"  /*ND*/
                                   "159 -> AllGroupTradeHistory\n"
                                   "160 -> GetAllGroupPositions\n"
                                   "161 -> GetGroupId\n"
                                   "162 -> BlockUser\n"
                                   "163 -> CancelWithdrawFunds\n"
                                   "164 -> PayoutStatusVerify\n"
                                   "165 -> GetWithdrawFundsReport\n"
                                   "166 -> SqrOffEntity\n"
                                   "167 -> GetOrderNumberByGui\n"
                                   "168 -> EntityCancelOrder\n"
                                   "169 -> SetLogWriting\n"
                                   "170 -> GetAllAuctionSymbols\n"
                                   "171 -> OFSOrderAdminSubscribe\n"
                                   "172 -> OFSOrderAdminUnSubscribe\n"
                                   "173 -> OFSPlaceOrder\n"
                                   "174 -> OFSModifyOrder\n"
                                   "175 -> OFSCancelOrder\n"
                                   "176 -> OFSOrderHistory\n"
                                   "177 -> OFSOrderBook\n"
                                   "178 -> GetAllOfsOrders\n"
                                   "179 -> GetAllIpoOrders\n"
                                   "180 -> PauseEquitySipOrder\n"
                                   "181 -> ResumeEquitySipOrder\n"
                                   "182 -> DPRThresholdAlertSubscribe\n"
                                   "183 -> DPRThresholdAlertUnSubscribe\n"
                                   "184 -> GetMaxBlockAmt\n"
                                   "100 -> Logout\n"
                                   "0 -> Exit\n");
                    break;
                    case 0: bRun = false;
                    break;
                    case 2:
                    {
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         pNorenControl->OrderAdminSubscribe(ClientData, Product);
                    }
                    break;
                    case 3:
                    {
                         printf("Enter Trading Symbol\t");
                         memset(&TrdSymbl[0], 0, sizeof(TrdSymbl));
                         scanf("%s", TrdSymbl);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Transaction Type\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         /*printf("Enter Order Duration\t");
                              char OrdDuration[10];
                              scanf("%s", OrdDuration);
                              printf("Enter Customer Firm\t");
                              char CustFirm[10];
                              scanf("%s", CustFirm);*/
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();
                         printf("Enter PAN\t");
                         memset(&Pan[0], 0, sizeof(Pan));
                         scanf("%s", Pan);
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         getchar();
                         printf("Enter AlgoName\t");
                         memset(&acAlgoName[0], 0, sizeof(acAlgoName));
                         scanf(" %[^\n]", acAlgoName);
                         getchar();
                         printf("Enter Auction Number\t");
                         AuNum = 0;
                         scanf("%d", &AuNum);
                         printf("Enter Location Id\t");
                         int LocId = 0;
                         scanf("%d", &LocId);
                         char acAlgoId[10];
                         printf("Enter Algo Id\t");
                         memset(&acAlgoId[0], 0, sizeof(acAlgoId));
                         scanf(" %[^\n]", acAlgoId);
                         getchar();
                         printf("Enter Exchange user Id\t");
                         memset(&ExchUsrId[0], 0, sizeof(ExchUsrId));
                         scanf(" %[^\n]", ExchUsrId);
                         getchar();
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);

                         //place limit order
                         tsOrderParams oPlaceOrder;
                         oPlaceOrder.acTrdSymbol = TrdSymbl;
                         oPlaceOrder.acExchSeg = ExchSeg;
                         oPlaceOrder.acTransType = TransType;
                         oPlaceOrder.acOrderType = OrdType;
                         oPlaceOrder.acProduct = Product;
                         oPlaceOrder.acOrdDuration = (char*)"DAY";
                         oPlaceOrder.acAccountId = acAcct;
                         oPlaceOrder.acUser = acUser;
                         oPlaceOrder.acCustomerFirm = (char*)"C";
                         oPlaceOrder.lQuantity = Qty;
                         oPlaceOrder.lDiscQuantity = Qty;
                         oPlaceOrder.dPrice = Price;
                         oPlaceOrder.acPan = Pan;
                         oPlaceOrder.acOrdSrc = OrdSrc;
                         oPlaceOrder.acOrdRemarks = (char*)"Testing DS order from API";
                         oPlaceOrder.acGuiOrdId = GuiOrdId;
                         oPlaceOrder.acExternalRemarks = acExternalRemarks;
                         oPlaceOrder.acAlgoName = acAlgoName;
                         oPlaceOrder.iAuctionNumber = AuNum;
                         oPlaceOrder.iLocationId = LocId;
                         oPlaceOrder.acAlgoId = acAlgoId;
                         oPlaceOrder.acExchUsrId = ExchUsrId;
                         pNorenControl->PlaceOrder(ClientData, &oPlaceOrder, acUser);
                    }
                    break;
                    case 4:
                    {
                         printf("Enter Order Number\t");
                         memset(&OrdNum[0], 0, sizeof(OrdNum));
                         scanf("%s", OrdNum);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         /*printf("Enter Order Duration\t");
                              char OrdDuration[10];
                              scanf("%s", OrdDuration);*/
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         printf("Enter GuiOrgOrdId\t");
                         memset(&acGuiOrgOrdId[0], 0, sizeof(acGuiOrgOrdId));
                         scanf("%s", acGuiOrgOrdId);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);

                         //modify order
                         tsModOrderParams oModOder;
                         oModOder.acNorenOrdNum = OrdNum;
                         oModOder.acOrderType = OrdType;
                         oModOder.acOrdDuration = (char*)"DAY";
                         oModOder.lQuantity = Qty;
                         oModOder.dPrice = Price;
                         oModOder.acOrdSrc = OrdSrc;
                         oModOder.acGuiOrdId = GuiOrdId;
                         oModOder.acGuiOrgOrdId = acGuiOrgOrdId;
                         pNorenControl->ModifyOrder(ClientData, &oModOder, acUser);
                    }
                    break;
                    case 5:
                    {
                         printf("Enter Order Number\t");
                         memset(&OrdNum[0], 0, sizeof(OrdNum));
                         scanf("%s", OrdNum);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         printf("Enter GuiOrgOrdId\t");
                         memset(&acGuiOrgOrdId[0], 0, sizeof(acGuiOrgOrdId));
                         scanf("%s", acGuiOrgOrdId);
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         getchar();
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);

                         //cancel order
                         tsCanOrderParams oCanOder;
                         oCanOder.acNorenOrdNum = OrdNum;
                         oCanOder.acOrdSrc = OrdSrc;
                         oCanOder.acGuiOrdId = GuiOrdId;
                         oCanOder.acGuiOrgOrdId = acGuiOrgOrdId;
                         pNorenControl->CancelOrder(ClientData, &oCanOder, acUser);
                    }
                    break;
                    case 6: 
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->GetOrders(ClientData, acUser);
                    }
                    break;
                    case 7:
                    {
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         pNorenControl->GetOrdersAcct(ClientData, acAcct);
                    }
                    break;
                    case 8:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->TradeHistory(ClientData, acUser);
                    }
                     
                    break;
                    case 9:
                    {
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         pNorenControl->TradeHistoryAcct(ClientData, acAcct);

                    }  
                    break;
                    case 10: 
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->GetAllClients(ClientData, acUser);
                    }
                    break;
                    case 11: 
                    {
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->GetPositions(acAcct,
                                                  nullptr,
                                                  nullptr/*token*/,
                                                  nullptr,
                                                  ClientData,
                                                  acUser);
                    }
                    break;
                    case 12:
                    {
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->GetAllSymbols(ClientData,
                                                      ExchSeg,
                                                      acUser);
                    }
                    break;
                    case 13:
                    {
                         printf("Enter Trading Symbol\t");
                         memset(&TrdSymbl[0], 0, sizeof(TrdSymbl));
                         scanf("%s", TrdSymbl);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Transaction Type\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         /*printf("Enter Order Duration\t");
                              char OrdDuration[10];
                              scanf("%s", OrdDuration);
                              printf("Enter Customer Firm\t");
                              char CustFirm[10];
                              scanf("%s", CustFirm);*/
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();
                         printf("Enter Auction Number\t");
                         AuNum = 0;
                         scanf("%d", &AuNum);

                         printf("Enter Trading Symbol Leg2\t");
                         memset(&TrdSymbl2[0], 0, sizeof(TrdSymbl2));
                         scanf("%s", TrdSymbl2);
                         printf("Enter Transaction Type Leg2\t");
                         memset(&TransType2[0], 0, sizeof(TransType2));
                         scanf("%s", TransType2);
                         printf("Enter Quantity Leg2\t");
                         Qty2 = 0;
                         scanf("%ld", &Qty2);
                         printf("Enter Price Leg2\t");
                         Price2 = 0;
                         scanf("%lf", &Price2);
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         getchar();
                         printf("Enter AlgoName\t");
                         memset(&acAlgoName[0], 0, sizeof(acAlgoName));
                         scanf(" %[^\n]", acAlgoName);
                         getchar();
                         printf("Enter Exchange user Id\t");
                         memset(&ExchUsrId[0], 0, sizeof(ExchUsrId));
                         scanf(" %[^\n]", ExchUsrId);
                         getchar();
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         // 2L ORDER
                         /*** ORDER DURATION should be "IOC"   ***/
                         tsOrderParams o2LOrderParams;
                         tsMultiLegParams o2LMultiLegParams;

                         o2LOrderParams.acTrdSymbol = TrdSymbl;
                         o2LOrderParams.acExchSeg = ExchSeg;
                         o2LOrderParams.acTransType = TransType;
                         o2LOrderParams.acOrderType = OrdType;
                         o2LOrderParams.acProduct = Product;
                         o2LOrderParams.acOrdDuration = (char*)"IOC";
                         o2LOrderParams.acAccountId = acAcct;
                         o2LOrderParams.acUser = acUser;
                         o2LOrderParams.acCustomerFirm = (char*)"C";
                         o2LOrderParams.lQuantity = Qty;
                         o2LOrderParams.dPrice = Price;
                         o2LOrderParams.acOrdSrc = OrdSrc;
                         o2LOrderParams.acOrdRemarks = (char*)"Testing DS order from API";
                         o2LOrderParams.acGuiOrdId = GuiOrdId;
                         o2LOrderParams.acExternalRemarks = acExternalRemarks;
                         o2LOrderParams.acAlgoName = acAlgoName;
                         o2LOrderParams.iAuctionNumber = AuNum;
                         o2LOrderParams.acExchUsrId = ExchUsrId;

                         o2LMultiLegParams.acTrdSymbol_Leg2 = TrdSymbl2;
                         o2LMultiLegParams.acTransType_Leg2 = TransType2;
                         o2LMultiLegParams.lQuantity_Leg2 = Qty2;
                         o2LMultiLegParams.dPrice_Leg2 = Price2;

                         pNorenControl->PlaceMultiLegOrder(ClientData,
                                                           &o2LMultiLegParams,
                                                           &o2LOrderParams,
                                                           acUser);
                    }
                    break;
                    case 14: 
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->GetGroupSettings(ClientData, acUser);
                    }
                    break;
                    case 15:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         /*int MWsize = 3;
                              char** pMWGroups = new char*[MWsize];*/
                         pMWGroups[0] = (char*)"{\"NSE Cash\":[\"NSE|22\",\"NSE|10\"]}";
                         pMWGroups[1] = (char*)"{\"BSE\":[\"BSE|500410\",\"BSE|500440\"]}";
                         pMWGroups[2] = (char*)"{\"Derivatives\":[\"NFO|42620\",\"NFO|56058\"]}";

                         pNorenControl->SetGroupSettings(ClientData,
                                                         MWsize,
                                                         pMWGroups,
                                                         acUser);
                         delete[] pMWGroups;
                    }
                    break;
                    case 16:
                    {
                         printf("Enter UserId\t");
                         memset(&acUid[0], 0, sizeof(acUid));
                         scanf("%s", acUid);
                         printf("Enter Password\t");
                         memset(&acPwd[0], 0, sizeof(acPwd));
                         scanf("%s", acPwd);
                         pNorenControl->ValidateUidPwd(ClientData, acPwd, acUid);
                    }
                    break;
                    case 17:
                    {
                         printf("Enter Order Number\t");
                         memset(&OrdNum[0], 0, sizeof(OrdNum));
                         scanf("%s", OrdNum);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->ExitCoverOrder(ClientData,
                                                       OrdNum,
                                                       acUser);
                    }
                    break;
                    case 18:
                    {
                         printf("Enter Order Number\t");
                         memset(&OrdNum[0], 0, sizeof(OrdNum));
                         scanf("%s", OrdNum);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->ExitBracketOrder(ClientData,
                                                         OrdNum,
                                                         acUser);
                    }
                    break;
                    case 19:
                    {
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->Subscribe(ExchSeg,
                                                  Token,
                                                  ClientData,
                                                  acUser);
                    }
                    break;
                    case 20:
                    {
                         printf("Enter Trading Symbol\t");
                         memset(&TrdSymbl[0], 0, sizeof(TrdSymbl));
                         scanf("%s", TrdSymbl);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Old Product\t");
                         char OProduct[10];
                         scanf("%s", OProduct);
                         printf("Enter New Product\t");
                         char NProduct[10];
                         scanf("%s", NProduct);
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AccountID\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);

                         tsPartialPosConvParams oPosConvParams{};

                         oPosConvParams.acAccountId = acAcct;
                         oPosConvParams.acTrdSymbol = TrdSymbl;
                         oPosConvParams.acExchSeg = ExchSeg;
                         oPosConvParams.acOldProduct = OProduct;
                         oPosConvParams.acNewProduct = NProduct;
                         oPosConvParams.lQuanToFill = Qty;
                         oPosConvParams.iMsgFlag = 1;//1 -> Buy and Day,2->Buy and CF,3->Sell and Day,4->Sell and CF
                         oPosConvParams.acOrderSrc = OrdSrc;
                         oPosConvParams.acSrcUserId = acUser;
                         pNorenControl->PartialPosConv(ClientData,
                                                       &oPosConvParams,
                                                       acUser);
                    }
                    break;
                    case 21:
                    {
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter Segment\t");
                         pSegment = nullptr;
                         memset(&Segment[0], 0, sizeof(Segment));
                         scanf("%s", Segment);
                         if(strcmp(Segment,(char*)"NULL") != 0)
                         {
                              pSegment = Segment;
                         }
                         printf("Enter Exchange Segment\t");
                         pExchSegment = nullptr;
                         memset(&ExchSegment[0], 0, sizeof(ExchSegment));
                         scanf("%s", ExchSegment);
                         if(strcmp(ExchSegment,(char*)"NULL") != 0)
                         {
                              pExchSegment = ExchSegment;
                         }
                         printf("Enter Product\t");
                         pProduct = nullptr;
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         if(strcmp(Product,(char*)"NULL") != 0)
                         {
                              pProduct = Product;
                         }
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->GetRmsLimits(BrokerId,
                                                     acAcct,
                                                     pSegment,
                                                     pExchSegment,
                                                     pProduct,
                                                     ClientData,
                                                     acUser);
                    }
                    break;
                    case 22:
                    {
                         printf("Enter Trading Symbol\t");
                         memset(&TrdSymbl[0], 0, sizeof(TrdSymbl));
                         scanf("%s", TrdSymbl);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Transaction Type\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         /*printf("Enter Order Duration\t");
                              char OrdDuration[10];
                              scanf("%s", OrdDuration);
                              printf("Enter Customer Firm\t");
                              char CustFirm[10];
                              scanf("%s", CustFirm);*/
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();
                         printf("Enter PAN\t");
                         memset(&Pan[0], 0, sizeof(Pan));
                         scanf("%s", Pan);
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         getchar();
                         printf("Enter AlgoName\t");
                         memset(&acAlgoName[0], 0, sizeof(acAlgoName));
                         scanf(" %[^\n]", acAlgoName);
                         getchar();
                         printf("Enter Auction Number\t");
                         AuNum = 0;
                         scanf("%d", &AuNum);
                         printf("Enter Exchange user Id\t");
                         memset(&ExchUsrId[0], 0, sizeof(ExchUsrId));
                         scanf(" %[^\n]", ExchUsrId);
                         getchar();
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         //place limit order
                         tsOrderParams oPlaceOrder;
                         oPlaceOrder.acTrdSymbol = TrdSymbl;
                         oPlaceOrder.acExchSeg = ExchSeg;
                         oPlaceOrder.acTransType = TransType;
                         oPlaceOrder.acOrderType = OrdType;
                         oPlaceOrder.acProduct = Product;
                         oPlaceOrder.acOrdDuration = (char*)"DAY";
                         oPlaceOrder.acAccountId = acAcct;
                         oPlaceOrder.acUser = acUser;
                         oPlaceOrder.acCustomerFirm = (char*)"C";
                         oPlaceOrder.lQuantity = Qty;
                         oPlaceOrder.lDiscQuantity = Qty;
                         oPlaceOrder.dPrice = Price;
                         oPlaceOrder.acPan = Pan;
                         oPlaceOrder.acOrdSrc = OrdSrc;
                         oPlaceOrder.acOrdRemarks = (char*)"Testing DS order from API";
                         oPlaceOrder.acGuiOrdId = GuiOrdId;
                         oPlaceOrder.acExternalRemarks = acExternalRemarks;
                         oPlaceOrder.acAlgoName = acAlgoName;
                         oPlaceOrder.iAuctionNumber = AuNum;
                         oPlaceOrder.acExchUsrId = ExchUsrId;
                         pNorenControl->PlaceAfterMktOrder(ClientData, &oPlaceOrder, acUser);
                    }
                    break;
                    case 23:
                    {
                         printf("Enter Order Number\t");
                         memset(&OrdNum[0], 0, sizeof(OrdNum));
                         scanf("%s", OrdNum);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         /*printf("Enter Order Duration\t");
                              char OrdDuration[10];
                              scanf("%s", OrdDuration);*/
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         printf("Enter GuiOrgOrdId\t");
                         memset(&acGuiOrgOrdId[0], 0, sizeof(acGuiOrgOrdId));
                         scanf("%s", acGuiOrgOrdId);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);

                         //modify order
                         tsModOrderParams oModOder;
                         oModOder.acNorenOrdNum = OrdNum;
                         oModOder.acOrderType = OrdType;
                         oModOder.acOrdDuration = (char*)"DAY";
                         oModOder.lQuantity = Qty;
                         oModOder.dPrice = Price;
                         oModOder.acOrdSrc = OrdSrc;
                         oModOder.acGuiOrdId = GuiOrdId;
                         oModOder.acGuiOrgOrdId = acGuiOrgOrdId;
                         pNorenControl->AfterMktModifyOrder(ClientData, &oModOder, acUser);
                    }
                    break;
                    case 24:
                    {
                         printf("Enter Trading Symbol\t");
                         memset(&TrdSymbl[0], 0, sizeof(TrdSymbl));
                         scanf("%s", TrdSymbl);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Transaction Type\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         /*printf("Enter Order Duration\t");
                              char OrdDuration[10];
                              scanf("%s", OrdDuration);
                              printf("Enter Customer Firm\t");
                              char CustFirm[10];
                              scanf("%s", CustFirm);*/
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();
                         printf("Enter Trading Symbol Leg2\t");
                         memset(&TrdSymbl2[0], 0, sizeof(TrdSymbl2));
                         scanf("%s", TrdSymbl2);
                         printf("Enter Transaction Type Leg2\t");
                         memset(&TransType2[0], 0, sizeof(TransType2));
                         scanf("%s", TransType2);
                         printf("Enter Quantity Leg2\t");
                         Qty2 = 0;
                         scanf("%ld", &Qty2);
                         printf("Enter Price Leg2\t");
                         Price2 = 0;
                         scanf("%lf", &Price2);
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         getchar();
                         printf("Enter AlgoName\t");
                         memset(&acAlgoName[0], 0, sizeof(acAlgoName));
                         scanf(" %[^\n]", acAlgoName);
                         getchar();
                         printf("Enter Auction Number\t");
                         AuNum = 0;
                         scanf("%d", &AuNum);
                         printf("Enter Exchange user Id\t");
                         memset(&ExchUsrId[0], 0, sizeof(ExchUsrId));
                         scanf(" %[^\n]", ExchUsrId);
                         getchar();
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         // 2L ORDER
                         /*** ORDER DURATION should be "IOC"   ***/
                         tsOrderParams o2LOrderParams;
                         tsMultiLegParams o2LMultiLegParams;

                         o2LOrderParams.acTrdSymbol = TrdSymbl;
                         o2LOrderParams.acExchSeg = ExchSeg;
                         o2LOrderParams.acTransType = TransType;
                         o2LOrderParams.acOrderType = OrdType;
                         o2LOrderParams.acProduct = Product;
                         o2LOrderParams.acOrdDuration = (char*)"IOC";
                         o2LOrderParams.acAccountId = acAcct;
                         o2LOrderParams.acUser = acUser;
                         o2LOrderParams.acCustomerFirm = (char*)"C";
                         o2LOrderParams.lQuantity = Qty;
                         o2LOrderParams.dPrice = Price;
                         o2LOrderParams.acOrdSrc = OrdSrc;
                         o2LOrderParams.acOrdRemarks = (char*)"Testing DS order from API";
                         o2LOrderParams.acGuiOrdId = GuiOrdId;
                         o2LOrderParams.acExternalRemarks = acExternalRemarks;
                         o2LOrderParams.acAlgoName = acAlgoName;
                         o2LOrderParams.iAuctionNumber = AuNum;
                         o2LOrderParams.acExchUsrId = ExchUsrId;

                         o2LMultiLegParams.acTrdSymbol_Leg2 = TrdSymbl2;
                         o2LMultiLegParams.acTransType_Leg2 = TransType2;
                         o2LMultiLegParams.lQuantity_Leg2 = Qty2;
                         o2LMultiLegParams.dPrice_Leg2 = Price2;

                         pNorenControl->PlaceAfterMktMultiLegOrder(ClientData,
                                                                   &o2LMultiLegParams,
                                                                   &o2LOrderParams,
                                                                   acUser);
                    }
                    break;
                    case 25:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         pNorenControl->GetIndexNames(ExchSeg,
                                                      ClientData,
                                                      acUser);
                    }
                    break;
                    case 26:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->GetProductList(ClientData,
                                                           acUser);
                    } 
                    break;
                    case 27: 
                    {
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->GetUserProfile(acAcct,
                                                       ClientData,
                                                       acUser);
                    }
                    break;
                    case 28:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         pNorenControl->SecurityInfo(Token,
                                                     ExchSeg,
                                                     ClientData,
                                                     acUser);
                    }
                    break;
                    case 29:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Order Number\t");
                         memset(&OrdNum[0], 0, sizeof(OrdNum));
                         scanf("%s", OrdNum);
                         pNorenControl->OrderHistory(ClientData,
                                                     OrdNum,
                                                     acUser);
                    }
                    break;
                    case 30:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         pNorenControl->ViewHoldings(ClientData,
                                                     acAcct,
                                                     Product,
                                                     acUser);
                    }
                    break;
                    case 31:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         pNorenControl->GetTopnKeys(ClientData,
                                                    ExchSeg,
                                                    acUser);
                    }
                    break;
                    case 32:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter TopnCriteria\t");
                         char TopnCriteria[10];
                         scanf("%s", TopnCriteria);
                         printf("Enter TopnBasket\t");
                         char TopnBasket[10];
                         scanf("%s", TopnBasket);
                         pNorenControl->GetTopnValues(ClientData,
                                                      ExchSeg,
                                                      TopnCriteria,
                                                      TopnBasket,
                                                      acUser);
                    }
                    break;
                    case 33:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Periodicity\t");
                         memset(&Periodicity[0], 0, sizeof(Periodicity));
                         scanf("%s", Periodicity);
                         printf("Enter StartTime\t");
                         long StartTime;
                         scanf("%ld", &StartTime);
                         printf("Enter EndTime\t");
                         long EndTime;
                         scanf("%ld", &EndTime);
                         pNorenControl->GetAllVwapData(ClientData,
                                                       ExchSeg,
                                                       Token,
                                                       Periodicity,
                                                       StartTime,
                                                       EndTime,
                                                       acUser);
                    }
                    break;
                    case 34:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         pNorenControl->GetScripDetails(ExchSeg,
                                                        Token,
                                                        ClientData,
                                                        acUser);
                    }
                    break;
                    case 35:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         pNorenControl->GetMarketStatus(ClientData,
                                                        ExchSeg,
                                                        acUser);
                    }
                    break;
                    case 36:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         pNorenControl->GetExchangeMessages(ClientData,
                                                            ExchSeg,
                                                            acUser);
                    }
                    break;
                    case 37:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Transaction Reference number\t");
                         long RefNum;
                         scanf("%ld", &RefNum);
                         printf("Enter Amount\t");
                         Amt = 0;
                         scanf("%lf", &Amt);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter Remarks\t");
                         char* pRemarks;
                         char Remarks[10];
                         scanf("%s", Remarks);
                         if(strcmp(Remarks,(char*)"NULL") != 0)
                         {
                              pRemarks = Remarks;
                         }
                         printf("Enter Bank Name\t");
                         char* pBnkNme;
                         char BnkNme[10];
                         scanf("%s", BnkNme);
                         if(strcmp(BnkNme,(char*)"NULL") != 0)
                         {
                              pBnkNme = BnkNme;
                         }
                         printf("Enter Segment\t");
                         pSegment = nullptr;
                         memset(&Segment[0], 0, sizeof(Segment));
                         scanf("%s", Segment);
                         if(strcmp(Segment,(char*)"NULL") != 0)
                         {
                              pSegment = Segment;
                         }
                         printf("Enter Exchange Segment\t");
                         pExchSegment = nullptr;
                         memset(&ExchSegment[0], 0, sizeof(ExchSegment));
                         scanf("%s", ExchSegment);
                         if(strcmp(ExchSegment,(char*)"NULL") != 0)
                         {
                              pExchSegment = ExchSegment;
                         }
                         printf("Enter Product\t");
                         pProduct = nullptr;
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         if(strcmp(Product,(char*)"NULL") != 0)
                         {
                              pProduct = Product;
                         }
                         pNorenControl->AddFunds(ClientData,
                                                 acAcct,
                                                 RefNum,
                                                 acUser,
                                                 Amt,
                                                 BrokerId,
                                                 pRemarks,
                                                 pBnkNme,
                                                 pSegment,
                                                 pExchSegment,
                                                 pProduct);
                    }
                    break;
                    case 38:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Amount\t");
                         Amt = 0;
                         scanf("%lf", &Amt);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter Segment\t");
                         pSegment = nullptr;
                         memset(&Segment[0], 0, sizeof(Segment));
                         scanf("%s", Segment);
                         if(strcmp(Segment,(char*)"NULL") != 0)
                         {
                              pSegment = Segment;
                         }
                         printf("Enter Exchange Segment\t");
                         pExchSegment = nullptr;
                         memset(&ExchSegment[0], 0, sizeof(ExchSegment));
                         scanf("%s", ExchSegment);
                         if(strcmp(ExchSegment,(char*)"NULL") != 0)
                         {
                              pExchSegment = ExchSegment;
                         }
                         printf("Enter Product\t");
                         pProduct = nullptr;
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         if(strcmp(Product,(char*)"NULL") != 0)
                         {
                              pProduct = Product;
                         }

                         pNorenControl->WithdrawFunds(ClientData,
                                                      acAcct,
                                                      acUser,
                                                      BrokerId,
                                                      Amt,
                                                      pSegment,
                                                      pExchSegment,
                                                      pProduct);
                    }
                    break;
                    case 39:
                    {
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter Segment\t");
                         pSegment = nullptr;
                         memset(&Segment[0], 0, sizeof(Segment));
                         scanf("%s", Segment);
                         if(strcmp(Segment,(char*)"NULL") != 0)
                         {
                              pSegment = Segment;
                         }
                         printf("Enter Exchange Segment\t");
                         pExchSegment = nullptr;
                         memset(&ExchSegment[0], 0, sizeof(ExchSegment));
                         scanf("%s", ExchSegment);
                         if(strcmp(ExchSegment,(char*)"NULL") != 0)
                         {
                              pExchSegment = ExchSegment;
                         }
                         printf("Enter Product\t");
                         pProduct = nullptr;
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         if(strcmp(Product,(char*)"NULL") != 0)
                         {
                              pProduct = Product;
                         }
                         pNorenControl->GetWithdrawalAmt(ClientData,
                                                         BrokerId,
                                                         acAcct,
                                                         pSegment,
                                                         pExchSegment,
                                                         pProduct);
                    }
                    break;
                    case 40:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         pNorenControl->IpoList(ClientData,
                                                BrokerId,
                                                acUser);
                    }
                    break;
                    case 41:
                    {
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         pNorenControl->IpoOrderAdminSubscribe(ClientData,
                                                               Product);
                    }
                    break;
                    case 42:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Trading Symbol\t");
                         memset(&TrdSymbl[0], 0, sizeof(TrdSymbl));
                         scanf("%s", TrdSymbl);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Transaction Type\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         /*printf("Enter Order Duration\t");
                              char OrdDuration[10];
                              scanf("%s", OrdDuration);
                              printf("Enter Customer Firm\t");
                              char CustFirm[10];
                              scanf("%s", CustFirm);*/
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         getchar();
                         printf("Enter AlgoName\t");
                         memset(&acAlgoName[0], 0, sizeof(acAlgoName));
                         scanf(" %[^\n]", acAlgoName);
                         getchar();

                         //place Ipo order
                         tsIpoPlaceOrderParams oPlaceIpoOrder;
                         oPlaceIpoOrder.acTrdSymbol = TrdSymbl;
                         oPlaceIpoOrder.acExchSeg = ExchSeg;
                         oPlaceIpoOrder.acTransType = TransType;
                         oPlaceIpoOrder.acOrderType = OrdType;
                         oPlaceIpoOrder.acProduct = Product;
                         oPlaceIpoOrder.acOrdDuration = (char*)"DAY";
                         oPlaceIpoOrder.acAccountId = acAcct;
                         oPlaceIpoOrder.acUser = acUser;
                         oPlaceIpoOrder.acOrdSrc = OrdSrc;
                         oPlaceIpoOrder.acCustomerFirm = (char*)"C";
                         oPlaceIpoOrder.lQuantity = Qty;
                         oPlaceIpoOrder.lDiscQuantity = Qty;
                         oPlaceIpoOrder.dPrice = Price;
                         oPlaceIpoOrder.acParticId = (char*)"1208160001951923";
                         oPlaceIpoOrder.iOrdLeg = 1;
                         oPlaceIpoOrder.acPurchaseType = (char*)"RETAIL";
                         oPlaceIpoOrder.acEuin = (char*)"@upi";
                         oPlaceIpoOrder.acIpAddr = (char*)"IP";
                         oPlaceIpoOrder.acOrderRemarks = (char*)"Testing DS order from API";
                         oPlaceIpoOrder.acExternalRemarks = acExternalRemarks;
                         oPlaceIpoOrder.acAlgoName = acAlgoName;
                         pNorenControl->IpoPlaceOrder(ClientData, &oPlaceIpoOrder, acUser);
                    }
                    break;
                    case 43:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Order Number\t");
                         memset(&OrdNum[0], 0, sizeof(OrdNum));
                         scanf("%s", OrdNum);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();

                         //modify ipo order
                         tsIpoModOrderParams oModIpoOder;
                         oModIpoOder.acNorenOrdNum = OrdNum;
                         oModIpoOder.acOrderRemarks = (char*)"Testing DS order from API";
                         oModIpoOder.acUser = acUser;
                         oModIpoOder.acOrdSrc = OrdSrc;
                         oModIpoOder.acOrderType = OrdType;
                         oModIpoOder.acOrdDuration = (char*)"DAY";
                         oModIpoOder.lQuantity = Qty;
                         oModIpoOder.dPrice = Price;
                         pNorenControl->IpoModifyOrder(ClientData, &oModIpoOder, acUser);
                    }
                    break;
                    case 44:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Order Number\t");
                         memset(&OrdNum[0], 0, sizeof(OrdNum));
                         scanf("%s", OrdNum);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();

                         //cancel ipo order
                         tsIpoCanOrderParams oCanIpoOder;
                         oCanIpoOder.acNorenOrdNum = OrdNum;
                         oCanIpoOder.acOrderRemarks = (char*)"Testing DS order from API";
                         oCanIpoOder.acUser = acUser;
                         oCanIpoOder.acOrdSrc = OrdSrc;
                         oCanIpoOder.acOrderType = OrdType;
                         oCanIpoOder.acOrdDuration = (char*)"DAY";
                         pNorenControl->IpoCancelOrder(ClientData,&oCanIpoOder,acUser);
                    }
                    break;
                    case 45:
                    {
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         pNorenControl->IpoOrderBook(ClientData,acAcct);
                    }  
                    break;
                    case 46:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Trading Symbol\t");
                         memset(&TrdSymbl[0], 0, sizeof(TrdSymbl));
                         scanf("%s", TrdSymbl);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Transaction Type\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         /*printf("Enter Order Duration\t");
                              char OrdDuration[10];
                              scanf("%s", OrdDuration);
                              printf("Enter Customer Firm\t");
                              char CustFirm[10];
                              scanf("%s", CustFirm);*/
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         getchar();
                         printf("Enter AlgoName\t");
                         memset(&acAlgoName[0], 0, sizeof(acAlgoName));
                         scanf(" %[^\n]", acAlgoName);
                         getchar();

                         //place mf order
                         tsMfPlaceOrderParams oPlaceMfOrder;
                         oPlaceMfOrder.acTrdSymbol = TrdSymbl;
                         oPlaceMfOrder.acExchSeg = ExchSeg;
                         oPlaceMfOrder.acTransType = TransType;
                         oPlaceMfOrder.acOrderType = OrdType;
                         oPlaceMfOrder.acProduct = Product;
                         oPlaceMfOrder.acOrdDuration = (char*)"DAY";
                         oPlaceMfOrder.acAccountId = acAcct;
                         oPlaceMfOrder.acUser = acUser;
                         oPlaceMfOrder.acOrdSrc = OrdSrc;
                         oPlaceMfOrder.acCustomerFirm = (char*)"C";
                         oPlaceMfOrder.lQuantity = Qty;
                         oPlaceMfOrder.lDiscQuantity = Qty;
                         oPlaceMfOrder.dPrice = Price;
                         oPlaceMfOrder.acOrderRemarks = (char*)"Testing DS order from API";
                         oPlaceMfOrder.acPurchaseType = (char*)"FRESH";
                         oPlaceMfOrder.acExternalRemarks = acExternalRemarks;
                         oPlaceMfOrder.acAlgoName = acAlgoName;
                         pNorenControl->MfPlaceOrder(ClientData, &oPlaceMfOrder, acUser);
                    }
                    break;
                    case 47:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Order Number\t");
                         memset(&OrdNum[0], 0, sizeof(OrdNum));
                         scanf("%s", OrdNum);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();

                         //modify mf order
                         tsMfModOrderParams oModMfOder;
                         oModMfOder.acNorenOrdNum = OrdNum;
                         oModMfOder.acOrderRemarks = (char*)"Testing DS order from API";
                         oModMfOder.acUser = acUser;
                         oModMfOder.acOrdSrc = OrdSrc;
                         oModMfOder.acOrderType = OrdType;
                         oModMfOder.acOrdDuration = (char*)"DAY";
                         oModMfOder.lQuantity = Qty;
                         oModMfOder.dPrice = Price;
                         pNorenControl->MfModifyOrder(ClientData, &oModMfOder, acUser);
                    }
                    break;
                    case 48:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Order Number\t");
                         memset(&OrdNum[0], 0, sizeof(OrdNum));
                         scanf("%s", OrdNum);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         getchar();

                         tsMfCanOrderParams oCanMfOder;
                         oCanMfOder.acNorenOrdNum = OrdNum;
                         oCanMfOder.acUser = acUser;
                         oCanMfOder.acGuiOrdId = GuiOrdId;
                         oCanMfOder.acExternalRemarks = acExternalRemarks;
                         oCanMfOder.acOrdSrc = OrdSrc;

                         //cancel mf order
                         pNorenControl->MfCancelOrder(ClientData,&oCanMfOder,acUser);
                    }
                    break;
                    case 49:
                    {
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         pNorenControl->MfOrderBook(ClientData,acAcct);
                    }  
                    break;
                    case 50:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter Quantity\t");
                         double dQty;
                         scanf("%lf", &dQty);
                         printf("Enter Collateral Quantity\t");
                         double dColQty;
                         scanf("%lf", &dColQty);
                         printf("Enter Brk Collateral Quantity\t");
                         double dBrkColQty;
                         scanf("%lf", &dBrkColQty);
                         printf("Enter DP Hold Quantity\t");
                         double dDpQty;
                         scanf("%lf", &dDpQty);
                         printf("Enter Benf Hold Quantity\t");
                         double dBenfQty;
                         scanf("%lf", &dBenfQty);
                         printf("Enter UNplgd Hold Quantity\t");
                         double dUnplgdQty;
                         scanf("%lf", &dUnplgdQty);

                         printf("Enter Collateral Mode\t");
                         int iCollateralMode;
                         scanf("%d", &iCollateralMode);
                         printf("Enter HairCut\t");
                         double dHairCut;
                         scanf("%lf", &dHairCut);
                         printf("Enter Close Price\t");
                         double dClosePrice;
                         scanf("%lf", &dClosePrice);
                         printf("Enter Broker Haircut\t");
                         double dBrokerHairCut;
                         scanf("%lf", &dBrokerHairCut);
                         printf("Enter Upload Price\t");
                         double dUploadPrice;
                         scanf("%lf", &dUploadPrice);
                         printf("Enter IsCollateral (true|false)\t");
                         char Collateral[10];
                         bool bIsCollateral = false;
                         scanf("%s", Collateral);
                         if(strcmp(Collateral,(char*)"true") == 0)
                              bIsCollateral = true;
                         
                         printf("Enter acInterOP Key\t");
                         memset(&InterOPKey[0], 0, sizeof(InterOPKey));
                         scanf("%s", InterOPKey);
                         printf("Enter acInterOP ExchSeg\t");
                         memset(&InterOPExchSeg[0], 0, sizeof(InterOPExchSeg));
                         scanf("%s", InterOPExchSeg);

                         tsAddHoldings oAddHold;
                         oAddHold.acAccountId = acAcct;
                         oAddHold.acProduct = Product;
                         oAddHold.iExchSegSize = 1;
                         oAddHold.ppExchSeg = new char*[oAddHold.iExchSegSize];
                         oAddHold.ppExchSeg[0] = ExchSeg;
                         oAddHold.iTokenSize = 1;
                         oAddHold.ppToken = new char*[oAddHold.iTokenSize];
                         oAddHold.ppToken[0] = Token;
                         oAddHold.acUserId = acUser;
                         oAddHold.acBrokerId = BrokerId;
                         oAddHold.dQuantity = dQty;
                         oAddHold.dCollateralQty = dColQty;
                         oAddHold.dBrokerCollateralQty = dBrkColQty;
                         oAddHold.dDpHoldQty = dDpQty;
                         oAddHold.dBenfHoldQty = dBenfQty;
                         oAddHold.dUnplgdHoldQty = dUnplgdQty;
                         oAddHold.iCollateralMode = iCollateralMode;
                         oAddHold.dHairCut = dHairCut;
                         oAddHold.dClosePrice = dClosePrice;
                         oAddHold.dBrokerHairCut = dBrokerHairCut;
                         oAddHold.dUploadPrice = dUploadPrice;
                         oAddHold.bIsCollateral = bIsCollateral;
                         oAddHold.acInterOPKey = InterOPKey;
                         oAddHold.acInterOPExchSeg = InterOPExchSeg;
      
                         pNorenControl->AddHoldings(ClientData, &oAddHold);
                    }
                    break;
                    case 51:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Trading Symbol\t");
                         memset(&TrdSymbl[0], 0, sizeof(TrdSymbl));
                         scanf("%s", TrdSymbl);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Transaction Type\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();
                         printf("Enter PAN\t");
                         memset(&Pan[0], 0, sizeof(Pan));
                         scanf("%s", Pan);
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter Al Name\t");
                         memset(&AlName[0], 0, sizeof(AlName));
                         scanf("%s", AlName);
                         printf("Enter GTT variable name\t");
                         memset(&GTTVarName[0], 0, sizeof(GTTVarName));
                         scanf("%s", GTTVarName);
                         printf("Enter GTT variable value\t");
                         GTTVarVal = 0;
                         scanf("%ld", &GTTVarVal);
                         printf("Enter GTT validity\t");
                         memset(&GTTValidity[0], 0, sizeof(GTTValidity));
                         scanf("%s", GTTValidity);
                         printf("Enter GTT Remarks\t");
                         memset(&GTTRemarks[0], 0, sizeof(GTTRemarks));
                         scanf(" %[^\n]", GTTRemarks);
                         getchar();
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         getchar();
                         printf("Enter AlgoName\t");
                         memset(&acAlgoName[0], 0, sizeof(acAlgoName));
                         scanf(" %[^\n]", acAlgoName);
                         getchar();
                         printf("Enter Exchange user Id\t");
                         memset(&ExchUsrId[0], 0, sizeof(ExchUsrId));
                         scanf(" %[^\n]", ExchUsrId);
                         getchar();

                         //place GTT order
                         tsGTTParams oGTTParams;
                         oGTTParams.acAlName = AlName;
                         oGTTParams.acExchSeg = ExchSeg;
                         oGTTParams.acToken = Token;
                         oGTTParams.acVariableName = GTTVarName;
                         oGTTParams.lVariableValue = GTTVarVal;
                         oGTTParams.acValidity = GTTValidity;
                         oGTTParams.acRemarksText = GTTRemarks;
                         oGTTParams.acTrdSymbol = TrdSymbl;
                         oGTTParams.iMultiplier = 1;
                         oGTTParams.iPrecision = 2;
                         oGTTParams.acSrcUserId = acUser;
                         oGTTParams.acSrcBrokerId = BrokerId;

                         oGTTParams.sOrderParams.acTrdSymbol = TrdSymbl;
                         oGTTParams.sOrderParams.acExchSeg = ExchSeg;
                         oGTTParams.sOrderParams.acTransType = TransType;
                         oGTTParams.sOrderParams.acOrderType = OrdType;
                         oGTTParams.sOrderParams.acProduct = Product;
                         oGTTParams.sOrderParams.acOrdDuration = (char*)"DAY";
                         oGTTParams.sOrderParams.acAccountId = acAcct;
                         oGTTParams.sOrderParams.acUser = acUser;
                         oGTTParams.sOrderParams.acCustomerFirm = (char*)"C";
                         oGTTParams.sOrderParams.lQuantity = Qty;
                         oGTTParams.sOrderParams.lDiscQuantity = Qty;
                         oGTTParams.sOrderParams.dPrice = Price;
                         oGTTParams.sOrderParams.acPan = Pan;
                         oGTTParams.sOrderParams.acOrdSrc = OrdSrc;
                         oGTTParams.sOrderParams.acOrdRemarks = (char*)"Testing DS order from API";
                         oGTTParams.sOrderParams.acGuiOrdId = GuiOrdId;
                         oGTTParams.sOrderParams.acExternalRemarks = acExternalRemarks;
                         oGTTParams.sOrderParams.acAlgoName = acAlgoName;
                         oGTTParams.sOrderParams.acExchUsrId = ExchUsrId;
                         pNorenControl->PlaceGTT(ClientData, &oGTTParams, acUser);
                    }
                    break;
                    case 52:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Trading Symbol\t");
                         memset(&TrdSymbl[0], 0, sizeof(TrdSymbl));
                         scanf("%s", TrdSymbl);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Transaction Type\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();
                         printf("Enter PAN\t");
                         memset(&Pan[0], 0, sizeof(Pan));
                         scanf("%s", Pan);
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter Al Name\t");
                         memset(&AlName[0], 0, sizeof(AlName));
                         scanf("%s", AlName);
                         printf("Enter GTT variable name\t");
                         memset(&GTTVarName[0], 0, sizeof(GTTVarName));
                         scanf("%s", GTTVarName);
                         printf("Enter GTT variable value\t");
                         GTTVarVal = 0;
                         scanf("%ld", &GTTVarVal);
                         printf("Enter GTT validity\t");
                         memset(&GTTValidity[0], 0, sizeof(GTTValidity));
                         scanf("%s", GTTValidity);
                         printf("Enter GTT Remarks\t");
                         memset(&GTTRemarks[0], 0, sizeof(GTTRemarks));
                         scanf(" %[^\n]", GTTRemarks);
                         getchar();
                         printf("Enter GTT Id\t");
                         memset(&GTTId[0], 0, sizeof(GTTId));
                         scanf("%s", GTTId);
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         getchar();
                         printf("Enter AlgoName\t");
                         memset(&acAlgoName[0], 0, sizeof(acAlgoName));
                         scanf(" %[^\n]", acAlgoName);
                         getchar();

                         //replace GTT order
                         tsGTTParams oGTTParams;
                         oGTTParams.acAlName = AlName;
                         oGTTParams.acExchSeg = ExchSeg;
                         oGTTParams.acToken = Token;
                         oGTTParams.acVariableName = GTTVarName;
                         oGTTParams.lVariableValue = GTTVarVal;
                         oGTTParams.acValidity = GTTValidity;
                         oGTTParams.acRemarksText = GTTRemarks;
                         oGTTParams.acTrdSymbol = TrdSymbl;
                         oGTTParams.iMultiplier = 1;
                         oGTTParams.iPrecision = 2;
                         oGTTParams.acSrcUserId = acUser;
                         oGTTParams.acSrcBrokerId = BrokerId;
                         oGTTParams.acGTTid = GTTId;

                         oGTTParams.sOrderParams.acTrdSymbol = TrdSymbl;
                         oGTTParams.sOrderParams.acExchSeg = ExchSeg;
                         oGTTParams.sOrderParams.acTransType = TransType;
                         oGTTParams.sOrderParams.acOrderType = OrdType;
                         oGTTParams.sOrderParams.acProduct = Product;
                         oGTTParams.sOrderParams.acOrdDuration = (char*)"DAY";
                         oGTTParams.sOrderParams.acAccountId = acAcct;
                         oGTTParams.sOrderParams.acUser = acUser;
                         oGTTParams.sOrderParams.acCustomerFirm = (char*)"C";
                         oGTTParams.sOrderParams.lQuantity = Qty;
                         oGTTParams.sOrderParams.lDiscQuantity = Qty;
                         oGTTParams.sOrderParams.dPrice = Price;
                         oGTTParams.sOrderParams.acPan = Pan;
                         oGTTParams.sOrderParams.acOrdSrc = OrdSrc;
                         oGTTParams.sOrderParams.acOrdRemarks = (char*)"Testing DS order from API";
                         oGTTParams.sOrderParams.acGuiOrdId = GuiOrdId;
                         oGTTParams.sOrderParams.acExternalRemarks = acExternalRemarks;
                         oGTTParams.sOrderParams.acAlgoName = acAlgoName;
                         pNorenControl->ModifyGTT(ClientData, &oGTTParams, acUser);
                    }
                    break;
                    case 53:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter GTT Id\t");
                         memset(&GTTId[0], 0, sizeof(GTTId));
                         scanf("%s", GTTId);
                         //cancel GTT order
                         pNorenControl->CancelGTT(ClientData,GTTId,acUser);
                    }
                    break;
                    case 54:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter GTT Id\t");
                         memset(&GTTId[0], 0, sizeof(GTTId));
                         scanf("%s", GTTId);
                         //get GTT order
                         pNorenControl->GetGTTOrders(ClientData,GTTId,acUser);
                    }
                    break;
                    case 55:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Trading Symbol\t");
                         memset(&TrdSymbl[0], 0, sizeof(TrdSymbl));
                         scanf("%s", TrdSymbl);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Transaction Type Leg1\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Transaction Type Leg2\t");
                         memset(&TransType2[0], 0, sizeof(TransType2));
                         scanf("%s", TransType2);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Quantity Leg1\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price Leg1\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter Order Source for Leg1\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();
                         printf("Enter Quantity Leg2\t");
                         Qty2 = 0;
                         scanf("%ld", &Qty2);
                         printf("Enter Price Leg2\t");
                         Price2 = 0;
                         scanf("%lf", &Price2);
                         printf("Enter Order Source for Leg2\t");
                         memset(&OrdSrc2[0], 0, sizeof(OrdSrc2));
                         scanf(" %[^\n]", OrdSrc2);
                         getchar();
                         printf("Enter PAN\t");
                         memset(&Pan[0], 0, sizeof(Pan));
                         scanf("%s", Pan);
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter Al Name\t");
                         memset(&AlName[0], 0, sizeof(AlName));
                         scanf("%s", AlName);
                         printf("Enter OCO variable name Leg1\t");
                         memset(&GTTVarName[0], 0, sizeof(GTTVarName));
                         scanf("%s", GTTVarName);
                         printf("Enter OCO variable value Leg1\t");
                         GTTVarVal = 0;
                         scanf("%ld", &GTTVarVal);
                         printf("Enter OCO variable name Leg2\t");
                         memset(&GTTVarName2[0], 0, sizeof(GTTVarName2));
                         scanf("%s", GTTVarName2);
                         printf("Enter OCO variable value Leg2\t");
                         GTTVarVal2 = 0;
                         scanf("%ld", &GTTVarVal2);
                         printf("Enter OCO validity\t");
                         memset(&GTTValidity[0], 0, sizeof(GTTValidity));
                         scanf("%s", GTTValidity);
                         printf("Enter OCO Remarks\t");
                         memset(&GTTRemarks[0], 0, sizeof(GTTRemarks));
                         scanf(" %[^\n]", GTTRemarks);
                         getchar();
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         getchar();
                         printf("Enter AlgoName\t");
                         memset(&acAlgoName[0], 0, sizeof(acAlgoName));
                         scanf(" %[^\n]", acAlgoName);
                         getchar();

                         //place OCO order
                         tsOCOParams oOCOParams;
                         oOCOParams.acAlName = AlName;
                         oOCOParams.acExchSeg = ExchSeg;
                         oOCOParams.acToken = Token;
                         oOCOParams.acVariableNameLeg1 = GTTVarName;
                         oOCOParams.lVariableValueLeg1 = GTTVarVal;
                         oOCOParams.acVariableNameLeg2 = GTTVarName2;
                         oOCOParams.lVariableValueLeg2 = GTTVarVal2;
                         oOCOParams.acValidity = GTTValidity;
                         oOCOParams.acRemarksText = GTTRemarks;
                         oOCOParams.acTrdSymbol = TrdSymbl;
                         oOCOParams.iMultiplier = 1;
                         oOCOParams.iPrecision = 2;
                         oOCOParams.acSrcUserId = acUser;
                         oOCOParams.acSrcBrokerId = BrokerId;

                         oOCOParams.sOrderParamsLeg1.acTrdSymbol = TrdSymbl;
                         oOCOParams.sOrderParamsLeg1.acExchSeg = ExchSeg;
                         oOCOParams.sOrderParamsLeg1.acTransType = TransType;
                         oOCOParams.sOrderParamsLeg1.acOrderType = OrdType;
                         oOCOParams.sOrderParamsLeg1.acProduct = Product;
                         oOCOParams.sOrderParamsLeg1.acOrdDuration = (char*)"DAY";
                         oOCOParams.sOrderParamsLeg1.acAccountId = acAcct;
                         oOCOParams.sOrderParamsLeg1.acUser = acUser;
                         oOCOParams.sOrderParamsLeg1.acCustomerFirm = (char*)"C";
                         oOCOParams.sOrderParamsLeg1.lQuantity = Qty;
                         oOCOParams.sOrderParamsLeg1.lDiscQuantity = Qty;
                         oOCOParams.sOrderParamsLeg1.dPrice = Price;
                         oOCOParams.sOrderParamsLeg1.acPan = Pan;
                         oOCOParams.sOrderParamsLeg1.acOrdSrc = OrdSrc;
                         oOCOParams.sOrderParamsLeg1.acOrdRemarks = (char*)"Testing DS order from API";
                         oOCOParams.sOrderParamsLeg1.acGuiOrdId = GuiOrdId;
                         oOCOParams.sOrderParamsLeg1.acExternalRemarks = acExternalRemarks;
                         oOCOParams.sOrderParamsLeg1.acAlgoName = acAlgoName;

                         oOCOParams.sOrderParamsLeg2.acTrdSymbol = TrdSymbl;
                         oOCOParams.sOrderParamsLeg2.acExchSeg = ExchSeg;
                         oOCOParams.sOrderParamsLeg2.acTransType = TransType2;
                         oOCOParams.sOrderParamsLeg2.acOrderType = OrdType;
                         oOCOParams.sOrderParamsLeg2.acProduct = Product;
                         oOCOParams.sOrderParamsLeg2.acOrdDuration = (char*)"DAY";
                         oOCOParams.sOrderParamsLeg2.acAccountId = acAcct;
                         oOCOParams.sOrderParamsLeg2.acUser = acUser;
                         oOCOParams.sOrderParamsLeg2.acCustomerFirm = (char*)"C";
                         oOCOParams.sOrderParamsLeg2.lQuantity = Qty2;
                         oOCOParams.sOrderParamsLeg2.lDiscQuantity = Qty2;
                         oOCOParams.sOrderParamsLeg2.dPrice = Price2;
                         oOCOParams.sOrderParamsLeg2.acPan = Pan;
                         oOCOParams.sOrderParamsLeg2.acOrdSrc = OrdSrc2;
                         oOCOParams.sOrderParamsLeg2.acOrdRemarks = (char*)"Testing DS order from API";
                         oOCOParams.sOrderParamsLeg2.acGuiOrdId = GuiOrdId;
                         oOCOParams.sOrderParamsLeg2.acExternalRemarks = acExternalRemarks;
                         oOCOParams.sOrderParamsLeg2.acAlgoName = acAlgoName;

                         pNorenControl->PlaceOCO(ClientData, &oOCOParams, acUser);
                    }
                    break;
                    case 56:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Trading Symbol\t");
                         memset(&TrdSymbl[0], 0, sizeof(TrdSymbl));
                         scanf("%s", TrdSymbl);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Transaction Type Leg1\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Transaction Type Leg2\t");
                         memset(&TransType2[0], 0, sizeof(TransType2));
                         scanf("%s", TransType2);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Quantity Leg1\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price Leg1\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter Order Source for Leg1\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();
                         printf("Enter Quantity Leg2\t");
                         Qty2 = 0;
                         scanf("%ld", &Qty2);
                         printf("Enter Price Leg2\t");
                         Price2 = 0;
                         scanf("%lf", &Price2);
                         printf("Enter Order Source for Leg2\t");
                         memset(&OrdSrc2[0], 0, sizeof(OrdSrc2));
                         scanf(" %[^\n]", OrdSrc2);
                         getchar();
                         printf("Enter PAN\t");
                         memset(&Pan[0], 0, sizeof(Pan));
                         scanf("%s", Pan);
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter Al Name\t");
                         memset(&AlName[0], 0, sizeof(AlName));
                         scanf("%s", AlName);
                         printf("Enter OCO variable name Leg1\t");
                         memset(&GTTVarName[0], 0, sizeof(GTTVarName));
                         scanf("%s", GTTVarName);
                         printf("Enter OCO variable value Leg1\t");
                         GTTVarVal = 0;
                         scanf("%ld", &GTTVarVal);
                         printf("Enter OCO variable name Leg2\t");
                         memset(&GTTVarName2[0], 0, sizeof(GTTVarName2));
                         scanf("%s", GTTVarName2);
                         printf("Enter OCO variable value Leg2\t");
                         GTTVarVal2 = 0;
                         scanf("%ld", &GTTVarVal2);
                         printf("Enter OCO validity\t");
                         memset(&GTTValidity[0], 0, sizeof(GTTValidity));
                         scanf("%s", GTTValidity);
                         printf("Enter OCO Remarks\t");
                         memset(&GTTRemarks[0], 0, sizeof(GTTRemarks));
                         scanf(" %[^\n]", GTTRemarks);
                         getchar();
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         getchar();
                         printf("Enter AlgoName\t");
                         memset(&acAlgoName[0], 0, sizeof(acAlgoName));
                         scanf(" %[^\n]", acAlgoName);
                         getchar();
                         printf("Enter OCO Id\t");
                         memset(&GTTId[0], 0, sizeof(GTTId));
                         scanf("%s", GTTId);

                         //place OCO order
                         tsOCOParams oOCOParams;
                         oOCOParams.acAlName = AlName;
                         oOCOParams.acExchSeg = ExchSeg;
                         oOCOParams.acToken = Token;
                         oOCOParams.acVariableNameLeg1 = GTTVarName;
                         oOCOParams.lVariableValueLeg1 = GTTVarVal;
                         oOCOParams.acVariableNameLeg2 = GTTVarName2;
                         oOCOParams.lVariableValueLeg2 = GTTVarVal2;
                         oOCOParams.acValidity = GTTValidity;
                         oOCOParams.acRemarksText = GTTRemarks;
                         oOCOParams.acTrdSymbol = TrdSymbl;
                         oOCOParams.iMultiplier = 1;
                         oOCOParams.iPrecision = 2;
                         oOCOParams.acSrcUserId = acUser;
                         oOCOParams.acSrcBrokerId = BrokerId;
                         oOCOParams.acOCOid = GTTId;

                         oOCOParams.sOrderParamsLeg1.acTrdSymbol = TrdSymbl;
                         oOCOParams.sOrderParamsLeg1.acExchSeg = ExchSeg;
                         oOCOParams.sOrderParamsLeg1.acTransType = TransType;
                         oOCOParams.sOrderParamsLeg1.acOrderType = OrdType;
                         oOCOParams.sOrderParamsLeg1.acProduct = Product;
                         oOCOParams.sOrderParamsLeg1.acOrdDuration = (char*)"DAY";
                         oOCOParams.sOrderParamsLeg1.acAccountId = acAcct;
                         oOCOParams.sOrderParamsLeg1.acUser = acUser;
                         oOCOParams.sOrderParamsLeg1.acCustomerFirm = (char*)"C";
                         oOCOParams.sOrderParamsLeg1.lQuantity = Qty;
                         oOCOParams.sOrderParamsLeg1.lDiscQuantity = Qty;
                         oOCOParams.sOrderParamsLeg1.dPrice = Price;
                         oOCOParams.sOrderParamsLeg1.acPan = Pan;
                         oOCOParams.sOrderParamsLeg1.acOrdSrc = OrdSrc;
                         oOCOParams.sOrderParamsLeg1.acOrdRemarks = (char*)"Testing DS order from API";
                         oOCOParams.sOrderParamsLeg1.acGuiOrdId = GuiOrdId;
                         oOCOParams.sOrderParamsLeg1.acExternalRemarks = acExternalRemarks;
                         oOCOParams.sOrderParamsLeg1.acAlgoName = acAlgoName;

                         oOCOParams.sOrderParamsLeg2.acTrdSymbol = TrdSymbl;
                         oOCOParams.sOrderParamsLeg2.acExchSeg = ExchSeg;
                         oOCOParams.sOrderParamsLeg2.acTransType = TransType2;
                         oOCOParams.sOrderParamsLeg2.acOrderType = OrdType;
                         oOCOParams.sOrderParamsLeg2.acProduct = Product;
                         oOCOParams.sOrderParamsLeg2.acOrdDuration = (char*)"DAY";
                         oOCOParams.sOrderParamsLeg2.acAccountId = acAcct;
                         oOCOParams.sOrderParamsLeg2.acUser = acUser;
                         oOCOParams.sOrderParamsLeg2.acCustomerFirm = (char*)"C";
                         oOCOParams.sOrderParamsLeg2.lQuantity = Qty2;
                         oOCOParams.sOrderParamsLeg2.lDiscQuantity = Qty2;
                         oOCOParams.sOrderParamsLeg2.dPrice = Price2;
                         oOCOParams.sOrderParamsLeg2.acPan = Pan;
                         oOCOParams.sOrderParamsLeg2.acOrdSrc = OrdSrc2;
                         oOCOParams.sOrderParamsLeg2.acOrdRemarks = (char*)"Testing DS order from API";
                         oOCOParams.sOrderParamsLeg2.acGuiOrdId = GuiOrdId;
                         oOCOParams.sOrderParamsLeg2.acExternalRemarks = acExternalRemarks;
                         oOCOParams.sOrderParamsLeg2.acAlgoName = acAlgoName;

                         pNorenControl->ModifyOCO(ClientData, &oOCOParams, acUser);
                    }
                    break;
                    case 57:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter OCO Id\t");
                         memset(&GTTId[0], 0, sizeof(GTTId));
                         scanf("%s", GTTId);
                         //cancel GTT order
                         pNorenControl->CancelOCO(ClientData,GTTId,acUser);
                    }
                    break;
                    case 58:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter OCO Id\t");
                         memset(&GTTId[0], 0, sizeof(GTTId));
                         scanf("%s", GTTId);
                         //get GTT order
                         pNorenControl->GetOCOOrders(ClientData,GTTId,acUser);
                    }
                    break;
                    case 59:
                         pNorenControl->MktStatusSubscribe((char*)"MktStatus");
                         break;
                    case 60:
                         pNorenControl->ModifyUserSubscribe((char*)"ModifyUser");
                         break;
                    case 61:
                    {
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter Quantity\t");
                         double dQty;
                         scanf("%lf", &dQty);

                         printf("Enter acInterOP Key\t");
                         memset(&InterOPKey[0], 0, sizeof(InterOPKey));
                         scanf("%s", InterOPKey);
                         printf("Enter acInterOP ExchSeg\t");
                         memset(&InterOPExchSeg[0], 0, sizeof(InterOPExchSeg));
                         scanf("%s", InterOPExchSeg);

                         tsAddHoldings oAddHold;
                         oAddHold.acAccountId = acAcct;
                         oAddHold.acProduct = Product;
                         oAddHold.iExchSegSize = 1;
                         oAddHold.ppExchSeg = new char*[oAddHold.iExchSegSize];
                         oAddHold.ppExchSeg[0] = ExchSeg;
                         oAddHold.iTokenSize = 1;
                         oAddHold.ppToken = new char*[oAddHold.iTokenSize];
                         oAddHold.ppToken[0] = Token;
                         oAddHold.acUserId = acUser;
                         oAddHold.acBrokerId = BrokerId;
                         oAddHold.dQuantity = dQty;
                         oAddHold.acInterOPKey = InterOPKey;
                         oAddHold.acInterOPExchSeg = InterOPExchSeg;
                         pNorenControl->AddT1Holdings(ClientData, &oAddHold);
                    }
                    break;
                    case 62:
                         pNorenControl->PositionAdminSubscribe((char*)"Position");
                         break;
                    case 63:
                         pNorenControl->PeakMarginSubscribe((char*)"PeakMargin");
                         break;
                    case 64:
                         pNorenControl->ExpiryMarginSubscribe((char*)"ExpiryMargin");
                         break;
                    case 65:
                         pNorenControl->RiskDashBoardSubscribe((char*)"RiskDash");
                         break;
                    case 66:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter TransType\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Price Type\t");
                         memset(&PriceType[0], 0, sizeof(PriceType));
                         scanf("%s", PriceType);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter acInterOP Key\t");
                         memset(&InterOPKey[0], 0, sizeof(InterOPKey));
                         scanf("%s", InterOPKey);
                         printf("Enter acInterOP ExchSeg\t");
                         memset(&InterOPExchSeg[0], 0, sizeof(InterOPExchSeg));
                         scanf("%s", InterOPExchSeg);
                         printf("Enter Quantity\t");
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         scanf("%ld", &lPrice);
                         int BlPrice = 0;
                         bool Bl = false;
                         if(strcmp(Product,"H") == 0)
                         {
                              Bl = true;
                              printf("Enter Book Loss Price\t");
                              scanf("%d", &BlPrice);
                         }
                         
                         printf("Enter Rms Exchange Segment\t");
                         memset(&RmsExchSeg[0], 0, sizeof(RmsExchSeg));
                         scanf("%s", RmsExchSeg);
                         printf("Enter Rms Segment\t");      
                         memset(&RmsSegment[0], 0, sizeof(RmsSegment));
                         scanf("%s", RmsSegment);
                         printf("Enter Rms Product\t");
                         memset(&RmsProduct[0], 0, sizeof(RmsProduct));
                         scanf("%s", RmsProduct);

                         tsOrderMargin oOrderMargin;
                         oOrderMargin.acAcctId = acAcct;
                         oOrderMargin.acExchSeg = ExchSeg;
                         oOrderMargin.acTransType = TransType;
                         oOrderMargin.acProduct = Product;
                         oOrderMargin.acToken = Token;
                         oOrderMargin.lQtyToFill = Qty;
                         oOrderMargin.lOrgQty = LONG_MIN;
                         oOrderMargin.acPriceType = PriceType;
                         oOrderMargin.lPriceToFill = lPrice;
                         oOrderMargin.lOrgPrice = LONG_MIN;
                         oOrderMargin.lTotalFillQty = LONG_MIN;
                         oOrderMargin.lTriggerPrice = LONG_MIN;
                         oOrderMargin.acSrcUserId = acUser;
                         oOrderMargin.acSrcBrokerId = BrokerId;
                         oOrderMargin.lOrderNumber = LONG_MIN;
                         oOrderMargin.lSNOOrderNumber = LONG_MIN;
                         oOrderMargin.iSNOOrderType = INT_MIN;
                         oOrderMargin.iOrgBLPrice = INT_MIN;
                         if(Bl)
                              oOrderMargin.iBLPrice = BlPrice;
                         oOrderMargin.acInterOPKey = InterOPKey;
                         oOrderMargin.acInterOPExchSeg = InterOPExchSeg;
                         
                          if(strcmp(RmsExchSeg,(char*)"NULL") != 0)
                         {
                              oOrderMargin.acRmsExchSeg = RmsExchSeg; 
                         }
                           if(strcmp(RmsSegment,(char*)"NULL") != 0)
                         {
                              oOrderMargin.acRmsSegment = RmsSegment; 
                         } 
                          if(strcmp(RmsProduct,(char*)"NULL") != 0)
                         {
                             oOrderMargin.acRmsProduct = RmsProduct; 
                         }      

                         pNorenControl->GetOrderMargin(ClientData, &oOrderMargin, acUser);
                    }
                    break;
                    case 67:
                    {
                         printf("Enter Update Time Seconds\t");
                         scanf("%ld", &UpdateTimeSec);
                         printf("Enter Update Time NanoSeconds\t");
                         scanf("%ld", &UpdateTimeNanoSec);
                         pNorenControl->GetAllOrders(ClientData,UpdateTimeSec,UpdateTimeNanoSec);
                    }
                    break;
                    case 68:
                    {
                         printf("Enter Update Time Seconds\t");
                         scanf("%ld", &UpdateTimeSec);
                         printf("Enter Update Time NanoSeconds\t");
                         scanf("%ld", &UpdateTimeNanoSec);
                         pNorenControl->AllTradeHistory(ClientData,UpdateTimeSec,UpdateTimeNanoSec);
                    }
                    break;
                    case 69:
                    {
                         printf("Enter Update Time\t");
                         scanf("%ld", &UpdateTime);
                         pNorenControl->GetAllPositions(ClientData,UpdateTime);
                    }
                    break;
                    case 70:
                    {
                         char OldPassword[10];
                         char NewPassword[10];
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Old Password\t");
                         memset(&OldPassword[0], 0, sizeof(OldPassword));
                         scanf("%s", OldPassword);
                         printf("Enter New Password\t");
                         memset(&NewPassword[0], 0, sizeof(NewPassword));
                         scanf("%s", NewPassword);
                         pNorenControl->ChangePassword(acUser,
                                                       OldPassword,
                                                       NewPassword,
                                                       ClientData);
                    }
                    break;
                    case 71:
                         pNorenControl->M2MAlertSubscribe(ClientData);
                         break;
                    case 72:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->GTTUpdatesSubscribe(ClientData,acUser);
                    }
                    break;
                    case 73: 
                    {
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         pNorenControl->GetGTTOrdersAcct(ClientData,acAcct);
                    }
                    break;
                    case 74:
                    {
                         printf("Enter Start Time\t");
                         scanf("%ld", &startTime);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         pNorenControl->GetAllGTTOrders(ClientData,BrokerId,startTime);
                    }
                    break;
                    case 75: 
                    {
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         pNorenControl->GetOCOOrdersAcct(ClientData,acAcct);
                    }
                    break;
                    case 76:
                    {
                         printf("Enter Start Time\t");
                         scanf("%ld", &startTime);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         pNorenControl->GetAllOCOOrders(ClientData,BrokerId,startTime);
                    }
                    break;
                    case 77:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter TransType\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Price Type\t");
                         memset(&PriceType[0], 0, sizeof(PriceType));
                         scanf("%s", PriceType);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter acInterOP Key\t");
                         memset(&InterOPKey[0], 0, sizeof(InterOPKey));
                         scanf("%s", InterOPKey);
                         printf("Enter acInterOP ExchSeg\t");
                         memset(&InterOPExchSeg[0], 0, sizeof(InterOPExchSeg));
                         scanf("%s", InterOPExchSeg);
                         printf("Enter Quantity\t");
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         scanf("%ld", &lPrice);
                         int BlPrice = 0;
                         bool Bl = false;
                         if((strcmp(Product,"C") == 0) || (strcmp(Product,"H") == 0))
                         {
                              Bl = true;
                              printf("Enter Book Loss Price\t");
                              scanf("%d", &BlPrice);
                         }

                         tsBasketMargin oBasketMargin;
                         oBasketMargin.acAcctId = acAcct;
                         oBasketMargin.acExchSeg = ExchSeg;
                         oBasketMargin.acTransType = TransType;
                         oBasketMargin.acProduct = Product;
                         oBasketMargin.acToken = Token;
                         oBasketMargin.lQtyToFill = Qty;
                         oBasketMargin.lOrgQty = LONG_MIN;
                         oBasketMargin.acPriceType = PriceType;
                         oBasketMargin.lPriceToFill = lPrice;
                         oBasketMargin.lOrgPrice = LONG_MIN;
                         oBasketMargin.lTotalFillQty = LONG_MIN;
                         oBasketMargin.lTriggerPrice = LONG_MIN;
                         oBasketMargin.acSrcUserId = acUser;
                         oBasketMargin.acSrcBrokerId = BrokerId;
                         oBasketMargin.lOrderNumber = LONG_MIN;
                         oBasketMargin.lSNOOrderNumber = LONG_MIN;
                         oBasketMargin.iSNOOrderType = INT_MIN;
                         oBasketMargin.iOrgBLPrice = INT_MIN;
                         if(Bl)
                              oBasketMargin.iBLPrice = BlPrice;
                         oBasketMargin.acInterOPKey = InterOPKey;
                         oBasketMargin.acInterOPExchSeg = InterOPExchSeg;
                         printf("Enter Basket1 Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Basket1 TransType\t");
                         memset(&TransType2[0], 0, sizeof(TransType));
                         scanf("%s", TransType2);
                         printf("Enter Basket1 Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Basket1 Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Basket1 Price Type\t");
                         memset(&PriceType[0], 0, sizeof(PriceType));
                         scanf("%s", PriceType);
                         printf("Enter Basket1 Quantity\t");
                         scanf("%ld", &Qty);
                         printf("Enter Basket1 Price\t");
                         scanf("%ld", &lPrice);
                         printf("Enter Basket1 acInterOP Key\t");
                         memset(&InterOPKey[0], 0, sizeof(InterOPKey));
                         scanf("%s", InterOPKey);
                         printf("Enter Basket1 acInterOP ExchSeg\t");
                         memset(&InterOPExchSeg[0], 0, sizeof(InterOPExchSeg));
                         scanf("%s", InterOPExchSeg);

                         oBasketMargin.List[0].acExchSeg = ExchSeg;
                         oBasketMargin.List[0].acTransType = TransType2;
                         oBasketMargin.List[0].acProduct = Product;
                         oBasketMargin.List[0].acToken = Token;
                         oBasketMargin.List[0].lQtyToFill = Qty;
                         oBasketMargin.List[0].acPriceType = PriceType;
                         oBasketMargin.List[0].lPriceToFill = lPrice;
                         oBasketMargin.List[0].acInterOPKey = InterOPKey;
                         oBasketMargin.List[0].acInterOPExchSeg = InterOPExchSeg;

                         oBasketMargin.iListSize = 1;

                         pNorenControl->GetBasketMargin(ClientData, &oBasketMargin, acUser);
                    }
                    break;
                    case 78:
                         pNorenControl->SqroffAlertsSubscribe((char*)"Sqroff");
                         break;
                    case 79:
                    {
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         pNorenControl->OrderAdminUnSubscribe(ClientData, Product);
                    }
                    break;
                    case 80:
                         pNorenControl->PositionAdminUnSubscribe(ClientData);
                         break;
                    case 81:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         pNorenControl->UnSubscribeFeed(ExchSeg,
                                                        Token,
                                                        ClientData,
                                                        acUser);
                    }
                    break;
                    case 82:
                         pNorenControl->MktStatusUnSubscribe(ClientData);
                         break;
                    case 83:
                    {
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         pNorenControl->IpoOrderAdminUnSubscribe(ClientData,
                                                                 Product);
                    }
                    break;
                    case 84:
                         pNorenControl->ModifyUserUnSubscribe((char*)"ModifyUser");
                         break;
                    case 85:
                         pNorenControl->PeakMarginUnSubscribe((char*)"PeakMargin");
                         break;
                    case 86:
                         pNorenControl->ExpiryMarginUnSubscribe((char*)"ExpiryMargin");
                         break;
                    case 87:
                         pNorenControl->RiskDashBoardUnSubscribe((char*)"RiskDash");
                         break;
                    case 88:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                          pNorenControl->GTTUpdatesUnSubscribe((char*)"GTT", acUser);
                    }
                         break;
                    case 89:
                         pNorenControl->M2MAlertUnSubscribe((char*)"M2M");
                         break;
                    case 90:
                         pNorenControl->SqroffAlertsUnSubscribe((char*)"SqroffAlert");
                         break;
                    case 91:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter Quantity\t");
                         double dQty;
                         scanf("%lf", &dQty);
                         printf("Enter Collateral Quantity\t");
                         double dColQty;
                         scanf("%lf", &dColQty);
                         printf("Enter Brk Collateral Quantity\t");
                         double dBrkColQty;
                         scanf("%lf", &dBrkColQty);
                         printf("Enter DP Hold Quantity\t");
                         double dDpQty;
                         scanf("%lf", &dDpQty);
                         printf("Enter Benf Hold Quantity\t");
                         double dBenfQty;
                         scanf("%lf", &dBenfQty);
                         printf("Enter UNplgd Hold Quantity\t");
                         double dUnplgdQty;
                         scanf("%lf", &dUnplgdQty);
                         printf("Enter acInterOP Key\t");
                         memset(&InterOPKey[0], 0, sizeof(InterOPKey));
                         scanf("%s", InterOPKey);
                         printf("Enter acInterOP ExchSeg\t");
                         memset(&InterOPExchSeg[0], 0, sizeof(InterOPExchSeg));
                         scanf("%s", InterOPExchSeg);
                        
                           
                         tsModHoldings oModHold;
                         oModHold.acAccountId = acAcct;   
                         oModHold.acProduct = Product;
                         oModHold.iExchSegSize = 1;
                         oModHold.ppExchSeg = new char*[oModHold.iExchSegSize];
                         oModHold.ppExchSeg[0] = ExchSeg;
                         oModHold.iTokenSize = 1;
                         oModHold.ppToken = new char*[oModHold.iTokenSize];
                         oModHold.ppToken[0] = Token;
                         oModHold.acUserId = acUser;  
                         oModHold.acBrokerId = BrokerId;
                         oModHold.dQuantity = dQty; 
                         oModHold.dCollateralQty = dColQty;
                         oModHold.dBrokerCollateralQty = dBrkColQty;
                         oModHold.dDpHoldQty = dDpQty;
                         oModHold.dBenfHoldQty = dBenfQty;
                         oModHold.dUnplgdHoldQty = dUnplgdQty; 
                         oModHold.acInterOPKey = InterOPKey; 
                         oModHold.acInterOPExchSeg = InterOPExchSeg;  
                         pNorenControl->ModifyHoldings(ClientData, &oModHold);
                    }
                    break;
                    case 92:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter OCO Id\t");
                         memset(&GTTId[0], 0, sizeof(GTTId));
                         scanf("%s", GTTId);
                         //get GTT order
                         pNorenControl->GetGTTOCOOrders(ClientData,GTTId,acUser);
                    }
                    break;
                    case 93:
                         pNorenControl->LimitsUpdateSubscribe((char*)"Limits");
                         break;
                    case 94:
                         pNorenControl->HoldingsUpdateSubscribe((char*)"Holdings");
                         break;
                    case 95:
                         pNorenControl->FundsUpdateSubscribe((char*)"Funds");
                         break;
                    case 96:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter SIP name\t");
                         memset(&acSipName[0], 0, sizeof(acSipName));
                         scanf("%s", acSipName);
                         printf("Enter Register Date\t");
                         long lRegDate;
                         scanf("%ld", &lRegDate);
                         printf("Enter Start Date\t");
                         long lStartDate;
                         scanf("%ld", &lStartDate);
                         printf("Enter Frequency\t");
                         int iFrequency;
                         scanf("%d", &iFrequency);
                         printf("Enter End Period\t");
                         int iEndPeriod;
                         scanf("%d", &iEndPeriod);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Trading Symbol\t");
                         memset(&TrdSymbl[0], 0, sizeof(TrdSymbl));
                         scanf("%s", TrdSymbl);
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);

                         tsSipOrderParams oSipOrderParams;
                         oSipOrderParams.acAcctId  = acAcct;
                         oSipOrderParams.acUser  = acUser;
                         oSipOrderParams.acBrokerId  = BrokerId;
                         oSipOrderParams.lRegDate  = lRegDate;
                         oSipOrderParams.lStartDate  = lStartDate;
                         oSipOrderParams.iFrequency  = iFrequency;
                         oSipOrderParams.iEndPeriod  = iEndPeriod;
                         oSipOrderParams.acSipName  = acSipName;
                         oSipOrderParams.iScripParamSize  = 1;

                         oSipOrderParams.pSipScripParams = new tsSipScripParams[oSipOrderParams.iScripParamSize];
                         oSipOrderParams.pSipScripParams[0].acExchSeg = ExchSeg;
                         oSipOrderParams.pSipScripParams[0].acToken = Token;
                         oSipOrderParams.pSipScripParams[0].acTrdSymbol = TrdSymbl;
                         oSipOrderParams.pSipScripParams[0].acProduct = Product;
                         oSipOrderParams.pSipScripParams[0].dPrice = Price;
                         oSipOrderParams.pSipScripParams[0].lQuantity = Qty;
                         //place SIP order
                         pNorenControl->PlaceEquitySipOrder(ClientData,&oSipOrderParams,acUser);
                    }
                    break;
                    case 97:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Previous Execution Date\t");
                         long lPrevExecDate;
                         scanf("%ld", &lPrevExecDate);
                         printf("Enter Due Date\t");
                         long lDueDate;
                         scanf("%ld", &lDueDate);
                         printf("Enter Execution Date\t");
                         long lExecDate;
                         scanf("%ld", &lExecDate);
                         printf("Enter Sip Id\t");
                         long lSipId;
                         scanf("%ld", &lSipId);
                         printf("Enter SIP state\t");
                         memset(&acSipState[0], 0, sizeof(acSipState));
                         scanf("%s", acSipState);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter SIP name\t");
                         memset(&acSipName[0], 0, sizeof(acSipName));
                         scanf("%s", acSipName);
                         printf("Enter Register Date\t");
                         long lRegDate;
                         scanf("%ld", &lRegDate);
                         printf("Enter Frequency\t");
                         int iFrequency;
                         scanf("%d", &iFrequency);
                         printf("Enter End Period\t");
                         int iEndPeriod;
                         scanf("%d", &iEndPeriod);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Trading Symbol\t");
                         memset(&TrdSymbl[0], 0, sizeof(TrdSymbl));
                         scanf("%s", TrdSymbl);
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);

                         tsSipOrderUpdate oSipOrderUpdate;
                         oSipOrderUpdate.lPrevExecDate = lPrevExecDate;
                         oSipOrderUpdate.lDueDate = lDueDate;
                         oSipOrderUpdate.lExecDate = lExecDate;
                         oSipOrderUpdate.lSipId = lSipId;
                         oSipOrderUpdate.acSipState = acSipState;

                         oSipOrderUpdate.sSipOrderParams.acAcctId  = acAcct;
                         oSipOrderUpdate.sSipOrderParams.acUser  = acUser;
                         oSipOrderUpdate.sSipOrderParams.acBrokerId  = BrokerId;
                         oSipOrderUpdate.sSipOrderParams.lRegDate  = lRegDate;
                         oSipOrderUpdate.sSipOrderParams.iFrequency  = iFrequency;
                         oSipOrderUpdate.sSipOrderParams.iEndPeriod  = iEndPeriod;
                         oSipOrderUpdate.sSipOrderParams.acSipName  = acSipName;
                         oSipOrderUpdate.sSipOrderParams.iScripParamSize  = 1;

                         oSipOrderUpdate.sSipOrderParams.pSipScripParams = new tsSipScripParams[oSipOrderUpdate.sSipOrderParams.iScripParamSize];
                         oSipOrderUpdate.sSipOrderParams.pSipScripParams[0].acExchSeg = ExchSeg;
                         oSipOrderUpdate.sSipOrderParams.pSipScripParams[0].acToken = Token;
                         oSipOrderUpdate.sSipOrderParams.pSipScripParams[0].acTrdSymbol = TrdSymbl;
                         oSipOrderUpdate.sSipOrderParams.pSipScripParams[0].acProduct = Product;
                         oSipOrderUpdate.sSipOrderParams.pSipScripParams[0].dPrice = Price;
                         oSipOrderUpdate.sSipOrderParams.pSipScripParams[0].lQuantity = Qty;

                         //modify SIP order
                         pNorenControl->ModifyEquitySipOrder(ClientData,&oSipOrderUpdate,acUser);
                    }
                    break;
                    case 98:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter SIP Id\t");
                         scanf("%ld", &SIPid);
                         //Cancel SIP order
                         pNorenControl->CancelEquitySipOrder(ClientData,SIPid,acUser);
                    }
                    break;
                    case 99:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter SIP Id\t");
                         scanf("%ld", &SIPid);
                         //get SIP order
                         pNorenControl->GetEquitySipOrder(ClientData,SIPid,acUser);
                    }
                    break;
                    case 100:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->Client_Logout(ClientData, acUser);
                    }
                         
                         break;
                    case 101:
                    { 
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter GTT Id\t");
                         memset(&GTTId[0], 0, sizeof(GTTId));
                         scanf("%s", GTTId);
                         pNorenControl->GetTriggeredGTTOrders(ClientData,GTTId,acUser);
                    }
                    break;
                    case 102:
                    {
                         printf("Enter Start Time\t");
                         scanf("%ld", &startTime);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         pNorenControl->GetAllTriggeredGTTOrders(ClientData,BrokerId,startTime);
                    }
                    break;
                    case 103:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter OCO Id\t");
                         memset(&GTTId[0], 0, sizeof(GTTId));
                         scanf("%s", GTTId);
                         pNorenControl->GetTriggeredOCOOrders(ClientData,GTTId,acUser);
                    }
                    break;
                    case 104:
                    {
                         printf("Enter Start Time\t");
                         scanf("%ld", &startTime);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         pNorenControl->GetAllTriggeredOCOOrders(ClientData,BrokerId,startTime);
                    }
                    break;
                    case 105:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter GTT/OCO Id\t");
                         memset(&GTTId[0], 0, sizeof(GTTId));
                         scanf("%s", GTTId);
                         pNorenControl->GetTriggeredGTTOCOOrders(ClientData,GTTId,acUser);
                    }
                    break;
                    case 106:
                         pNorenControl->SubscribeMsgToMaster(userID,(char*)"MsgToMaster");
                         break;
                    case 107:
                         pNorenControl->UnSubscribeMsgToMaster(userID,(char*)"MsgToMaster");
                         break;
                    case 108:
                         pNorenControl->PosConvSubscribe((char*)"PosConv");
                         break;
                    case 109:
                         pNorenControl->PosConvUnSubscribe((char*)"PosConv");
                         break;
                    case 110:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter Quantity\t");
                         double dQty;
                         scanf("%lf", &dQty);
                         printf("Enter Collateral Quantity\t");
                         double dColQty;
                         scanf("%lf", &dColQty);
                         printf("Enter Brk Collateral Quantity\t");
                         double dBrkColQty;
                         scanf("%lf", &dBrkColQty);
                         printf("Enter DP Hold Quantity\t");
                         double dDpQty;
                         scanf("%lf", &dDpQty);
                         printf("Enter Benf Hold Quantity\t");
                         double dBenfQty;
                         scanf("%lf", &dBenfQty);
                         printf("Enter UNplgd Hold Quantity\t");
                         double dUnplgdQty;
                         scanf("%lf", &dUnplgdQty);

                         printf("Enter Collateral Mode\t");
                         int iCollateralMode;
                         scanf("%d", &iCollateralMode);
                         printf("Enter HairCut\t");
                         double dHairCut;
                         scanf("%lf", &dHairCut);
                         printf("Enter Close Price\t");
                         double dClosePrice;
                         scanf("%lf", &dClosePrice);
                         printf("Enter Broker Haircut\t");
                         double dBrokerHairCut;
                         scanf("%lf", &dBrokerHairCut);
                         printf("Enter Upload Price\t");
                         double dUploadPrice;
                         scanf("%lf", &dUploadPrice);
                         printf("Enter IsCollateral (true|false)\t");
                         char Collateral[10];
                         bool bIsCollateral = false;
                         scanf("%s", Collateral);
                         if(strcmp(Collateral,(char*)"true") == 0)
                              bIsCollateral = true;

                         tsAddHoldings oAddHold;
                         oAddHold.acAccountId = acAcct;
                         oAddHold.acProduct = Product;
                         oAddHold.iExchSegSize = 1;
                         oAddHold.ppExchSeg = new char*[oAddHold.iExchSegSize];
                         oAddHold.ppExchSeg[0] = ExchSeg;
                         oAddHold.iTokenSize = 1;
                         oAddHold.ppToken = new char*[oAddHold.iTokenSize];
                         oAddHold.ppToken[0] = Token;
                         oAddHold.acUserId = acUser;
                         oAddHold.acBrokerId = BrokerId;
                         oAddHold.dQuantity = dQty;
                         oAddHold.dCollateralQty = dColQty;
                         oAddHold.dBrokerCollateralQty = dBrkColQty;
                         oAddHold.dDpHoldQty = dDpQty;
                         oAddHold.dBenfHoldQty = dBenfQty;
                         oAddHold.dUnplgdHoldQty = dUnplgdQty;
                         oAddHold.iCollateralMode = iCollateralMode;
                         oAddHold.dHairCut = dHairCut;
                         oAddHold.dClosePrice = dClosePrice;
                         oAddHold.dBrokerHairCut = dBrokerHairCut;
                         oAddHold.dUploadPrice = dUploadPrice;
                         oAddHold.bIsCollateral = bIsCollateral;
                         pNorenControl->AddMfHoldings(ClientData, &oAddHold);
                    }
                    break;
                    case 111:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         pNorenControl->ViewMfHoldings(ClientData,
                                                       acAcct,
                                                       Product,
                                                       acUser);
                    }
                    break;
                    case 112:
                    {
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Trading Symbol\t");
                         memset(&TrdSymbl[0], 0, sizeof(TrdSymbl));
                         scanf("%s", TrdSymbl);
                         printf("Enter TransType\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Lot Size\t");
                         int iLotSize;
                         scanf("%d", &iLotSize);
                         printf("Enter Instrument Name\t");
                         memset(&acInstName[0], 0, sizeof(acInstName));
                         scanf("%s", acInstName);
                         printf("Enter Quantity\t");
                         long lQty;
                         scanf("%ld", &lQty);
                         printf("Enter Price\t");
                         scanf("%ld", &lPrice);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Segment\t");
                         memset(&Segment[0], 0, sizeof(Segment));
                         scanf("%s", Segment);

                         tsGetBrokerageParams oGetBrokerage;
                         oGetBrokerage.acTrdSymbol = TrdSymbl;
                         oGetBrokerage.acTransType = TransType;
                         oGetBrokerage.acExchSeg = ExchSeg;
                         oGetBrokerage.iLotSize = iLotSize;
                         oGetBrokerage.acInstName = acInstName;
                         oGetBrokerage.lQtyToFill = lQty;
                         oGetBrokerage.lPriceToFill = lPrice;
                         oGetBrokerage.acAcctId = acAcct;
                         oGetBrokerage.acProduct = Product;
                         oGetBrokerage.acSegment = Segment;
                         pNorenControl->GetBrokerage(ClientData, &oGetBrokerage);
                    }
                    break;
                    case 113:
                         pNorenControl->BlockAmtUpdateSubscribe((char*)"BlockAmt");
                         break;
                    case 114:
                         pNorenControl->BlockAmtUpdateUnSubscribe((char*)"BlockAmt");
                         break;
                    case 115:
                         pNorenControl->PayInUpdateSubscribe((char*)"PayIn");
                         break;
                    case 116:
                         pNorenControl->PayInUpdateUnSubscribe((char*)"PayIn");
                         break;
                    case 117:
                         pNorenControl->PayOutUpdateSubscribe((char*)"PayOut");
                         break;
                    case 118:
                         pNorenControl->PayOutUpdateUnSubscribe((char*)"PayOut");
                         break;
                    case 119:
                         pNorenControl->IncrCashUpdateSubscribe((char*)"IncrCash");
                         break;
                    case 120:
                         pNorenControl->IncrCashUpdateUnSubscribe((char*)"IncrCash");
                         break;
                    case 121:
                    {
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         pNorenControl->GetAmoStatus((char*)"GetAmoStatus",ExchSeg);
                    }
                    break;
                    case 122:
                         pNorenControl->ExchangeMessageSubscribe((char*)"ExchMsg");
                         break;
                    case 123:
                         pNorenControl->ExchangeMessageUnSubscribe((char*)"ExchMsg");
                         break;
                    case 124:
                         pNorenControl->DPRSubscribe((char*)"DPR");
                         break;
                    case 125:
                         pNorenControl->DPRUnSubscribe((char*)"DPR");
                         break;
                    case 126:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter Segment\t");
                         pSegment = nullptr;
                         memset(&Segment[0], 0, sizeof(Segment));
                         scanf("%s", Segment);
                         if(strcmp(Segment,(char*)"NULL") != 0)
                         {
                              pSegment = Segment;
                         }
                         printf("Enter Exchange Segment\t");
                         pExchSegment = nullptr;
                         memset(&ExchSegment[0], 0, sizeof(ExchSegment));
                         scanf("%s", ExchSegment);
                         if(strcmp(ExchSegment,(char*)"NULL") != 0)
                         {
                              pExchSegment = ExchSegment;
                         }
                         printf("Enter Product\t");
                         pProduct = nullptr;
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         if(strcmp(Product,(char*)"NULL") != 0)
                         {
                              pProduct = Product;
                         }
                         pNorenControl->GetAllRmsLimits(BrokerId,
                                                        acAcct,
                                                        pSegment,
                                                        pExchSegment,
                                                        pProduct,
                                                        ClientData,
                                                        acUser);
                    }
                    break;
                    case 127:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Vendor Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter Transaction Reference Number\t");
                         long lTranRefNumber;
                         scanf("%ld", &lTranRefNumber);
                         pNorenControl->PayinStatusVerify(ClientData,
                                                          lTranRefNumber,
                                                          acAcct,
                                                          acUser,
                                                          BrokerId);
                    }
                    break;
                    case 128:
                    {
                         //get SIP order
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         pNorenControl->GetEquitySipOrderAcct(ClientData, acAcct);
                    }
                    break;
                    case 129:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->GetHSToken(ClientData, acUser);
                    }
                    break;
                    case 130:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Order Number\t");
                         memset(&OrdNum[0], 0, sizeof(OrdNum));
                         scanf("%s", OrdNum);
                         pNorenControl->RegenerateCoverOrder(ClientData,
                                                             OrdNum,
                                                             acUser);
                    }
                    break;
                    case 131:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Order Number\t");
                         memset(&OrdNum[0], 0, sizeof(OrdNum));
                         scanf("%s", OrdNum);
                         pNorenControl->RegenerateBracketOrder(ClientData,
                                                               OrdNum,
                                                               acUser);
                    }
                    break;
                    case 132:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Block Amount\t");
                         Amt = 0;
                         scanf("%lf", &Amt);
                         //                    	if(scanf("%lf", &Amt)!=1)
                         //                    	{
                         //
                         //                    		printf("Please enter the valid block amount\n");
                         //                    		int buf;
                         //                    		while((buf=getchar())!='\n' && buf!= EOF);
                         //                    	}
                         //                    	else
                         //                    	{
                         pNorenControl->UpdateBlockAmount(ClientData,
                                                          Amt,
                                                          acAcct,
                                                          acUser);
                         //	}
                    }
                    break;
                    case 133:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         
                         int iBasketListSize=2;
                         tsBasketList sBasketList[iBasketListSize];

                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Transaction Type\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         lPrice = 0;
                         scanf("%ld", &lPrice);

                         sBasketList[0].acExchSeg = ExchSeg;
                         sBasketList[0].acTransType = TransType;
                         sBasketList[0].acProduct = Product;
                         sBasketList[0].acToken = Token;
                         sBasketList[0].acPriceType = OrdType;
                         sBasketList[0].lQtyToFill = Qty;
                         sBasketList[0].lPriceToFill = lPrice;

                         char Token2[10];
                         char ExchSeg2[10];
                         //                         char TransType[10];
                         char OrdType2[10];
                         char Product2[10];

                         printf("Enter Token2\t");
                         memset(&Token2[0], 0, sizeof(Token2));
                         scanf("%s", Token2);
                         printf("Enter Exchange Segment2\t");
                         memset(&ExchSeg2[0], 0, sizeof(ExchSeg2));
                         scanf("%s", ExchSeg2);
                         printf("Enter Transaction Type2\t");
                         memset(&TransType2[0], 0, sizeof(TransType2));
                         scanf("%s", TransType2);
                         printf("Enter Order Type2\t");
                         memset(&OrdType2[0], 0, sizeof(OrdType2));
                         scanf("%s", OrdType2);
                         printf("Enter Product2\t");
                         memset(&Product2[0], 0, sizeof(Product2));
                         scanf("%s", Product2);
                         printf("Enter Quantity2\t");
                         Qty2 = 0;
                         scanf("%ld", &Qty2);
                         printf("Enter Price2\t");
                         long lPrice2 = 0;
                         scanf("%ld", &lPrice2);

                         sBasketList[1].acExchSeg = ExchSeg2;
                         sBasketList[1].acTransType = TransType2;
                         sBasketList[1].acProduct = Product2;
                         sBasketList[1].acToken = Token2;
                         sBasketList[1].acPriceType = OrdType2;
                         sBasketList[1].lQtyToFill = Qty2;
                         sBasketList[1].lPriceToFill = lPrice2;

                         printf("Enter BrokerId\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);

                         pNorenControl->GetOptimizedBasketSequence(ClientData,
                                                                   acAcct,
                                                                   sBasketList,
                                                                   iBasketListSize,
                                                                   LONG_MIN,
                                                                   LONG_MIN,
                                                                   BrokerId,
                                                                   acUser);
                    }
                    break;
                    case 134:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Amount\t");
                         Amt = 0;
                         scanf("%lf", &Amt);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter Segment\t");
                         pSegment = nullptr;
                         memset(&Segment[0], 0, sizeof(Segment));
                         scanf("%s", Segment);
                         if(strcmp(Segment,(char*)"NULL") != 0)
                         {
                              pSegment = Segment;
                         }
                         printf("Enter Exchange Segment\t");
                         pExchSegment = nullptr;
                         memset(&ExchSegment[0], 0, sizeof(ExchSegment));
                         scanf("%s", ExchSegment);
                         if(strcmp(ExchSegment,(char*)"NULL") != 0)
                         {
                              pExchSegment = ExchSegment;
                         }
                         printf("Enter Product\t");
                         pProduct = nullptr;
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         if(strcmp(Product,(char*)"NULL") != 0)
                         {
                              pProduct = Product;
                         }
                         printf("Enter Bank Name\t");
                         char* pBnkNme;
                         char BnkNme[10];
                         scanf(" %[^\n]", BnkNme);
                         if(strcmp(BnkNme,(char*)"NULL") != 0)
                         {
                              pBnkNme = BnkNme;
                         }
                         printf("Enter Transaction Reference number\t");
                         long RefNum;
                         scanf("%ld", &RefNum);
                       
                         pNorenControl->WithdrawFunds2(ClientData,
                                                       acAcct,
                                                       RefNum,
                                                       acUser,
                                                       BrokerId,
                                                       pBnkNme,
                                                       Amt,
                                                       pSegment,
                                                       pExchSegment,
                                                       pProduct);              
                    }
                    break;
                    case 135:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         char Type[2];
                         printf("Enter Freeze Type\t");
                         memset(&Type[0], 0, sizeof(Type));
                         scanf("%s", Type);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         pNorenControl->FreezeAccount(ClientData,
                                                      acAcct,
                                                      Type,
                                                      BrokerId,
                                                      acUser);
                    }
                    break;
                    case 136:
                    {
                         printf("Enter Seconds\t");
                         UpdateTimeSec = 0;
                         scanf("%ld", &UpdateTimeSec);
                         printf("Enter Nano Seconds\t");
                         UpdateTimeNanoSec = 0;
                         scanf("%ld", &UpdateTimeNanoSec);
                         pNorenControl->GetResolutionTime(ClientData,
                                                          UpdateTimeSec,
                                                          UpdateTimeNanoSec);
                    }
                    break;
                    case 137:
                    {
                         pNorenControl->GetQueueLoad(ClientData);
                    }
                    break;
                    case 138:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);

                         pNorenControl->DeFreezeAccount(ClientData,
                                                        acAcct,
                                                        BrokerId,
                                                        acUser);
                    }
                    break;
                    case 139:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->GetMasterMsg(ClientData,
                                                     acUser);
                    }
                    break;
                    case 140:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->GetPositionConv(ClientData,
                                                        acUser);
                    }
                    break;
                    case 141:
                    {
                        printf("Enter UserId\t");
                        memset(&acUser[0], 0, sizeof(acUser));
                        scanf("%s", acUser);
                        printf("Enter AcctId\t");
                        memset(&acAcct[0], 0, sizeof(acAcct));
                        scanf("%s", acAcct);
                        printf("Enter Product\t");
                        memset(&Product[0], 0, sizeof(Product));
                        scanf("%s", Product);
                        printf("Enter Broker Id\t");
                        memset(&BrokerId[0], 0, sizeof(BrokerId));
                        scanf("%s", BrokerId);
                        printf("Enter Quantity\t");
                        double dQty;
                        scanf("%lf", &dQty);
                        printf("Enter Collateral Quantity\t");
                        double dColQty;
                        scanf("%lf", &dColQty);
                        printf("Enter Brk Collateral Quantity\t");
                        double dBrkColQty;
                        scanf("%lf", &dBrkColQty);
                        printf("Enter DP Hold Quantity\t");
                        double dDpQty;
                        scanf("%lf", &dDpQty);
                        printf("Enter Benf Hold Quantity\t");
                        double dBenfQty;
                        scanf("%lf", &dBenfQty);
                        printf("Enter UNplgd Hold Quantity\t");
                        double dUnplgdQty;
                        scanf("%lf", &dUnplgdQty);
 				    printf("Enter Collateral Mode\t");
                        int iCollateralMode;
                        scanf("%d", &iCollateralMode);
                        printf("Enter HairCut\t");
                        double dHairCut;
                        scanf("%lf", &dHairCut);
                        printf("Enter Close Price\t");
                        double dClosePrice;
                        scanf("%lf", &dClosePrice);
                        printf("Enter Broker Haircut\t");
                        double dBrokerHairCut;
                        scanf("%lf", &dBrokerHairCut);
                        printf("Enter Upload Price\t");
                        double dUploadPrice;
                        scanf("%lf", &dUploadPrice);
                        printf("Enter Equity Brk Collateral Quantity \t");
                        double dEqtBrkColQty;
                        scanf("%lf", &dEqtBrkColQty);
                        printf("Enter Derivative Brk Collateral Quantity \t");
                        double dDerBrkColQty;
                        scanf("%lf", &dDerBrkColQty);
                        printf("Enter Fx Brk Collateral Quantity \t");
                        double dFxBrkColQty;
                        scanf("%lf", &dFxBrkColQty);
                        printf("Enter Commodity Brk Collateral Quantity \t");
                        double dComBrkColQty;
                        scanf("%lf", &dComBrkColQty);
                        printf("Enter EPI Quantity \t");
                        double dEpiQty;
                        scanf("%lf", &dEpiQty);
                        printf("Enter ISIN\t");
                        memset(&Isin[0], 0, sizeof(Isin));
                        scanf("%s", Isin);   
                        
                        tsAbsIsinHoldings oAbsIsinHold;
                        oAbsIsinHold.acProduct = Product;
                        oAbsIsinHold.acBrokerId = BrokerId;
                        oAbsIsinHold.dQuantity = dQty;
                        oAbsIsinHold.dCollateralQty = dColQty;
                        oAbsIsinHold.dBrokerCollateralQty = dBrkColQty;
                        oAbsIsinHold.dDpHoldQty = dDpQty;
                        oAbsIsinHold.dBenfHoldQty = dBenfQty;
                        oAbsIsinHold.dUnplgdHoldQty = dUnplgdQty;
                        oAbsIsinHold.iCollateralMode = iCollateralMode;
                        oAbsIsinHold.dHairCut = dHairCut;
                        oAbsIsinHold.dClosePrice = dClosePrice;
                        oAbsIsinHold.dBrokerHairCut = dBrokerHairCut;
                        oAbsIsinHold.dUploadPrice = dUploadPrice;
                        oAbsIsinHold.dEqtBrokerCollateralQty = dEqtBrkColQty;
                        oAbsIsinHold.dDerBrokerCollateralQty = dDerBrkColQty;
                        oAbsIsinHold.dFxBrokerCollateralQty = dFxBrkColQty;
                        oAbsIsinHold.dComBrokerCollateralQty = dComBrkColQty;
                        oAbsIsinHold.dEpiQty = dEpiQty;
                        oAbsIsinHold.acIsin = Isin;
                        oAbsIsinHold.acAccountId = acAcct;
                        oAbsIsinHold.acUserId = acUser;
                        pNorenControl->PublishAbsIsinHoldings(ClientData,&oAbsIsinHold);    
                    }
                    break;
                    case 142:
                    {  
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);        
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter TransType\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Price Type\t");
                         memset(&PriceType[0], 0, sizeof(PriceType));
                         scanf("%s", PriceType);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter acInterOP Key\t");
                         memset(&InterOPKey[0], 0, sizeof(InterOPKey));
                         scanf("%s", InterOPKey);
                         printf("Enter acInterOP ExchSeg\t");
                         memset(&InterOPExchSeg[0], 0, sizeof(InterOPExchSeg));
                         scanf("%s", InterOPExchSeg);
                         printf("Enter Quantity\t");
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         scanf("%ld", &lPrice);
                         int BlPrice = 0;
                         bool Bl = false;           
                         if(strcmp(Product,"H") == 0)
                         {
                              Bl = true;
                              printf("Enter Book Loss Price\t");
                              scanf("%d", &BlPrice);
                         }
                         printf("Enter Rms Exchange Segment\t");
                         memset(&RmsExchSeg[0], 0, sizeof(RmsExchSeg));
                         scanf("%s", RmsExchSeg);
                         printf("Enter Rms Segment\t");
                         memset(&RmsSegment[0], 0, sizeof(RmsSegment));
                         scanf("%s", RmsSegment);
                         printf("Enter Rms Product\t");
                         memset(&RmsProduct[0], 0, sizeof(RmsProduct));
                         scanf("%s", RmsProduct);

                         tsOrderMargin oOrderMargin2;
                         oOrderMargin2.acAcctId = acAcct;
                         oOrderMargin2.acExchSeg = ExchSeg;
                         oOrderMargin2.acTransType = TransType;
                         oOrderMargin2.acProduct = Product;
                         oOrderMargin2.acToken = Token;
                         oOrderMargin2.lQtyToFill = Qty;
                         oOrderMargin2.lOrgQty = LONG_MIN;
                         oOrderMargin2.acPriceType = PriceType;
                         oOrderMargin2.lPriceToFill = lPrice;
                         oOrderMargin2.lOrgPrice = LONG_MIN;
                         oOrderMargin2.lTotalFillQty = LONG_MIN;
                         oOrderMargin2.lTriggerPrice = LONG_MIN;
                         oOrderMargin2.acSrcUserId = acUser;
                         oOrderMargin2.acSrcBrokerId = BrokerId;
                         oOrderMargin2.lOrderNumber = LONG_MIN;
                         oOrderMargin2.lSNOOrderNumber = LONG_MIN;
                         oOrderMargin2.iSNOOrderType = INT_MIN;
                         oOrderMargin2.iOrgBLPrice = INT_MIN;
                         if (Bl)
                              oOrderMargin2.iBLPrice = BlPrice;  
                         oOrderMargin2.acInterOPKey = InterOPKey;
                         oOrderMargin2.acInterOPExchSeg = InterOPExchSeg;
                         
                         if(strcmp(RmsExchSeg,(char*)"NULL") != 0)
                         {
                              oOrderMargin2.acRmsExchSeg = RmsExchSeg; 
                         }
                         if(strcmp(RmsSegment,(char*)"NULL") != 0)
                         {
                              oOrderMargin2.acRmsSegment = RmsSegment; 
                         } 
                          if(strcmp(RmsProduct,(char*)"NULL") != 0)
                         {
                             oOrderMargin2.acRmsProduct = RmsProduct; 
                         }   
                         pNorenControl->GetOrderMargin2(ClientData, &oOrderMargin2, acUser);
                    }
                    break;
                    case 143:
                         pNorenControl->TradeEnhancementSubscribe((char*)"Trade");
                    break;
                    case 144:
                         pNorenControl->TradeEnhancementUnSubscribe((char*)"Trade");
                    break;
                    case 145:
                    {
                         printf("Enter Order Number\t");
                         memset(&OrdNum[0], 0, sizeof(OrdNum));
                         scanf("%s", OrdNum);
                         pNorenControl->GetExternalRemarks((char*)"GetExtrRmks",OrdNum);
                    }
                    break;
                    case 146:
                    {
                         printf("Enter External Remarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf("%s", acExternalRemarks);
                         pNorenControl->GetOrderNumber((char*)"GetExtrRmks",acExternalRemarks);
                    }
                    break;
                    case 147:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Trading Symbol\t");
                         memset(&TrdSymbl[0], 0, sizeof(TrdSymbl));
                         scanf("%s", TrdSymbl);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Transaction Type\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Order Duration\t");
                         char OrdDuration[10];
                         scanf("%s", OrdDuration);
                         printf("Enter Customer Firm\t");
                         char CustFirm[10];
                         scanf("%s", CustFirm);
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter TriggerPrice(SL & SL-M)\t");
                         double TriggerPrice = 0;
                         scanf("%lf", &TriggerPrice);
                         // printf("Enter PAN\t");
                         // memset(&Pan[0], 0, sizeof(Pan));
                         // scanf("%s", Pan);
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         char IpAddr[20];
                         printf("Enter IpAddr\t");
                         memset(&IpAddr[0], 0, sizeof(IpAddr));
                         scanf("%s", IpAddr);
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         getchar();
                         // printf("Enter AlgoName\t");
                         // memset(&acAlgoName[0], 0, sizeof(acAlgoName));
                         // scanf(" %[^\n]", acAlgoName);
                         // char* pAlgoName = nullptr;
                         // getchar();
                         // printf("Enter Auction Number\t");
                         // AuNum = 0;
                         // scanf("%d", &AuNum);

                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Book Profit Price\t");
                         BpPrice = 0;
                         scanf("%ld", &BpPrice);
                         printf("Enter Trailing Price\t");
                         TrailingPrice = 0;
                         scanf("%ld", &TrailingPrice);
                         printf("Enter Order Source \t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter Exchange user Id\t");
                         memset(&ExchUsrId[0], 0, sizeof(ExchUsrId));
                         scanf(" %[^\n]", ExchUsrId);
                         getchar();

                         //place limit order
                         tsAQParams oAQOrder;
                         oAQOrder.sOrderParams.acTrdSymbol = TrdSymbl;
                         oAQOrder.sOrderParams.acExchSeg = ExchSeg;
                         oAQOrder.sOrderParams.acTransType = TransType;
                         oAQOrder.sOrderParams.acOrderType = OrdType;
                         oAQOrder.sOrderParams.acProduct = Product;
                         oAQOrder.sOrderParams.acOrdDuration = OrdDuration;
                         oAQOrder.sOrderParams.acAccountId = acAcct;
                         oAQOrder.sOrderParams.acUser = acUser;
                         oAQOrder.sOrderParams.acCustomerFirm = CustFirm;
                         oAQOrder.sOrderParams.lQuantity = Qty;
                         oAQOrder.sOrderParams.lDiscQuantity = Qty;
                         oAQOrder.sOrderParams.dPrice = Price;
                         oAQOrder.sOrderParams.dTriggerPrice = TriggerPrice;
                         oAQOrder.sOrderParams.acPan = Pan;
                         oAQOrder.sOrderParams.acOrdSrc = OrdSrc;
                         oAQOrder.sOrderParams.acOrdRemarks = (char*)"Testing DS order from API";
                         oAQOrder.sOrderParams.acGuiOrdId = GuiOrdId;
                         oAQOrder.sOrderParams.acExternalRemarks = acExternalRemarks;
                         // oAQOrder.sOrderParams.acAlgoName = acAlgoName;
                         // oAQOrder.sOrderParams.iAuctionNumber = AuNum;
                         oAQOrder.sOrderParams.acIpAddr = IpAddr;
                         oAQOrder.sOrderParams.acCustomerFirm = CustFirm;
                         oAQOrder.sOrderParams.acExchUsrId = ExchUsrId;

                         oAQOrder.acToken = Token;
                         oAQOrder.lBpPrice = BpPrice;
                         oAQOrder.lTrialPrice = TrailingPrice;
                         oAQOrder.acSrcUserId = acUser;
                         oAQOrder.acBrokerId = BrokerId;

                         pNorenControl->PlaceTrailingOrder(ClientData, &oAQOrder, acUser);
                    }
                    break;
                    case 148:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Trading Symbol\t");
                         memset(&TrdSymbl[0], 0, sizeof(TrdSymbl));
                         scanf("%s", TrdSymbl);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Transaction Type\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Order Duration\t");
                         char OrdDuration[10];
                         scanf("%s", OrdDuration);
                         printf("Enter Customer Firm\t");
                         char CustFirm[10];
                         scanf("%s", CustFirm);
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter TriggerPrice(SL & SL-M)\t");
                         double TriggerPrice = 0;
                         scanf("%lf", &TriggerPrice);
                         // printf("Enter PAN\t");
                         // memset(&Pan[0], 0, sizeof(Pan));
                         // scanf("%s", Pan);
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         char IpAddr[20];
                         printf("Enter IpAddr\t");
                         memset(&IpAddr[0], 0, sizeof(IpAddr));
                         scanf("%s", IpAddr);
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         getchar();
                         // printf("Enter AlgoName\t");
                         // memset(&acAlgoName[0], 0, sizeof(acAlgoName));
                         // scanf(" %[^\n]", acAlgoName);
                         // char* pAlgoName = nullptr;
                         // getchar();
                         // printf("Enter Auction Number\t");
                         // AuNum = 0;
                         // scanf("%d", &AuNum);

                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Iceberg Leg Trailing Price\t");
                         Iceberg_leg = 0;
                         scanf("%ld", &Iceberg_leg);
                         printf("Enter Order Source \t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter Exchange user Id\t");
                         memset(&ExchUsrId[0], 0, sizeof(ExchUsrId));
                         scanf(" %[^\n]", ExchUsrId);
                         getchar();

                         //place limit order
                         tsAQParams oAQOrder;
                         oAQOrder.sOrderParams.acTrdSymbol = TrdSymbl;
                         oAQOrder.sOrderParams.acExchSeg = ExchSeg;
                         oAQOrder.sOrderParams.acTransType = TransType;
                         oAQOrder.sOrderParams.acOrderType = OrdType;
                         oAQOrder.sOrderParams.acProduct = Product;
                         oAQOrder.sOrderParams.acOrdDuration = OrdDuration;
                         oAQOrder.sOrderParams.acAccountId = acAcct;
                         oAQOrder.sOrderParams.acUser = acUser;
                         oAQOrder.sOrderParams.acCustomerFirm = CustFirm;
                         oAQOrder.sOrderParams.lQuantity = Qty;
                         oAQOrder.sOrderParams.dPrice = Price;
                         oAQOrder.sOrderParams.acPan = Pan;
                         oAQOrder.sOrderParams.dTriggerPrice = TriggerPrice;
                         oAQOrder.sOrderParams.acOrdSrc = OrdSrc;
                         oAQOrder.sOrderParams.acOrdRemarks = (char*)"Testing DS order from API";
                         oAQOrder.sOrderParams.acGuiOrdId = GuiOrdId;
                         oAQOrder.sOrderParams.acExternalRemarks = acExternalRemarks;
                         oAQOrder.sOrderParams.acExchUsrId = ExchUsrId;
                         // oAQOrder.sOrderParams.acAlgoName = acAlgoName;
                         // oAQOrder.sOrderParams.iAuctionNumber = AuNum;
                         oAQOrder.sOrderParams.acIpAddr = IpAddr;
                         oAQOrder.sOrderParams.acCustomerFirm = CustFirm;
                         oAQOrder.acToken = Token;
                         oAQOrder.lIceberg_leg = Iceberg_leg;
                         oAQOrder.acSrcUserId = acUser;
                         oAQOrder.acBrokerId = BrokerId;

                         pNorenControl->PlaceIceBergOrder(ClientData, &oAQOrder, acUser);
                    }
                    break;
                    case 149:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter Trading Symbol\t");
                         memset(&TrdSymbl[0], 0, sizeof(TrdSymbl));
                         scanf("%s", TrdSymbl);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Transaction Type\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Order Duration\t");
                         char OrdDuration[10];
                         scanf("%s", OrdDuration);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter Customer Firm\t");
                         char CustFirm[10];
                         scanf("%s", CustFirm);
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter AQ_ID\t");
                         AQ_ID = 0;
                         scanf("%ld", &AQ_ID);
                         printf("Enter Order Source \t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf(" %[^\n]", OrdSrc);
                         getchar();
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);

                         tsAQParams oAQOrder;     
                         oAQOrder.sOrderParams.acTrdSymbol = TrdSymbl; 
                         oAQOrder.sOrderParams.acExchSeg = ExchSeg;
                         oAQOrder.sOrderParams.acTransType = TransType;
                         oAQOrder.sOrderParams.acOrderType = OrdType;
                         oAQOrder.sOrderParams.acProduct = Product;
                         oAQOrder.sOrderParams.acOrdDuration = OrdDuration;   
                         oAQOrder.sOrderParams.dPrice = Price;   
                         oAQOrder.sOrderParams.acCustomerFirm = CustFirm;   
                         oAQOrder.sOrderParams.lQuantity = Qty;        
                         oAQOrder.sOrderParams.acAccountId = acAcct;
                         oAQOrder.sOrderParams.acUser = acUser;       
                         oAQOrder.sOrderParams.acOrdSrc = OrdSrc;              
                         oAQOrder.sOrderParams.acOrdRemarks = (char*)"Testing DS order from API";              
                         oAQOrder.acToken = Token; 
                         oAQOrder.lAQ_ID = AQ_ID;
                         oAQOrder.sOrderParams.acGuiOrdId = GuiOrdId;
                         oAQOrder.sOrderParams.acExternalRemarks = acExternalRemarks;
                         oAQOrder.acSrcUserId = acUser;
                         oAQOrder.acBrokerId = BrokerId;
                      
                         pNorenControl->ModifyIceBergOrder(ClientData, &oAQOrder, acUser);
                    }
                    break;
                    case 150:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter AQ ID\t");
                         AQ_ID = 0;
                         scanf("%ld", &AQ_ID); 
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         getchar();
                        
                         pNorenControl->CancelIceBergOrder(ClientData,
                                                            AQ_ID,
                                                            GuiOrdId,
                                                            acExternalRemarks,
                                                            acUser);
                    }
                    break;
                    case 151:
                    {
                         printf("Enter Update Time Seconds\t");
                         scanf("%ld", &UpdateTimeSec);
                         pNorenControl->GetTrailingOrdersAcct(ClientData,accountID,UpdateTimeSec);
                    }
                    break;
                    case 152:
                    {
                         printf("Enter Update Time Seconds\t");
                         scanf("%ld", &UpdateTimeSec);
                         pNorenControl->GetIceBergOrdersAcct(ClientData,accountID,UpdateTimeSec);
                    }
                    break;
                    case 153:
                    {
                         printf("Enter GroupId\t");
                         memset(&GrpId[0], 0, sizeof(GrpId));
                         scanf("%s", GrpId);
                         pNorenControl->OrderAdminGroupSubscribe(ClientData, GrpId);
                    }
                    break;
                    case 154:
                    {
                         printf("Enter GroupId\t");
                         memset(&GrpId[0], 0, sizeof(GrpId));
                         scanf("%s", GrpId);
                         pNorenControl->OrderAdminGroupUnSubscribe(ClientData, GrpId);
                    }
                    break;
                    case 155:
                    {
                         printf("Enter GroupId\t");
                         memset(&GrpId[0], 0, sizeof(GrpId));
                         scanf("%s", GrpId);
                         pNorenControl->PositionAdminGroupSubscribe(ClientData, GrpId);
                    }
                    break;
                    case 156:
                    {
                         printf("Enter GroupId\t");
                         memset(&GrpId[0], 0, sizeof(GrpId));
                         scanf("%s", GrpId);
                         pNorenControl->PositionAdminGroupUnSubscribe(ClientData, GrpId);
                    }
                    break;
                    case 157:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter GroupId\t");
                         memset(&GrpId[0], 0, sizeof(GrpId));
                         scanf("%s", GrpId);
                         pNorenControl->GetGroupPositionConv(ClientData,
                                                        GrpId,
                                                        acUser);
                    }
                    break;
                    case 158:
                    {
                         printf("Enter GroupId\t");
                         memset(&GrpId[0], 0, sizeof(GrpId));
                         scanf("%s", GrpId);
                         printf("Enter Update Time Seconds\t");
                         scanf("%ld", &UpdateTimeSec);
                         printf("Enter Update Time NanoSeconds\t");
                         scanf("%ld", &UpdateTimeNanoSec);
                         pNorenControl->GetAllGroupOrders(ClientData,GrpId,UpdateTimeSec,UpdateTimeNanoSec);
                    }
                    break;
                    case 159:
                    {
                         printf("Enter GroupId\t");
                         memset(&GrpId[0], 0, sizeof(GrpId));
                         scanf("%s", GrpId);
                         printf("Enter Update Time Seconds\t");
                         scanf("%ld", &UpdateTimeSec);
                         printf("Enter Update Time NanoSeconds\t");
                         scanf("%ld", &UpdateTimeNanoSec);
                         pNorenControl->AllGroupTradeHistory(ClientData,GrpId,UpdateTimeSec,UpdateTimeNanoSec);
                    }
                    break;
                    case 160:
                    {
                         printf("Enter GroupId\t");
                         memset(&GrpId[0], 0, sizeof(GrpId));
                         scanf("%s", GrpId);
                         printf("Enter Update Time\t");
                         scanf("%ld", &UpdateTime);
                         pNorenControl->GetAllGroupPositions(ClientData,GrpId,UpdateTime);
                    }
                    break;
                    case 161:
                    {
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         pNorenControl->GetGroupId(ClientData,acAcct);
                    }
                    break;
                    case 162:
                    {
                         printf("Enter UserId\t");
                         memset(&acUid[0], 0, sizeof(acUid));
                         scanf("%s", acUid);
                         pNorenControl->BlockUser(ClientData,acUid);
                    }
                    break;
                    case 163:
                    {
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter UserId\t");
                         memset(&acUid[0], 0, sizeof(acUid));
                         scanf("%s", acUid);
                         printf("Enter Broker Id\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);
                         printf("Enter Transaction Reference Number\t");
                         long lTranRefNumber;
                         scanf("%ld", &lTranRefNumber);
                         pNorenControl->CancelWithdrawFunds(ClientData,acAcct,acUid,BrokerId,lTranRefNumber);
                    }
                    break;
                    case 164:
                    {
                         printf("Enter Transaction Reference Number\t");
                         long lTranRefNumber;
                         scanf("%ld", &lTranRefNumber);
                         pNorenControl->PayoutStatusVerify(ClientData,lTranRefNumber);
                    }
                    break;
                    case 165:
                    {
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         pNorenControl->GetWithdrawFundsReport(ClientData,acAcct);
                    }
                    break;
                    case 166:
                    {
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Token\t");
                         memset(&Token[0], 0, sizeof(Token));
                         scanf("%s", Token);
                         printf("Enter Source BrokerId\t");
                         memset(&BrokerId[0], 0, sizeof(BrokerId));
                         scanf("%s", BrokerId);

                         int MktInd = 0;
                         printf("Enter Market Indicator\t");
                         scanf("%d", &MktInd);
                         int LocationId = 0;
                         printf("Enter LocationId\t");
                         scanf("%d", &LocationId);
                         Qty = 0;
                         printf("Enter Quantity\t");
                         scanf("%ld", &Qty);
                         lPrice = 0;
                         printf("Enter Price\t");
                         scanf("%ld", &lPrice);
                         double MktPro = 0;
                         printf("Enter Market Protection Percentage\t");
                         scanf("%lf", &MktPro);

                         tsSqrOffEntityParams oSqrOffEntityParams;
                         oSqrOffEntityParams.acAccountId = acAcct;
                         oSqrOffEntityParams.acExchSeg = ExchSeg;
                         oSqrOffEntityParams.acProduct = Product;
                         oSqrOffEntityParams.acToken = Token;
                         oSqrOffEntityParams.acSrcUserId = acUser;
                         oSqrOffEntityParams.acSrcBrokerId = BrokerId;
                         oSqrOffEntityParams.iMktInd = MktInd;
                         oSqrOffEntityParams.iLocationId = LocationId;
                         oSqrOffEntityParams.lQty = Qty;
                         oSqrOffEntityParams.lPrice = lPrice;
                         oSqrOffEntityParams.dMktProtectionPercentage = MktPro;
                         pNorenControl->SqrOffEntity(ClientData, &oSqrOffEntityParams);
                    }
                    break;
                    case 167:
                    {
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         pNorenControl->GetOrderNumberByGui(ClientData,GuiOrdId);
                    }
                    break;
                    case 168:
                    {
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf("%s", OrdSrc);
                         pNorenControl->EntityCancelOrder(ClientData,acAcct,Product,OrdSrc,acUser);
                    }
                    break;
                    case 169:
                    {
                         printf("Do you want to enable log writing(true/false):\t");
                         memset(&input[0], 0, sizeof(input));
                         scanf("%s", input);
                         enabaleLogs = (strcmp(input, "true") == 0);
                         printf("Do you want to enable timestamp in logs(true/false):\t");
                         memset(&input[0], 0, sizeof(input));
                         scanf("%s", input);
                         enableTimestamp = (strcmp(input, "true") == 0);
                         pNorenControl->SetLogWriting(enabaleLogs,enableTimestamp);
                    }
                    break;
                    case 170:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->getAllAuctionSymbols(ClientData,acUser);
                    }
                    break;
                    case 171:
                    {
                          printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         pNorenControl->OfsOrderAdminSubscribe(ClientData,Product);
                    }
                    break;
                    case 172:
                    {
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         pNorenControl->OfsOrderAdminUnSubscribe(ClientData,Product);
                    }
                    break;
                    case 173:
                    {
                         printf("Enter Trading Symbol\t");
                         memset(&TrdSymbl[0], 0, sizeof(TrdSymbl));
                         scanf("%s", TrdSymbl);
                         printf("Enter Exchange Segment\t");
                         memset(&ExchSeg[0], 0, sizeof(ExchSeg));
                         scanf("%s", ExchSeg);
                         printf("Enter Transaction Type\t");
                         memset(&TransType[0], 0, sizeof(TransType));
                         scanf("%s", TransType);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Product\t");
                         memset(&Product[0], 0, sizeof(Product));
                         scanf("%s", Product);
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         Qty = 0;
                         printf("Enter Quantity\t");
                         scanf("%ld", &Qty);
                         Price = 0;
                         printf("Enter Price\t");
                         scanf("%lf", &Price);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf("%s", OrdSrc);
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         getchar();
                         // char IpAddr[20];
                         // printf("Enter IpAddr\t");
                         // memset(&IpAddr[0], 0, sizeof(IpAddr));
                         // scanf("%s", IpAddr);

                         tsOfsPlaceOrderParams ofsPlaceOrder;
                         ofsPlaceOrder.acTrdSymbol = TrdSymbl;
                         ofsPlaceOrder.acExchSeg = ExchSeg;
                         ofsPlaceOrder.acTransType = TransType;
                         ofsPlaceOrder.acOrderType = OrdType;
                         ofsPlaceOrder.acProduct = Product;
                         ofsPlaceOrder.acOrdDuration = (char*)"DAY";
                         ofsPlaceOrder.acAccountId = acAcct;
                         ofsPlaceOrder.acUser = acUser;
                         ofsPlaceOrder.acCustomerFirm = (char*)"C";
                         ofsPlaceOrder.lQuantity = Qty;
                         ofsPlaceOrder.dPrice = Price;
                         ofsPlaceOrder.acOrdSrc = OrdSrc;
                         ofsPlaceOrder.acOrderRemarks = (char*)"Testing DS order from API";
                         ofsPlaceOrder.acGuiOrdId = GuiOrdId;
                         ofsPlaceOrder.acExternalRemarks = acExternalRemarks;
                        // ofsPlaceOrder.acIpAddr = IpAddr;
                         pNorenControl->OfsPlaceOrder(ClientData,&ofsPlaceOrder,acUser);
                    }
                    break;
                    case 174:
                    {
                         printf("Enter Order Number\t");
                         memset(&OrdNum[0], 0, sizeof(OrdNum));
                         scanf("%s", OrdNum);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Quantity\t");
                         Qty = 0;
                         scanf("%ld", &Qty);
                         printf("Enter Price\t");
                         Price = 0;
                         scanf("%lf", &Price);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf("%s", OrdSrc);
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         getchar();
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         
                         tsOfsModOrderParams OfsModOrderParams;
                         OfsModOrderParams.acNorenOrdNum = OrdNum;
                         OfsModOrderParams.acUser = acUser;
                         OfsModOrderParams.acOrdSrc = OrdSrc;
                         OfsModOrderParams.acOrderType = OrdType;
                         OfsModOrderParams.acOrdDuration = (char*)"DAY";
                         OfsModOrderParams.lQuantity = Qty;
                         OfsModOrderParams.dPrice = Price;
                         OfsModOrderParams.acGuiOrdId = GuiOrdId;
                         OfsModOrderParams.acExternalRemarks = acExternalRemarks;
                         pNorenControl->OfsModifyOrder(ClientData,&OfsModOrderParams,acUser);
                    }
                    break;
                    case 175:
                    {
                         printf("Enter Order Number\t");
                         memset(&OrdNum[0], 0, sizeof(OrdNum));
                         scanf("%s", OrdNum);
                         printf("Enter Order Type\t");
                         memset(&OrdType[0], 0, sizeof(OrdType));
                         scanf("%s", OrdType);
                         printf("Enter Order Source\t");
                         memset(&OrdSrc[0], 0, sizeof(OrdSrc));
                         scanf("%s", OrdSrc);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter GuiOrdId\t");
                         memset(&GuiOrdId[0], 0, sizeof(GuiOrdId));
                         scanf("%s", GuiOrdId);
                         printf("Enter ExternalRemarks\t");
                         memset(&acExternalRemarks[0], 0, sizeof(acExternalRemarks));
                         scanf(" %[^\n]", acExternalRemarks);
                         getchar();

                         tsOfsCanOrderParams OfsCanOrderParams;
                         OfsCanOrderParams.acNorenOrdNum = OrdNum;
                         OfsCanOrderParams.acUser = acUser;
                         OfsCanOrderParams.acOrdSrc = OrdSrc;
                         OfsCanOrderParams.acGuiOrdId = GuiOrdId;
                         OfsCanOrderParams.acExternalRemarks = acExternalRemarks;
                         pNorenControl->OfsCancelOrder(ClientData,&OfsCanOrderParams,acUser);
                    }
                    break;
                    case 176:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         printf("Enter Order Number\t");
                         memset(&OrdNum[0], 0, sizeof(OrdNum));
                         scanf("%s", OrdNum);
                         pNorenControl->OfsOrderHistory(ClientData,OrdNum,acUser);
                    }
                    break;
                    case 177:
                    {
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->OfsOrderBook(ClientData,acUser);
                    }
                    break;
                    case 178:
                    {
                         pNorenControl->GetAllOfsOrders(ClientData);
                    }
                    break;
                    case 179:
                    {
                         pNorenControl->GetAllIpoOrders(ClientData);
                    }
                    break;
                    case 180:
                    {
                         printf("Enter Sip Id\t");
                         long lSipId;
                         scanf("%ld", &lSipId);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->PauseEquitySipOrder(ClientData,lSipId,acUser);
                    }
                    break;
                    case 181:
                    {
                         printf("Enter Sip Id\t");
                         long lSipId;
                         scanf("%ld", &lSipId);
                         printf("Enter UserId\t");
                         memset(&acUser[0], 0, sizeof(acUser));
                         scanf("%s", acUser);
                         pNorenControl->ResumeEquitySipOrder(ClientData,lSipId,acUser); 

                    }
                    break;
                    case 182:
                    {
                         pNorenControl->DPRThresholdAlertSubscribe(ClientData);
                    }
                    break;
                    case 183:
                    {
                         pNorenControl->DPRThresholdAlertUnSubscribe(ClientData);
                    }
                    break;
                    case 184:
                    {
                         printf("Enter AcctId\t");
                         memset(&acAcct[0], 0, sizeof(acAcct));
                         scanf("%s", acAcct);
                         pNorenControl->GetMaxBlockAmt(ClientData,acAcct);
                    }
                    break;
                    default : printf("Please Enter proper character\t Enter 1 for help\n");
                    break;
               }
          }

          char* version = nullptr;
          pNorenControl->GetApiVersion(version);
          std::cout<<"VERSION :"<<version<<std::endl;

          sleep(5);
          pNorenControl->Client_Logout(ClientData, userID);

          sleep(10);
     }

     pNorenControl->shutdown_Control();
     delete pNorenControl;

     std::cout << "shutdown !! \n";
     return 0;
}

