//************************************************************************************************* 
// Copyright © Kambala Solutions Private Limited All rights reserved.
//
//*************************************************************************************************

1. Prerequisites
Ensure the following files are available in the Docker/ directory (latest versions as per our team’s delivery):
a) CAPI_LIBS_UBUNTU22_20250801.tar.gz – CAPI dependency libraries for UBUNTU22
b) NOREN_LIB_API_v*.UBUNTU22.tar.gz – (Team provied CAPI Latest API package)
c) CAPI.key – License key (our team will provide a valid one)
d) config.xml – Noren API configuration file (our team will provide a valid one)
e) Dockerfile_UBUNTU22 – Dockerfile to create the Docker image

Note: Dummy CAPI.key and config.xml are provided, these must be replaced with the actual files sent by the team.

2. Folder Structure Before Build
Make sure Docker/ folder contains
Docker/
|___________  CAPI_LIBS_UBUNTU22_20250801.tar.gz
|___________  NOREN_LIB_API_v*.UBUNTU22.tar.gz
|___________  CAPI.key
|___________  config.xml
|___________  Dockerfile_UBUNTU22

3. Building the Docker Image
Navigate to the Docker/ directory and run:

docker build -f Dockerfile_UBUNTU22 -t my-noren-image .
 -replace my-noren-image with your preferred image name.
 -The build process extracts and organizes the required files for deployment, and also installs the GCC version 13.1.0 to support compilation tasks within the container.
  
4. Running the Docker Containe
After the image is built successfully, run the container using:

docker run -it --name my-noren-container my-noren-image
 -replace my-noren-container with your preferred container name.

5. Inside the Docker Container – Folder Structure
After launching the container, the following directory structure will be available:

app/
|
|---->config_xml/
	|------------>config.xml  (Noren config xml file content)

|----->lib/
	|----------->CAPI_LIBS/  (UBUNTU22 supported Library package)
|	
|----->lic/
	|------------>CAPI.key  (API license file) 
	 
|----->log/
	|-------------->NorenTestApi.log (Runtime log of API)
	
|----->pkg/
	|
	|------->NOREN_LIB_API_v*.UBUNTU22/(latest API Package)


6. Important Notes

a) Ensure you replace the dummy CAPI.key and config.xml files with actual files provided by the team before building the image.
b) Always use the latest API package (NOREN_LIB_API_v*.UBUNTU22.tar.gz) as shared with you.
c) Edit Dockerfile_UBUNTU22, hardcoded file name NOREN_LIB_API_v*.UBUNTU22.tar.gz with latest CAPI package, before building docker image, to ensure the container uses the updated API package.
 
7. To stop and remove the container/image 

docker stop my-noren-container
docker rm my-noren-container
docker rmi my-noren-image
