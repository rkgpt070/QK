//*************************************************************************************************
// Copyright © Kambala Solutions Private Limited All rights reserved.
//
//*************************************************************************************************

#ifndef __NORENCAPIDS_HPP_INCL
#define __NORENCAPIDS_HPP_INCL

#include <iostream>
#include <cstring>
#include <climits>
#include <cfloat>

#ifdef GRPC
// #include "grpc_protos.grpc.pb.h"
#include "grpc_protos.pb.h"
#endif

namespace NorenSpace
{

  /* ------------------------------------------------------------------------- */

  enum ErrorCode
  {
    NO_ERR,
    UNKNOWN_ERROR,
    API_ERROR,
    ORDER_BROKER_DOWN,
    REQUEST_BROKER_DOWN,
    FEED_BROKER_DOWN,
    ORDER_SWITCH_DOWN,
    USER_NOT_LOGGED_IN,
    SERIALIZE_FAILED,
    MISC_ERROR,
    InValid_USER,
    INVALID_ACCOUNT,
    INVALID_BROKER,
    INVALID_PASSWORD,
    INVALID_ORDER_NUM,
    INVALID_EXCHANGE,
    INVALID_SYMBOL,
    INVALID_PRODUCT,
    INVALID_INPUT,
    MISMATCHED_BROKER,
    INVALID_GTT_ID,
    INVALID_OCO_ID,
    ZERO_QTY,
    INVALID_ORDERTYPE,
    UNKNOWN_REQ,
    ALGO_ID_MANDATORY,
    NO_DATA_FOUND
  };

  enum ApiRequest
  {
    GetOrders,
    GetOrdersAcct,
    GetAllOrders,
    GetAllGroupOrders,
    TradeHistory,
    TradeHistoryAcct,
    AllTradeHistory,
    AllGroupTradeHistory,
    GetAllClients,
    GetPositions,
    GetAllGroupPositions,
    GetAllPositions,
    GetAllSymbols,
    GetGroupSettings,
    GetRmsLimits,
    GetAllRmsLimits,
    GetOrderMargin,
    GetOrderMargin2,
    GetIndexNames,
    GetProductList,
    GetUserProfile,
    SecurityInfo,
    OrderHistory,
    ViewHoldings,
    GetTopnKeys,
    GetTopnValues,
    GetAllVwapData,
    GetScripDetails,
    GetMarketStatus,
    GetExchangeMessages,
    GetBasketMargin,
    GetWithdrawalAmt,
    WithdrawFunds,
    WithdrawFunds2,
    IpoList,
    IpoOrderBook,
    MfOrderBook,
    GetAllOCOOrders,
    GetOCOOrders,
    GetOCOOrdersAcct,
    GetGTTOCOOrders,
    GetAllGTTOrders,
    GetGTTOrders,
    GetGTTOrdersAcct,
    GetAllTriggeredOCOOrders,
    GetTriggeredOCOOrders,
    GetTriggeredGTTOCOOrders,
    GetAllTriggeredGTTOrders,
    GetTriggeredGTTOrders,
    GetEquitySipOrder,
    ViewMfHoldings,
    GetBrokerage,
    GetAmoStatus,
    PayinStatusVerify,
    PayoutStatusVerify,
    GetHSToken,
    UpdateBlockAmount,
    GetOptimizedBasketSequence,
    FreezeAccount,
    DeFreezeAccount,
    GetMasterMsg,
    GetPositionConv,
    GetGroupPositionConv,
    GetExternalRemarks,
    GetOrderNumber,
    GetOrderNumberByGui,
    GetTrailingOrdersAcct,
    GetIceBergOrdersAcct,
    CancelWithdrawFunds,
    PendingWithdrawFunds,
    GetOptCalc,
    Admin_Login,
    PlaceOrder,
    PlaceMultiLegOrder,
    PlaceAfterMktOrder,
    PlaceAfterMktMultiLegOrder,
    IpoPlaceOrder,
    MfPlaceOrder,
    ModifyOrder,
    AfterMktModifyOrder,
    IpoModifyOrder,
    MfModifyOrder,
    CancelOrder,
    IpoCancelOrder,
    MfCancelOrder,
    ValidateUidPwd,
    PartialPosConv,
    ChangePassword,
    PlaceGTT,
    PlaceOCO,
    ModifyGTT,
    ModifyOCO,
    CancelGTT,
    CancelOCO,
    PlaceEquitySipOrder,
    ModifyEquitySipOrder,
    CancelEquitySipOrder,
    PlaceTrailingOrder,
    PlaceIceBergOrder,
    ModifyIceBergOrder,
    CancelIceBergOrder,
    GetGroupId,
    EntityCancelOrder,
    ExitCoverOrder,
    ExitBracketOrder,
    RegenerateCoverOrder,
    RegenerateBracketOrder,
    AddHoldings,
    AddT1Holdings,
    ModifyHoldings,
    PublishAbsIsinHoldings,
    HoldingsUpdateSubscribe,
    PositionAdminSubscribe,
    OrderAdminSubscribe,
    SetGroupSettings,
    Subscribe,
    AddFunds,
    GetWithdrawFundsReport,
    AddMfHoldings,
    BlockUser,
    SqrOffEntity,
    GetOptionCalc,
    Client_Logout,
    GetEquitySipOrderAcct,
    getAllAuctionSymbols,
    OfsPlaceOrder,
    OfsModifyOrder,
    OfsCancelOrder,
    OfsOrderHistory,
    OfsOrderBook,
    GetAllOfsOrders,
    GetAllIpoOrders,
    PauseEquitySipOrder,
    ResumeEquitySipOrder,
    GetMaxBlockAmt,

  };

  enum LogOutStatus
  {
    LOGGEDIN,
    LOGGEDOUT
  };

  /* ------------------------------------------------------------------------- */
#ifdef GRPC

  using tsOrderParams = GRPC_PROTOS::PlaceOrder_Params;
  using tsModOrderParams = GRPC_PROTOS::ModifyOrder_Params;
  using tsCanOrderParams = GRPC_PROTOS::CancelOrder_Params;
  using tsPartialPosConvParams = GRPC_PROTOS::PosConv_Params;
  using tsRmsLimits = GRPC_PROTOS::RmsLimits_ack;
  using tsUserProfile = GRPC_PROTOS::GetUserProfile_ack;
  using tsSecurityInfo = GRPC_PROTOS::SecurityInfo_ack;
  using tsMultiLegParams = GRPC_PROTOS::MultiLeg_Params;

  using tsIpoPlaceOrderParams = GRPC_PROTOS::IpoPlaceOrder_Params;
  using tsIpoModOrderParams = GRPC_PROTOS::IpoModOrder_Params;
  using tsIpoCanOrderParams = GRPC_PROTOS::IpoCanOrder_Params;

  using tsMfPlaceOrderParams = GRPC_PROTOS::MfPlaceOrder_Params;
  using tsMfModOrderParams = GRPC_PROTOS::MfModOrder_Params;
  using tsMfCanOrderParams = GRPC_PROTOS::MfCanOrder_Params;

  using tsOrderMargin = GRPC_PROTOS::OrderMargin_Params;
  using tsBasketMargin = GRPC_PROTOS::BasketMargin_Params;

  using tsAddHoldings = GRPC_PROTOS::AddHoldings_Params;
  using tsModHoldings = GRPC_PROTOS::ModHoldings_Params;
  using tsAbsIsinHoldings = GRPC_PROTOS::AbsIsinHold_Params;

  using tsGTTParams = GRPC_PROTOS::GTT_Params;
  using tsOCOParams = GRPC_PROTOS::OCO_Params;

  using tsOrderUpdate = GRPC_PROTOS::OrderUpdate_Params;
  using tsMultiLegUpdate = GRPC_PROTOS::MultiLegUpdate_Params;
  using tsOrderHistory = GRPC_PROTOS::OrderHistory_Params;

  using tsMarketData = GRPC_PROTOS::MarketData_Params;

  using tsSipOrderParams = GRPC_PROTOS::SipOrderParams;
  using tsSipOrderUpdate = GRPC_PROTOS::SipOrderUpdate;
  using tsGetBrokerageParams = GRPC_PROTOS::GetBrokerageParams;
  using tsBrokerageRespParams = GRPC_PROTOS::BrokerageRespParams;
  using tsPayinStatusRespParams = GRPC_PROTOS::PayinStatusRespParams;
  using tsPayoutStatusRespParams = GRPC_PROTOS::PayinStatusRespParams;

  using tsFillReport = GRPC_PROTOS::FillReport_Params;
  using tsSymbolData = GRPC_PROTOS::SymbolDataRespParams;
  using tsClientData = GRPC_PROTOS::ClientDataRespParams;
  using tsIndexName = GRPC_PROTOS::IndexNameRespParams;
  using tsViewHoldings = GRPC_PROTOS::HoldingDataRespParams;
  using tsTopnValues = GRPC_PROTOS::TopnValuesRespParams;
  using tsVwapData = GRPC_PROTOS::VwapDataRespParams;
  using tsIpoList = GRPC_PROTOS::IpoListRespParams;
  using tsIpoOrdBook = GRPC_PROTOS::IpoOrderBookRespParams;
  using tsMfOrdBook = GRPC_PROTOS::MfOrderBookRespParams;
  using tsMasterMsgParams = GRPC_PROTOS::MasterMsgRespParams;

  using tsPosConvParams = GRPC_PROTOS::PositionConvRespParams;

  using tsPosData = GRPC_PROTOS::PosDataRespParams;
  using sBasketList = GRPC_PROTOS::BasketList;

  using tsAQParams = GRPC_PROTOS::Algo_Params;  
  using tsFundsReportParams = GRPC_PROTOS::FundsReport_Params;
  using tsOptionCalcParams = GRPC_PROTOS::OptCalc_Params;
  using tsSqrOffEntityParams = GRPC_PROTOS::SqrOffEntity_Params;

  using tsCallbackErrorParams = GRPC_PROTOS::CallbackError_Params;
  using tsAuctionSymbolsParams = GRPC_PROTOS::AuctionSymbl_Params;

  using tsOfsPlaceOrderParams = GRPC_PROTOS::OfsPlaceOrder_Params;
  using tsOfsModOrderParams = GRPC_PROTOS::OfsModOrder_Params;
  using tsOfsCanOrderParams = GRPC_PROTOS::OfsCanOrder_Params;
  using tsOfsOrderBook = GRPC_PROTOS::OfsOrderBookResp_Params;


#else

  typedef struct sLoginRespParams
  {
    char *acStatus; //[max: 24]
    bool bPasswordReset;
    long lLoginTime;
    int iLstAtmptcount;
    char *acSessId; //[max: 24]
    //               int       i2faQuesSize;
    //               char**    ppc2faQues;
    int iDaysLeft;
    bool bDevicePin;
    int iExchSegSize;
    char **ppcExchSeg; //[max: 6]
    int iProductSize;
    char **ppcProduct; //[max: 2]

    sLoginRespParams()
        : acStatus(nullptr),
          bPasswordReset(false),
          lLoginTime(LONG_MIN),
          iLstAtmptcount(INT_MIN),
          acSessId(nullptr),
          iDaysLeft(INT_MIN),
          bDevicePin(false),
          iExchSegSize(INT_MIN),
          ppcExchSeg(nullptr),
          iProductSize(INT_MIN),
          ppcProduct(nullptr)
    {
    }
  } tsLoginRespParams;

  typedef struct sClientData
  {
    char **ppAccId;   //[max: 16]
    char **ppAccName; //[max: 16]
    int iNumOfAcc;
    char *pClientStatus;
    char *pClientContext;

    sClientData()
        : ppAccId(nullptr),
          ppAccName(nullptr),
          iNumOfAcc(INT_MIN),
          pClientStatus(nullptr),
          pClientContext(nullptr)
    {
    }
  } tsClientData;

  typedef struct sUserProfile
  {
    char *pEmailAddress;
    char *pCellAddress;
    char *pAccountName;
    char *pAccountId; //[max: 16]
    char *pExchSeg;   //[max: 6]
    char *pProduct;   //[max: 2]
    char *pOrderType; //
    char *pBankName;
    char *pBankAcctNo;
    char *pBankBranchName;
    char *pBankIFSCcode;
    char *pBankName2;
    char *pBankAcctNo2;
    char *pBankBranchName2;
    char *pBankIFSCcode2;
    char *pBankName3;
    char *pBankAcctNo3;
    char *pBankBranchName3;
    char *pBankIFSCcode3;
    char *pBankName4;
    char *pBankAcctNo4;
    char *pBankBranchName4;
    char *pBankIFSCcode4;
    char *pBankName5;
    char *pBankAcctNo5;
    char *pBankBranchName5;
    char *pBankIFSCcode5;
    char *pBankName6;
    char *pBankAcctNo6;
    char *pBankBranchName6;
    char *pBankIFSCcode6;
    char *pDpAcctNo;
    char *pDpAcctNo2;
    char *pDpAcctNo3;
    char *pBroker;
    char *pPan; //[max: 12]
    char *pResidencePhone;
    char *pStatusIndicator;
    char *pOfficephone;
    char *pOfficeAddress;
    char *pBankId;
    char *pAddress;
    char *pDpId;
    char *pDpName;
    char *pDepository;

    sUserProfile()
        : pEmailAddress(nullptr),
          pCellAddress(nullptr),
          pAccountName(nullptr),
          pAccountId(nullptr),
          pExchSeg(nullptr),
          pProduct(nullptr),
          pOrderType(nullptr),
          pBankName(nullptr),
          pBankAcctNo(nullptr),
          pBankBranchName(nullptr),
          pBankIFSCcode(nullptr),
          pBankName2(nullptr),
          pBankAcctNo2(nullptr),
          pBankBranchName2(nullptr),
          pBankIFSCcode2(nullptr),
          pBankName3(nullptr),
          pBankAcctNo3(nullptr),
          pBankBranchName3(nullptr),
          pBankIFSCcode3(nullptr),
          pBankName4(nullptr),
          pBankAcctNo4(nullptr),
          pBankBranchName4(nullptr),
          pBankIFSCcode4(nullptr),
          pBankName5(nullptr),
          pBankAcctNo5(nullptr),
          pBankBranchName5(nullptr),
          pBankIFSCcode5(nullptr),
          pBankName6(nullptr),
          pBankAcctNo6(nullptr),
          pBankBranchName6(nullptr),
          pBankIFSCcode6(nullptr),
          pDpAcctNo(nullptr),
          pDpAcctNo2(nullptr),
          pDpAcctNo3(nullptr),
          pBroker(nullptr),
          pPan(nullptr),
          pResidencePhone(nullptr),
          pStatusIndicator(nullptr),
          pOfficephone(nullptr),
          pOfficeAddress(nullptr),
          pBankId(nullptr),
          pAddress(nullptr),
          pDpId(nullptr),
          pDpName(nullptr),
          pDepository(nullptr)
    {
    }
  } tsUserProfile;

  typedef struct sSymbolData
  {
    char *pSymbol;     //[max: 16]
    char *pExchSeg;    //[max: 6]
    char *pInstType;   //[max: 8]
    char *pSymbolName; //[max: 24]
    char *pTrdSymbol;  //[max: 24]
    char *pOptionType; //[max: 4]
    char *pISIN;       //[max: 16]
    char *pDesc;       //[max: ANY]
    double dTickSize;
    long lLotSize;
    long lExpiryDate;
    long lMultiplier;
    long lPrecision;
    double dStrikePrice;
    char *pUnderlyingSymbol;  //[max: 24]
    char *pUnderlyingExchSeg; //[max: 6]
    double dPriceMultiplier;
    char *pInterOPKey;     //[max: 24]
    char *pInterOPExchSeg; //[max: 6]
    char *pExchange;       //[max: 3]
    char *pMaturityDate;   //[max: 12]
    char *pSegment;        //[max: 6]
    double dPriceNum;
    double dGenDen;
    double dGenNum;
    double dPriceDen;
    char *pExchSymblName;

    sSymbolData()
        : pSymbol(nullptr),
          pExchSeg(nullptr),
          pInstType(nullptr),
          pSymbolName(nullptr),
          pTrdSymbol(nullptr),
          pOptionType(nullptr),
          pISIN(nullptr),
          pDesc(nullptr),
          dTickSize(DBL_MIN),
          lLotSize(LONG_MIN),
          lExpiryDate(LONG_MIN),
          lMultiplier(1),
          lPrecision(2),
          dStrikePrice(DBL_MIN),
          pUnderlyingSymbol(nullptr),
          pUnderlyingExchSeg(nullptr),
          dPriceMultiplier(1),
          pInterOPKey(nullptr),
          pInterOPExchSeg(nullptr),
          pExchange(nullptr),
          pMaturityDate(nullptr),
          pSegment(nullptr),
          dPriceNum(DBL_MIN),
          dGenDen(DBL_MIN),
          dGenNum(DBL_MIN),
          dPriceDen(DBL_MIN),
          pExchSymblName(nullptr)
    {
    }
  } tsSymbolData;

  typedef struct sIndexName
  {
    char *pExchSeg; //[max: 6]
    int iIndexNameSize;
    char **ppIndexName; //[max: 24]
    int iIndexTokenSize;
    char **ppIndexToken; //[max: 16]

    sIndexName()
        : pExchSeg(nullptr),
          iIndexNameSize(INT_MIN),
          ppIndexName(nullptr),
          iIndexTokenSize(INT_MIN),
          ppIndexToken(nullptr)
    {
    }
  } tsIndexName;

  typedef struct sSecurityInfo
  {

    char *pSymbol;           //[max: 16]
    char *pExchange;         //[max: 3]
    char *pExchSeg;          //[max: 6]
    char *pGroup;            //[max: 8]
    char *pInstName;         //[max: 8]
    char *pExpiryDate;       //[max: 12]
    char *pIssueDate;        //[max: 12]
    char *pMaturityDate;     //[max: 12]
    char *pListingDate;      //[max: 12]
    char *pNoDelStartDate;   //[max: 12]
    char *pNoDelEndDate;     //[max: 12]
    char *pBookClsStartDate; //[max: 12]
    char *pBookClsEndDate;   //[max: 12]
    char *pRecordDate;       //[max: 12]
    char *pCreditRating;     //[max: 12]
    char *pReAdminDate;      //[max: 12]
    char *pExpulsionDate;    //[max: 12]
    char *pLocalUpdateTime;  //[max: 12]
    char *pDeliveryUnits;
    char *pPriceUnits;
    char *pLastTradingDate; //[max: 12]
    long lTenderPeridEndDate;
    long lTenderPeridStartDate;
    char *pSellVarMargin; //[max: 2]
    char *pBuyVarMargin;  //[max: 2]
    char *pInstrumentInfo;
    char *pRemarksText; //[max: ANY]
    char *pSegment;
    char *pNav;
    char *pNavDate;     //[max: 12]
    char *pMfAmt;       //[max: 2]
    char *pSipSecurity; //[max: 2]
    char *pIsin;        //[max: 16]
    char *pFaceValue;   //[max: 12]
    char *pTrdUnits;
    char *pExerciseStartDate; //[max: 12]
    char *pExerciseEndDate;   //[max: 12]
    char *pElmMargin;
    char *pVarMargin;
    char *pTotProposedLimitValue; //[max: 2]
    char *pScripBasePrice;        //[max: 12]
    char *pCombinedSymbol;        //[max: 2]
    char *pSettlementType;        //[max: 4]
    int iPermittedToTrade;
    int iBoardLotQty;
    int iMaxOrderSize;
    double dOpenInterest;
    double dHighPriceRange;
    double dLowPriceRange;
    double dPriceNum;
    double dGenDen;
    double dGenNum;
    double dPriceQuatation;
    double dIssuerate;
    double dPriceDen;
    double dTickSize;
    double dWarningQty;
    double dIssueCapital;
    double dExposureMargin;
    double dMinRedemptionQty;
    long lFreezeQty;
    char *pSymbolName;  //[max: 24]
    char *pTrdSymbol;   //[max: 24]
    char *pOptionType;  //[max: 4]
    char *pScripRefKey; //[max: 2]
    char *pAssetCode;   //[max: 2]
    char *pSubGroup;    //[max: 2]
    char *pDesc;        //[max: 14]
    char *pAmcCode;     //[max: 2]
    char *pContractId;  //[max: 2]
    long lLotSize;
    long lExpiryDate;
    long lMultiplier;
    long lPrecision;
    double dStrikePrice;
    char *pUnderlyingSymbol;  //[max: 24]
    char *pUnderlyingExchSeg; //[max: 6]
    double dPriceMultiplier;
    char *pOrdMsg;
    double dPrevOi;
    double dTotalOi;
    int iAuctionNumber;
    long lExcLowRange;
    long lExcHighRange;

    sSecurityInfo()
        : pSymbol(nullptr),
          pExchange(nullptr),
          pExchSeg(nullptr),
          pGroup(nullptr),
          pInstName(nullptr),
          pExpiryDate(nullptr),
          pIssueDate(nullptr),
          pMaturityDate(nullptr),
          pListingDate(nullptr),
          pNoDelStartDate(nullptr),
          pNoDelEndDate(nullptr),
          pBookClsStartDate(nullptr),
          pBookClsEndDate(nullptr),
          pRecordDate(nullptr),
          pCreditRating(nullptr),
          pReAdminDate(nullptr),
          pExpulsionDate(nullptr),
          pLocalUpdateTime(nullptr),
          pDeliveryUnits(nullptr),
          pPriceUnits(nullptr),
          pLastTradingDate(nullptr),
          lTenderPeridEndDate(LONG_MIN),
          lTenderPeridStartDate(LONG_MIN),
          pSellVarMargin(nullptr),
          pBuyVarMargin(nullptr),
          pInstrumentInfo(nullptr),
          pRemarksText(nullptr),
          pSegment(nullptr),
          pNav(nullptr),
          pNavDate(nullptr),
          pMfAmt(nullptr),
          pSipSecurity(nullptr),
          pIsin(nullptr),
          pFaceValue(nullptr),
          pTrdUnits(nullptr),
          pExerciseStartDate(nullptr),
          pExerciseEndDate(nullptr),
          pElmMargin(nullptr),
          pVarMargin(nullptr),
          pTotProposedLimitValue(nullptr),
          pScripBasePrice(nullptr),
          pCombinedSymbol(nullptr),
          pSettlementType(nullptr),
          iPermittedToTrade(INT_MIN),
          iBoardLotQty(INT_MIN),
          iMaxOrderSize(INT_MIN),
          dOpenInterest(DBL_MIN),
          dHighPriceRange(DBL_MIN),
          dLowPriceRange(DBL_MIN),
          dPriceNum(DBL_MIN),
          dGenDen(DBL_MIN),
          dGenNum(DBL_MIN),
          dPriceQuatation(DBL_MIN),
          dIssuerate(DBL_MIN),
          dPriceDen(DBL_MIN),
          dTickSize(DBL_MIN),
          dWarningQty(DBL_MIN),
          dIssueCapital(DBL_MIN),
          dExposureMargin(DBL_MIN),
          dMinRedemptionQty(DBL_MIN),
          lFreezeQty(LONG_MIN),
          pSymbolName(nullptr),
          pTrdSymbol(nullptr),
          pOptionType(nullptr),
          pScripRefKey(nullptr),
          pAssetCode(nullptr),
          pSubGroup(nullptr),
          pDesc(nullptr),
          pAmcCode(nullptr),
          pContractId(nullptr),
          lLotSize(LONG_MIN),
          lExpiryDate(LONG_MIN),
          lMultiplier(1),
          lPrecision(2),
          dStrikePrice(DBL_MIN),
          pUnderlyingSymbol(nullptr),
          pUnderlyingExchSeg(nullptr),
          dPriceMultiplier(1),
          pOrdMsg(nullptr),
          dPrevOi(DBL_MIN),
          dTotalOi(DBL_MIN),
          iAuctionNumber(INT_MIN),
          lExcLowRange(LONG_MIN),
          lExcHighRange(LONG_MIN)
    {
    }

  } tsSecurityInfo;

  typedef struct DepthUnit
  {
    long lQty;
    double dPrice;
    long lNoOfOrders;

    DepthUnit()
        : lQty(LONG_MIN),
          dPrice(DBL_MIN),
          lNoOfOrders(LONG_MIN)
    {
    }
  } tsDepthUnit;

  typedef struct sMarketData
  {
    char *acExchSeg;      //[max: 6]
    char *acSymbol;       //[max: 16]
    char *acTradeTime;    //[max: 10]
    char *acExchFeedTime; //[max: 10]
    double dOpenPrice;
    double dHighPrice;
    double dLowPrice;
    double dClosePrice;
    double dTradePrice;
    double dPrevClose;
    double dLowPriceRange;
    double dHighPriceRange;
    double dAvgPrice;
    double dImpVolCM;
    double dImpVolFO;
    double dImpVolBuyCM;
    double dImpVolBuyFO;
    double dImpVolSellCM;
    double dImpVolSellFO;
    double dOpnInterest;
    double dHiOpenInterest;
    double dLowOpenInterest;
    long lTradeVolume;
    long lTotBuyQuan;
    long lTotSellQuan;
    long lLastTradeQty;
    long lYearlyHigh;
    long lYearlyLow;
    int iDepthSize;
    DepthUnit BestBuy[20];
    DepthUnit BestSell[20];
    double dPrevOi;
    double dTotalOi;
    char *acIssueDate;
    char *acListingDate;
    char *acNoDelStartDate;
    char *acNoDelEndDate;
    char *acBookClsStartDate;
    char *acBookClsEndDate;
    char *acRecordDate;
    char *acCreditRating;
    char *acReAdminDate;
    char *acExpulsionDate;
    char *acDeliveryUnits;
    char *acPriceUnits;
    char *acLastTradingDate;
    long lTenderPeridEndDate;
    long lTenderPeridStartDate;
    char *acInstrumentInfo;
    char *acRemarksText;
    char *acNav;
    char *acNavDate;
    char *acFaceValue;
    char *acTrdUnits;
    char *acExerciseStartDate;
    char *acExerciseEndDate;
    char *acElmMargin;
    char *acVarMargin;
    char *acScripBasePrice;
    char *acSettlementType;
    double dIssueCapital;
    double dExposureMargin;
    long lFreezeQty;
    char *acOrdMsg;
    int iAuctionNumber;
    long lExcLowRange;
    long lExcHighRange;

    sMarketData()
        : acExchSeg(nullptr),
          acSymbol(nullptr),
          acTradeTime(nullptr),
          acExchFeedTime(nullptr),
          dOpenPrice(DBL_MIN),
          dHighPrice(DBL_MIN),
          dLowPrice(DBL_MIN),
          dClosePrice(DBL_MIN),
          dTradePrice(DBL_MIN),
          dPrevClose(DBL_MIN),
          dLowPriceRange(DBL_MIN),
          dHighPriceRange(DBL_MIN),
          dAvgPrice(DBL_MIN),
          dImpVolCM(DBL_MIN),
          dImpVolFO(DBL_MIN),
          dImpVolBuyCM(DBL_MIN),
          dImpVolBuyFO(DBL_MIN),
          dImpVolSellCM(DBL_MIN),
          dImpVolSellFO(DBL_MIN),
          dOpnInterest(DBL_MIN),
          dHiOpenInterest(DBL_MIN),
          dLowOpenInterest(DBL_MIN),
          lTradeVolume(LONG_MIN),
          lTotBuyQuan(LONG_MIN),
          lTotSellQuan(LONG_MIN),
          lLastTradeQty(LONG_MIN),
          lYearlyHigh(LONG_MIN),
          lYearlyLow(LONG_MIN),
          iDepthSize(INT_MIN),
          dPrevOi(DBL_MIN),
          dTotalOi(DBL_MIN),
          acIssueDate(nullptr),
          acListingDate(nullptr),
          acNoDelStartDate(nullptr),
          acNoDelEndDate(nullptr),
          acBookClsStartDate(nullptr),
          acBookClsEndDate(nullptr),
          acRecordDate(nullptr),
          acCreditRating(nullptr),
          acReAdminDate(nullptr),
          acExpulsionDate(nullptr),
          acDeliveryUnits(nullptr),
          acPriceUnits(nullptr),
          acLastTradingDate(nullptr),
          lTenderPeridEndDate(LONG_MIN),
          lTenderPeridStartDate(LONG_MIN),
          acInstrumentInfo(nullptr),
          acRemarksText(nullptr),
          acNav(nullptr),
          acNavDate(nullptr),
          acFaceValue(nullptr),
          acTrdUnits(nullptr),
          acExerciseStartDate(nullptr),
          acExerciseEndDate(nullptr),
          acElmMargin(nullptr),
          acVarMargin(nullptr),
          acScripBasePrice(nullptr),
          acSettlementType(nullptr),
          dIssueCapital(DBL_MIN),
          dExposureMargin(DBL_MIN),
          lFreezeQty(LONG_MIN),
          acOrdMsg(nullptr),
          iAuctionNumber(INT_MIN),
          lExcLowRange(LONG_MIN),
          lExcHighRange(LONG_MIN)
    {
    }
  } tsMarketData;

  typedef struct sVwapData
  {
    char *pSymbol;  //[max: 16]
    char *pExchSeg; //[max: 6]
    long lDateTime; // 8 byte
    double dPrice;
    double dOpen;
    double dHigh;
    double dLow;
    double dVolume;
    double dOpenInterest;
    double dVwapCloseRate;
    double dVwap;
    int iPeriodicity;

    sVwapData()
        : pSymbol(nullptr),
          pExchSeg(nullptr),
          lDateTime(LONG_MIN),
          dPrice(DBL_MIN),
          dOpen(DBL_MIN),
          dHigh(DBL_MIN),
          dLow(DBL_MIN),
          dVolume(DBL_MIN),
          dOpenInterest(DBL_MIN),
          dVwapCloseRate(DBL_MIN),
          dVwap(DBL_MIN),
          iPeriodicity(INT_MIN)
    {
    }
  } tsVwapData;

  typedef struct sTopnValues
  {
    char *pTopnCriteria;
    char *pTopnBasket;
    char *pExchSeg;      //[max: 6]
    char *pSymbolTopn1;  //[max: 24]
    char *pSymbolTopn2;  //[max: 24]
    char *pSymbolTopn3;  //[max: 24]
    char *pSymbolTopn4;  //[max: 24]
    char *pSymbolTopn5;  //[max: 24]
    char *pSymbolTopn6;  //[max: 24]
    char *pSymbolTopn7;  //[max: 24]
    char *pSymbolTopn8;  //[max: 24]
    char *pSymbolTopn9;  //[max: 24]
    char *pSymbolTopn10; //[max: 24]
    char *pSymbolBotn1;  //[max: 24]
    char *pSymbolBotn2;  //[max: 24]
    char *pSymbolBotn3;  //[max: 24]
    char *pSymbolBotn4;  //[max: 24]
    char *pSymbolBotn5;  //[max: 24]
    char *pSymbolBotn6;  //[max: 24]
    char *pSymbolBotn7;  //[max: 24]
    char *pSymbolBotn8;  //[max: 24]
    char *pSymbolBotn9;  //[max: 24]
    char *pSymbolBotn10; //[max: 24]
    double dLTPTopn1;
    double dLTPTopn2;
    double dLTPTopn3;
    double dLTPTopn4;
    double dLTPTopn5;
    double dLTPTopn6;
    double dLTPTopn7;
    double dLTPTopn8;
    double dLTPTopn9;
    double dLTPTopn10;
    double dLTPBotn1;
    double dLTPBotn2;
    double dLTPBotn3;
    double dLTPBotn4;
    double dLTPBotn5;
    double dLTPBotn6;
    double dLTPBotn7;
    double dLTPBotn8;
    double dLTPBotn9;
    double dLTPBotn10;
    double dPrevCloseTopn1;
    double dPrevCloseTopn2;
    double dPrevCloseTopn3;
    double dPrevCloseTopn4;
    double dPrevCloseTopn5;
    double dPrevCloseTopn6;
    double dPrevCloseTopn7;
    double dPrevCloseTopn8;
    double dPrevCloseTopn9;
    double dPrevCloseTopn10;
    double dPrevCloseBotn1;
    double dPrevCloseBotn2;
    double dPrevCloseBotn3;
    double dPrevCloseBotn4;
    double dPrevCloseBotn5;
    double dPrevCloseBotn6;
    double dPrevCloseBotn7;
    double dPrevCloseBotn8;
    double dPrevCloseBotn9;
    double dPrevCloseBotn10;
    double dVolumeTopn1;
    double dVolumeTopn2;
    double dVolumeTopn3;
    double dVolumeTopn4;
    double dVolumeTopn5;
    double dVolumeTopn6;
    double dVolumeTopn7;
    double dVolumeTopn8;
    double dVolumeTopn9;
    double dVolumeTopn10;
    double dVolumeBotn1;
    double dVolumeBotn2;
    double dVolumeBotn3;
    double dVolumeBotn4;
    double dVolumeBotn5;
    double dVolumeBotn6;
    double dVolumeBotn7;
    double dVolumeBotn8;
    double dVolumeBotn9;
    double dVolumeBotn10;
    double dOITopn1;
    double dOITopn2;
    double dOITopn3;
    double dOITopn4;
    double dOITopn5;
    double dOITopn6;
    double dOITopn7;
    double dOITopn8;
    double dOITopn9;
    double dOITopn10;
    double dOIBotn1;
    double dOIBotn2;
    double dOIBotn3;
    double dOIBotn4;
    double dOIBotn5;
    double dOIBotn6;
    double dOIBotn7;
    double dOIBotn8;
    double dOIBotn9;
    double dOIBotn10;
    double dValueTopn1;
    double dValueTopn2;
    double dValueTopn3;
    double dValueTopn4;
    double dValueTopn5;
    double dValueTopn6;
    double dValueTopn7;
    double dValueTopn8;
    double dValueTopn9;
    double dValueTopn10;
    double dValueBotn1;
    double dValueBotn2;
    double dValueBotn3;
    double dValueBotn4;
    double dValueBotn5;
    double dValueBotn6;
    double dValueBotn7;
    double dValueBotn8;
    double dValueBotn9;
    double dValueBotn10;
    double dLTPChangePercTopn1;
    double dLTPChangePercTopn2;
    double dLTPChangePercTopn3;
    double dLTPChangePercTopn4;
    double dLTPChangePercTopn5;
    double dLTPChangePercTopn6;
    double dLTPChangePercTopn7;
    double dLTPChangePercTopn8;
    double dLTPChangePercTopn9;
    double dLTPChangePercTopn10;
    double dLTPChangePercBotn1;
    double dLTPChangePercBotn2;
    double dLTPChangePercBotn3;
    double dLTPChangePercBotn4;
    double dLTPChangePercBotn5;
    double dLTPChangePercBotn6;
    double dLTPChangePercBotn7;
    double dLTPChangePercBotn8;
    double dLTPChangePercBotn9;
    double dLTPChangePercBotn10;

    sTopnValues()
        : pTopnCriteria(nullptr),
          pTopnBasket(nullptr),
          pExchSeg(nullptr),
          pSymbolTopn1(nullptr),
          pSymbolTopn2(nullptr),
          pSymbolTopn3(nullptr),
          pSymbolTopn4(nullptr),
          pSymbolTopn5(nullptr),
          pSymbolTopn6(nullptr),
          pSymbolTopn7(nullptr),
          pSymbolTopn8(nullptr),
          pSymbolTopn9(nullptr),
          pSymbolTopn10(nullptr),
          pSymbolBotn1(nullptr),
          pSymbolBotn2(nullptr),
          pSymbolBotn3(nullptr),
          pSymbolBotn4(nullptr),
          pSymbolBotn5(nullptr),
          pSymbolBotn6(nullptr),
          pSymbolBotn7(nullptr),
          pSymbolBotn8(nullptr),
          pSymbolBotn9(nullptr),
          pSymbolBotn10(nullptr),
          dLTPTopn1(DBL_MIN),
          dLTPTopn2(DBL_MIN),
          dLTPTopn3(DBL_MIN),
          dLTPTopn4(DBL_MIN),
          dLTPTopn5(DBL_MIN),
          dLTPTopn6(DBL_MIN),
          dLTPTopn7(DBL_MIN),
          dLTPTopn8(DBL_MIN),
          dLTPTopn9(DBL_MIN),
          dLTPTopn10(DBL_MIN),
          dLTPBotn1(DBL_MIN),
          dLTPBotn2(DBL_MIN),
          dLTPBotn3(DBL_MIN),
          dLTPBotn4(DBL_MIN),
          dLTPBotn5(DBL_MIN),
          dLTPBotn6(DBL_MIN),
          dLTPBotn7(DBL_MIN),
          dLTPBotn8(DBL_MIN),
          dLTPBotn9(DBL_MIN),
          dLTPBotn10(DBL_MIN),
          dPrevCloseTopn1(DBL_MIN),
          dPrevCloseTopn2(DBL_MIN),
          dPrevCloseTopn3(DBL_MIN),
          dPrevCloseTopn4(DBL_MIN),
          dPrevCloseTopn5(DBL_MIN),
          dPrevCloseTopn6(DBL_MIN),
          dPrevCloseTopn7(DBL_MIN),
          dPrevCloseTopn8(DBL_MIN),
          dPrevCloseTopn9(DBL_MIN),
          dPrevCloseTopn10(DBL_MIN),
          dPrevCloseBotn1(DBL_MIN),
          dPrevCloseBotn2(DBL_MIN),
          dPrevCloseBotn3(DBL_MIN),
          dPrevCloseBotn4(DBL_MIN),
          dPrevCloseBotn5(DBL_MIN),
          dPrevCloseBotn6(DBL_MIN),
          dPrevCloseBotn7(DBL_MIN),
          dPrevCloseBotn8(DBL_MIN),
          dPrevCloseBotn9(DBL_MIN),
          dPrevCloseBotn10(DBL_MIN),
          dVolumeTopn1(DBL_MIN),
          dVolumeTopn2(DBL_MIN),
          dVolumeTopn3(DBL_MIN),
          dVolumeTopn4(DBL_MIN),
          dVolumeTopn5(DBL_MIN),
          dVolumeTopn6(DBL_MIN),
          dVolumeTopn7(DBL_MIN),
          dVolumeTopn8(DBL_MIN),
          dVolumeTopn9(DBL_MIN),
          dVolumeTopn10(DBL_MIN),
          dVolumeBotn1(DBL_MIN),
          dVolumeBotn2(DBL_MIN),
          dVolumeBotn3(DBL_MIN),
          dVolumeBotn4(DBL_MIN),
          dVolumeBotn5(DBL_MIN),
          dVolumeBotn6(DBL_MIN),
          dVolumeBotn7(DBL_MIN),
          dVolumeBotn8(DBL_MIN),
          dVolumeBotn9(DBL_MIN),
          dVolumeBotn10(DBL_MIN),
          dOITopn1(DBL_MIN),
          dOITopn2(DBL_MIN),
          dOITopn3(DBL_MIN),
          dOITopn4(DBL_MIN),
          dOITopn5(DBL_MIN),
          dOITopn6(DBL_MIN),
          dOITopn7(DBL_MIN),
          dOITopn8(DBL_MIN),
          dOITopn9(DBL_MIN),
          dOITopn10(DBL_MIN),
          dOIBotn1(DBL_MIN),
          dOIBotn2(DBL_MIN),
          dOIBotn3(DBL_MIN),
          dOIBotn4(DBL_MIN),
          dOIBotn5(DBL_MIN),
          dOIBotn6(DBL_MIN),
          dOIBotn7(DBL_MIN),
          dOIBotn8(DBL_MIN),
          dOIBotn9(DBL_MIN),
          dOIBotn10(DBL_MIN),
          dValueTopn1(DBL_MIN),
          dValueTopn2(DBL_MIN),
          dValueTopn3(DBL_MIN),
          dValueTopn4(DBL_MIN),
          dValueTopn5(DBL_MIN),
          dValueTopn6(DBL_MIN),
          dValueTopn7(DBL_MIN),
          dValueTopn8(DBL_MIN),
          dValueTopn9(DBL_MIN),
          dValueTopn10(DBL_MIN),
          dValueBotn1(DBL_MIN),
          dValueBotn2(DBL_MIN),
          dValueBotn3(DBL_MIN),
          dValueBotn4(DBL_MIN),
          dValueBotn5(DBL_MIN),
          dValueBotn6(DBL_MIN),
          dValueBotn7(DBL_MIN),
          dValueBotn8(DBL_MIN),
          dValueBotn9(DBL_MIN),
          dValueBotn10(DBL_MIN),
          dLTPChangePercTopn1(DBL_MIN),
          dLTPChangePercTopn2(DBL_MIN),
          dLTPChangePercTopn3(DBL_MIN),
          dLTPChangePercTopn4(DBL_MIN),
          dLTPChangePercTopn5(DBL_MIN),
          dLTPChangePercTopn6(DBL_MIN),
          dLTPChangePercTopn7(DBL_MIN),
          dLTPChangePercTopn8(DBL_MIN),
          dLTPChangePercTopn9(DBL_MIN),
          dLTPChangePercTopn10(DBL_MIN),
          dLTPChangePercBotn1(DBL_MIN),
          dLTPChangePercBotn2(DBL_MIN),
          dLTPChangePercBotn3(DBL_MIN),
          dLTPChangePercBotn4(DBL_MIN),
          dLTPChangePercBotn5(DBL_MIN),
          dLTPChangePercBotn6(DBL_MIN),
          dLTPChangePercBotn7(DBL_MIN),
          dLTPChangePercBotn8(DBL_MIN),
          dLTPChangePercBotn9(DBL_MIN),
          dLTPChangePercBotn10(DBL_MIN)
    {
    }
  } tsTopnValues;

  typedef struct sOrderParams
  {
    char *acExchSeg;      //[max: 6]
    char *acAccountId;    //[max: 16]
    char *acOrdDuration;  //[max: 5]
    char *acCustomerFirm; //[max: 2]
    char *acProduct;      //[max: 2]
    char *acOrderType;    //[max: 8]
    char *acTrdSymbol;    //[max: 24]
    char *acTransType;    //[max: 2]
    char *acGuiOrdId;     //[max: 32]
    char *acGuiOrgOrdId;  //[max: 32]
    char *acToken;        //[max: 16]
    double dPrice;
    double dTriggerPrice;
    long lQuantity;
    long lDiscQuantity;
    long lCancelledSize;
    char *acPan;  //[max: 12]
    char *acUser; //[max: 16]
    double dMktProtectionPrice;
    char *acVendorCode; //[max: 8]
    char *acOrdSrc;     //[max: 8]
    char *acOrdRemarks; //[max: ANY]
    int iBookProfitPrice;
    int iBookLossPrice;
    int iTrailingPrice;
    char *acSpreadTrdSymbol; //[max: 24]
    char *acSpreadToken;     //[max: 16]
    char *acExternalRemarks; //[max: 32]
    char *acAlgoName;        //[max: 32]
    int iSnoOrdType;
    char *acAlgoId;       //[max: 32]
    char *acAlgoCategory; //[max: 32]
    char *acIpAddr;
    char *acChannel;
    char *acUserAgent;
    char *acAppInstallId;
    char *acSrcUserId;
    int iAuctionNumber;
    int iLocationId;
    char *acExchUsrId;

    sOrderParams()
        : acExchSeg(nullptr),
          acAccountId(nullptr),
          acOrdDuration(nullptr),
          acCustomerFirm(nullptr),
          acProduct(nullptr),
          acOrderType(nullptr),
          acTrdSymbol(nullptr),
          acTransType(nullptr),
          acGuiOrdId(nullptr),
          acGuiOrgOrdId(nullptr),
          acToken(nullptr),
          dPrice(DBL_MIN),
          dTriggerPrice(DBL_MIN),
          lQuantity(LONG_MIN),
          lDiscQuantity(LONG_MIN),
          lCancelledSize(LONG_MIN),
          acPan(nullptr),
          acUser(nullptr),
          dMktProtectionPrice(DBL_MIN),
          acVendorCode(nullptr),
          acOrdSrc(nullptr),
          acOrdRemarks(nullptr),
          iBookProfitPrice(INT_MIN),
          iBookLossPrice(INT_MIN),
          iTrailingPrice(INT_MIN),
          acSpreadTrdSymbol(nullptr),
          acSpreadToken(nullptr),
          acExternalRemarks(nullptr),
          acAlgoName(nullptr),
          iSnoOrdType(INT_MIN),
          acAlgoId(nullptr),
          acAlgoCategory(nullptr),
          acIpAddr(nullptr),
          acChannel(nullptr),
          acUserAgent(nullptr),
          acAppInstallId(nullptr),
          acSrcUserId(nullptr),
          iAuctionNumber(INT_MIN),
          iLocationId(INT_MIN),
          acExchUsrId(nullptr)
    {
    }
  } tsOrderParams;

  typedef struct sModOrderParams
  {
    char *acNorenOrdNum; //[max: 16]
    char *acOrdDuration; //[max: 5]
    char *acOrderType;   //[max: 8]
    char *acGuiOrdId;    //[max: 32]
    char *acGuiOrgOrdId; //[max: 32]
    char *acToken;       //[max: 16]
    double dPrice;
    double dTriggerPrice;
    long lQuantity;
    long lDiscQuantity;
    double dMktProtectionPrice;
    char *acOrdSrc;  //[max: 8]
    char *acProduct; //[max: 2]
    int iBookProfitPrice;
    int iBookLossPrice;
    int iTrailingPrice;
    char *acExternalRemarks; //[max: 32]
    char *acIpAddr;
    char *acChannel;
    char *acUserAgent;
    char *acAppInstallId;

    sModOrderParams()
        : acNorenOrdNum(nullptr),
          acOrdDuration(nullptr),
          acOrderType(nullptr),
          acGuiOrdId(nullptr),
          acGuiOrgOrdId(nullptr),
          acToken(nullptr),
          dPrice(DBL_MIN),
          dTriggerPrice(DBL_MIN),
          lQuantity(LONG_MIN),
          lDiscQuantity(LONG_MIN),
          dMktProtectionPrice(DBL_MIN),
          acOrdSrc(nullptr),
          acProduct(nullptr),
          iBookProfitPrice(INT_MIN),
          iBookLossPrice(INT_MIN),
          iTrailingPrice(INT_MIN),
          acExternalRemarks(nullptr),
          acIpAddr(nullptr),
          acChannel(nullptr),
          acUserAgent(nullptr),
          acAppInstallId(nullptr)
    {
    }
  } tsModOrderParams;

  typedef struct sCanOrderParams
  {
    char *acNorenOrdNum;     //[max: 16]
    char *acGuiOrdId;        //[max: 32]
    char *acGuiOrgOrdId;     //[max: 32]
    char *acOrdSrc;          //[max: 8]
    char *acExternalRemarks; //[max: 32]
    char *acIpAddr;
    char *acChannel;
    char *acUserAgent;
    char *acAppInstallId;

    sCanOrderParams()
        : acNorenOrdNum(nullptr),
          acGuiOrdId(nullptr),
          acGuiOrgOrdId(nullptr),
          acOrdSrc(nullptr),
          acExternalRemarks(nullptr),
          acIpAddr(nullptr),
          acChannel(nullptr),
          acUserAgent(nullptr),
          acAppInstallId(nullptr)
    {
    }
  } tsCanOrderParams;

  typedef struct sMultiLegParams
  {
    char *acTrdSymbol_Leg2; //[max: 24]
    char *acTrdSymbol_Leg3; //[max: 24]
    char *acTransType_Leg2; //[max: 2]
    char *acTransType_Leg3; //[max: 2]
    char *acToken_Leg2;     //[max: 16]
    char *acToken_Leg3;     //[max: 16]
    double dPrice_Leg2;
    double dPrice_Leg3;
    long lQuantity_Leg2;
    long lQuantity_Leg3;
    long lDiscQuantity_Leg2;
    long lDiscQuantity_Leg3;

    sMultiLegParams()
        : acTrdSymbol_Leg2(nullptr),
          acTrdSymbol_Leg3(nullptr),
          acTransType_Leg2(nullptr),
          acTransType_Leg3(nullptr),
          acToken_Leg2(nullptr),
          acToken_Leg3(nullptr),
          dPrice_Leg2(DBL_MIN),
          dPrice_Leg3(DBL_MIN),
          lQuantity_Leg2(LONG_MIN),
          lQuantity_Leg3(LONG_MIN),
          lDiscQuantity_Leg2(LONG_MIN),
          lDiscQuantity_Leg3(LONG_MIN)
    {
    }
  } tsMultiLegParams;

  typedef struct sOrderUpdate
  {
    tsOrderParams sOrderParams;
    double dAvgPrice;
    long lFilledShares;
    long lUnfilledSize;
    char *acNorenOrdNum; //[max: 16]
    char *acReqId;       //[max: 3]
    char *acExchOrdId;   //[max: 16]
    char *acText;        //[max: ANY]
    char cStatus;
    char *acOrdStatus;       //[max: 24]
    char *acNorenUpdateTime; //[max: 24]
    long lNorenUpdateTimeEpoch;
    long lNorenUpdateTimeNanoSec;
    char *acExchTime; //[max: 24]
    long lExchTimeEpoch;
    long lExchTimeNanoSec;
    char *acOrgExchTime;  //[max: 11]
    char *acRejectionBy;  //[max: 16]
    char *acOrderGenType; //[max: 4]
    char *acSyomOrderId;  //[max: 16]
    char *acNorenTimeSec; //[max: 24]
    long lNorenTimeSecEpoch;
    char *acNorenTimeMiliSec; //[max: 4]
    long lNorenTimeNanoSec;
    char *acPan;        //[max: 12]
    char *acReportType; //[max: 24]
    char cRepTyp;
    char *acRejReason; //[max: ANY]
    long lRejQty;
    char *acRejOrdSrc;    //[max: 8]
    char *acRejPriceType; //[max: 8]
    double dRmsPrice;
    long lBasketId;
    char *acExchUsrInfo;
    char *acOrgOrdSrc;
    char *acRegion;
    char *acFamilyId;
    char *acExchUsrId;
    long lLineId;
    long lUnderlineId;

    sOrderUpdate()
        : dAvgPrice(DBL_MIN),
          lFilledShares(0),
          lUnfilledSize(0),
          acNorenOrdNum(nullptr),
          acReqId(nullptr),
          acExchOrdId(nullptr),
          acText(nullptr),
          cStatus(CHAR_MIN),
          acOrdStatus(nullptr),
          acNorenUpdateTime(nullptr),
          lNorenUpdateTimeEpoch(LONG_MIN),
          lNorenUpdateTimeNanoSec(LONG_MIN),
          acExchTime(nullptr),
          lExchTimeEpoch(LONG_MIN),
          lExchTimeNanoSec(LONG_MIN),
          acOrgExchTime(nullptr),
          acRejectionBy(nullptr),
          acOrderGenType(nullptr),
          acSyomOrderId(nullptr),
          acNorenTimeSec(nullptr),
          lNorenTimeSecEpoch(LONG_MIN),
          acNorenTimeMiliSec(nullptr),
          lNorenTimeNanoSec(LONG_MIN),
          acPan(nullptr),
          acReportType(nullptr),
          cRepTyp(CHAR_MIN),
          acRejReason(nullptr),
          lRejQty(0),
          acRejOrdSrc(nullptr),
          acRejPriceType(nullptr),
          dRmsPrice(DBL_MIN),
          lBasketId(LONG_MIN),
          acExchUsrInfo(nullptr),
          acOrgOrdSrc(nullptr),
          acRegion(nullptr),
          acFamilyId(nullptr),
          acExchUsrId(nullptr),
          lLineId(LONG_MIN),
          lUnderlineId(LONG_MIN)
    {
    }
  } tsOrderUpdate;

  typedef struct sMultiLegUpdate
  {
    tsMultiLegParams sMultiLegParams;
    short siLeg;
    double dAvgPrice_Leg2;
    double dAvgPrice_Leg3;
    long lFilledShares_Leg2;
    long lFilledShares_Leg3;
    long lUnfilledSize_Leg2;
    long lUnfilledSize_Leg3;

    sMultiLegUpdate()
        : siLeg(SHRT_MIN),
          dAvgPrice_Leg2(DBL_MIN),
          dAvgPrice_Leg3(DBL_MIN),
          lFilledShares_Leg2(0),
          lFilledShares_Leg3(0),
          lUnfilledSize_Leg2(0),
          lUnfilledSize_Leg3(0)
    {
    }
  } tsMultiLegUpdate;

  typedef struct sFillReport
  {
    double dFillPrice;
    short siFillLeg;
    long lFillSize;
    long lFilledShares;
    char *acOrdStatus; //[max: 24]
    char cStatus;
    char *acFillId;   //[max: 16]
    char *acSymbol;   //[max: 16]
    char *acExchTime; //[max: 24]
    long lExchTimeEpoch;
    long lExchTimeNanoSec;
    char *acNorenUpdateTime; //[max: 24]
    long lNorenUpdateTimeEpoch;
    long lNorenUpdateTimeNanoSec;
    char *acExchSeg;      //[max: 6]
    char *acGuiOrdId;     //[max: 32]
    char *acAccountId;    //[max: 16]
    char *acCustomerFirm; //[max: 2]
    char *acProduct;      //[max: 2]
    char *acTrdSymbol;    //[max: 24]
    char *acGuiOrgOrdId;  //[max: 32]
    char *acFillDate;     //[max: 12]
    char *acFillTime;     //[max: 24]
    char *acNorenOrdNum;  //[max: 16]
    char *acExchOrdId;    //[max: 16]
    char *acTransType;    //[max: 2]
    char *acReportType;   //[max: 24]
    char cRepTyp;
    char *acFillStatus;   //[max: 2]
    char *acPriceType;    //[max: 8]
    char *acUser;         //[max: 16]
    char *acOrderGenType; //[max: 4]
    char *acSyomOrderId;  //[max: 16]
    char *acNorenTimeSec; //[max: 24]
    long lNorenTimeSecEpoch;
    char *acNorenTimeMiliSec; //[max: 4]
    long lNorenTimeNanoSec;
    char *acPan; //[max: 12]
    long lQuantity;
    long lUnfilledSize;
    char *acOrdSrc; //[max: 8]
    char *acText;   //[max: ANY]
    int iBookProfitPrice;
    int iBookLossPrice;
    int iTrailingPrice;
    char *acExternalRemarks; //[max: 32]
    char *acAlgoName;        //[max: 32]
    int iSnoOrdType;
    char *acAlgoId;       //[max: 32]
    char *acAlgoCategory; //[max: 32]
    char *acSrcUserId;
    long lBasketId;
    char *acExchUsrInfo;
    char *acOrgOrdSrc;
    char *acRegion;
    char *acFamilyId;
    char *acExchUsrId;
    long lLineId;
    long lUnderlineId;

    sFillReport()
        : dFillPrice(DBL_MIN),
          siFillLeg(SHRT_MIN),
          lFillSize(LONG_MIN),
          lFilledShares(0),
          acOrdStatus(nullptr),
          cStatus(CHAR_MIN),
          acFillId(nullptr),
          acSymbol(nullptr),
          acExchTime(nullptr),
          lExchTimeEpoch(LONG_MIN),
          lExchTimeNanoSec(LONG_MIN),
          acNorenUpdateTime(nullptr),
          lNorenUpdateTimeEpoch(LONG_MIN),
          lNorenUpdateTimeNanoSec(LONG_MIN),
          acExchSeg(nullptr),
          acGuiOrdId(nullptr),
          acAccountId(nullptr),
          acCustomerFirm(nullptr),
          acProduct(nullptr),
          acTrdSymbol(nullptr),
          acGuiOrgOrdId(nullptr),
          acFillDate(nullptr),
          acFillTime(nullptr),
          acNorenOrdNum(nullptr),
          acExchOrdId(nullptr),
          acTransType(nullptr),
          acReportType(nullptr),
          cRepTyp(CHAR_MIN),
          acFillStatus(nullptr),
          acPriceType(nullptr),
          acUser(nullptr),
          acOrderGenType(nullptr),
          acSyomOrderId(nullptr),
          acNorenTimeSec(nullptr),
          lNorenTimeSecEpoch(LONG_MIN),
          acNorenTimeMiliSec(nullptr),
          lNorenTimeNanoSec(LONG_MIN),
          acPan(nullptr),
          lQuantity(LONG_MIN),
          lUnfilledSize(0),
          acOrdSrc(nullptr),
          acText(nullptr),
          iBookProfitPrice(INT_MIN),
          iBookLossPrice(INT_MIN),
          iTrailingPrice(INT_MIN),
          acExternalRemarks(nullptr),
          acAlgoName(nullptr),
          iSnoOrdType(INT_MIN),
          acAlgoId(nullptr),
          acAlgoCategory(nullptr),
          acSrcUserId(nullptr),
          lBasketId(LONG_MIN),
          acExchUsrInfo(nullptr),
          acOrgOrdSrc(nullptr),
          acRegion(nullptr),
          acFamilyId(nullptr),
          acExchUsrId(nullptr),
          lLineId(LONG_MIN),
          lUnderlineId(LONG_MIN)
    {
    }
  } tsFillReport;

  typedef struct sTradeReport
  {
    double dFillPrice;
    short siFillLeg;
    long lFillSize;
    char cStatus;
    char *acFillStatus; //[max: 24]
    char *acFillId;   //[max: 16]
    char *acSymbol;   //[max: 16]
    char *acExchTime; //[max: 24]
    long lExchTimeEpoch;
    long lExchTimeNanoSec;
    char *acNorenUpdateTime; //[max: 24]
    long lNorenUpdateTimeEpoch;
    long lNorenUpdateTimeNanoSec;
    char *acExchSeg;      //[max: 6]
    char *acGuiOrdId;     //[max: 32]
    char *acAccountId;    //[max: 16]
    char *acProduct;      //[max: 2]
    char *acTrdSymbol;    //[max: 24]
    char *acFillDate;     //[max: 12]
    char *acFillTime;     //[max: 24]
    char *acNorenOrdNum;  //[max: 16]
    char *acExchOrdId;    //[max: 16]
    char *acTransType;    //[max: 2]
    char *acPriceType;    //[max: 8]
    char *acUser;         //[max: 16]
    char *acPan; //[max: 12]
    char *acOrdSrc; //[max: 8]
    char *acText;   //[max: ANY]
    char *acSrcUserId;
    long lBasketId;
    char *acExchUsrInfo;
    char *acOrgOrdSrc;
    char *acRegion;
    char *acFamilyId;
    char *acExchUsrId;
    long lLineId;
    long lUnderlineId;

    sTradeReport()
        : dFillPrice(DBL_MIN),
          siFillLeg(SHRT_MIN),
          lFillSize(LONG_MIN),
          cStatus(CHAR_MIN),
          acFillStatus(nullptr),
          acFillId(nullptr),
          acSymbol(nullptr),
          acExchTime(nullptr),
          lExchTimeEpoch(LONG_MIN),
          lExchTimeNanoSec(LONG_MIN),
          acNorenUpdateTime(nullptr),
          lNorenUpdateTimeEpoch(LONG_MIN),
          lNorenUpdateTimeNanoSec(LONG_MIN),
          acExchSeg(nullptr),
          acGuiOrdId(nullptr),
          acAccountId(nullptr),
          acProduct(nullptr),
          acTrdSymbol(nullptr),
          acFillDate(nullptr),
          acFillTime(nullptr),
          acNorenOrdNum(nullptr),
          acExchOrdId(nullptr),
          acTransType(nullptr),
          acPriceType(nullptr),
          acUser(nullptr),
          acPan(nullptr),
          acOrdSrc(nullptr),
          acText(nullptr),
          acSrcUserId(nullptr),
          lBasketId(LONG_MIN),
          acExchUsrInfo(nullptr),
          acOrgOrdSrc(nullptr),
          acRegion(nullptr),
          acFamilyId(nullptr),
          acExchUsrId(nullptr),
          lLineId(LONG_MIN),
          lUnderlineId(LONG_MIN)
    {
    }
  } tsTradeReport;

  typedef struct sOrderHistory
  {
    tsOrderUpdate sOrderUpdate;
    tsMultiLegUpdate sMultiLegUpdate;
    double dPrice_Leg2;
    double dPrice_Leg3;
    char *acFillId;      //[max: 16]
    char *acSymbol;      //[max: 16]
    char *acFillTime;    //[max: 24]
    char *acInstName;    //[max: 8]
    char *acExpiryDate;  //[max: 12]
    char *acStrikePrice; //[max: 10]
    char *acOptionType;  //[max: 4]
    long lQuantity_Leg2;
    long lQuantity_Leg3;

    sOrderHistory()
        : dPrice_Leg2(DBL_MIN),
          dPrice_Leg3(DBL_MIN),
          acFillId(nullptr),
          acSymbol(nullptr),
          acFillTime(nullptr),
          acInstName(nullptr),
          acExpiryDate(nullptr),
          acStrikePrice(nullptr),
          acOptionType(nullptr),
          lQuantity_Leg2(LONG_MIN),
          lQuantity_Leg3(LONG_MIN)
    {
    }
  } tsOrderHistory;

  typedef struct sPartialPosConvParams
  {
    char *acAccountId;  //[max: 16]
    char *acTrdSymbol;  //[max: 24]
    char *acExchSeg;    //[max: 6]
    char *acOldProduct; //[max: 2]
    char *acNewProduct; //[max: 2]
    long lQuanToFill;
    int iMsgFlag;
    char *acOrderSrc;  //[max: 8]
    char *acSrcUserId; //[max: 16]

    sPartialPosConvParams()
        : acAccountId(nullptr),
          acTrdSymbol(nullptr),
          acExchSeg(nullptr),
          acOldProduct(nullptr),
          acNewProduct(nullptr),
          lQuanToFill(LONG_MIN),
          iMsgFlag(INT_MIN),
          acOrderSrc(nullptr),
          acSrcUserId(nullptr)
    {
    }
  } tsPartialPosConvParams;

  typedef struct sPosConvParams
  {
    char *acAccountId;  //[max: 16]
    char *acTrdSymbol;  //[max: 24]
    char *acExchSeg;    //[max: 6]
    char *acOldProduct; //[max: 2]
    char *acNewProduct; //[max: 2]
    long lQuanToFill;
    int iMsgFlag;
    char *acOrderSrc;  //[max: 8]
    char *acSrcUserId; //[max: 16]
    char *acToken;     //[max: 16]
    char *acBrokerId;  //[max: 16]
    double dPriceToFill;
    char *acTransType;      //[max: 2]
    char *acSegment;        //[max: 6]
    char *acInterOPKey;     //[max: 24]
    char *acInterOPExchSeg; //[max: 6]
    long lNorenTimeSec;
    long lNorenTimeNanoSec;

    sPosConvParams()
        : acAccountId(nullptr),
          acTrdSymbol(nullptr),
          acExchSeg(nullptr),
          acOldProduct(nullptr),
          acNewProduct(nullptr),
          lQuanToFill(LONG_MIN),
          iMsgFlag(INT_MIN),
          acOrderSrc(nullptr),
          acSrcUserId(nullptr),
          acToken(nullptr),
          acBrokerId(nullptr),
          dPriceToFill(DBL_MIN),
          acTransType(nullptr),
          acSegment(nullptr),
          acInterOPKey(nullptr),
          acInterOPExchSeg(nullptr),
          lNorenTimeSec(LONG_MIN),
          lNorenTimeNanoSec(LONG_MIN)
    {
    }
  } tsPosConvParams;

  typedef struct sPosData
  {
    char *pExchSeg;   //[max: 6]
    char *pSymbol;    //[max: 16]
    char *pAccId;     //[max: 16]
    char *pProduct;   //[max: 2]
    char *pTrdSymbol; //[max: 24]
    double dBuyQty;
    double dSellQty;
    double dBuyAmount;
    double dSellAmount;
    double dCfBuyQty;
    double dCfSellQty;
    double dCfBuyAmount;
    double dCfSellAmount;
    double dUploadPrice;
    long lUpdateTime;
    char *acInterOPKey;     //[max: 24]
    char *acInterOPExchSeg; //[max: 6]
    double dOpenBuyQty;
    double dOpenSellQty;
    double dOpenBuyAmount;
    double dOpenSellAmount;

    sPosData()
        : pExchSeg(nullptr),
          pSymbol(nullptr),
          pAccId(nullptr),
          pProduct(nullptr),
          pTrdSymbol(nullptr),
          dBuyQty(DBL_MIN),
          dSellQty(DBL_MIN),
          dBuyAmount(DBL_MIN),
          dSellAmount(DBL_MIN),
          dCfBuyQty(DBL_MIN),
          dCfSellQty(DBL_MIN),
          dCfBuyAmount(DBL_MIN),
          dCfSellAmount(DBL_MIN),
          dUploadPrice(DBL_MIN),
          lUpdateTime(LONG_MIN),
          acInterOPKey(nullptr),
          acInterOPExchSeg(nullptr),
          dOpenBuyQty(DBL_MIN),
          dOpenSellQty(DBL_MIN),
          dOpenBuyAmount(DBL_MIN),
          dOpenSellAmount(DBL_MIN)
    {
    }
  } tsPosData;

  struct sQueueLoad
  {
    int ORD;  // Order msgs queue
    int REQ;  // Bulk msgs queue
    int SREQ; // Single msg queue
  };

  /*   ----------------------------------------------------------------   */

  typedef struct sRmsLimits
  {
    char *pCategory; //[max: 16]
    char *pSegment;  //[max: 6]
    double dCollateralValue;
    double dCollateral;
    double dRmsCollateral;
    double dAdhocMargin;
    double dNotionalCash;
    double dCdsSpreadBenefit;
    double dAmountUtilizedPrsnt;
    double dUnrealizedMtomPrsnt;
    double dRealizedMtomPrsnt;
    double dExposureMarginPrsnt;
    double dSpanMarginPrsnt;
    double dNfospreadBenefit;
    double dPremiumPrsnt;
    double dMarginVarPrsnt;
    double dMarginScripBasketPrsnt;
    double dMtomWarningPrcntPrsnt;
    double dMarginWarningPrcntPrsnt;
    double dMtomSquareOffWarningPrcntPrsnt;
    double dMarginUsed;
    double dRmsPayInAmt;
    double dRmsPayOutAmt;
    double dNet;
    double dSpecialMarginPrsnt;
    double dDaneLimit;
    double dDeliveryMarginPresent;
    double dCncSellcrdPresent;
    double dCncBuyUsed;
    double dCollateralValueMult;
    double dAdhocLimitMult;
    double dRmsCollateralMult;
    double dNationalCashMult;
    double dComSpanMrgnNrmlPrsnt;
    double dComSpanMrgnMisPrsnt;
    double dComExpsrMrgnNrmlPrsnt;
    double dComExpsrMrgnMisPrsnt;
    double dAddMrgnNrmlPrsnt;
    double dAddMrgnMisPrsnt;
    double dAddPreExpMrgnNrmlPrsnt;
    double dAddPreExpMrgnMisPrsnt;
    double dSplMrgnNrmlPrsnt;
    double dSplMrgnMisPrsnt;
    double dTenderMrgnNrmlPrsnt;
    double dTenderMrgnMisPrsnt;
    double dDeliveryMrgnNrmlPrsnt;
    double dDeliveryMrgnMisPrsnt;
    double dCurExpMrgnNrmlPrsnt;
    double dCurExpMrgnMisPrsnt;
    double dCurPremiumNrmlPrsnt;
    double dCurPremiumMisPrsnt;
    double dCurSpanMrgnNrmlPrsnt;
    double dCurSpanMrgnMisPrsnt;
    double dFoPremiumNrmlPrsnt;
    double dFoPremiumMisPrsnt;
    double dFoExpMrgnNrmlPrsnt;
    double dFoExpMrgnMisPrsnt;
    double dFoSpanrgnNrmlPrsnt;
    double dFoSpanrgnMisPrsnt;
    double dMrgnScrpBsktNrmlPrsnt;
    double dMrgnScrpBsktMisPrsnt;
    double dMrgnScrpBsktCncPrsnt;
    double dMrgnVarNrmlPrsnt;
    double dMrgnVarMisPrsnt;
    double dAmtUntilizedPrsnt;
    double dCncMrgnVarPrsnt;
    double dMarginUsedPrsnt;
    double dAuxRmsCollateral;
    double dAuxAdhocMargin;
    double dAuxNotionalCash;
    double dAvailableMargin;
    double dBrokerage;
    double dMrgnProtection;
    double dFoPremium;
    double dCurPremium;
    double dComPremium;
    double dMtomCurrentPerc;
    double dMarginCurrentPerc;
    double dLiquidCashCollateral;
    double dMfCollateral;
    double dMfCashCollateral;
    double dAddMrgnPrsnt;
    double dTenderMrgnPrsnt;
    double dDeliveryMrgnPrsnt;
    double dBrokerageCnc;
    double dBrokerageMis;
    double dBrokerageNrml;
    double dBrokerageCO;
    double dBrokerageBO;
    double dFoBrokerageMis;
    double dFoBrokerageNrml;
    double dFoBrokerageCO;
    double dFoBrokerageBO;
    double dCurBrokerageMis;
    double dCurBrokerageNrml;
    double dCurBrokerageCO;
    double dCurBrokerageBO;
    double dComBrokerageMis;
    double dComBrokerageNrml;
    double dComBrokerageCO;
    double dComBrokerageBO;
    double dMrgnProtectionCO;
    double dMrgnProtectionBO;
    double dFoMrgnProtectionCO;
    double dFoMrgnProtectionBO;
    double dCurMrgnProtectionCO;
    double dCurMrgnProtectionBO;
    double dComMrgnProtectionCO;
    double dComMrgnProtectionBO;
    double dComPremiumMisPrsnt;
    double dComPremiumNrmlPrsnt;
    char *acExchSeg; //[max: 6]
    char *acProduct; //[max: 2]
    double dExchMrgn;
    double dFoExchMrgn;
    double dCurExchMrgn;
    double dComExchMrgn;
    double dExchMrgnSellCrd;
    double dExchMrgnT1SellCrd;
    double dAlloc;
    double dFoAlloc;
    double dCurAlloc;
    double dComAlloc;
    double dBlockAmt;
    char *acAcctId; //[max: 16]
    double dMtfLimit;
    double dSlbmLimit;
    double dRemarksAmt;

    sRmsLimits()
        : pCategory(nullptr),
          pSegment(nullptr),
          dCollateralValue(DBL_MIN),
          dCollateral(DBL_MIN),
          dRmsCollateral(DBL_MIN),
          dAdhocMargin(DBL_MIN),
          dNotionalCash(DBL_MIN),
          dCdsSpreadBenefit(DBL_MIN),
          dAmountUtilizedPrsnt(DBL_MIN),
          dUnrealizedMtomPrsnt(DBL_MIN),
          dRealizedMtomPrsnt(DBL_MIN),
          dExposureMarginPrsnt(DBL_MIN),
          dSpanMarginPrsnt(DBL_MIN),
          dNfospreadBenefit(DBL_MIN),
          dPremiumPrsnt(DBL_MIN),
          dMarginVarPrsnt(DBL_MIN),
          dMarginScripBasketPrsnt(DBL_MIN),
          dMtomWarningPrcntPrsnt(DBL_MIN),
          dMarginWarningPrcntPrsnt(DBL_MIN),
          dMtomSquareOffWarningPrcntPrsnt(DBL_MIN),
          dMarginUsed(DBL_MIN),
          dRmsPayInAmt(DBL_MIN),
          dRmsPayOutAmt(DBL_MIN),
          dNet(DBL_MIN),
          dSpecialMarginPrsnt(DBL_MIN),
          dDaneLimit(DBL_MIN),
          dDeliveryMarginPresent(DBL_MIN),
          dCncSellcrdPresent(DBL_MIN),
          dCncBuyUsed(DBL_MIN),
          dCollateralValueMult(DBL_MIN),
          dAdhocLimitMult(DBL_MIN),
          dRmsCollateralMult(DBL_MIN),
          dNationalCashMult(DBL_MIN),
          dComSpanMrgnNrmlPrsnt(DBL_MIN),
          dComSpanMrgnMisPrsnt(DBL_MIN),
          dComExpsrMrgnNrmlPrsnt(DBL_MIN),
          dComExpsrMrgnMisPrsnt(DBL_MIN),
          dAddMrgnNrmlPrsnt(DBL_MIN),
          dAddMrgnMisPrsnt(DBL_MIN),
          dAddPreExpMrgnNrmlPrsnt(DBL_MIN),
          dAddPreExpMrgnMisPrsnt(DBL_MIN),
          dSplMrgnNrmlPrsnt(DBL_MIN),
          dSplMrgnMisPrsnt(DBL_MIN),
          dTenderMrgnNrmlPrsnt(DBL_MIN),
          dTenderMrgnMisPrsnt(DBL_MIN),
          dDeliveryMrgnNrmlPrsnt(DBL_MIN),
          dDeliveryMrgnMisPrsnt(DBL_MIN),
          dCurExpMrgnNrmlPrsnt(DBL_MIN),
          dCurExpMrgnMisPrsnt(DBL_MIN),
          dCurPremiumNrmlPrsnt(DBL_MIN),
          dCurPremiumMisPrsnt(DBL_MIN),
          dCurSpanMrgnNrmlPrsnt(DBL_MIN),
          dCurSpanMrgnMisPrsnt(DBL_MIN),
          dFoPremiumNrmlPrsnt(DBL_MIN),
          dFoPremiumMisPrsnt(DBL_MIN),
          dFoExpMrgnNrmlPrsnt(DBL_MIN),
          dFoExpMrgnMisPrsnt(DBL_MIN),
          dFoSpanrgnNrmlPrsnt(DBL_MIN),
          dFoSpanrgnMisPrsnt(DBL_MIN),
          dMrgnScrpBsktNrmlPrsnt(DBL_MIN),
          dMrgnScrpBsktMisPrsnt(DBL_MIN),
          dMrgnScrpBsktCncPrsnt(DBL_MIN),
          dMrgnVarNrmlPrsnt(DBL_MIN),
          dMrgnVarMisPrsnt(DBL_MIN),
          dAmtUntilizedPrsnt(DBL_MIN),
          dCncMrgnVarPrsnt(DBL_MIN),
          dMarginUsedPrsnt(DBL_MIN),
          dAuxRmsCollateral(DBL_MIN),
          dAuxAdhocMargin(DBL_MIN),
          dAuxNotionalCash(DBL_MIN),
          dAvailableMargin(DBL_MIN),
          dBrokerage(DBL_MIN),
          dMrgnProtection(DBL_MIN),
          dFoPremium(DBL_MIN),
          dCurPremium(DBL_MIN),
          dComPremium(DBL_MIN),
          dMtomCurrentPerc(DBL_MIN),
          dMarginCurrentPerc(DBL_MIN),
          dLiquidCashCollateral(DBL_MIN),
          dMfCollateral(DBL_MIN),
          dMfCashCollateral(DBL_MIN),
          dAddMrgnPrsnt(DBL_MIN),
          dTenderMrgnPrsnt(DBL_MIN),
          dDeliveryMrgnPrsnt(DBL_MIN),
          dBrokerageCnc(DBL_MIN),
          dBrokerageMis(DBL_MIN),
          dBrokerageNrml(DBL_MIN),
          dBrokerageCO(DBL_MIN),
          dBrokerageBO(DBL_MIN),
          dFoBrokerageMis(DBL_MIN),
          dFoBrokerageNrml(DBL_MIN),
          dFoBrokerageCO(DBL_MIN),
          dFoBrokerageBO(DBL_MIN),
          dCurBrokerageMis(DBL_MIN),
          dCurBrokerageNrml(DBL_MIN),
          dCurBrokerageCO(DBL_MIN),
          dCurBrokerageBO(DBL_MIN),
          dComBrokerageMis(DBL_MIN),
          dComBrokerageNrml(DBL_MIN),
          dComBrokerageCO(DBL_MIN),
          dComBrokerageBO(DBL_MIN),
          dMrgnProtectionCO(DBL_MIN),
          dMrgnProtectionBO(DBL_MIN),
          dFoMrgnProtectionCO(DBL_MIN),
          dFoMrgnProtectionBO(DBL_MIN),
          dCurMrgnProtectionCO(DBL_MIN),
          dCurMrgnProtectionBO(DBL_MIN),
          dComMrgnProtectionCO(DBL_MIN),
          dComMrgnProtectionBO(DBL_MIN),
          dComPremiumMisPrsnt(DBL_MIN),
          dComPremiumNrmlPrsnt(DBL_MIN),
          acExchSeg(nullptr),
          acProduct(nullptr),
          dExchMrgn(DBL_MIN),
          dFoExchMrgn(DBL_MIN),
          dCurExchMrgn(DBL_MIN),
          dComExchMrgn(DBL_MIN),
          dExchMrgnSellCrd(DBL_MIN),
          dExchMrgnT1SellCrd(DBL_MIN),
          dAlloc(DBL_MIN),
          dFoAlloc(DBL_MIN),
          dCurAlloc(DBL_MIN),
          dComAlloc(DBL_MIN),
          dBlockAmt(DBL_MIN),
          acAcctId(nullptr),
          dMtfLimit(DBL_MIN),
          dSlbmLimit(DBL_MIN),
          dRemarksAmt(DBL_MIN)
    {
    }
  } tsRmsLimits;

  typedef struct sRiskDasBoard
  {
    char *acAcctId; //[max: 16]
    double dTotalCash;
    double dTotalMtoM;
    double dMtoMWarningPercentage;
    double dMtoMWarningIncrPercentage;
    double dMtoMSqrOffPercentage;
    char *acProfileName; //[max: 16]
    double dMtoMWarningFollowPercentage;
    double dTotalMarginCash;
    double dTotalMargin;
    double dMarginWarningPercentage;
    double dMarginWarningIncrPercentage;
    double dMarginSqrOffPercentage;
    double dMarginCurrentPercentage;
    double dMarginWarningFollowPercentage;
    double dMarginUsed;
    double dSpan;
    double dSpanDerIntraday;
    double dExposure;
    double dExposureDerIntraday;
    double dTurnOver;
    double dPeakMargin;
    double dExpiryMargin;
    double dCollateralValue;
    double dNotionalCash;
    double dCollateral;
    double dRmsPayInAmt;
    double dRealizedMtomPrsnt;
    double dUnrealizedMtomPrsnt;
    double dPremiumPrsnt;
    double dCncBuyUsed;
    double dCncSellcrdPresent;
    double dAddMrgnNrmlPrsnt;
    double dTenderMrgnNrmlPrsnt;
    double dSplMrgnNrmlPrsnt;
    double dDeliveryMarginPresent;
    double dMarginScripBasketPrsnt;
    double dMrgnProtection;
    double dFoPremium;
    double dCurPremium;
    double dComPremium;
    double dMtomCurrentPerc;
    double dLiquidCashCollateral;
    double dMfCollateral;
    double dMfCashCollateral;
    double dExchMrgn;
    double dFoExchMrgn;
    double dCurExchMrgn;
    double dComExchMrgn;
    double dExchMrgnSellCrd;
    double dExchMrgnT1SellCrd;
    double dAlloc;
    double dFoAlloc;
    double dCurAlloc;
    double dComAlloc;
    double dBlockAmt;
    char *acNorenUpdateTime; //[max: 24]
    long lNorenUpdateTimeEpoch;
    long lNorenUpdateTimeNanoSec;
    double dRemarksAmt;

    sRiskDasBoard()
        : acAcctId(nullptr),
          dTotalCash(DBL_MIN),
          dTotalMtoM(DBL_MIN),
          dMtoMWarningPercentage(DBL_MIN),
          dMtoMWarningIncrPercentage(DBL_MIN),
          dMtoMSqrOffPercentage(DBL_MIN),
          acProfileName(nullptr),
          dMtoMWarningFollowPercentage(DBL_MIN),
          dTotalMarginCash(DBL_MIN),
          dTotalMargin(DBL_MIN),
          dMarginWarningPercentage(DBL_MIN),
          dMarginWarningIncrPercentage(DBL_MIN),
          dMarginSqrOffPercentage(DBL_MIN),
          dMarginCurrentPercentage(DBL_MIN),
          dMarginWarningFollowPercentage(DBL_MIN),
          dMarginUsed(DBL_MIN),
          dSpan(DBL_MIN),
          dSpanDerIntraday(DBL_MIN),
          dExposure(DBL_MIN),
          dExposureDerIntraday(DBL_MIN),
          dTurnOver(DBL_MIN),
          dPeakMargin(DBL_MIN),
          dExpiryMargin(DBL_MIN),
          dCollateralValue(DBL_MIN),
          dNotionalCash(DBL_MIN),
          dCollateral(DBL_MIN),
          dRmsPayInAmt(DBL_MIN),
          dRealizedMtomPrsnt(DBL_MIN),
          dUnrealizedMtomPrsnt(DBL_MIN),
          dPremiumPrsnt(DBL_MIN),
          dCncBuyUsed(DBL_MIN),
          dCncSellcrdPresent(DBL_MIN),
          dAddMrgnNrmlPrsnt(DBL_MIN),
          dTenderMrgnNrmlPrsnt(DBL_MIN),
          dSplMrgnNrmlPrsnt(DBL_MIN),
          dDeliveryMarginPresent(DBL_MIN),
          dMarginScripBasketPrsnt(DBL_MIN),
          dMrgnProtection(DBL_MIN),
          dFoPremium(DBL_MIN),
          dCurPremium(DBL_MIN),
          dComPremium(DBL_MIN),
          dMtomCurrentPerc(DBL_MIN),
          dLiquidCashCollateral(DBL_MIN),
          dMfCollateral(DBL_MIN),
          dMfCashCollateral(DBL_MIN),
          dExchMrgn(DBL_MIN),
          dFoExchMrgn(DBL_MIN),
          dCurExchMrgn(DBL_MIN),
          dComExchMrgn(DBL_MIN),
          dExchMrgnSellCrd(DBL_MIN),
          dExchMrgnT1SellCrd(DBL_MIN),
          dAlloc(DBL_MIN),
          dFoAlloc(DBL_MIN),
          dCurAlloc(DBL_MIN),
          dComAlloc(DBL_MIN),
          dBlockAmt(DBL_MIN),
          acNorenUpdateTime(nullptr),
          lNorenUpdateTimeEpoch(LONG_MIN),
          lNorenUpdateTimeNanoSec(LONG_MIN),
          dRemarksAmt(DBL_MIN)
    {
    }
  } tsRiskDasBoard;

  typedef struct sM2MAlert
  {
    char *acAcctId; //[max: 16]
    int iAlertType;
    char *acText; //[max: ANY]

    sM2MAlert()
        : acAcctId(nullptr),
          iAlertType(INT_MIN),
          acText(nullptr)
    {
    }
  } tsM2MAlert;

  typedef struct sLimitUpdatesParams
  {
    char *acAcctId;      //[max: 16]
    char *acProfileName; //[max: 16]
    char *acSegment;     //[max: 6]
    char *acExchSeg;     //[max: 6]
    char *acProduct;     //[max: 2]
    double dCollateralValue;
    double dRmsPayInAmt;
    double dRmsPayOutAmt;
    double dAdhocMargin;
    double dNotionalCash;
    double dRmsCollateral;
    double dBlockAmt;

    sLimitUpdatesParams()
        : acAcctId(nullptr),
          acProfileName(nullptr),
          acSegment(nullptr),
          acExchSeg(nullptr),
          acProduct(nullptr),
          dCollateralValue(DBL_MIN),
          dRmsPayInAmt(DBL_MIN),
          dRmsPayOutAmt(DBL_MIN),
          dAdhocMargin(DBL_MIN),
          dNotionalCash(DBL_MIN),
          dRmsCollateral(DBL_MIN),
          dBlockAmt(DBL_MIN)
    {
    }
  } tsLimitUpdatesParams;

  typedef struct sFundsUpdatesParams
  {
    char *acAcctId;    //[max: 16]
    char *acSrcUserId; //[max: 16]
    char *acBrokerId;  //[max: 16]
    long lTranRefNumber;
    double dAmount;
    char *acRemarks;  //[max: ANY]
    char *acBankName; //[max: ANY]
    char *acSegment;  //[max: 6]
    char *acExchSeg;  //[max: 6]
    char *acProduct;  //[max: 2]

    sFundsUpdatesParams()
        : acAcctId(nullptr),
          acSrcUserId(nullptr),
          acBrokerId(nullptr),
          lTranRefNumber(LONG_MIN),
          dAmount(DBL_MIN),
          acRemarks(nullptr),
          acBankName(nullptr),
          acSegment(nullptr),
          acExchSeg(nullptr),
          acProduct(nullptr)
    {
    }
  } tsFundsUpdatesParams;

  typedef struct sAddHoldings
  {
    char *acAccountId; //[max: 16]
    char *acProduct;   //[max: 2]
    int iExchSegSize;
    char **ppExchSeg; //[max: 6]
    int iTokenSize;
    char **ppToken;   //[max: 16]
    char *acUserId;   //[max: 16]
    char *acBrokerId; //[max: 16]
    double dQuantity;
    double dCollateralQty;
    double dBrokerCollateralQty;
    double dDpHoldQty;
    double dBenfHoldQty;
    double dUnplgdHoldQty;
    int iCollateralMode;
    double dHairCut;
    double dClosePrice;
    bool bIsCollateral;
    double dBrokerHairCut;
    double dUploadPrice;
    char *acInterOPKey;     //[max: 24]
    char *acInterOPExchSeg; //[max: 6]

    sAddHoldings()
        : acAccountId(nullptr),
          acProduct(nullptr),
          iExchSegSize(INT_MIN),
          ppExchSeg(nullptr),
          iTokenSize(INT_MIN),
          ppToken(nullptr),
          acUserId(nullptr),
          acBrokerId(nullptr),
          dQuantity(DBL_MIN),
          dCollateralQty(DBL_MIN),
          dBrokerCollateralQty(DBL_MIN),
          dDpHoldQty(DBL_MIN),
          dBenfHoldQty(DBL_MIN),
          dUnplgdHoldQty(DBL_MIN),
          iCollateralMode(INT_MIN),
          dHairCut(DBL_MIN),
          dClosePrice(DBL_MIN),
          bIsCollateral(false),
          dBrokerHairCut(DBL_MIN),
          dUploadPrice(DBL_MIN),
          acInterOPKey(nullptr),
          acInterOPExchSeg(nullptr)
    {
    }
  } tsAddHoldings;

  typedef struct sModHoldings
  {
    char *acAccountId; //[max: 16]
    char *acProduct;   //[max: 2]
    int iExchSegSize;
    char **ppExchSeg; //[max: 6]
    int iTokenSize;
    char **ppToken;   //[max: 16]
    char *acUserId;   //[max: 16]
    char *acBrokerId; //[max: 16]
    double dQuantity;
    double dCollateralQty;
    double dBrokerCollateralQty;
    double dDpHoldQty;
    double dBenfHoldQty;
    double dUnplgdHoldQty;
    char *acInterOPKey;     //[max: 24]
    char *acInterOPExchSeg; //[max: 6]

    sModHoldings()
        : acAccountId(nullptr),
          acProduct(nullptr),
          iExchSegSize(INT_MIN),
          ppExchSeg(nullptr),
          iTokenSize(INT_MIN),
          ppToken(nullptr),
          acUserId(nullptr),
          acBrokerId(nullptr),
          dQuantity(DBL_MIN),
          dCollateralQty(DBL_MIN),
          dBrokerCollateralQty(DBL_MIN),
          dDpHoldQty(DBL_MIN),
          dBenfHoldQty(DBL_MIN),
          dUnplgdHoldQty(DBL_MIN),
          acInterOPKey(nullptr),
          acInterOPExchSeg(nullptr)
    {
    }
  } tsModHoldings;

  typedef struct sViewHoldings
  {
    char *pExchSeg1;       //[max: 6]
    char *pExchSeg2;       //[max: 6]
    char *pExchSeg3;       //[max: 6]
    char *pToken1;         //[max: 16]
    char *pToken2;         //[max: 16]
    char *pToken3;         //[max: 16]
    char *pAccountId;      //[max: 16]
    char *pProduct;        //[max: 2]
    char *pCollateralType; // 0 ->close price , 1->LTP ,2 ->WC
    double dClosePrice;
    double dUploadPrice;
    double dT1UploadPrice;
    double dHairCut;
    double dCollateralQty;
    double dCollUpdateQty;
    double dHoldUpdateQty;
    double dWithheldHoldQty;
    double dQty;
    double dUsedQty;
    double dT1Qty;
    double dNpoaQty;
    double dT1NpoaQty;
    double dUnplgdQty;
    double dEQTCollUpdateQty;
    double dCOMCollUpdateQty;
    double dBrokerHairCut;
    bool bIsCollateral;
    double dEpiQty;
    char *acInterOPKey;     //[max: 24]
    char *acInterOPExchSeg; //[max: 6]

    sViewHoldings()
        : pExchSeg1(nullptr),
          pExchSeg2(nullptr),
          pExchSeg3(nullptr),
          pToken1(nullptr),
          pToken2(nullptr),
          pToken3(nullptr),
          pAccountId(nullptr),
          pProduct(nullptr),
          pCollateralType(nullptr), // 0 ->close price , 1->LTP ,2 ->WC
          dClosePrice(DBL_MIN),
          dUploadPrice(DBL_MIN),
          dT1UploadPrice(DBL_MIN),
          dHairCut(DBL_MIN),
          dCollateralQty(DBL_MIN),
          dCollUpdateQty(DBL_MIN),
          dHoldUpdateQty(DBL_MIN),
          dWithheldHoldQty(DBL_MIN),
          dQty(DBL_MIN),
          dUsedQty(DBL_MIN),
          dT1Qty(DBL_MIN),
          dNpoaQty(DBL_MIN),
          dT1NpoaQty(DBL_MIN),
          dUnplgdQty(DBL_MIN),
          dEQTCollUpdateQty(DBL_MIN),
          dCOMCollUpdateQty(DBL_MIN),
          dBrokerHairCut(DBL_MIN),
          bIsCollateral(false),
          dEpiQty(DBL_MIN),
          acInterOPKey(nullptr),
          acInterOPExchSeg(nullptr)
    {
    }
  } tsViewHoldings;
  typedef struct sAbsIsinHoldings
  {
    char *acAccountId; //[max: 16]
    char *acProduct;   //[max: 2]
    char *acUserId;   //[max: 16]
    char *acBrokerId; //[max: 16]
    double dQuantity;
    double dCollateralQty;
    double dBrokerCollateralQty;
    double dDpHoldQty;
    double dBenfHoldQty;
    double dUnplgdHoldQty;
    int iCollateralMode;
    double dHairCut;
    double dClosePrice;
    double dBrokerHairCut;
    double dUploadPrice;
    double dEqtBrokerCollateralQty;
    double dDerBrokerCollateralQty;
    double dFxBrokerCollateralQty;
    double dComBrokerCollateralQty;
    double dEpiQty;
    char *acIsin;

    sAbsIsinHoldings()
        : acAccountId(nullptr),
          acProduct(nullptr),
          acUserId(nullptr),
          acBrokerId(nullptr),
          dQuantity(DBL_MIN),
          dCollateralQty(DBL_MIN),
          dBrokerCollateralQty(DBL_MIN),
          dDpHoldQty(DBL_MIN),
          dBenfHoldQty(DBL_MIN),
          dUnplgdHoldQty(DBL_MIN),
          iCollateralMode(INT_MIN),
          dHairCut(DBL_MIN),
          dClosePrice(DBL_MIN),
          dBrokerHairCut(DBL_MIN),
          dUploadPrice(DBL_MIN),
          dEqtBrokerCollateralQty(DBL_MIN),
          dDerBrokerCollateralQty(DBL_MIN),
          dFxBrokerCollateralQty(DBL_MIN),
          dComBrokerCollateralQty(DBL_MIN),
          dEpiQty(DBL_MIN),
          acIsin(nullptr)
    {
    }
  } tsAbsIsinHoldings;

  typedef struct sOrderMargin
  {
    char *acAcctId;    //[max: 16]
    char *acExchSeg;   //[max: 6]
    char *acTransType; //[max: 2]
    char *acProduct;   //[max: 2]
    char *acToken;     //[max: 16]
    long lQtyToFill;
    long lOrgQty;
    char *acPriceType; //[max: 8]
    long lPriceToFill;
    long lOrgPrice;
    long lTotalFillQty;
    long lTriggerPrice;
    char *acSrcUserId;   //[max: 16]
    char *acSrcBrokerId; //[max: 16]
    long lOrderNumber;
    long lSNOOrderNumber;
    int iSNOOrderType;
    int iOrgBLPrice;
    int iBLPrice;
    long lOrgTriggerPrice;
    char *acInterOPKey;     //[max: 24]
    char *acInterOPExchSeg; //[max: 6]
    char *acRmsSegment;     //[max: 6]
    char *acRmsExchSeg;     //[max: 6]
    char *acRmsProduct;     //[max: 2]

    sOrderMargin()
        : acAcctId(nullptr),
          acExchSeg(nullptr),
          acTransType(nullptr),
          acProduct(nullptr),
          acToken(nullptr),
          lQtyToFill(LONG_MIN),
          lOrgQty(LONG_MIN),
          acPriceType(nullptr),
          lPriceToFill(LONG_MIN),
          lOrgPrice(LONG_MIN),
          lTotalFillQty(LONG_MIN),
          lTriggerPrice(LONG_MIN),
          acSrcUserId(nullptr),
          acSrcBrokerId(nullptr),
          lOrderNumber(LONG_MIN),
          lSNOOrderNumber(LONG_MIN),
          iSNOOrderType(INT_MIN),
          iOrgBLPrice(INT_MIN),
          iBLPrice(INT_MIN),
          lOrgTriggerPrice(LONG_MIN),
          acInterOPKey(nullptr),
          acInterOPExchSeg(nullptr),
          acRmsSegment(nullptr),
          acRmsExchSeg(nullptr),
          acRmsProduct(nullptr)
    {
    }
  } tsOrderMargin;

  typedef struct sBasketList
  {
    char *acExchSeg;   //[max: 6]
    char *acTransType; //[max: 2]
    char *acProduct;   //[max: 2]
    char *acToken;     //[max: 16]
    long lQtyToFill;
    char *acPriceType; //[max: 8]
    long lPriceToFill;
    long lTriggerPrice;
    char *acInterOPKey;     //[max: 24]
    char *acInterOPExchSeg; //[max: 6]

    sBasketList()
        : acExchSeg(nullptr),
          acTransType(nullptr),
          acProduct(nullptr),
          acToken(nullptr),
          lQtyToFill(LONG_MIN),
          acPriceType(nullptr),
          lPriceToFill(LONG_MIN),
          lTriggerPrice(LONG_MIN),
          acInterOPKey(nullptr),
          acInterOPExchSeg(nullptr)
    {
    }
  } tsBasketList;

  typedef struct sBasketMargin
  {
    char *acAcctId;    //[max: 16]
    char *acExchSeg;   //[max: 6]
    char *acTransType; //[max: 2]
    char *acProduct;   //[max: 2]
    char *acToken;     //[max: 16]
    long lQtyToFill;
    long lOrgQty;
    char *acPriceType; //[max: 8]
    long lPriceToFill;
    long lOrgPrice;
    long lTotalFillQty;
    long lTriggerPrice;
    char *acSrcUserId;   //[max: 16]
    char *acSrcBrokerId; //[max: 16]
    long lOrderNumber;
    long lSNOOrderNumber;
    int iSNOOrderType;
    int iOrgBLPrice;
    int iBLPrice;
    long lOrgTriggerPrice;
    char *acInterOPKey;     //[max: 24]
    char *acInterOPExchSeg; //[max: 6]
    sBasketList List[50];
    int iListSize;

    sBasketMargin()
        : acAcctId(nullptr),
          acExchSeg(nullptr),
          acTransType(nullptr),
          acProduct(nullptr),
          acToken(nullptr),
          lQtyToFill(LONG_MIN),
          lOrgQty(LONG_MIN),
          acPriceType(nullptr),
          lPriceToFill(LONG_MIN),
          lOrgPrice(LONG_MIN),
          lTotalFillQty(LONG_MIN),
          lTriggerPrice(LONG_MIN),
          acSrcUserId(nullptr),
          acSrcBrokerId(nullptr),
          lOrderNumber(LONG_MIN),
          lSNOOrderNumber(LONG_MIN),
          iSNOOrderType(INT_MIN),
          iOrgBLPrice(INT_MIN),
          iBLPrice(INT_MIN),
          lOrgTriggerPrice(LONG_MIN),
          acInterOPKey(nullptr),
          acInterOPExchSeg(nullptr),
          iListSize(0)
    {
    }
  } tsBasketMargin;

  typedef struct sIpoPlaceOrderParams
  {
    char *acTrdSymbol;    //[max: 24]
    char *acExchSeg;      //[max: 6]
    char *acTransType;    //[max: 2]
    char *acOrderType;    //[max: 8]
    char *acProduct;      //[max: 2]
    char *acOrdDuration;  //[max: 5]
    char *acAccountId;    //[max: 16]
    char *acUser;         //[max: 16]
    char *acOrdSrc;       //[max: 8]
    char *acCustomerFirm; //[max: 2]
    long lQuantity;
    long lDiscQuantity;
    double dPrice;
    char *acParticId; //[max: 16]
    long lQuantityLeg2;
    double dPriceLeg2;
    long lQuantityLeg3;
    double dPriceLeg3;
    int iOrdLeg;
    char *acPurchaseType; //[max: 8]
    char *acEuin;
    char *acIpAddr;          //[max: 16]
    char *acOrderRemarks;    //[max: ANY]
    char *acGuiOrdId;        //[max: 32]
    char *acExternalRemarks; //[max: 32]
    char *acAlgoName;        //[max: 32]
    char *acAlgoId;          //[max: 32]
    char *acAlgoCategory;    //[max: 32]

    sIpoPlaceOrderParams()
        : acTrdSymbol(nullptr),
          acExchSeg(nullptr),
          acTransType(nullptr),
          acOrderType(nullptr),
          acProduct(nullptr),
          acOrdDuration(nullptr),
          acAccountId(nullptr),
          acUser(nullptr),
          acOrdSrc(nullptr),
          acCustomerFirm(nullptr),
          lQuantity(LONG_MIN),
          lDiscQuantity(LONG_MIN),
          dPrice(DBL_MIN),
          acParticId(nullptr),
          lQuantityLeg2(LONG_MIN),
          dPriceLeg2(DBL_MIN),
          lQuantityLeg3(LONG_MIN),
          dPriceLeg3(DBL_MIN),
          iOrdLeg(INT_MIN),
          acPurchaseType(nullptr),
          acEuin(nullptr),
          acIpAddr(nullptr),
          acOrderRemarks(nullptr),
          acGuiOrdId(nullptr),
          acExternalRemarks(nullptr),
          acAlgoName(nullptr),
          acAlgoId(nullptr),
          acAlgoCategory(nullptr)
    {
    }
  } tsIpoPlaceOrderParams;

  typedef struct sIpoModOrderParams
  {
    char *acNorenOrdNum;  //[max: 16]
    char *acOrderRemarks; //[max: ANY]
    char *acUser;         //[max: 16]
    char *acOrdSrc;       //[max: 8]
    char *acOrderType;    //[max: 8]
    char *acOrdDuration;  //[max: 5]
    long lQuantity;
    double dPrice;
    long lQuantityLeg2;
    double dPriceLeg2;
    long lQuantityLeg3;
    double dPriceLeg3;
    char *acGuiOrdId;        //[max: 32]
    char *acExternalRemarks; //[max: 32]

    sIpoModOrderParams()
        : acNorenOrdNum(nullptr),
          acOrderRemarks(nullptr),
          acUser(nullptr),
          acOrdSrc(nullptr),
          acOrderType(nullptr),
          acOrdDuration(nullptr),
          lQuantity(LONG_MIN),
          dPrice(DBL_MIN),
          lQuantityLeg2(LONG_MIN),
          dPriceLeg2(DBL_MIN),
          lQuantityLeg3(LONG_MIN),
          dPriceLeg3(DBL_MIN),
          acGuiOrdId(nullptr),
          acExternalRemarks(nullptr)
    {
    }
  } tsIpoModOrderParams;

  typedef struct sIpoCanOrderParams
  {
    char *acNorenOrdNum;     //[max: 16]
    char *acOrderRemarks;    //[max: ANY]
    char *acUser;            //[max: 16]
    char *acOrdSrc;          //[max: 8]
    char *acOrderType;       //[max: 8]
    char *acOrdDuration;     //[max: 5]
    char *acGuiOrdId;        //[max: 32]
    char *acExternalRemarks; //[max: 32]

    sIpoCanOrderParams()
        : acNorenOrdNum(nullptr),
          acOrderRemarks(nullptr),
          acUser(nullptr),
          acOrdSrc(nullptr),
          acOrderType(nullptr),
          acOrdDuration(nullptr),
          acGuiOrdId(nullptr),
          acExternalRemarks(nullptr)
    {
    }
  } tsIpoCanOrderParams;

  typedef struct sIpoList
  {
    char *pSymbolName; //[max: 24]
    int iLotSize;
    char *pCompanyName; //[max: ANY]
    char *pInstName;    //[max: 8]
    int iMinLotSize;
    long lFaceValue;
    long lUprCkt;
    long lLwrCkt;
    int iTickSize;
    char *pStartDate;   //[max: 12]
    char *pEndDate;     //[max: 12]
    char *pStartTime;   //[max: 10]
    char *pEndTime;     //[max: 10]
    char *pSeries;      //[max: 8]
    char *pAppStartNum; //[max: 16]
    char *pAppEndNum;   //[max: 16]
    char *pCurAppNum;   //[max: 16]
    char *pCategoryList;
    char *pISIN;            //[max: 16]
    char *pCategoryName;    //[max: 6]
    char *pCatStartTime;    //[max: 10]
    char *pCatEndTime;      //[max: 10]
    char *pDiscountValue;   //[max: 16]
    char *pDiscountPercent; //[max: 16]

    sIpoList()
        : pSymbolName(nullptr),
          iLotSize(INT_MIN),
          pCompanyName(nullptr),
          pInstName(nullptr),
          iMinLotSize(INT_MIN),
          lFaceValue(LONG_MIN),
          lUprCkt(LONG_MIN),
          lLwrCkt(LONG_MIN),
          iTickSize(INT_MIN),
          pStartDate(nullptr),
          pEndDate(nullptr),
          pStartTime(nullptr),
          pEndTime(nullptr),
          pSeries(nullptr),
          pAppStartNum(nullptr),
          pAppEndNum(nullptr),
          pCurAppNum(nullptr),
          pCategoryList(nullptr),
          pISIN(nullptr),
          pCategoryName(nullptr),
          pCatStartTime(nullptr),
          pCatEndTime(nullptr),
          pDiscountValue(nullptr),
          pDiscountPercent(nullptr)
    {
    }
  } tsIpoList;

  typedef struct sIpoOrdBook
  {
    tsOrderUpdate sOrderUpdate;
    tsMultiLegUpdate sMultiLegUpdate;
    long lRejectionQty;
    char *acRejectionOrdSrc;    //[max: 8]
    char *acRejectionPriceType; //[max: 8]
    char *acPurchaseType;       //[max: 8]
    char *acDpTrans;            //[max: 16]
    char *acFolioNum;           //[max: 16]
    char *acEuin;
    char *acIpAddr; //[max: 16]

    sIpoOrdBook()
        : lRejectionQty(LONG_MIN),
          acRejectionOrdSrc(nullptr),
          acRejectionPriceType(nullptr),
          acPurchaseType(nullptr),
          acDpTrans(nullptr),
          acFolioNum(nullptr),
          acEuin(nullptr),
          acIpAddr(nullptr)
    {
    }
  } tsIpoOrdBook;

  typedef struct sMfPlaceOrderParams
  {
    char *acTrdSymbol;    //[max: 24]
    char *acExchSeg;      //[max: 6]
    char *acTransType;    //[max: 2]
    char *acOrderType;    //[max: 8]
    char *acProduct;      //[max: 2]
    char *acOrdDuration;  //[max: 5]
    char *acAccountId;    //[max: 16]
    char *acUser;         //[max: 16]
    char *acOrdSrc;       //[max: 8]
    char *acCustomerFirm; //[max: 2]
    long lQuantity;
    long lDiscQuantity;
    double dPrice;
    char *acOrderRemarks;    //[max: ANY]
    char *acPurchaseType;    //[max: 8]
    char *acGuiOrdId;        //[max: 32]
    char *acExternalRemarks; //[max: 32]
    char *acAlgoName;        //[max: 32]
    char *acAlgoId;          //[max: 32]
    char *acAlgoCategory;    //[max: 32]

    sMfPlaceOrderParams()
        : acTrdSymbol(nullptr),
          acExchSeg(nullptr),
          acTransType(nullptr),
          acOrderType(nullptr),
          acProduct(nullptr),
          acOrdDuration(nullptr),
          acAccountId(nullptr),
          acUser(nullptr),
          acOrdSrc(nullptr),
          acCustomerFirm(nullptr),
          lQuantity(LONG_MIN),
          lDiscQuantity(LONG_MIN),
          dPrice(DBL_MIN),
          acOrderRemarks(nullptr),
          acPurchaseType(nullptr),
          acGuiOrdId(nullptr),
          acExternalRemarks(nullptr),
          acAlgoName(nullptr),
          acAlgoId(nullptr),
          acAlgoCategory(nullptr)
    {
    }
  } tsMfPlaceOrderParams;

  typedef struct sMfModOrderParams
  {
    char *acNorenOrdNum;  //[max: 16]
    char *acOrderRemarks; //[max: ANY]
    char *acUser;         //[max: 16]
    char *acOrdSrc;       //[max: 8]
    char *acOrderType;    //[max: 8]
    char *acOrdDuration;  //[max: 5]
    long lQuantity;
    double dPrice;
    char *acGuiOrdId;        //[max: 32]
    char *acExternalRemarks; //[max: 32]

    sMfModOrderParams()
        : acNorenOrdNum(nullptr),
          acOrderRemarks(nullptr),
          acUser(nullptr),
          acOrdSrc(nullptr),
          acOrderType(nullptr),
          acOrdDuration(nullptr),
          lQuantity(LONG_MIN),
          dPrice(DBL_MIN),
          acGuiOrdId(nullptr),
          acExternalRemarks(nullptr)
    {
    }
  } tsMfModOrderParams;

  typedef struct sMfCanOrderParams
  {
    char *acNorenOrdNum;     //[max: 16]
    char *acUser;            //[max: 16]
    char *acOrdSrc;          //[max: 8]
    char *acGuiOrdId;        //[max: 32]
    char *acExternalRemarks; //[max: 32]

    sMfCanOrderParams()
        : acNorenOrdNum(nullptr),
          acUser(nullptr),
          acOrdSrc(nullptr),
          acGuiOrdId(nullptr),
          acExternalRemarks(nullptr)
    {
    }
  } tsMfCanOrderParams;

  typedef struct sMfOrdBook
  {
    tsOrderUpdate sOrderUpdate;
    long lRejectionQty;
    char *acRejectionOrdSrc;
    char *acRejectionPriceType;
    char *acPurchaseType; //[max: 8]
    char *acDpTrans;
    char *acStreamId;
    bool bKycStatus;
    bool bAllRedeem;

    sMfOrdBook()
        : lRejectionQty(LONG_MIN),
          acRejectionOrdSrc(nullptr),
          acRejectionPriceType(nullptr),
          acPurchaseType(nullptr),
          acDpTrans(nullptr),
          acStreamId(nullptr),
          bKycStatus(false),
          bAllRedeem(false)
    {
    }
  } tsMfOrdBook;

  typedef struct sGTTParams
  {
    tsOrderParams sOrderParams;
    char *acAlName;       //[max: 16]
    char *acExchSeg;      //[max: 6]
    char *acToken;        //[max: 16]
    char *acVariableName; //[max: 2]
    long lVariableValue;
    char *acValidity;    //[max: 6]
    char *acGTTid;       //[max: 16]
    char *acRemarksText; //[max: ANY]
    char *acTrdSymbol;   //[max: 24]
    int iMultiplier;
    int iPrecision;
    char *acSrcUserId;   //[max: 16]
    char *acSrcBrokerId; //[max: 16]
    char *acStatus;      //[max: 16]
    long lUpdateTime;
    long lUpdateTimeNanoSec;

    sGTTParams()
        : acAlName(nullptr),
          acExchSeg(nullptr),
          acToken(nullptr),
          acVariableName(nullptr),
          lVariableValue(LONG_MIN),
          acValidity(nullptr),
          acGTTid(nullptr),
          acRemarksText(nullptr),
          acTrdSymbol(nullptr),
          iMultiplier(INT_MIN),
          iPrecision(INT_MIN),
          acSrcUserId(nullptr),
          acSrcBrokerId(nullptr),
          acStatus(nullptr),
          lUpdateTime(LONG_MIN),
          lUpdateTimeNanoSec(LONG_MIN)
    {
    }
  } tsGTTParams;

  typedef struct sOCOParams
  {
    tsOrderParams sOrderParamsLeg1;
    tsOrderParams sOrderParamsLeg2;
    char *acAlName;           //[max: 16]
    char *acExchSeg;          //[max: 6]
    char *acToken;            //[max: 16]
    char *acVariableNameLeg1; //[max: 1]
    long lVariableValueLeg1;
    char *acVariableNameLeg2; //[max: 1]
    long lVariableValueLeg2;
    char *acValidity;    //[max: 5]
    char *acOCOid;       //[max: 16]
    char *acRemarksText; //[max: ANY]
    char *acTrdSymbol;   //[max: 24]
    int iMultiplier;
    int iPrecision;
    char *acSrcUserId;   //[max: 16]
    char *acSrcBrokerId; //[max: 16]
    char *acStatus;      //[max: 16]
    long lUpdateTime;
    long lUpdateTimeNanoSec;

    sOCOParams()
        : acAlName(nullptr),
          acExchSeg(nullptr),
          acToken(nullptr),
          acVariableNameLeg1(nullptr),
          lVariableValueLeg1(LONG_MIN),
          acVariableNameLeg2(nullptr),
          lVariableValueLeg2(LONG_MIN),
          acValidity(nullptr),
          acOCOid(nullptr),
          acRemarksText(nullptr),
          acTrdSymbol(nullptr),
          iMultiplier(INT_MIN),
          iPrecision(INT_MIN),
          acSrcUserId(nullptr),
          acSrcBrokerId(nullptr),
          acStatus(nullptr),
          lUpdateTime(LONG_MIN),
          lUpdateTimeNanoSec(LONG_MIN)
    {
    }
  } tsOCOParams;

  typedef struct sGTTUpdateParams
  {
    char *acType;        //[max: 5]
    char *acStatus;      //[max: 10]
    char *acRemarksText; //[max: ANY]
    char *acExchSeg;     //[max: 6]
    char *acTrdSymbol;   //[max: 24]
    char *acGTTid;       //[max: 16]
    char *acSrcUserId;   //[max: 16]

    sGTTUpdateParams()
        : acType(nullptr),
          acStatus(nullptr),
          acRemarksText(nullptr),
          acExchSeg(nullptr),
          acTrdSymbol(nullptr),
          acGTTid(nullptr),
          acSrcUserId(nullptr)
    {
    }
  } tsGTTUpdateParams;

  typedef struct sSipScripParams
  {
    char *acExchSeg;   //[max: 6]
    char *acToken;     //[max: 16]
    char *acTrdSymbol; //[max: 24]
    char *acProduct;   //[max: 2]
    double dPrice;
    long lQuantity;

    sSipScripParams()
        : acExchSeg(nullptr),
          acToken(nullptr),
          acTrdSymbol(nullptr),
          acProduct(nullptr),
          dPrice(DBL_MIN),
          lQuantity(LONG_MIN)
    {
    }
  } tsSipScripParams;

  typedef struct sSipOrderParams
  {
    tsSipScripParams *pSipScripParams;
    int iScripParamSize;
    char *acAcctId;   //[max: 16]
    char *acUser;     //[max: 16]
    char *acBrokerId; //[max: 16]
    long lRegDate;
    long lStartDate;
    int iFrequency;
    int iEndPeriod;
    char *acSipName;

    sSipOrderParams()
        : pSipScripParams(nullptr),
          iScripParamSize(INT_MIN),
          acAcctId(nullptr),
          acUser(nullptr),
          acBrokerId(nullptr),
          lRegDate(LONG_MIN),
          lStartDate(LONG_MIN),
          iFrequency(INT_MIN),
          iEndPeriod(INT_MIN),
          acSipName(nullptr)
    {
    }
  } tsSipOrderParams;

  typedef struct sSipOrderUpdate
  {
    tsSipOrderParams sSipOrderParams;
    long lPrevExecDate;
    long lDueDate;
    long lExecDate;
    long lSipId;
    int iPeriod;
    char *acSipState; //[max: 8]

    sSipOrderUpdate()
        : lPrevExecDate(LONG_MIN),
          lDueDate(LONG_MIN),
          lExecDate(LONG_MIN),
          lSipId(LONG_MIN),
          iPeriod(INT_MIN),
          acSipState(nullptr)
    {
    }
  } tsSipOrderUpdate;

  typedef struct sMasterMsgParams
  {
    char *acMsgString;
    char *acRecoPrice;
    char *acStopPrice;
    char *acProfitPrice;
    char *acDisclaimerString;
    char *acUserId;
    long lDateTime;
    char *acRemarks;
    char *acSubType;
    int iMsgType;
    char *acExchSeg;   //[max: 6]
    char *acTrdSymbol; //[max: 24]
    char *acTransType; //[max: 2]

    sMasterMsgParams()
        : acMsgString(nullptr),
          acRecoPrice(nullptr),
          acStopPrice(nullptr),
          acProfitPrice(nullptr),
          acDisclaimerString(nullptr),
          acUserId(nullptr),
          lDateTime(LONG_MIN),
          acRemarks(nullptr),
          acSubType(nullptr),
          iMsgType(INT_MIN),
          acExchSeg(nullptr),
          acTrdSymbol(nullptr),
          acTransType(nullptr)
    {
    }
  } tsMasterMsgParams;

  typedef struct sGetBrokerageParams
  {
    char *acTrdSymbol; //[max: 24]
    char *acTransType; //[max: 2]
    char *acExchSeg;   //[max: 6]
    int iLotSize;
    char *acInstName; //[max: 8]
    long lQtyToFill;
    long lPriceToFill;
    char *acAcctId;  //[max: 16]
    char *acProduct; //[max: 2]
    char *acSegment; //[max: 6]
    long lStrikePrice;
    long lMultiplier;
    long lPrecision;
    long lQty_Precision;
    double dPriceMultiplier;

    sGetBrokerageParams()
        : acTrdSymbol(nullptr),
          acTransType(nullptr),
          acExchSeg(nullptr),
          iLotSize(INT_MIN),
          acInstName(nullptr),
          lQtyToFill(LONG_MIN),
          lPriceToFill(LONG_MIN),
          acAcctId(nullptr),
          acProduct(nullptr),
          acSegment(nullptr),
          lStrikePrice(LONG_MIN),
          lMultiplier(LONG_MIN),
          lPrecision(LONG_MIN),
          lQty_Precision(LONG_MIN),
          dPriceMultiplier(DBL_MIN)
    {
    }
  } tsGetBrokerageParams;

  typedef struct sBrokerageRespParams
  {
    long lBrokerage;
    long lSttCtt;
    long lExchangeCharge;
    long lSebiCharge;
    long lGST;
    long lStampDuty;
    char *acRemarks; //[max: ANY]
    char *acUrl;     //[max: ANY]
    long lIpftChargesAmt;
    long lCmChargesAmt;

    sBrokerageRespParams()
        : lBrokerage(LONG_MIN),
          lSttCtt(LONG_MIN),
          lExchangeCharge(LONG_MIN),
          lSebiCharge(LONG_MIN),
          lGST(LONG_MIN),
          lStampDuty(LONG_MIN),
          acRemarks(nullptr),
          acUrl(nullptr),
          lIpftChargesAmt(LONG_MIN),
          lCmChargesAmt(LONG_MIN)
    {
    }
  } tsBrokerageRespParams;

  typedef struct sPayinStatusRespParams
  {
    long lTranRefNumber;
    char *pAccountId;
    char *pTranStatus;
    char *pUser;
    char *pVendor;
    double dAmt;
    char *pBankName;
    char *pBankActNum;
    char *pBankRefNum;
    long lNorenTimeStamp;

    sPayinStatusRespParams()
        : lTranRefNumber(LONG_MIN),
          pAccountId(nullptr),
          pTranStatus(nullptr),
          pUser(nullptr),
          pVendor(nullptr),
          dAmt(DBL_MIN),
          pBankName(nullptr),
          pBankActNum(nullptr),
          pBankRefNum(nullptr),
          lNorenTimeStamp(LONG_MIN)
    {
    }
  } tsPayinStatusRespParams, tsPayoutStatusRespParams;

  typedef struct sAQParams
  {
    tsOrderParams sOrderParams;
    char *acToken;
    long lBpPrice;
    long lTrialPrice;
    long lIceberg_leg;
    long lAQ_ID;
    long lUpdateTrialPrice;
    long lPendingQty;
    char* acOrdStatus;
    int iStatus;
    char* acAlgoName;
    char* acRejReason;
    long lLeg1TradeQty;
    long lLeg1TradePrc;
    char* acSrcUserId;
    char* acBrokerId;
    sAQParams()
        : acToken(nullptr),
          lBpPrice(LONG_MIN),
          lTrialPrice(LONG_MIN),
          lIceberg_leg(LONG_MIN),
          lAQ_ID(LONG_MIN),
          lUpdateTrialPrice(LONG_MIN),
          lPendingQty(LONG_MIN),
          acOrdStatus(nullptr),
          iStatus(INT_MIN),
          acAlgoName(nullptr),
          acRejReason(nullptr),
          lLeg1TradeQty(LONG_MIN),
          lLeg1TradePrc(LONG_MIN),
          acSrcUserId(nullptr),
          acBrokerId(nullptr)
    {
    }
  } tsAQParams;

  typedef struct sCallbackErrorParams
  {
    ErrorCode ErrCode;
    ApiRequest Api;

    sCallbackErrorParams()
    {
    }
  } tsCallbackErrorParams;

  typedef struct sFundsReportParams
  {
    char *acAccountId;
    long lTranRefNumber;
    double dAmount;
    char *acRemarks;
    char *acBankName;
    char *acBankAcctNo;
    char *acBankIFSCcode;
    char *acBrokerId;
    char *acSegment;
    char *acExchSeg;
    char *acProduct;
    long lInitTimeStamp;
    long lNorenTimeStamp;
    char *acTranStatus;

    sFundsReportParams()
        : acAccountId(nullptr),
          lTranRefNumber(LONG_MIN),
          dAmount(DBL_MIN),
          acRemarks(nullptr),
          acBankName(nullptr),
          acBankAcctNo(nullptr),
          acBankIFSCcode(nullptr),
          acBrokerId(nullptr),
          acSegment(nullptr),
          acExchSeg(nullptr),
          acProduct(nullptr),
          lInitTimeStamp(LONG_MIN),
          lNorenTimeStamp(LONG_MIN),
          acTranStatus(nullptr)
    {
    }
  } tsFundsReportParams;

  typedef struct sSqrOffEntityParams
  {
    char *acAccountId;
    char *acExchSeg;
    char *acProduct;
    char *acToken;
    char *acSrcUserId;
    char *acSrcBrokerId;
    int iMktInd;
    int iLocationId;
    long lQty;
    long lPrice;
    double dMktProtectionPercentage;

    sSqrOffEntityParams()
        : acAccountId(nullptr),
          acExchSeg(nullptr),
          acProduct(nullptr),
          acToken(nullptr),
          acSrcUserId(nullptr),
          acSrcBrokerId(nullptr),
          iMktInd(INT_MIN),
          iLocationId(INT_MIN),
          lQty(LONG_MIN),
          lPrice(LONG_MIN),
          dMktProtectionPercentage(DBL_MIN)
    {
    }
  } tsSqrOffEntityParams;

  typedef struct sAuctionSymbolsParams
  {
    char *pSymbol;
    char *pExchSeg;
    char *pInstType;
    char *pSymbolName;
    char *pTrdSymbol;
    char *pISIN;
    char *pDesc;
    double dTickSize;
    long lLotSize;
    char *pScripUniqKey;
    int iMsgFlag;
    char *pSegment;
    char *pInterOPKey;
    char *pInterOPExchSeg;
    double dTradePrice;
    double dAskPrice1;
    double dBidPrice1;
    long lAskSize1;
    long lBidSize1;
    long lAskNumOfOrders1;
    long lBidNumOfOrders1;
    double dHighPriceRange;
    double dLowPriceRange;
    long lTotBuyQuan;
    long lTotSellQuan;
    int iAuctionNumber;

    sAuctionSymbolsParams()
        : pSymbol(nullptr),
          pExchSeg(nullptr),
          pInstType(nullptr),
          pSymbolName(nullptr),
          pTrdSymbol(nullptr),
          pISIN(nullptr),
          pDesc(nullptr),
          dTickSize(DBL_MIN),
          lLotSize(LONG_MIN),
          pScripUniqKey(nullptr),
          iMsgFlag(INT_MIN),
          pSegment(nullptr),
          pInterOPKey(nullptr),
          pInterOPExchSeg(nullptr),
          dTradePrice(DBL_MIN),
          dAskPrice1(DBL_MIN),
          dBidPrice1(DBL_MIN),
          lAskSize1(LONG_MIN),
          lBidSize1(LONG_MIN),
          lAskNumOfOrders1(LONG_MIN),
          lBidNumOfOrders1(LONG_MIN),
          dHighPriceRange(DBL_MIN),
          dLowPriceRange(DBL_MIN),
          lTotBuyQuan(LONG_MIN),
          lTotSellQuan(LONG_MIN),
          iAuctionNumber(INT_MIN)
    {
    }
  } tsAuctionSymbolsParams;

  typedef struct sOfsPlaceOrderParams
  {
    char *acTrdSymbol;    //[max: 24]
    char *acExchSeg;      //[max: 6]
    char *acTransType;    //[max: 2]
    char *acOrderType;    //[max: 8]
    char *acProduct;      //[max: 2]
    char *acOrdDuration;  //[max: 5]
    char *acAccountId;    //[max: 16]
    char *acUser;         //[max: 16]
    char *acOrdSrc;       //[max: 8]
    char *acCustomerFirm; //[max: 2]
    long lQuantity;
    double dPrice;
    char *acIpAddr;          //[max: 16]
    char *acOrderRemarks;    //[max: ANY]
    char *acChannel;
    char *acUserAgent;
    char *acAppInstallId;
    char *acGuiOrdId;        //[max: 32]
    char *acExternalRemarks;    //[max: ANY]

    sOfsPlaceOrderParams()
        : acTrdSymbol(nullptr),
          acExchSeg(nullptr),
          acTransType(nullptr),
          acOrderType(nullptr),
          acProduct(nullptr),
          acOrdDuration(nullptr),
          acAccountId(nullptr),
          acUser(nullptr),
          acOrdSrc(nullptr),
          acCustomerFirm(nullptr),
          lQuantity(LONG_MIN),
          dPrice(DBL_MIN),
          acIpAddr(nullptr),
          acOrderRemarks(nullptr),      
          acChannel(nullptr),
          acUserAgent(nullptr),
          acAppInstallId(nullptr),
          acGuiOrdId(nullptr),
          acExternalRemarks(nullptr)
    {
    }
  } tsOfsPlaceOrderParams;

  typedef struct sOfsModOrderParams
  {
    char *acNorenOrdNum;  //[max: 16]
    char *acUser;         //[max: 16]
    char *acOrdSrc;       //[max: 8]
    char *acOrderType;    //[max: 8]
    char *acOrdDuration;  //[max: 5]
    long lQuantity;
    double dPrice;
    char *acChannel;
    char *acUserAgent;
    char *acAppInstallId;
    char *acGuiOrdId;        //[max: 32]
    char *acExternalRemarks; //[max: 32]

    sOfsModOrderParams()
        : acNorenOrdNum(nullptr),
          acUser(nullptr),
          acOrdSrc(nullptr),
          acOrderType(nullptr),
          acOrdDuration(nullptr),
          lQuantity(LONG_MIN),
          dPrice(DBL_MIN),
          acChannel(nullptr),
          acUserAgent(nullptr),
          acAppInstallId(nullptr),
          acGuiOrdId(nullptr),
          acExternalRemarks(nullptr)
    {
    }
  } tsOfsModOrderParams;

  typedef struct sOfsCanOrderParams
  {
    char *acNorenOrdNum;     //[max: 16]
    char *acUser;            //[max: 16]
    char *acOrdSrc;          //[max: 8]
    char *acChannel;
    char *acUserAgent;
    char *acAppInstallId;
    char *acGuiOrdId;        //[max: 32]
    char *acExternalRemarks; //[max: 32]

    sOfsCanOrderParams()
        : acNorenOrdNum(nullptr),
          acUser(nullptr),
          acOrdSrc(nullptr),
          acChannel(nullptr),
          acUserAgent(nullptr),
          acAppInstallId(nullptr),
          acGuiOrdId(nullptr),
          acExternalRemarks(nullptr)
    {
    }
  } tsOfsCanOrderParams;

  typedef struct sOfsOrderBook
  {
    char *acExchSeg;      //[max: 6]
    char *acAccountId;    //[max: 16]
    char *acOrdDuration;  //[max: 5]
    char *acCustomerFirm; //[max: 2]
    char *acProduct;      //[max: 2]
    char *acOrderType;    //[max: 8]
    char *acTrdSymbol;    //[max: 24]
    char *acTransType;    //[max: 2]
    char *acGuiOrdId;     //[max: 32]
    char *acGuiOrgOrdId;  //[max: 32]
    char *acToken;        //[max: 16]
    double dPrice;
    long lQuantity;
    long lDiscQuantity;
    char *acPan;  //[max: 12]
    char *acUser; //[max: 16]
    char *acVendorCode; //[max: 8]
    char *acOrdSrc;     //[max: 8]
    char *acOrdRemarks; //[max: ANY]
    char *acIpAddr;
    char *acNorenOrdNum; //[max: 16]
    char *acReqId;       //[max: 3]
    char *acExchOrdId;   //[max: 16]
    char cStatus;
    char *acOrdStatus;       //[max: 24]
    char *acNorenUpdateTime; //[max: 24]
    long lNorenUpdateTimeEpoch;
    long lNorenUpdateTimeNanoSec;
    char *acExchTime; //[max: 24]
    long lExchTimeEpoch;
    long lExchTimeNanoSec;
    char *acOrgExchTime;  //[max: 11]
    char *acRejectionBy;  //[max: 16]
    char *acNorenTimeSec; //[max: 24]
    long lNorenTimeSecEpoch;
    char *acNorenTimeMiliSec; //[max: 4]
    long lNorenTimeNanoSec;
    char *acReportType; //[max: 24]
    char cRepTyp;
    char *acRejReason; //[max: ANY]
    long lRejQty;
    char *acRejOrdSrc;    //[max: 8]
    char *acRejPriceType; //[max: 8]
    char *acRegion;
    char *acFamilyId;
    char *acExchUsrId;
    char *acBrokerId;

    sOfsOrderBook()
        : acExchSeg(nullptr),
          acAccountId(nullptr),
          acOrdDuration(nullptr),
          acCustomerFirm(nullptr),
          acProduct(nullptr),
          acOrderType(nullptr),
          acTrdSymbol(nullptr),
          acTransType(nullptr),
          acGuiOrdId(nullptr),
          acGuiOrgOrdId(nullptr),
          acToken(nullptr),
          dPrice(DBL_MIN),
          lQuantity(LONG_MIN),
          lDiscQuantity(LONG_MIN),
          acPan(nullptr),
          acUser(nullptr),
          acVendorCode(nullptr),
          acOrdSrc(nullptr),
          acOrdRemarks(nullptr),
          acIpAddr(nullptr),
          acNorenOrdNum(nullptr),
          acReqId(nullptr),
          acExchOrdId(nullptr),
          cStatus(CHAR_MIN),
          acOrdStatus(nullptr),
          acNorenUpdateTime(nullptr),
          lNorenUpdateTimeEpoch(LONG_MIN),
          lNorenUpdateTimeNanoSec(LONG_MIN),
          acExchTime(nullptr),
          lExchTimeEpoch(LONG_MIN),
          lExchTimeNanoSec(LONG_MIN),
          acOrgExchTime(nullptr),
          acRejectionBy(nullptr),
          acNorenTimeSec(nullptr),
          lNorenTimeSecEpoch(LONG_MIN),
          acNorenTimeMiliSec(nullptr),
          lNorenTimeNanoSec(LONG_MIN),
          acReportType(nullptr),
          cRepTyp(CHAR_MIN),
          acRejReason(nullptr),
          lRejQty(LONG_MIN),
          acRejOrdSrc(nullptr),
          acRejPriceType(nullptr),
          acRegion(nullptr),
          acFamilyId(nullptr),
          acExchUsrId(nullptr),
          acBrokerId(nullptr)
    {
    }
  } tsOfsOrderBook;

  typedef struct sThresholdAlertParams
  {
    char *acISIN;    //[max: 24]
    char *acExchSeg;      //[max: 6]
    char *acToken;        //[max: 16]
    char *acTrdSymbol;    //[max: 24]
    long lPrevClose;
    long lTradePrice;
    double dBreachPerc;
    int  iAlertType;
    char *acRemarks;

    sThresholdAlertParams()
        : acISIN(nullptr),
          acExchSeg(nullptr),
          acToken(nullptr),
          acTrdSymbol(nullptr),
          lPrevClose(LONG_MIN),
          lTradePrice(LONG_MIN),
          dBreachPerc(DBL_MIN),
          iAlertType(INT_MIN),
          acRemarks(nullptr)
    {
    }
  } tsThresholdAlertParams;

#endif
  /* ------------------------------------------------------------------------- */

  class CNorenControl;

  class CNorenClient
  {
  public:
    virtual ~CNorenClient()
    {
    }
#ifndef GRPC
    virtual int LoginResponse(void *pEchoBackData,
                              tsLoginRespParams *pOrderParams) = 0;

    virtual int LogoutResponse(void *pEchoBackData,
                               short siLogoutStatus) = 0;
#endif

    virtual int CNorenClientOConnected(CNorenControl *pCNorenControl) = 0;
    virtual int CNorenClientOReConnected(CNorenControl *pCNorenControl) = 0;
    virtual int CNorenClientODisConnected(CNorenControl *pCNorenControl) = 0;

    virtual int CNorenClientRConnected(CNorenControl *pCNorenControl) = 0;
    virtual int CNorenClientRReConnected(CNorenControl *pCNorenControl) = 0;
    virtual int CNorenClientRDisConnected(CNorenControl *pCNorenControl) = 0;

    virtual int CNorenClientFConnected(CNorenControl *pCNorenControl) = 0;
    virtual int CNorenClientFReConnected(CNorenControl *pCNorenControl) = 0;
    virtual int CNorenClientFDisConnected(CNorenControl *pCNorenControl) = 0;

    virtual int CNorenClientSConnected(CNorenControl *pCNorenControl) = 0;
    virtual int CNorenClientSReConnected(CNorenControl *pCNorenControl) = 0;
    virtual int CNorenClientSDisConnected(CNorenControl *pCNorenControl) = 0;

    virtual int CNorenClientStartUp(CNorenControl *pCNorenControl) = 0;
    virtual int CNorenClientCleanUp(CNorenControl *pCNorenControl) = 0;

    virtual int PutOrderResponse(void *pEchoBackData,
                                 char *pNorenOrd,
                                 char *pGuiOrdId,
                                 char *pReqStatus,
                                 char *pRejReason,
                                 char *pExternalRemarks,
                                 char *pUser) = 0;

    virtual int ModifyOrderResponse(void *pEchoBackData,
                                    char *pNorenOrd,
                                    char *pGuiOrdId,
                                    char *pReqStatus,
                                    char *pRejReason,
                                    char *pExternalRemarks,
                                    char *pUser) = 0;

    virtual int CancelOrderResponse(void *pEchoBackData,
                                    char *pNorenOrd,
                                    char *pGuiOrdId,
                                    char *pReqStatus,
                                    char *pRejReason,
                                    char *pExternalRemarks,
                                    char *pUser) = 0;

    virtual int GetOrdersStart(void *pEchoBackData) = 0;
    virtual int GetOrders(void *pEchoBackData,
                          tsOrderHistory *pGetOrders) = 0;
    virtual int GetOrdersEnd(void *pEchoBackData) = 0;

    virtual int GetAllOrdersStart(void *pEchoBackData) = 0;
    virtual int GetAllOrders(void *pEchoBackData,
                             tsOrderHistory *pGetOrders) = 0;
    virtual int GetAllOrdersEnd(void *pEchoBackData) = 0;

#ifndef GRPC

    virtual int FillReport(tsFillReport *pFillReport,
                           void *pEchoBackData) = 0;
    virtual int OrderUpdate(tsOrderUpdate *pOrderUpdate,
                            void *pEchoBackData) = 0;
    virtual int MultiLegOrderUpdate(tsOrderUpdate *pOrderUpdate,
                                    tsMultiLegUpdate *pMultiLegUpdate,
                                    void *pEchoBackData) = 0;

    virtual int OrderAdminUnSubscribeResponse(void *pEchoBackData,
                                              char *pStatus) = 0;

    virtual int OrderAdminGroupUnSubscribeResponse(void *pEchoBackData,
                                                  char *pStatus) = 0;

    virtual int PositionUpdate(tsPosData **pPositionUpdate,
                               int PositionUpdateSize,
                               void *pEchoBackData) = 0;
    virtual int PositionAdminUnSubscribeResponse(void *pEchoBackData,
                                                 char *pStatus) = 0;
    virtual int PositionAdminGroupUnSubscribeResponse(void *pEchoBackData,
                                                      char *pStatus) = 0;

    virtual int TradeEnhancementReport(tsTradeReport *pTradeReport,
                                      void *pEchoBackData) = 0;
    virtual int TradeEnhancementUnSubscribeResponse(void *pEchoBackData,
                                              char *pStatus) = 0;
#endif

    virtual int TradeHistoryStart(void *pEchoBackData) = 0;
    virtual int TradeHistory(void *pEchoBackData,
                             tsFillReport *pFillReport) = 0;
    virtual int TradeHistoryEnd(void *pEchoBackData) = 0;

    virtual int AllTradeHistoryStart(void *pEchoBackData) = 0;
    virtual int AllTradeHistory(void *pEchoBackData,
                                tsFillReport *pFillReport) = 0;
    virtual int AllTradeHistoryEnd(void *pEchoBackData) = 0;

    virtual int GetClientsStart(void *pEchoBackData) = 0;
    virtual int GetClients(void *pEchoBackData,
                           tsClientData *pClntData) = 0;
    virtual int GetClientsEnd(void *pEchoBackData) = 0;

    virtual int GetPositionsStart(void *pEchoBackData) = 0;
    virtual int GetPositions(tsPosData **pPositionUpdate,
                             int PositionUpdateSize,
                             void *pEchoBackData) = 0;
    virtual int GetPositionsEnd(void *pEchoBackData) = 0;

    virtual int GetAllPositionsStart(void *pEchoBackData) = 0;
    virtual int GetAllPositions(tsPosData **pPositionUpdate,
                                int PositionUpdateSize,
                                void *pEchoBackData) = 0;
    virtual int GetAllPositionsEnd(void *pEchoBackData) = 0;

    virtual int GetAllSymbolsStart(void *pEchoBackData,
                                   char *pExchSeg) = 0;
    virtual int GetAllSymbols(void *pEchoBackData,
                              tsSymbolData *pSymbolData) = 0;
    virtual int GetAllSymbolsEnd(void *pEchoBackData,
                                 char *pExchSeg) = 0;

    virtual int GetGroupSettingsStart(void *pEchoBackData) = 0;
    virtual int SendGroupSettings(void *pEchoBackData,
                                  int MWsize,
                                  char **pMarketWatch) = 0;
    virtual int GetGroupSettingsEnd(void *pEchoBackData) = 0;

    virtual int SetGroupSettingsResp(void *pEchoBackData,
                                     char *pComment) = 0;

    virtual int ValidateUidPwdResp(void *pEchoBackData,
                                   char *pComments) = 0;
#ifndef GRPC

    virtual int OrderBookSnapQuote(char *pSymbol,
                                   char *pExchSeg,
                                   char *pExchTimeStamp,
                                   int iDepthSize,
                                   double *adAskPrice,
                                   double *adBidPrice,
                                   long *alAskSize,
                                   long *alBidSize,
                                   long *alAskNumOfOrders,
                                   long *alBidNumOfOrders) = 0;

    virtual int UnSubscribeFeedResponse(void *pEchoBackData,
                                        char *pExchSeg,
                                        char *pSymbol,
                                        char *pStatus) = 0;
#endif

    virtual int ExitCoverOrderResp(void *pEchoBackData,
                                   char *pComments) = 0;

    virtual int ExitBracketOrderResp(void *pEchoBackData,
                                     char *pComments) = 0;

    virtual int PartialPosConResponse(void *pEchoBackData,
                                      char *pText) = 0;

    virtual int GetRmsLimitsStart(void *pEchoBackData) = 0;
    virtual int SendRmsLimits(tsRmsLimits *pRmsLimits,
                              void *pEchoBackData) = 0;
    virtual int GetRmsLimitsEnd(void *pEchoBackData) = 0;

    virtual int GetAllRmsLimitsStart(void *pEchoBackData) = 0;
    virtual int SendAllRmsLimits(tsRmsLimits *pRmsLimits,
                                 void *pEchoBackData) = 0;
    virtual int GetAllRmsLimitsEnd(void *pEchoBackData) = 0;

    virtual int ChangePasswordResponse(char *pText,
                                       int iPwdStatus,
                                       void *pEchoBackData) = 0;

    virtual int AfterMktOrderResponse(void *pEchoBackData,
                                      char *pNorenOrd,
                                      char *pGuiOrdId,
                                      char *pReqStatus,
                                      char *pRejReason,
                                      char *pExternalRemarks,
                                      char *pUser) = 0;

    virtual int AfterMktModifyOrderResponse(void *pEchoBackData,
                                            char *pNorenOrd,
                                            char *pGuiOrdId,
                                            char *pReqStatus,
                                            char *pRejReason,
                                            char *pExternalRemarks,
                                            char *pUser) = 0;

    virtual int AfterMktMultiLegOrderResponse(void *pEchoBackData,
                                              char *pNorenOrd,
                                              char *pGuiOrdId,
                                              char *pReqStatus,
                                              char *pRejReason,
                                              char *pExternalRemarks,
                                              char *pUser) = 0;

    virtual int GetIndexNamesStart(void *pEchoBackData) = 0;
    virtual int GetIndexName(tsIndexName *pIndexName,
                             void *pEchoBackData) = 0;
    virtual int GetIndexNamesEnd(void *pEchoBackData) = 0;

    virtual int GetProductListStart(void *pEchoBackData) = 0;
    virtual int GetProductList(void *pEchoBackData,
                               char *pExchSeg,
                               char *pProduct) = 0;
    virtual int GetProductListEnd(void *pEchoBackData) = 0;

    virtual int GetUserProfileStart(void *pEchoBackData) = 0;
    virtual int SendUserProfile(tsUserProfile *pUserProfile,
                                void *pEchoBackData) = 0;
    virtual int GetUserProfileEnd(void *pEchoBackData) = 0;

    virtual int SecurityInfoStart(void *pEchoBackData) = 0;
    virtual int SendSecurityInfo(tsSecurityInfo *pSecurityInfo,
                                 void *pEchoBackData) = 0;
    virtual int SecurityInfoEnd(void *pEchoBackData) = 0;

    virtual int OrderHistoryStart(void *pEchoBackData) = 0;
    virtual int OrderHistory(void *pEchoBackData,
                             tsOrderHistory *pOrderHistory) = 0;
    virtual int OrderHistoryEnd(void *pEchoBackData) = 0;

    virtual int ViewHoldingsStart(void *pEchoBackData,
                                  char *pAccountId) = 0;
    virtual int ViewHoldings(void *pEchoBackData,
                             tsViewHoldings *pViewHoldings) = 0;
    virtual int ViewHoldingsEnd(void *pEchoBackData,
                                char *pAccountId) = 0;

    virtual int GetTopnKeysStart(void *pEchoBackData) = 0;
    virtual int SendTopnKeys(void *pEchoBackData,
                             char *pTopnCriteria,
                             char *pTopnBasket) = 0;
    virtual int GetTopnKeysEnd(void *pEchoBackData) = 0;

    virtual int GetTopnValuesStart(void *pEchoBackData) = 0;
    virtual int SendTopnValues(void *pEchoBackData,
                               tsTopnValues *pTopnValues) = 0;
    virtual int GetTopnValuesEnd(void *pEchoBackData) = 0;

    virtual int GetAllVwapDataStart(void *pEchoBackData) = 0;
    virtual int GetAllVwapData(void *pEchoBackData,
                               long lStartTime,
                               long lEndTime,
                               tsVwapData *pVwapData) = 0;
    virtual int GetAllVwapDataEnd(void *pEchoBackData) = 0;

    virtual int GetMarketDataStart(void *pEchoBackData) = 0;
    virtual int GetMarketData(tsMarketData *pMarketData,
                              void *pEchoBackData) = 0;
    virtual int GetMarketDataEnd(void *pEchoBackData) = 0;

    virtual int MarketStatusNotifyStart(void *pEchoBackData) = 0;
    virtual int MarketStatusNotify(char *pExchSeg,
                                   char *pMktStatus,
                                   char *pMktType,
                                   void *pEchoBackData) = 0;
    virtual int MarketStatusNotifyEnd(void *pEchoBackData) = 0;

#ifndef GRPC
    virtual int MarketStatusUpdate(char *pExchSeg,
                                   char *pMktStatus,
                                   char *pMktType,
                                   void *pEchoBackData) = 0;
    virtual int MktStatusUnSubscribeResponse(char *pStatus,
                                             void *pEchoBackData) = 0;
#endif

    virtual int ExchangeMessageStart(void *pEchoBackData) = 0;
    virtual int ExchangeMessage(char *pExchSeg,
                                char *pMessage,
                                void *pEchoBackData) = 0;
    virtual int ExchangeMessageEnd(void *pEchoBackData) = 0;

#ifndef GRPC
    virtual int ExchangeMessageUpdate(char *pExchSeg,
                                      char *pMessage,
                                      long lExchTime,
                                      void *pEchoBackData) = 0;
    virtual int ExchangeMessageUnSubscribeResponse(char *pStatus,
                                                   void *pEchoBackData) = 0;
#endif

    virtual int AddFundResponse(char *pStatus,
                                char *pRemarks,
                                void *pEchoBackData) = 0;

    virtual int GetOrderMarginStart(void *pEchoBackData) = 0;

    virtual int GetOrderMarginResponse(char *pRemarks,
                                       double TotalCash,
                                       double MarginOnNewOrder,
                                       double AvailableMarginForTheOrder,
                                       void *pEchoBackData) = 0;

    virtual int GetOrderMarginResponse(char *pRemarks,
                                       double TotalCash,
                                       double MarginOnNewOrder,
                                       double AvailableMarginForTheOrder,
                                       void *pEchoBackData,
                                       long lNorenUpdateTimeEpoch,
                                       long lNorenUpdateTimeNanoSec) = 0;

    virtual int GetOrderMarginEnd(void *pEchoBackData) = 0;

    virtual int GetOrderMargin2Start(void *pEchoBackData) = 0;
    virtual int GetOrderMargin2Response(char *pRemarks,
                                       double TotalCash,
                                       double MarginOnNewOrder,
                                       double AvailableMarginForTheOrder,
                                       double OrderMarginUsed,
                                       void *pEchoBackData) = 0;
    virtual int GetOrderMargin2End(void *pEchoBackData) = 0;

    virtual int GetOrderMarginLimits2(void *pEchoBackData,
                                     tsRmsLimits *pRmsLimits,
                                     double &dTotalRmsValue,
                                     double &dRmsMarginUsed) = 0;

    virtual int GetBasketMarginStart(void *pEchoBackData) = 0;
    virtual int GetBasketMarginResponse(char *pRemarks,
                                        double MarginOnNewOrder,
                                        double TradedMargin,
                                        double PreviousMargin,
                                        double *BasketMargin,
                                        int BasketSize,
                                        void *pEchoBackData) = 0;
    virtual int GetBasketMarginEnd(void *pEchoBackData) = 0;

    virtual int GetWithdrawalAmtStart(void *pEchoBackData) = 0;
    virtual int GetWithdrawalAmtResponse(double MaxWithdrawalAmt,
                                         void *pEchoBackData) = 0;
    virtual int GetWithdrawalAmtEnd(void *pEchoBackData) = 0;

    virtual int GetWithdrawFundStart(void *pEchoBackData) = 0;
    virtual int GetWithdrawFund(char *pStatus,
                                char *pRemarks,
                                void *pEchoBackData) = 0;
    virtual int GetWithdrawFundEnd(void *pEchoBackData) = 0;

    virtual int GetWithdrawFund2Start(void *pEchoBackData) = 0;
    virtual int GetWithdrawFund2(char *pAccountId,
                                 long lTranRefNumber,
                                 double dAmount,
                                 char *pTranStatus,
                                 char *pRemarks,
                                 void *pEchoBackData) = 0;
    virtual int GetWithdrawFund2End(void *pEchoBackData) = 0;

#ifndef GRPC
    virtual int M2MAlertUpdate(tsM2MAlert *pM2MAlert,
                               void *pEchoBackData) = 0;
    virtual int M2MAlertUnSubscribeResponse(char *pStatus,
                                            void *pEchoBackData) = 0;
#endif

    virtual int IpoListStart(void *pEchoBackData) = 0;
    virtual int IpoListResp(void *pEchoBackData,
                            tsIpoList *pIpoList) = 0;
    virtual int IpoListEnd(void *pEchoBackData) = 0;

#ifndef GRPC

    virtual int IpoOrderUpdate(tsIpoOrdBook *pIpoOrderUpdate,
                               void *pEchoBackData) = 0;

    virtual int IpoOrderAdminUnSubscribeResponse(void *pEchoBackData,
                                                 char *pStatus) = 0;
#endif

    virtual int IpoOrderBookStart(void *pEchoBackData) = 0;
    virtual int IpoOrderBookResp(void *pEchoBackData,
                                 tsIpoOrdBook *pIpoOrdBookResp) = 0;
    virtual int IpoOrderBookEnd(void *pEchoBackData) = 0;

    virtual int GetAllIpoOrdersStart(void *pEchoBackData) = 0;
    virtual int GetAllIpoOrders(void *pEchoBackData,
                                tsIpoOrdBook *pIpoOrdBookResp) = 0;
    virtual int GetAllIpoOrdersEnd(void *pEchoBackData) = 0;

    virtual int MfOrderBookStart(void *pEchoBackData) = 0;
    virtual int MfOrderBookResp(void *pEchoBackData,
                                tsMfOrdBook *pMfOrdBookResp) = 0;
    virtual int MfOrderBookEnd(void *pEchoBackData) = 0;

    virtual int AddHoldingsResponse(char *pStatus,
                                    void *pEchoBackData) = 0;

    virtual int AddT1HoldingsResponse(char *pStatus,
                                      void *pEchoBackData) = 0;

    virtual int ModifyHoldingsResponse(char *pStatus,
                                       char *pRejReason,
                                       void *pEchoBackData) = 0;

    virtual int GTTPlaceResponse(void *pEchoBackData,
                                 char *pGTTid,
                                 char *pStatus) = 0;

    virtual int GTTModifyResponse(void *pEchoBackData,
                                  char *pGTTid,
                                  char *pStatus) = 0;

    virtual int GTTCancelResponse(void *pEchoBackData,
                                  char *pGTTid,
                                  char *pStatus) = 0;

    virtual int GTTOrdersStart(void *pEchoBackData) = 0;
    virtual int GTTOrdersResp(void *pEchoBackData,
                              tsGTTParams *pGTTParams) = 0;
    virtual int GTTOrdersEnd(void *pEchoBackData) = 0;

    virtual int AllGTTOrdersStart(void *pEchoBackData) = 0;
    virtual int AllGTTOrdersResp(void *pEchoBackData,
                                 tsGTTParams *pGTTParams) = 0;
    virtual int AllGTTOrdersEnd(void *pEchoBackData) = 0;

    virtual int TriggeredGTTOrdersStart(void *pEchoBackData) = 0;
    virtual int TriggeredGTTOrdersResp(void *pEchoBackData,
                                       tsGTTParams *pGTTParams,
                                       char *pStatus) = 0;
    virtual int TriggeredGTTOrdersEnd(void *pEchoBackData) = 0;

    virtual int AllTriggeredGTTOrdersStart(void *pEchoBackData) = 0;
    virtual int AllTriggeredGTTOrdersResp(void *pEchoBackData,
                                          tsGTTParams *pGTTParams,
                                          char *pStatus) = 0;
    virtual int AllTriggeredGTTOrdersEnd(void *pEchoBackData) = 0;

    virtual int OCOPlaceResponse(void *pEchoBackData,
                                 char *pOCOid,
                                 char *pStatus) = 0;

    virtual int OCOModifyResponse(void *pEchoBackData,
                                  char *pOCOid,
                                  char *pStatus) = 0;

    virtual int OCOCancelResponse(void *pEchoBackData,
                                  char *pOCOid,
                                  char *pStatus) = 0;

    virtual int OCOOrdersStart(void *pEchoBackData) = 0;
    virtual int OCOOrdersResp(void *pEchoBackData,
                              tsOCOParams *pOCOParams) = 0;
    virtual int OCOOrdersEnd(void *pEchoBackData) = 0;

    virtual int AllOCOOrdersStart(void *pEchoBackData) = 0;
    virtual int AllOCOOrdersResp(void *pEchoBackData,
                                 tsOCOParams *pOCOParams) = 0;
    virtual int AllOCOOrdersEnd(void *pEchoBackData) = 0;

    virtual int TriggeredOCOOrdersStart(void *pEchoBackData) = 0;
    virtual int TriggeredOCOOrdersResp(void *pEchoBackData,
                                       tsOCOParams *pOCOParams,
                                       char *pStatus) = 0;
    virtual int TriggeredOCOOrdersEnd(void *pEchoBackData) = 0;

    virtual int AllTriggeredOCOOrdersStart(void *pEchoBackData) = 0;
    virtual int AllTriggeredOCOOrdersResp(void *pEchoBackData,
                                          tsOCOParams *pOCOParams,
                                          char *pStatus) = 0;
    virtual int AllTriggeredOCOOrdersEnd(void *pEchoBackData) = 0;

    virtual int GTTOCOOrdersStart(void *pEchoBackData) = 0;
    virtual int GTTOCOOrdersResp(void *pEchoBackData,
                                 tsOCOParams *pOCOParams) = 0;
    virtual int GTTOCOOrdersEnd(void *pEchoBackData) = 0;

    virtual int TriggeredGTTOCOOrdersStart(void *pEchoBackData) = 0;
    virtual int TriggeredGTTOCOOrdersResp(void *pEchoBackData,
                                          tsOCOParams *pOCOParams,
                                          char *pStatus) = 0;
    virtual int TriggeredGTTOCOOrdersEnd(void *pEchoBackData) = 0;

#ifndef GRPC
    virtual int ModifyUserResponse(char *pUserId,
                                   void *pEchoBackData) = 0;
    virtual int ModifyUserUnSubscribeResponse(char *pStatus,
                                              void *pEchoBackData) = 0;

    virtual int PeakMarginUpdate(char *pAcctId,
                                 double dAmount,
                                 void *pEchoBackData) = 0;
    virtual int PeakMarginUnSubscribeResponse(char *pStatus,
                                              void *pEchoBackData) = 0;

    virtual int ExpiryMarginUpdate(char *pAcctId,
                                   double dAmount,
                                   void *pEchoBackData) = 0;
    virtual int ExpiryMarginUnSubscribeResponse(char *pStatus,
                                                void *pEchoBackData) = 0;

    virtual int RiskDashBoardUpdate(tsRiskDasBoard *pRiskDasBoardResp,
                                    void *pEchoBackData) = 0;
    virtual int RiskDashBoardUnSubscribeResponse(char *pStatus,
                                                 void *pEchoBackData) = 0;

    virtual int SqroffAlertUpdate(char *AlertMessage,
                                  void *pEchoBackData) = 0;
    virtual int PreSqroffAlertUpdate(char *AlertMessage,
                                     void *pEchoBackData) = 0;
    virtual int SqroffAlertsUnSubscribeResponse(char *pStatus,
                                                void *pEchoBackData) = 0;

    virtual int GTTUpdates(tsGTTUpdateParams *pGTTUpdateResp,
                           void *pEchoBackData) = 0;
    virtual int GTTUpdatesUnSubscribeResponse(char *pStatus,
                                              void *pEchoBackData) = 0;

    virtual int LimitsUpdate(tsLimitUpdatesParams *pLimitUpdateResp,
                             void *pEchoBackData) = 0;
    virtual int LimitsUpdateUnSubscribeResponse(char *pStatus,
                                                void *pEchoBackData) = 0;

    virtual int HoldingsUpdate(tsViewHoldings *pViewHoldings,
                               void *pEchoBackData) = 0;
    virtual int HoldingsUpdateUnSubscribeResponse(char *pStatus,
                                                  void *pEchoBackData) = 0;

    virtual int FundsUpdate(tsFundsUpdatesParams *pFundsUpdatesParams,
                            void *pEchoBackData) = 0;
    virtual int FundsUpdateUnSubscribeResponse(char *pStatus,
                                               void *pEchoBackData) = 0;
#endif

    virtual int PlaceEquitySipOrderResp(void *pEchoBackData,
                                        char *pReqStatus,
                                        long lSipId) = 0;

    virtual int ModifyEquitySipOrderResp(void *pEchoBackData,
                                         char *pReqStatus,
                                         long lSipId) = 0;

    virtual int CancelSipOrderResp(void *pEchoBackData,
                                   char *pReqStatus,
                                   long lSipId) = 0;

    virtual int PauseSipOrderResp(void *pEchoBackData,
                                   char *pReqStatus,
                                   long lSipId) = 0;

    virtual int ResumeSipOrderResp(void *pEchoBackData,
                                   char *pReqStatus,
                                   long lSipId) = 0;

    virtual int GetEquitySipOrderStart(void *pEchoBackData) = 0;
    virtual int GetEquitySipOrderResp(void *pEchoBackData,
                                      tsSipOrderUpdate *pSipOrderUpdate) = 0;
    virtual int GetEquitySipOrderEnd(void *pEchoBackData) = 0;

#ifndef GRPC

    virtual int MasterMsgUpdate(sMasterMsgParams *pMasterMsgParams,
                                void *pEchoBackData) = 0;
    virtual int UnSubscribeMasterMsgResponse(char *pStatus,
                                             void *pEchoBackData) = 0;

    virtual int PosConvUpdate(tsPosConvParams *pPosConvParams,
                              void *pEchoBackData) = 0;
    virtual int PosConvUnSubscribeResponse(char *pStatus,
                                           void *pEchoBackData) = 0;
#endif

    virtual int AddMfHoldingsResponse(char *pStatus,
                                      void *pEchoBackData) = 0;

    virtual int ViewMfHoldingsStart(void *pEchoBackData,
                                    char *pAccountId) = 0;
    virtual int ViewMfHoldings(void *pEchoBackData,
                               tsViewHoldings *pViewHoldings) = 0;
    virtual int ViewMfHoldingsEnd(void *pEchoBackData,
                                  char *pAccountId) = 0;

    virtual int GetBrokerageStart(void *pEchoBackData) = 0;
    virtual int GetBrokerageResp(void *pEchoBackData,
                                 tsBrokerageRespParams *pBrokerageRespParams) = 0;
    virtual int GetBrokerageEnd(void *pEchoBackData) = 0;

#ifndef GRPC

    virtual int BlockAmtUpdate(char *pAccountId,
                               char *pSrcUserId,
                               char *pSrcBrokerId,
                               double dBlockAmount,
                               void *pEchoBackData) = 0;
    virtual int BlockAmtUpdateUnSubscribeResponse(char *pStatus,
                                                  void *pEchoBackData) = 0;

    virtual int PayInUpdate(char *pAccountId,
                            char *pSrcUserId,
                            char *pSrcBrokerId,
                            double dPayIn,
                            void *pEchoBackData) = 0;
    virtual int PayInUpdateUnSubscribeResponse(char *pStatus,
                                               void *pEchoBackData) = 0;

    virtual int PayOutUpdate(char *pAccountId,
                             char *pSrcUserId,
                             char *pSrcBrokerId,
                             double dPayOut,
                             void *pEchoBackData) = 0;
    virtual int PayOutUpdateUnSubscribeResponse(char *pStatus,
                                                void *pEchoBackData) = 0;

    virtual int IncrCASHUpdate(char *pAccountId,
                               char *pSrcUserId,
                               char *pSrcBrokerId,
                               double dCash,
                               void *pEchoBackData) = 0;
    virtual int IncrCASHUpdateUnSubscribeResponse(char *pStatus,
                                                  void *pEchoBackData) = 0;
#endif

    virtual int AmoStatusStart(void *pEchoBackData) = 0;
    virtual int AmoStatusResponse(void *pEchoBackData,
                                  char *pExchSeg,
                                  char *pAmoStatus) = 0;
    virtual int AmoStatusEnd(void *pEchoBackData) = 0;

    virtual int GetOrderMarginLimits(void *pEchoBackData,
                                     tsRmsLimits *pRmsLimits,
                                     double &dTotalRmsValue,
                                     double &dRmsMarginUsed) = 0;
#ifndef GRPC
    virtual int DPRMsgUpdate(char *pUserId,
                             char *pMsgString,
                             long lDateTime,
                             void *pEchoBackData) = 0;
    virtual int DPRMsgUnSubscribeResponse(char *pStatus,
                                          void *pEchoBackData) = 0;
#endif

    virtual int PayinStatusStart(void *pEchoBackData) = 0;
    virtual int PayinStatusResponse(void *pEchoBackData,
                                    tsPayinStatusRespParams *pPayinStatus) = 0;
    virtual int PayinStatusEnd(void *pEchoBackData) = 0;

    virtual int HSTokenStart(void *pEchoBackData) = 0;
    virtual int HSTokenResponse(void *pEchoBackData,
                                char *pUser,
                                char *pHsToken) = 0;
    virtual int HSTokenEnd(void *pEchoBackData) = 0;

    virtual int RegenerateCoverOrderResp(void *pEchoBackData,
                                         char *pComments) = 0;

    virtual int RegenerateBracketOrderResp(void *pEchoBackData,
                                           char *pComments) = 0;

    virtual int UpdateBlockAmountStart(void *pEchoBackData) = 0;
    virtual int UpdateBlockAmountResponse(void *pEchoBackData,
                                          char *pStatus) = 0;
    virtual int UpdateBlockAmountEnd(void *pEchoBackData) = 0;

    virtual int GetOptimizedBasketSequenceStart(void *pEchoBackData) = 0;
    virtual int GetOptimizedBasketSequenceResponse(void *pEchoBackData,
                                                   double dMarginUsed,
                                                   double dMarginUsedTrade,
                                                   double dMarginUsedPrev,
                                                   char *acOptimumSequence,
                                                   double dBasketMaginList[50],
                                                   int iBasketMaginListSize) = 0;
    virtual int GetOptimizedBasketSequenceEnd(void *pEchoBackData) = 0;

    virtual int FreezeAccountStart(void *pEchoBackData) = 0;
    virtual int FreezeAccountResponse(void *pEchoBackData,
                                      char *pStatus) = 0;
    virtual int FreezeAccountEnd(void *pEchoBackData) = 0;

    virtual int DeFreezeAccountStart(void *pEchoBackData) = 0;
    virtual int DeFreezeAccountResponse(void *pEchoBackData,
                                        char *pStatus) = 0;
    virtual int DeFreezeAccountEnd(void *pEchoBackData) = 0;

    virtual int GetMasterMsgStart(void *pEchoBackData) = 0;
    virtual int GetMasterMsgResponse(void *pEchoBackData,
                                     tsMasterMsgParams *pMasterMsgParams) = 0;
    virtual int GetMasterMsgEnd(void *pEchoBackData) = 0;

    virtual int GetPositionConvStart(void *pEchoBackData) = 0;
    virtual int GetPositionConvResponse(void *pEchoBackData,
                                        tsPosConvParams *pPosConvParams) = 0;
    virtual int GetPositionConvEnd(void *pEchoBackData) = 0;

    virtual int AbsIsinHoldingsResponse(char *pStatus,
                                      void *pEchoBackData) = 0;

    virtual int ResolutionTimeResp(void *pEchoBackData,
                                   long lUpdateTimeSec,
                                   long lUpdateTimeNsec,
                                   long lResolutionTime) = 0;

    virtual int GetExternalRemarksStart(void *pEchoBackData) = 0;
    virtual int GetExternalRemarksResponse(void *pEchoBackData,
                                          char *pNorenOrderNo,
                                          char *pExternalRemarks) = 0;
    virtual int GetExternalRemarksEnd(void *pEchoBackData) = 0;

    virtual int GetOrderNumberStart(void *pEchoBackData) = 0;
    virtual int GetOrderNumberResponse(void *pEchoBackData,
                                      char *pExternalRemarks,
                                      char *pNorenOrderNo) = 0;
    virtual int GetOrderNumberEnd(void *pEchoBackData) = 0;

    virtual int TralingOrderResponse(void *pEchoBackData,
                                    long lAQ_ID,
                                    char *pGuiOrdId,
                                    char *pReqStatus,
                                    char *pRejReason,
                                    char *pExternalRemarks,
                                    char *pUser) = 0;

    virtual int GetTrailingOrdersStart(void *pEchoBackData) = 0;
    virtual int GetTrailingOrders(void *pEchoBackData,
                                  tsAQParams *pGetOrders) = 0;
    virtual int GetTrailingOrdersEnd(void *pEchoBackData) = 0;
                                
    virtual int IceBergOrderResponse(void *pEchoBackData,
                                    long lAQ_ID,
                                    char *pGuiOrdId,
                                    char *pReqStatus,
                                    char *pRejReason,
                                    char *pExternalRemarks,
                                    char *pUser) = 0;

    virtual int ModifyIceBergOrderResponse(void *pEchoBackData,
                                    long lAQ_ID,
                                    char *pGuiOrdId,
                                    char *pReqStatus,
                                    char *pRejReason,
                                    char *pExternalRemarks,
                                    char *pUser) = 0;

    virtual int CancelIceBergOrderResponse(void *pEchoBackData,
                                    long lAQ_ID,
                                    char *pGuiOrdId,
                                    char *pReqStatus,
                                    char *pRejReason,
                                    char *pExternalRemarks,
                                    char *pUser) = 0;

    virtual int GetIceBergOrdersStart(void *pEchoBackData) = 0;
    virtual int GetIceBergOrders(void *pEchoBackData,
                                  tsAQParams *pGetOrders) = 0;
    virtual int GetIceBergOrdersEnd(void *pEchoBackData) = 0;

    virtual int GetGroupIdResponse(void *pEchoBackData,
                                    char *pGroupId,
                                    char *pAccount) = 0;

    virtual int BlockUserResponse(char *pStatus,
                                  void *pEchoBackData) = 0;

    virtual int CancelWithdrawFundStart(void *pEchoBackData) = 0;
    virtual int CancelWithdrawFundsResponse(char *pAccountId,
                                            long lTranRefNumber,
                                            double dAmount,
                                            int pTranStatus,
                                            void *pEchoBackData) = 0;
    virtual int CancelWithdrawFundEnd(void *pEchoBackData) = 0;

    virtual int GetWithdrawFundsReportStart(void *pEchoBackData) = 0;
    virtual int GetWithdrawFundsReportResp(tsFundsReportParams *pFundsReportParams,
                                            void *pEchoBackData) = 0;
    virtual int GetWithdrawFundsReportEnd(void *pEchoBackData) = 0;

    virtual int SqrOffEntityResponse(char *pStatus,
                                    void *pEchoBackData) = 0;

    virtual int GetOrderNumberByGuiStart(void *pEchoBackData) = 0;
    virtual int GetOrderNumberByGuiResponse(void *pEchoBackData,
                                          char *pGuiOrdId,
                                          char *pNorenOrderNo,
                                          char *pReportType) = 0;
    virtual int GetOrderNumberByGuiEnd(void *pEchoBackData) = 0;

    virtual int PayoutStatusStart(void *pEchoBackData) = 0;
    virtual int PayoutStatusResponse(void *pEchoBackData,
                                    tsPayoutStatusRespParams *pPayinStatus) = 0;
    virtual int PayoutStatusEnd(void *pEchoBackData) = 0;

    virtual int EntityCancelOrderStart(void *pEchoBackData) = 0;
    virtual int EntityCancelOrderResponse(void *pEchoBackData,
                                    char *pNorenOrderNo) = 0;
    virtual int EntityCancelOrderEnd(void *pEchoBackData) = 0;

    virtual int getAllAuctionSymbolsStart(void *pEchoBackData) = 0;
    virtual int getAllAuctionSymbolsResp(void *pEchoBackData,
                                    tsAuctionSymbolsParams *pPayinStatus) = 0;
    virtual int getAllAuctionSymbolsEnd(void *pEchoBackData) = 0;

#ifndef GRPC
    virtual int OfsOrderUpdate(tsOfsOrderBook *pOfsOrderUpdate,
                               void *pEchoBackData) = 0;

    virtual int OfsOrderAdminUnSubscribeResponse(void *pEchoBackData,
                                                 char *pStatus) = 0;
#endif

    virtual int OfsOrderHistoryStart(void *pEchoBackData) = 0;
    virtual int OfsOrderHistory(void *pEchoBackData,
                             tsOfsOrderBook *pOfsOrderBook) = 0;
    virtual int OfsOrderHistoryEnd(void *pEchoBackData) = 0;

    virtual int OfsOrderBookStart(void *pEchoBackData) = 0;
    virtual int OfsOrderBookResp(void *pEchoBackData,
                                tsOfsOrderBook *pOfsOrdBookResp) = 0;
    virtual int OfsOrderBookEnd(void *pEchoBackData) = 0;

    virtual int GetAllOfsOrdersStart(void *pEchoBackData) = 0;
    virtual int GetAllOfsOrders(void *pEchoBackData,
                             tsOfsOrderBook *pOfsOrdBookResp) = 0;
    virtual int GetAllOfsOrdersEnd(void *pEchoBackData) = 0;

#ifndef GRPC
    virtual int ThresholdAlertUpdate(tsThresholdAlertParams *pThresholdAlertUpdate,
                               void *pEchoBackData) = 0;

    virtual int DPRThresholdAlertUnSubscribeResponse(char *pStatus,
                                                    void *pEchoBackData) = 0;
#endif

    virtual int GetMaxBlockAmtStart(void *pEchoBackData) = 0;
    virtual int GetMaxBlockAmtResponse(double MaxBlockAmt,
                                      void *pEchoBackData) = 0;
    virtual int GetMaxBlockAmtEnd(void *pEchoBackData) = 0;

    virtual int CallBackError(void *pEchoBackData,tsCallbackErrorParams *pCallbackErrorParams) = 0;
                                    
#ifndef GRPC
    virtual int QueueLoadResp(void *pEchoBackData,
                              const sQueueLoad &) = 0;
#endif
  };

  typedef void(task_fn)(const int iTimerID,
                        void *arg_);
}

#endif

