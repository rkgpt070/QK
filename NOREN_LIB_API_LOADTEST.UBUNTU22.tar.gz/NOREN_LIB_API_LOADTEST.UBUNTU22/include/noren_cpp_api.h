//*************************************************************************************************
// Copyright © Kambala Solutions Private Limited All rights reserved.
//
//*************************************************************************************************

#ifndef __NORENCAPI_HPP_INCL
#define __NORENCAPI_HPP_INCL

#include "noren_cpp_data_structs.h"

namespace NorenSpace
{
#include "Control.begin"     
#include "Control.gen"
#include "Control.min"
#include "Control.end"
}

#endif
