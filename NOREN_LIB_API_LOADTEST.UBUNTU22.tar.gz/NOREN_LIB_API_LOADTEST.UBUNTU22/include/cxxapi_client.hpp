//*************************************************************************************************
// Copyright © Kambala Solutions Private Limited All rights reserved.
//
//*************************************************************************************************

#ifndef __NORENCAPICLIENT_H_INCL
#define __NORENCAPICLIENT_H_INCL

#include "noren_cpp_api.h"

using namespace NorenSpace;

class CXXAPINorenClient final:public CNorenClient
{

     public:
          CXXAPINorenClient();
          ~CXXAPINorenClient();

          int LoginResponse(void * pEchoBackData,
                                    tsLoginRespParams * pOrderParams) final override;

          int  LogoutResponse(void * pEchoBackData,
                                      short siLogoutStatus) final override;

          int  CNorenClientOConnected(CNorenControl* pCNorenControl) final override;
          int  CNorenClientOReConnected(CNorenControl* pCNorenControl) final override;
          int  CNorenClientODisConnected(CNorenControl* pCNorenControl) final override;

          int  CNorenClientRConnected(CNorenControl* pCNorenControl) final override;
          int  CNorenClientRReConnected(CNorenControl* pCNorenControl) final override;
          int  CNorenClientRDisConnected(CNorenControl* pCNorenControl) final override;

          int  CNorenClientFConnected(CNorenControl* pCNorenControl) final override;
          int  CNorenClientFReConnected(CNorenControl* pCNorenControl) final override;
          int  CNorenClientFDisConnected(CNorenControl* pCNorenControl) final override;
          
          int CNorenClientSConnected(CNorenControl *pCNorenControl) final override;
          int CNorenClientSReConnected(CNorenControl *pCNorenControl) final override;
          int CNorenClientSDisConnected(CNorenControl *pCNorenControl) final override;

          int  CNorenClientStartUp(CNorenControl* pCNorenControl) final override;
          int  CNorenClientCleanUp(CNorenControl* pCNorenControl) final override;

          int  PutOrderResponse(void * pEchoBackData,
                                        char * pNorenOrd,
                                        char * pGuiOrdId,
                                        char* pReqStatus,
                                        char* pRejReason,
                                        char* pExternalRemarks,
                                        char * pUser) final override;

          int  ModifyOrderResponse(void * pEchoBackData,
                                           char * pNorenOrd,
                                           char * pGuiOrdId,
                                           char* pReqStatus,
                                           char* pRejReason,
                                           char* pExternalRemarks,
                                           char * pUser) final override;

          int  CancelOrderResponse(void * pEchoBackData,
                                           char * pNorenOrd,
                                           char * pGuiOrdId,
                                           char* pReqStatus,
                                           char* pRejReason,
                                           char* pExternalRemarks,
                                           char * pUser) final override;

          int  GetOrdersStart(void * pEchoBackData) final override;
          int  GetOrders(void * pEchoBackData,
                                 tsOrderHistory * pGetOrders) final override;
          int  GetOrdersEnd(void * pEchoBackData) final override;

          int  GetAllOrdersStart(void* pEchoBackData) final override;
          int  GetAllOrders(void* pEchoBackData,
                                    tsOrderHistory* pGetOrders) final override;
          int  GetAllOrdersEnd(void* pEchoBackData) final override;

          int  FillReport(tsFillReport* pFillReport,
                                  void* pEchoBackData) final override;
          int  OrderUpdate(tsOrderUpdate* pOrderUpdate,
                                   void* pEchoBackData) final override;
          int  MultiLegOrderUpdate(tsOrderUpdate* pOrderUpdate,
                                           tsMultiLegUpdate* pMultiLegUpdate,
                                           void* pEchoBackData) final override;
          int  OrderAdminUnSubscribeResponse(void * pEchoBackData,
                                                     char * pStatus) final override;
          int  OrderAdminGroupUnSubscribeResponse(void * pEchoBackData,
                                                  char * pStatus) final override;

          int  PositionUpdate(tsPosData** pPositionUpdate,
                                      int  PositionUpdateSize,
                                      void* pEchoBackData) final override;
          int  PositionAdminUnSubscribeResponse(void * pEchoBackData,
                                                  char * pStatus) final override;
          int  PositionAdminGroupUnSubscribeResponse(void * pEchoBackData,
                                                  char * pStatus) final override;

          int  TradeHistoryStart(void* pEchoBackData) final override;
          int  TradeHistory(void* pEchoBackData,
                                    tsFillReport* pFillReport) final override;
          int  TradeHistoryEnd(void* pEchoBackData) final override;

          int  AllTradeHistoryStart(void* pEchoBackData) final override;
          int  AllTradeHistory(void* pEchoBackData,
                                       tsFillReport* pFillReport) final override;
          int  AllTradeHistoryEnd(void* pEchoBackData) final override;

          int  GetClientsStart(void * pEchoBackData) final override;
          int  GetClients(void * pEchoBackData,
                                  tsClientData * pClntData) final override;
          int  GetClientsEnd(void * pEchoBackData) final override;

          int  GetPositionsStart(void* pEchoBackData) final override;
          int  GetPositions(tsPosData** pPositionUpdate,
                                    int PositionUpdateSize,
                                    void* pEchoBackData) final override;
          int  GetPositionsEnd(void* pEchoBackData) final override;

          int  GetAllPositionsStart(void* pEchoBackData) final override;
          int  GetAllPositions(tsPosData** pPositionUpdate,
                                       int PositionUpdateSize,
                                       void* pEchoBackData) final override;
          int  GetAllPositionsEnd(void* pEchoBackData) final override;

          int  GetAllSymbolsStart(void * pEchoBackData,
                                          char * pExchSeg) final override;
          int  GetAllSymbols(void * pEchoBackData,
                                     tsSymbolData * pSymbolData) final override;
          int  GetAllSymbolsEnd(void * pEchoBackData,
                                        char * pExchSeg) final override;
          int  GetGroupSettingsStart(void* pEchoBackData) final override;
          int  SendGroupSettings(void * pEchoBackData,
                                         int MWsize,
                                         char ** pMarketWatch) final override;
          int  GetGroupSettingsEnd(void* pEchoBackData) final override;

          int  SetGroupSettingsResp(void * pEchoBackData,
                                            char * pComment) final override;

          int  ValidateUidPwdResp(void * pEchoBackData,
                                          char * pComments) final override;

          int  OrderBookSnapQuote(char * pSymbol,
                                          char * pExchSeg,
                                          char * pExchTimeStamp,
                                          int iDepthSize,
                                          double * adAskPrice,
                                          double * adBidPrice,
                                          long * alAskSize,
                                          long * alBidSize,
                                          long * alAskNumOfOrders,
                                          long * alBidNumOfOrders) final override;

          int  UnSubscribeFeedResponse(void * pEchoBackData,
                                               char * pExchSeg,
                                               char * pSymbol,
                                               char * pStatus) final override;

          int  ExitCoverOrderResp(void * pEchoBackData,
                                          char * pComments) final override;

          int  ExitBracketOrderResp(void * pEchoBackData,
                                            char * pComments) final override;

          int RegenerateCoverOrderResp(void *pEchoBackData,
                                               char *pComments) final override;

          int RegenerateBracketOrderResp(void *pEchoBackData,
                                                 char *pComments) final override;

          int  PartialPosConResponse(void * pEchoBackData,
                                             char * pText) final override;

          int  GetRmsLimitsStart(void * pEchoBackData) final override;
          int  SendRmsLimits(tsRmsLimits * pRmsLimits,
                                     void * pEchoBackData) final override;
          int  GetRmsLimitsEnd(void * pEchoBackData) final override;

          int  GetAllRmsLimitsStart(void * pEchoBackData) final override;
          int  SendAllRmsLimits(tsRmsLimits * pRmsLimits,
                                        void * pEchoBackData) final override;
          int  GetAllRmsLimitsEnd(void * pEchoBackData) final override;

          int  ChangePasswordResponse(char * pText,
                                              int iPwdStatus,
                                              void * pEchoBackData) final override;

          int  AfterMktOrderResponse(void * pEchoBackData,
                                             char * pNorenOrd,
                                             char * pGuiOrdId,
                                             char* pReqStatus,
                                             char* pRejReason,
                                             char* pExternalRemarks,
                                             char * pUser) final override;

          int  AfterMktModifyOrderResponse(void * pEchoBackData,
                                                   char * pNorenOrd,
                                                   char * pGuiOrdId,
                                                   char* pReqStatus,
                                                   char* pRejReason,
                                                   char* pExternalRemarks,
                                                   char * pUser) final override;

          int  AfterMktMultiLegOrderResponse(void * pEchoBackData,
                                                     char * pNorenOrd,
                                                     char * pGuiOrdId,
                                                     char* pReqStatus,
                                                     char* pRejReason,
                                                     char* pExternalRemarks,
                                                     char * pUser) final override;

          int  GetIndexNamesStart(void * pEchoBackData) final override;
          int  GetIndexName(tsIndexName * pIndexName,
                                    void * pEchoBackData) final override;
          int  GetIndexNamesEnd(void * pEchoBackData) final override;

          int  GetProductListStart(void * pEchoBackData) final override;
          int  GetProductList(void * pEchoBackData,
                                      char * pExchSeg,
                                      char * pProduct) final override;
          int  GetProductListEnd(void * pEchoBackData) final override;

          int  GetUserProfileStart(void * pEchoBackData) final override;
          int  SendUserProfile(tsUserProfile * pUserProfile,
                                       void * pEchoBackData) final override;
          int  GetUserProfileEnd(void * pEchoBackData) final override;

          int  SecurityInfoStart(void * pEchoBackData) final override;
          int  SendSecurityInfo(tsSecurityInfo * pSecurityInfo,
                                        void * pEchoBackData) final override;
          int  SecurityInfoEnd(void * pEchoBackData) final override;

          int  OrderHistoryStart(void * pEchoBackData) final override;
          int  OrderHistory(void * pEchoBackData,
                                    tsOrderHistory * pOrderHistory) final override;
          int  OrderHistoryEnd(void * pEchoBackData) final override;

          int  ViewHoldingsStart(void * pEchoBackData,
                                         char * pAccountId) final override;
          int  ViewHoldings(void * pEchoBackData,
                                    tsViewHoldings * pViewHoldings) final override;
          int  ViewHoldingsEnd(void * pEchoBackData,
                                       char * pAccountId) final override;

          int  GetTopnKeysStart(void * pEchoBackData) final override;
          int  SendTopnKeys(void * pEchoBackData,
                                    char * pTopnCriteria,
                                    char * pTopnBasket) final override;
          int  GetTopnKeysEnd(void * pEchoBackData) final override;

          int  GetTopnValuesStart(void * pEchoBackData) final override;
          int  SendTopnValues(void * pEchoBackData,
                                      tsTopnValues * pTopnValues) final override;
          int  GetTopnValuesEnd(void * pEchoBackData) final override;

          int  GetAllVwapDataStart(void * pEchoBackData) final override;
          int  GetAllVwapData(void * pEchoBackData,
                                      long lStartTime,
                                      long lEndTime,
                                      tsVwapData * pVwapData) final override;
          int  GetAllVwapDataEnd(void * pEchoBackData) final override;

          int  GetMarketDataStart(void * pEchoBackData) final override;
          int  GetMarketData(tsMarketData * pMarketData,
                                     void * pEchoBackData) final override;
          int  GetMarketDataEnd(void * pEchoBackData) final override;

          int  MarketStatusNotifyStart(void * pEchoBackData) final override;
          int  MarketStatusNotify(char * pExchSeg,
                                          char * pMktStatus,
                                          char * pMktType,
                                          void * pEchoBackData) final override;
          int  MarketStatusNotifyEnd(void * pEchoBackData) final override;

          int  MarketStatusUpdate(char * pExchSeg,
                                          char * pMktStatus,
                                          char * pMktType,
                                          void * pEchoBackData) final override;
          int  MktStatusUnSubscribeResponse(char * pStatus,
                                                    void * pEchoBackData) final override;

          int  ExchangeMessageStart(void * pEchoBackData) final override;
          int  ExchangeMessage(char * pExchSeg,
                                       char * pMessage,
                                       void * pEchoBackData) final override;
          int  ExchangeMessageEnd(void * pEchoBackData) final override;

          int  ExchangeMessageUpdate(char * pExchSeg,
                                             char * pMessage,
                                             long lExchTime,
                                             void * pEchoBackData) final override;
          int  ExchangeMessageUnSubscribeResponse(char * pStatus,
                                                          void * pEchoBackData) final override;

          int  AddFundResponse(char * pStatus,
                                       char * pRemarks,
                                       void * pEchoBackData) final override;

          int  GetOrderMarginStart(void * pEchoBackData) final override;
          int  GetOrderMarginResponse(char * pRemarks,
                                              double TotalCash,
                                              double MarginOnNewOrder,
                                              double AvailableMarginForTheOrder,
                                              void * pEchoBackData) final override;
          int GetOrderMarginResponse(char *pRemarks,
                                             double TotalCash,
                                             double MarginOnNewOrder,
                                             double AvailableMarginForTheOrder,
                                             void *pEchoBackData,
                                             long lNorenUpdateTimeEpoch,
                                             long lNorenUpdateTimeNanoSec) final override;
          int  GetOrderMarginEnd(void * pEchoBackData) final override;

          int  GetOrderMargin2Start(void * pEchoBackData) final override;
          int  GetOrderMargin2Response(char * pRemarks,
                                              double TotalCash,
                                              double MarginOnNewOrder,
                                              double AvailableMarginForTheOrder,
                                              double OrderMarginUsed,
                                              void * pEchoBackData) final override;
          int  GetOrderMargin2End(void * pEchoBackData) final override;

          int GetOrderMarginLimits2(void *pEchoBackData,
                                     tsRmsLimits *pRmsLimits,
                                     double &dTotalRmsValue,
                                     double &dRmsMarginUsed);

          int  GetBasketMarginStart(void * pEchoBackData) final override;
          int  GetBasketMarginResponse(char * pRemarks,
                                               double MarginOnNewOrder,
                                               double TradedMargin,
                                               double PreviousMargin,
                                               double * BasketMargin,
                                               int BasketSize,
                                               void * pEchoBackData) final override;
          int  GetBasketMarginEnd(void * pEchoBackData) final override;

          int  GetWithdrawalAmtStart(void * pEchoBackData) final override;
          int  GetWithdrawalAmtResponse(double MaxWithdrawalAmt,
                                                void * pEchoBackData) final override;
          int  GetWithdrawalAmtEnd(void * pEchoBackData) final override;

          int  GetWithdrawFundStart(void * pEchoBackData) final override;
          int  GetWithdrawFund(char * pStatus,
                                       char * pRemarks,
                                       void * pEchoBackData) final override;
          int  GetWithdrawFundEnd(void * pEchoBackData) final override;

          int GetWithdrawFund2Start(void *pEchoBackData) final override;
          int GetWithdrawFund2(char *pAccountId,
                                       long lTranRefNumber,
                                       double dAmount,
                                       char *pTranStatus,
                                       char *pRemarks,
                                       void *pEchoBackData) final override;
          int GetWithdrawFund2End(void *pEchoBackData) final override;

          int  M2MAlertUpdate(tsM2MAlert* pM2MAlert,
                                      void * pEchoBackData) final override;
          int  M2MAlertUnSubscribeResponse(char * pStatus,
                                                   void * pEchoBackData) final override;

          int  IpoListStart(void * pEchoBackData) final override;
          int  IpoListResp(void * pEchoBackData,
                                   tsIpoList * pIpoList) final override;
          int  IpoListEnd(void * pEchoBackData) final override;

          int  IpoOrderUpdate(tsIpoOrdBook* pIpoOrderUpdate,
                                      void* pEchoBackData) final override;
          int  IpoOrderAdminUnSubscribeResponse(void * pEchoBackData,
                                                        char * pStatus) final override;

          int  IpoOrderBookStart(void * pEchoBackData) final override;
          int  IpoOrderBookResp(void * pEchoBackData,
                                        tsIpoOrdBook * pIpoOrdBookResp) final override;
          int  IpoOrderBookEnd(void * pEchoBackData) final override;

          int GetAllIpoOrdersStart(void *pEchoBackData) final override;
          int GetAllIpoOrders(void *pEchoBackData,
                                tsIpoOrdBook *pIpoOrdBookResp) final override;
          int GetAllIpoOrdersEnd(void *pEchoBackData) final override;

          int  MfOrderBookStart(void * pEchoBackData) final override;
          int  MfOrderBookResp(void * pEchoBackData,
                                       tsMfOrdBook * pMfOrdBookResp) final override;
          int  MfOrderBookEnd(void * pEchoBackData) final override;

          int  AddHoldingsResponse(char * pStatus,
                                           void * pEchoBackData) final override;

          int  AddT1HoldingsResponse(char * pStatus,
                                             void * pEchoBackData) final override;

          int  ModifyHoldingsResponse(char * pStatus,
                                              char * pRejReason,
                                              void * pEchoBackData) final override;

          int  GTTPlaceResponse(void* pEchoBackData,
                                        char* pGTTid,
                                        char* pStatus) final override;

          int  GTTModifyResponse(void* pEchoBackData,
                                         char* pGTTid,
                                         char* pStatus) final override;

          int  GTTCancelResponse(void* pEchoBackData,
                                         char* pGTTid,
                                         char* pStatus) final override;

          int  GTTOrdersStart(void * pEchoBackData) final override;
          int  GTTOrdersResp(void * pEchoBackData,
                                     tsGTTParams * pGTTParams) final override;
          int  GTTOrdersEnd(void * pEchoBackData) final override;

          int  AllGTTOrdersStart(void * pEchoBackData) final override;
          int  AllGTTOrdersResp(void * pEchoBackData,
                                        tsGTTParams * pGTTParams) final override;
          int  AllGTTOrdersEnd(void * pEchoBackData) final override;

          int  TriggeredGTTOrdersStart(void * pEchoBackData) final override;
          int  TriggeredGTTOrdersResp(void * pEchoBackData,
                                              tsGTTParams * pGTTParams,
                                              char* pStatus) final override;
          int  TriggeredGTTOrdersEnd(void * pEchoBackData) final override;

          int  AllTriggeredGTTOrdersStart(void * pEchoBackData) final override;
          int  AllTriggeredGTTOrdersResp(void * pEchoBackData,
                                                 tsGTTParams * pGTTParams,
                                                 char* pStatus) final override;
          int  AllTriggeredGTTOrdersEnd(void * pEchoBackData) final override;

          int  OCOPlaceResponse(void* pEchoBackData,
                                        char* pOCOid,
                                        char* pStatus) final override;

          int  OCOModifyResponse(void* pEchoBackData,
                                         char* pOCOid,
                                         char* pStatus) final override;

          int  OCOCancelResponse(void* pEchoBackData,
                                         char* pOCOid,
                                         char* pStatus) final override;

          int  OCOOrdersStart(void * pEchoBackData) final override;
          int  OCOOrdersResp(void * pEchoBackData,
                                     tsOCOParams * pOCOParams) final override;
          int  OCOOrdersEnd(void * pEchoBackData) final override;

          int  AllOCOOrdersStart(void * pEchoBackData) final override;
          int  AllOCOOrdersResp(void * pEchoBackData,
                                        tsOCOParams * pOCOParams) final override;
          int  AllOCOOrdersEnd(void * pEchoBackData) final override;

          int  TriggeredOCOOrdersStart(void * pEchoBackData) final override;
          int  TriggeredOCOOrdersResp(void * pEchoBackData,
                                              tsOCOParams * pOCOParams,
                                              char* pStatus) final override;
          int  TriggeredOCOOrdersEnd(void * pEchoBackData) final override;

          int  AllTriggeredOCOOrdersStart(void * pEchoBackData) final override;
          int  AllTriggeredOCOOrdersResp(void * pEchoBackData,
                                                 tsOCOParams * pOCOParams,
                                                 char* pStatus) final override;
          int  AllTriggeredOCOOrdersEnd(void * pEchoBackData) final override;

          int  GTTOCOOrdersStart(void * pEchoBackData) final override;
          int  GTTOCOOrdersResp(void * pEchoBackData,
                                        tsOCOParams * pOCOParams) final override;
          int  GTTOCOOrdersEnd(void * pEchoBackData) final override;

          int  TriggeredGTTOCOOrdersStart(void * pEchoBackData) final override;
          int  TriggeredGTTOCOOrdersResp(void * pEchoBackData,
                                                 tsOCOParams * pOCOParams,
                                                 char* pStatus) final override;
          int  TriggeredGTTOCOOrdersEnd(void * pEchoBackData) final override;

          int  ModifyUserResponse(char * pUserId,
                                          void * pEchoBackData) final override;
          int  ModifyUserUnSubscribeResponse(char * pStatus,
                                                     void * pEchoBackData) final override;

          int  PeakMarginUpdate(char* pAcctId,
                                        double dAmount,
                                        void * pEchoBackData) final override;
          int  PeakMarginUnSubscribeResponse(char * pStatus,
                                                     void * pEchoBackData) final override;

          int  ExpiryMarginUpdate(char* pAcctId,
                                          double dAmount,
                                          void * pEchoBackData) final override;
          int  ExpiryMarginUnSubscribeResponse(char * pStatus,
                                                       void * pEchoBackData) final override;

          int  RiskDashBoardUpdate(tsRiskDasBoard * pRiskDasBoardResp,
                                           void * pEchoBackData) final override;
          int  RiskDashBoardUnSubscribeResponse(char * pStatus,
                                                        void * pEchoBackData) final override;

          int  SqroffAlertUpdate(char* AlertMessage,
                                         void * pEchoBackData) final override;
          int  PreSqroffAlertUpdate(char* AlertMessage,
                                            void * pEchoBackData) final override;
          int  SqroffAlertsUnSubscribeResponse(char * pStatus,
                                                       void * pEchoBackData) final override;

          int  GTTUpdates(tsGTTUpdateParams * pGTTUpdateResp,
                                  void * pEchoBackData) final override;
          int  GTTUpdatesUnSubscribeResponse(char * pStatus,
                                                     void * pEchoBackData) final override;

          int  LimitsUpdate(tsLimitUpdatesParams * pLimitUpdateResp,
                                    void * pEchoBackData) final override;
          int  LimitsUpdateUnSubscribeResponse(char * pStatus,
                                                       void * pEchoBackData) final override;

          int  HoldingsUpdate(tsViewHoldings * pViewHoldings,
                                      void * pEchoBackData) final override;
          int  HoldingsUpdateUnSubscribeResponse(char * pStatus,
                                                         void * pEchoBackData) final override;

          int  FundsUpdate(tsFundsUpdatesParams * pFundsUpdatesParams,
                                   void * pEchoBackData) final override;
          int  FundsUpdateUnSubscribeResponse(char * pStatus,
                                                      void * pEchoBackData) final override;

          int  PlaceEquitySipOrderResp(void * pEchoBackData,
                                               char * pReqStatus,
                                               long lSipId) final override;

          int  ModifyEquitySipOrderResp(void * pEchoBackData,
                                                char * pReqStatus,
                                                long lSipId) final override;

          int  CancelSipOrderResp(void * pEchoBackData,
                                          char * pReqStatus,
                                          long lSipId) final override;

          int  GetEquitySipOrderStart(void * pEchoBackData) final override;
          int  GetEquitySipOrderResp(void * pEchoBackData,
                                             tsSipOrderUpdate * pSipOrderUpdate) final override;
          int  GetEquitySipOrderEnd(void * pEchoBackData) final override;
          int  PauseSipOrderResp(void *pEchoBackData,
                                   char *pReqStatus,
                                   long lSipId) final override;

          int  ResumeSipOrderResp(void *pEchoBackData,
                                   char *pReqStatus,
                                   long lSipId) final override;

          int  MasterMsgUpdate(sMasterMsgParams * pMasterMsgParams,
                                       void * pEchoBackData) final override;
          int  UnSubscribeMasterMsgResponse(char * pStatus,
                                                    void * pEchoBackData) final override;

          int  PosConvUpdate(tsPosConvParams * pPosConvParams,
                                     void * pEchoBackData) final override;
          int  PosConvUnSubscribeResponse(char * pStatus,
                                                  void * pEchoBackData) final override;

          int  AddMfHoldingsResponse(char * pStatus,
                                             void * pEchoBackData) final override;

          int  ViewMfHoldingsStart(void * pEchoBackData,
                                           char * pAccountId) final override;
          int  ViewMfHoldings(void * pEchoBackData,
                                      tsViewHoldings * pViewHoldings) final override;
          int  ViewMfHoldingsEnd(void * pEchoBackData,
                                         char * pAccountId) final override;

          int  GetBrokerageStart(void * pEchoBackData) final override;
          int  GetBrokerageResp(void * pEchoBackData,
                                        tsBrokerageRespParams * pBrokerageRespParams) final override;
          int  GetBrokerageEnd(void * pEchoBackData) final override;

          int  BlockAmtUpdate(char * pAccountId,
                                      char * pSrcUserId,
                                      char * pSrcBrokerId,
                                      double dBlockAmount,
                                      void * pEchoBackData) final override;
          int  BlockAmtUpdateUnSubscribeResponse(char * pStatus,
                                                         void * pEchoBackData) final override;

          int  PayInUpdate(char * pAccountId,
                                   char * pSrcUserId,
                                   char * pSrcBrokerId,
                                   double dPayIn,
                                   void * pEchoBackData) final override;
          int  PayInUpdateUnSubscribeResponse(char * pStatus,
                                                      void * pEchoBackData) final override;

          int  PayOutUpdate(char * pAccountId,
                                    char * pSrcUserId,
                                    char * pSrcBrokerId,
                                    double dPayOut,
                                    void * pEchoBackData) final override;
          int  PayOutUpdateUnSubscribeResponse(char * pStatus,
                                                       void * pEchoBackData) final override;

          int  IncrCASHUpdate(char * pAccountId,
                                      char * pSrcUserId,
                                      char * pSrcBrokerId,
                                      double dCash,
                                      void * pEchoBackData) final override;
          int  IncrCASHUpdateUnSubscribeResponse(char * pStatus,
                                                         void * pEchoBackData) final override;

          int  AmoStatusStart(void * pEchoBackData) final override;
          int  AmoStatusResponse(void * pEchoBackData,
                                         char * pExchSeg,
                                         char * pAmoStatus) final override;
          int  AmoStatusEnd(void * pEchoBackData) final override;

          int  GetOrderMarginLimits(void * pEchoBackData,
                                            tsRmsLimits * pRmsLimits,
                                            double& dTotalRmsValue,
                                            double& dRmsMarginUsed) final override;

          int  DPRMsgUpdate(char * pUserId,
                                    char * pMsgString,
                                    long lDateTime,
                                    void * pEchoBackData) final override;
          int  DPRMsgUnSubscribeResponse(char * pStatus,
                                                 void * pEchoBackData) final override;

          int  PayinStatusStart(void * pEchoBackData) final override;
          int  PayinStatusResponse(void * pEchoBackData,
                                           tsPayinStatusRespParams * pPayinStatus) final override;
          int  PayinStatusEnd(void * pEchoBackData) final override;

          int HSTokenStart(void *pEchoBackData) final override;
          int HSTokenResponse(void *pEchoBackData,
                                      char *pUser,
                                      char *pHsToken) final override;
          int HSTokenEnd(void *pEchoBackData) final override;

          int UpdateBlockAmountStart(void *pEchoBackData) final override;
          int UpdateBlockAmountResponse(void *pEchoBackData,
                                                char *pStatus) final override;
          int UpdateBlockAmountEnd(void *pEchoBackData) final override;

          int GetOptimizedBasketSequenceStart(void *pEchoBackData) final override;
          int GetOptimizedBasketSequenceResponse(void *pEchoBackData,
                                                         double dMarginUsed,
                                                         double dMarginUsedTrade,
                                                         double dMarginUsedPrev,
                                                         char *acOptimumSequence,
                                                         double dBasketMaginList[50],
                                                         int iBasketMaginListSize) final override;
          int GetOptimizedBasketSequenceEnd(void *pEchoBackData) final override;

          int FreezeAccountStart(void *pEchoBackData) final override;
          int FreezeAccountResponse(void *pEchoBackData,
                                            char *pStatus) final override;
          int FreezeAccountEnd(void *pEchoBackData) final override;

          int ResolutionTimeResp(void *pEchoBackData,
                                         long lUpdateTimeSec,
                                         long lUpdateTimeNsec,
                                         long lResolutionTime) final override;
          int DeFreezeAccountStart(void *pEchoBackData)  final override;

          int DeFreezeAccountResponse(void *pEchoBackData,
                                              char *pStatus) final override;
          int DeFreezeAccountEnd(void *pEchoBackData)  final override;

          int GetMasterMsgStart(void *pEchoBackData) final override;
          int GetMasterMsgResponse(void *pEchoBackData,
                                           sMasterMsgParams *pMasterMsgParams) final override;
          int GetMasterMsgEnd(void *pEchoBackData) final override;

          int GetPositionConvStart(void *pEchoBackData) final override;
          int GetPositionConvResponse(void *pEchoBackData,
                                           tsPosConvParams *pPosConvParams) final override;
          int GetPositionConvEnd(void *pEchoBackData) final override;
          
          int AbsIsinHoldingsResponse(char *pStatus,void *pEchoBackData) final override;

          int TradeEnhancementReport(tsTradeReport *pTradeReport,
                                             void *pEchoBackData) final override;
          int TradeEnhancementUnSubscribeResponse(void *pEchoBackData,
                                                       char *pStatus) final override;

          int GetExternalRemarksStart(void *pEchoBackData) final override;
          int GetExternalRemarksResponse(void *pEchoBackData,
                                        char *pNorenOrderNo,
                                        char *pExternalRemarks) final override;
          int GetExternalRemarksEnd(void *pEchoBackData) final override;

          int GetOrderNumberStart(void *pEchoBackData) final override;
          int GetOrderNumberResponse(void *pEchoBackData,
                                   char *pExternalRemarks,
                                   char *pNorenOrderNo) final override;
          int GetOrderNumberEnd(void *pEchoBackData) final override;
          
          int TralingOrderResponse(void *pEchoBackData,
                                   long lAQ_ID,
                                   char *pGuiOrdId,
                                   char *pReqStatus,
                                   char *pRejReason,
                                   char *pExternalRemarks,
                                   char *pUser) final override;

          int GetTrailingOrdersStart(void *pEchoBackData) final override;
          int GetTrailingOrders(void *pEchoBackData,
                              tsAQParams *pGetOrders) final override;
          int GetTrailingOrdersEnd(void *pEchoBackData) final override;

          int IceBergOrderResponse(void *pEchoBackData,
                                        long lAQ_ID,
                                        char *pGuiOrdId,
                                        char *pReqStatus,
                                        char *pRejReason,
                                        char *pExternalRemarks,
                                        char *pUser) final override;
          
          int ModifyIceBergOrderResponse(void *pEchoBackData,
                                    long lAQ_ID,
                                    char *pGuiOrdId,
                                    char *pReqStatus,
                                    char *pRejReason,
                                    char *pExternalRemarks,
                                    char *pUser) final override;

          int CancelIceBergOrderResponse(void *pEchoBackData,
                                    long lAQ_ID,
                                    char *pGuiOrdId,
                                    char *pReqStatus,
                                    char *pRejReason,
                                    char *pExternalRemarks,
                                    char *pUser) final override;

          int GetIceBergOrdersStart(void *pEchoBackData) final override;
          int GetIceBergOrders(void *pEchoBackData,
                              tsAQParams *pGetOrders) final override;
          int GetIceBergOrdersEnd(void *pEchoBackData) final override;

          int GetGroupIdResponse(void *pEchoBackData,
                              char *pGroupId,
                              char *pAccount) final override;

          int BlockUserResponse(char *pStatus,
                              void *pEchoBackData) final override;

          int CancelWithdrawFundStart(void *pEchoBackData) final override;
          int CancelWithdrawFundsResponse(char *pAccountId,
                                            long lTranRefNumber,
                                            double dAmount,
                                            int pTranStatus,
                                            void *pEchoBackData) final override;
          int CancelWithdrawFundEnd(void *pEchoBackData) final override;

          int PayoutStatusStart(void *pEchoBackData) final override;
          int PayoutStatusResponse(void *pEchoBackData,
                                   tsPayoutStatusRespParams *pPayinStatus) final override;
          int PayoutStatusEnd(void *pEchoBackData) final override;

          int GetWithdrawFundsReportStart(void *pEchoBackData) final override;
          int GetWithdrawFundsReportResp(tsFundsReportParams *pFundsReportParams,
                                            void *pEchoBackData) final override;
          int GetWithdrawFundsReportEnd(void *pEchoBackData) final override;

          int SqrOffEntityResponse(char *pStatus,
                                   void *pEchoBackData) final override;

          // int OptionCalcResponse(tsOptionCalcParams *pOptionCalcParams,
          //                         void *pEchoBackData) final override;
          int GetOrderNumberByGuiStart(void *pEchoBackData) final override;
          int GetOrderNumberByGuiResponse(void *pEchoBackData,
                                          char *pGuiOrdId,
                                          char *pNorenOrderNo,
                                          char *pReportType) final override;
          int GetOrderNumberByGuiEnd(void *pEchoBackData) final override;
          
          int EntityCancelOrderStart(void *pEchoBackData) final override;
          int EntityCancelOrderResponse(void *pEchoBackData,
                                    char *pNorenOrderNo) final override;
          int EntityCancelOrderEnd(void *pEchoBackData) final override;
          
          int getAllAuctionSymbolsStart(void *pEchoBackData) final override;
          int getAllAuctionSymbolsResp(void *pEchoBackData,
                                   tsAuctionSymbolsParams *pPayinStatus) final override;
          int getAllAuctionSymbolsEnd(void *pEchoBackData) final override;
          
          int OfsOrderUpdate(tsOfsOrderBook *pOfsOrderUpdate,
                              void *pEchoBackData) final override;
          int OfsOrderAdminUnSubscribeResponse(void *pEchoBackData,
                              char *pStatus) final override;
          
          int OfsOrderHistoryStart(void *pEchoBackData) final override;
          int OfsOrderHistory(void *pEchoBackData,
                              tsOfsOrderBook *pOfsOrderBook) final override;
          int OfsOrderHistoryEnd(void *pEchoBackData) final override;

          int OfsOrderBookStart(void *pEchoBackData) final override;
          int OfsOrderBookResp(void *pEchoBackData,
                              tsOfsOrderBook *pOfsOrdBookResp) final override;
          int OfsOrderBookEnd(void *pEchoBackData) final override;

          int GetAllOfsOrdersStart(void *pEchoBackData) final override;
          int GetAllOfsOrders(void *pEchoBackData,
                             tsOfsOrderBook *pOfsOrdBookResp) final override;
          int GetAllOfsOrdersEnd(void *pEchoBackData) final override;

          int ThresholdAlertUpdate(tsThresholdAlertParams *pThresholdAlertUpdate,
                                   void *pEchoBackData) final override;

          int DPRThresholdAlertUnSubscribeResponse(char *pStatus,
                                                  void *pEchoBackData) final override;

          int GetMaxBlockAmtStart(void *pEchoBackData) final override;
          int GetMaxBlockAmtResponse(double MaxBlockAmt,
                                   void *pEchoBackData) final override;
          int GetMaxBlockAmtEnd(void *pEchoBackData) final override;

          int CallBackError(void *pEchoBackData,
                         tsCallbackErrorParams *pCallbackErrorParams) final override;

          int QueueLoadResp(void *pEchoBackData, const sQueueLoad &) final override;

//          int ThreadCountResp(void *pEchoBackData,
//                                      long lOrderThreadCreated,
//                                      long lOrderThreadClosed,
//                                      long lRequestThreadCreated,
//                                      long lRequestThreadClosed,
//                                      long lServiceRequestThreadCreated,
//                                      long lServiceRequestThreadClosed) final override;
};

#endif //__NORENCAPICLIENT_H_INCL
