//*************************************************************************************************
// Copyright © Kambala Solutions Private Limited All rights reserved.
//
//*************************************************************************************************

#include "cxxapi_client.hpp"
#include <unistd.h>
#include "pugixml/pugixml.hpp"
#include <iostream>
#include <fstream>
#define BUFFER_SIZE 4096

#define LOG_WRITE "LOG_WRITE"
#define FORM_UPDATE_TIME2(sec, nsec) (((sec - ((sec / (86400 * 365)) * (86400 * 365))) * 1000000) + (nsec / 1000))

unsigned int microseconds = 10;

int imIntrvlms;
int imOrderPerIntrvl;
int imOrderOnLastIter;
long lmTestOrderCount;
bool logflag = false;

char *Product;
char *OrdType;
char *acOrderRemarks;

char **Buy = nullptr;
char **Sell = nullptr;
unsigned long countB = 1;
unsigned long countS = 1;

char *BuyPrefix = nullptr;
char *SellPrefix = nullptr;

char **ExchSegArray = nullptr;
char **TradingSymblArray = nullptr;
char **ProductArray = nullptr;
char **OrderTypeArray = nullptr;

long QtyArray[100];
double PriceArray[100];

int lB = 0, lS = 0, ODB = 0, ODS = 0;
int Invcount = 2;
int ScripCount = 0;

void s_get_current_time_in_nano_sec(unsigned long &sec,
                                    unsigned long &nsec)
{
     struct timespec ts_dtime;
     clock_gettime(CLOCK_REALTIME, &ts_dtime);
     sec = ts_dtime.tv_sec;
     nsec = ts_dtime.tv_nsec;
}

char *findkey(pugi::xml_node oRoot, const char *const pcKey) noexcept
{
     if (pcKey != nullptr)
     {
          int ikeyCount = 0;
          char *pkeyData[16] = {};
          char *pTokenizeData = nullptr;
          char *pcTmpBuff = strdup(pcKey);
          while ((pTokenizeData = strsep(&pcTmpBuff, "/")))
          {
               if (pTokenizeData)
               {
                    pkeyData[ikeyCount++] = pTokenizeData;
               }
               else
                    break;
          }

          int iReadkeyCount = 0;
          pugi::xml_node childnode = oRoot.child(pkeyData[iReadkeyCount++]); // parent root

          while (childnode)
          {
               if (iReadkeyCount == ikeyCount)
               {
                    free(pkeyData[0]);
                    return (char *)strndup((char *)childnode.child_value(),
                                           __builtin_strlen((char *)childnode.child_value()));
               }

               childnode = childnode.child(pkeyData[iReadkeyCount++]); // parent root
          }

          free(pkeyData[0]);
     }
     return nullptr;
}

int CXXAPINorenClient::LoginResponse(void *pEchoBackData,
                                     tsLoginRespParams *pOrderParams)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer),
              "LoginResponse\n{"
              "\nEchoBackData [%s]\nStatus [%s]\nPassword Reset [%d]\n"
              "Login Time [%ld]\nWrong Attempt Count [%d]\nSessionID [%s]\n"
              "Days Left [%d]\nDevicePinFlag[%d]\n}",
              (char *)pEchoBackData,
              pOrderParams->acStatus,
              pOrderParams->bPasswordReset,
              pOrderParams->lLoginTime,
              pOrderParams->iLstAtmptcount,
              pOrderParams->acSessId,
              pOrderParams->iDaysLeft,
              pOrderParams->bDevicePin);
     logString += buffer;

     logString += " \nExchange Segment : [";
     for (int i = 0; i < pOrderParams->iExchSegSize; i++)
     {
          logString += pOrderParams->ppcExchSeg[i];
          logString += ' ';
     }
     logString += ']';
     logString += " \nProduct : [";
     for (int i = 0; i < pOrderParams->iProductSize; i++)
     {
          logString += pOrderParams->ppcProduct[i];
          logString += ' ';
     }
     logString += "]\n}";
     std::clog << logString << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::LogoutResponse(void *pEchoBackData,
                                      short siLogoutStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "LogoutResponse  EchoBackData: %s | Status :%hd|",
              (char *)pEchoBackData,
              siLogoutStatus);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::PutOrderResponse(void * /*pEchoBackData*/,
                                        char *pNorenOrd,
                                        char *,
                                        char *,
                                        char *,
                                        char *,
                                        char *)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PlaceOrderResponse  NorenOrd: %s ",
              pNorenOrd);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::FillReport(tsFillReport *pFillReport,
                                  void *)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char cOut[256];

     if (logflag)
     {
          unsigned long lTimeStamp = 0;
          unsigned long lTimeStampnsec = 0;

          s_get_current_time_in_nano_sec(lTimeStamp, lTimeStampnsec);
          snprintf(cOut, 256, "TrdUpd:%s:%s:%ld:%ld", pFillReport->acExternalRemarks,
                   pFillReport->acNorenOrdNum,
                   lTimeStamp, lTimeStampnsec);
     }

     snprintf(cOut, 256, ":%s:%c:%c:%ld:%ld",
              pFillReport->acNorenOrdNum,
              pFillReport->cStatus, pFillReport->cRepTyp,
              pFillReport->lNorenUpdateTimeEpoch,
              pFillReport->lNorenUpdateTimeNanoSec);

     std::clog << cOut << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::OrderUpdate(tsOrderUpdate *pOrderUpdate,
                                   void *pEchoBackData)
{
     char cOut[256];

     if (logflag)
     {
          unsigned long lTimeStamp = 0;
          unsigned long lTimeStampnsec = 0;

          s_get_current_time_in_nano_sec(lTimeStamp, lTimeStampnsec);
          snprintf(cOut, 256, "OrdUpd:%s:%s:%c:%c:%ld:%ld", pOrderUpdate->sOrderParams.acExternalRemarks,
                   pOrderUpdate->acNorenOrdNum,
                   pOrderUpdate->cStatus, pOrderUpdate->cRepTyp,
                   lTimeStamp, lTimeStampnsec);
     }

     snprintf(cOut, 256, ":%s:%c:%c:%ld:%ld",
              pOrderUpdate->acNorenOrdNum,
              pOrderUpdate->cStatus, pOrderUpdate->cRepTyp,
              pOrderUpdate->lNorenUpdateTimeEpoch,
              pOrderUpdate->lNorenUpdateTimeNanoSec);

     std::clog << cOut << std::endl;
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OrderUpdate:1st :pEchoBackData :%s| Exch :%s | Act Id :%s| Ord Duration :%s|"
                                      " CustomFirm :%s | Product :%s | Ord Type :%s | Trd Symbol :%s | Trans Type :%s | acGuiOrdId :%s|"
                                      " Token :%s  |Price :%f  |TriggerPrice :%f |Quantity :%ld |DiscQuantity :%ld |CancelledSize :%ld|"
                                      " OrdSrc :%s |acOrdRemarks :%s  |BookProfitPrice :%d | BookLossPrice :%d |TrailingPrice :%d|"
                                      " iSnoOrdType :%d |ExternalRemarks :%s | AlgoName :%s | AlgoId :%s | AlgoCategory :%s |User :%s|"
                                      " VendorCode  :%s |  AvgPrice :%f | FilledShares :%ld |UnfilledSize :%ld |  NorenOrdNum :%s|"
                                      "ReqId :%s | ExchOrdId :%s |Text :%s |OrdStatus :%s |Status :%c | ReportType :%s | RepTyp :%c|"
                                      " NorenTime Sec :%s|  NorenUpdateTime :%s | lNorenUpdateTimeNanoSec :%ld | ExchTime :%s | ExchTimeNanoSec :%ld|"
                                      " ExchOrdUpdateTime :%s| RejectionBy :%s | Rejection Reason :%s | OrderGenType :%s | NorenTime MiliSec :%s|"
                                      " lNorenTimeNanoSec :%ld | lRejQty :%ld| RejOrdSrc :%s| RejPriceType :%s|"
                                      "  dRmsPrice :%f |GTTid :%ld |acIpAddr :%s| acChannel :%s |acUserAgent :%s |acAppInstallId :%s|",
              (char *)pEchoBackData,
              pOrderUpdate->sOrderParams.acExchSeg,
              pOrderUpdate->sOrderParams.acAccountId,
              pOrderUpdate->sOrderParams.acOrdDuration,
              pOrderUpdate->sOrderParams.acCustomerFirm,
              pOrderUpdate->sOrderParams.acProduct,
              pOrderUpdate->sOrderParams.acOrderType,
              pOrderUpdate->sOrderParams.acTrdSymbol,
              pOrderUpdate->sOrderParams.acTransType,
              pOrderUpdate->sOrderParams.acGuiOrdId,
              pOrderUpdate->sOrderParams.acToken,
              pOrderUpdate->sOrderParams.dPrice,
              pOrderUpdate->sOrderParams.dTriggerPrice,
              pOrderUpdate->sOrderParams.lQuantity,
              pOrderUpdate->sOrderParams.lDiscQuantity,
              pOrderUpdate->sOrderParams.lCancelledSize,
              pOrderUpdate->sOrderParams.acOrdSrc,
              pOrderUpdate->sOrderParams.acOrdRemarks,
              pOrderUpdate->sOrderParams.iBookProfitPrice,
              pOrderUpdate->sOrderParams.iBookLossPrice,
              pOrderUpdate->sOrderParams.iTrailingPrice,
              pOrderUpdate->sOrderParams.iSnoOrdType,
              pOrderUpdate->sOrderParams.acExternalRemarks,
              pOrderUpdate->sOrderParams.acAlgoName,
              pOrderUpdate->sOrderParams.acAlgoId,
              pOrderUpdate->sOrderParams.acAlgoCategory,
              //                    " Pan "
              //                    << pOrderUpdate->acPan <<

              pOrderUpdate->sOrderParams.acUser,
              pOrderUpdate->sOrderParams.acVendorCode,
              pOrderUpdate->dAvgPrice,
              pOrderUpdate->lFilledShares,
              pOrderUpdate->lUnfilledSize,
              pOrderUpdate->acNorenOrdNum,
              pOrderUpdate->acReqId,
              pOrderUpdate->acExchOrdId,
              pOrderUpdate->acText,
              pOrderUpdate->acOrdStatus,
              pOrderUpdate->cStatus,
              pOrderUpdate->acReportType,
              pOrderUpdate->cRepTyp,
              pOrderUpdate->acNorenTimeSec,
              pOrderUpdate->acNorenUpdateTime,
              pOrderUpdate->lNorenUpdateTimeNanoSec,
              pOrderUpdate->acExchTime,
              pOrderUpdate->lExchTimeNanoSec,
              pOrderUpdate->acOrgExchTime,
              pOrderUpdate->acRejectionBy,
              pOrderUpdate->acRejReason,
              pOrderUpdate->acOrderGenType,
              pOrderUpdate->acNorenTimeMiliSec,
              pOrderUpdate->lNorenTimeNanoSec,
              pOrderUpdate->lRejQty,
              pOrderUpdate->acRejOrdSrc,
              pOrderUpdate->acRejPriceType,
              pOrderUpdate->dRmsPrice,
              pOrderUpdate->lBasketId,
              pOrderUpdate->sOrderParams.acIpAddr,
              pOrderUpdate->sOrderParams.acChannel,
              pOrderUpdate->sOrderParams.acUserAgent,
              pOrderUpdate->sOrderParams.acAppInstallId);
     logString += buffer;

     if (pOrderUpdate->sOrderParams.acIpAddr)
     {
          snprintf(buffer, sizeof(buffer), "acIpAddr :%s |", pOrderUpdate->sOrderParams.acIpAddr);
          logString += buffer;
     }
     if (pOrderUpdate->sOrderParams.acChannel)
     {
          snprintf(buffer, sizeof(buffer), "acChannel :%s |", pOrderUpdate->sOrderParams.acChannel);
          logString += buffer;
     }
     if (pOrderUpdate->sOrderParams.acUserAgent)
     {
          snprintf(buffer, sizeof(buffer), "acUserAgent :%s |", pOrderUpdate->sOrderParams.acUserAgent);
          logString += buffer;
     }
     if (pOrderUpdate->sOrderParams.acAppInstallId)
     {
          snprintf(buffer, sizeof(buffer), "acAppInstallId :%s |", pOrderUpdate->sOrderParams.acAppInstallId);
          logString += buffer;
     }
     std::clog << logString << std::endl;

     return 0;
}
int CXXAPINorenClient::OrderAdminUnSubscribeResponse(void *pEchoBackData,
                                                     char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OrderAdminUnSubscribeResponse : EchoBackData: %s Status :%s",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

void PlaceOrderTask1(int, void *pNorenControl)
{
     std::cout << "PlaceOrderTask1 : " << lmTestOrderCount << std::endl;

     if (!lmTestOrderCount)
          return;

     int iOpi = imOrderPerIntrvl;
     if (lmTestOrderCount < (imOrderPerIntrvl * 2))
          iOpi += imOrderOnLastIter;

     for (int i = 0; i < iOpi && lmTestOrderCount > 0; ++i)
     {
          unsigned long lTimeStamp = 0;
          unsigned long lTimeStampnsec = 0;
          char *EchoBackData;

          if (BuyPrefix)
          {
               char __[64];
               lB++;
               int index = lB % Invcount;
               ODB++;
               int ODindex = ODB % ScripCount;

               tsOrderParams oPlaceOrder;
               oPlaceOrder.acTrdSymbol = TradingSymblArray[ODindex];
               oPlaceOrder.acExchSeg = ExchSegArray[ODindex];
               oPlaceOrder.acTransType = (char *)"B";
               oPlaceOrder.acOrderType = OrderTypeArray[ODindex];
               oPlaceOrder.acProduct = ProductArray[ODindex];
               oPlaceOrder.acOrdDuration = (char *)"DAY";
               oPlaceOrder.acAccountId = Buy[index];
               oPlaceOrder.acUser = Buy[index];
               oPlaceOrder.acCustomerFirm = (char *)"C";
               oPlaceOrder.lQuantity = QtyArray[ODindex];
               oPlaceOrder.lDiscQuantity = QtyArray[ODindex];
               oPlaceOrder.dPrice = PriceArray[ODindex];
               oPlaceOrder.acOrdSrc = (char *)"CPPAPI";
               oPlaceOrder.acOrdRemarks = acOrderRemarks;

               s_get_current_time_in_nano_sec(lTimeStamp, lTimeStampnsec);
               snprintf(__, 64, "B-%ld", FORM_UPDATE_TIME2(lTimeStamp, lTimeStampnsec));
               EchoBackData = __;
               oPlaceOrder.acExternalRemarks = __;

               ((CNorenControl *)pNorenControl)->PlaceOrder(EchoBackData, &oPlaceOrder, Buy[index]);
          }

          usleep(microseconds);

          if (SellPrefix)
          {
               char __[64];
               lS++;
               int index = lS % Invcount;
               ODS++;
               int ODindex = ODS % ScripCount;

               tsOrderParams oPlaceOrder;
               oPlaceOrder.acTrdSymbol = TradingSymblArray[ODindex];
               oPlaceOrder.acExchSeg = ExchSegArray[ODindex];
               oPlaceOrder.acTransType = (char *)"S";
               oPlaceOrder.acOrderType = OrderTypeArray[ODindex];
               oPlaceOrder.acProduct = ProductArray[ODindex];
               oPlaceOrder.acOrdDuration = (char *)"DAY";
               oPlaceOrder.acAccountId = Sell[index];
               oPlaceOrder.acUser = Sell[index];
               oPlaceOrder.acCustomerFirm = (char *)"C";
               oPlaceOrder.lQuantity = QtyArray[ODindex];
               oPlaceOrder.lDiscQuantity = QtyArray[ODindex];
               oPlaceOrder.dPrice = PriceArray[ODindex];
               oPlaceOrder.acOrdSrc = (char *)"CPPAPI";
               oPlaceOrder.acOrdRemarks = acOrderRemarks;

               s_get_current_time_in_nano_sec(lTimeStamp, lTimeStampnsec);
               snprintf(__, 64, "S-%ld", FORM_UPDATE_TIME2(lTimeStamp, lTimeStampnsec));
               EchoBackData = __;
               oPlaceOrder.acExternalRemarks = __;

               ((CNorenControl *)pNorenControl)->PlaceOrder(EchoBackData, &oPlaceOrder, Sell[index]);
          }

          --lmTestOrderCount;
     }
}

void LatencyCheck(int no_of_orders,
                  int To_no_of_seconds,
                  CNorenControl *pNorenControl)
{
     int im1secOrderCount = no_of_orders;
     lmTestOrderCount = (long)(no_of_orders * To_no_of_seconds);

     imIntrvlms = 10; // millisec
     imOrderPerIntrvl = 1;
     imOrderOnLastIter = 0;

     if (im1secOrderCount < 100)
     {
          imIntrvlms = 1000 / im1secOrderCount;
          imOrderPerIntrvl = (int)ceil((float)im1secOrderCount / (float)imIntrvlms);

          imOrderOnLastIter = (int)(lmTestOrderCount % imOrderPerIntrvl);
     }
     else
     {
          imIntrvlms = 10;
          imOrderPerIntrvl = (int)ceil((float)im1secOrderCount / (float)100);
          imOrderOnLastIter = (int)(lmTestOrderCount % imOrderPerIntrvl);
     }

     std::cout << " pNorxEMSApp->lmTestOrderCount" << lmTestOrderCount << " pNorxEMSApp->imIntrvlms" << imIntrvlms << " pNorxEMSApp->imOrderPerIntrvl" << imOrderPerIntrvl << "pNorxEMSApp->imOrderOnLastIter" << imOrderOnLastIter << std::endl;

     while (lmTestOrderCount > 0)
     {
          PlaceOrderTask1(0, pNorenControl);
          usleep(imIntrvlms * 1000); // milliseconds -> microseconds
     }
}

int main(int argc,
         char *argv[])
{
     /*---------------------------------------VARIABLE DECLARATIONS-------------------------------*/

     char *xml_file = (char *)"/home/xxx/config.xml";

     if (argc < 1)
     {
          printf("menu options--->\n"
                 "1)./Exe config_xml AdminUsr AdminPwd Mode(1->Order Update, 2-> Position Update) inputdata_xml\n"
                 "2)./Exe config_xml AdminUsr AdminPwd TotalSeconds OrderRate InvUsrcount InputData_xml\n");
     }

     if (argc > 1)
          xml_file = argv[1];

     CXXAPINorenClient oCMyNorenClient;
     CNorenControl *pNorenControl = new CNorenControl(&oCMyNorenClient,
                                                      xml_file, true);

     if (pNorenControl->IsValid())
     {
          if (std::getenv(LOG_WRITE) != NULL)
          {
               auto _log = atoi(std::getenv(LOG_WRITE));
               if (_log == 1)
                    logflag = true;
          }

          char *AdminUserID = nullptr;
          char *AdminPassword = nullptr;
          char *ClientData = (char *)"ClientData";

          char *pFilePath = nullptr;
          int Mode = 0; // 0- place order
          int TotalSeconds = 0;
          int OrderRate = 0;

          if (argc == 8)
          {
               //./Exe xml adminusr AdminPwd TotalSeconds OrderRate Invcount pFilePath
               AdminUserID = argv[2];
               AdminPassword = argv[3];
               TotalSeconds = atoi(argv[4]);
               OrderRate = atoi(argv[5]);
               Invcount = atoi(argv[6]);
               pFilePath = argv[7];
          }
          else if (argc == 6)
          {
               //./Exe xml adminusr AdminPwd Mode pFilePath
               AdminUserID = argv[2];
               AdminPassword = argv[3];
               Mode = atoi(argv[4]); // 1->Order Update, 2-> Position Update
               pFilePath = argv[5];
          }
          else
          {
               printf("menu options--->\n"
                      "1)./Exe config_xml AdminUsr AdminPwd Mode(1->Order Update, 2-> Position Update) inputdata_xml\n"
                      "2)./Exe config_xml AdminUsr AdminPwd TotalSeconds OrderRate InvUsrcount InputData_xml\n");

               return 0;
          }
          // login
          pNorenControl->Admin_Login(ClientData, AdminUserID, AdminPassword);
          pNorenControl->SetLogWriting(true, true);
          // bool bRun = false;
          int iCount = 3;
          while (!pNorenControl->IsLogged() && iCount--)
          {
               sleep(1);
          }

          pugi::xml_document oXmlDoc;
          pugi::xml_node oRoot;

          if (!oXmlDoc.load_file(pFilePath))
          {
               printf("Error: cozy_xml couldn't load the file properly.\n");
               return 0;
          }
          else
          {
               oRoot = oXmlDoc.child((char *)"root");
          }

          if (oRoot.empty())
          {
               printf("Error: extract_data_from_xml.\n");
               return 0;
          }

          if (Mode == 0)
          {
               // fetch prefix
               Buy = (char **)malloc(Invcount * sizeof(char *));
               Sell = (char **)malloc(Invcount * sizeof(char *));

               if (Buy == NULL && Sell == NULL)
               {
                    printf("Failure to allocate the memory\n");
                    return 0;
               }

               BuyPrefix = findkey(oRoot, (char *)"Buy");
               SellPrefix = findkey(oRoot, (char *)"Sell");
               if (BuyPrefix == NULL && SellPrefix == NULL)
               {
                    printf("Unable to fetch the data from xml\n");
                    return 0;
               }

               // for loop to create inv
               if (BuyPrefix)
               {
                    for (int k = 0; k < Invcount; k++)
                    {
                         char __[64];
                         snprintf(__, 64, "%s%ld", BuyPrefix, countB++);
                         Buy[k] = strdup(__);
                         printf("Buy[%d]: %s\n", k, Buy[k]);
                    }
               }
               if (SellPrefix)
               {
                    for (int k = 0; k < Invcount; k++)
                    {
                         char __[64];
                         snprintf(__, 64, "%s%ld", SellPrefix, countS++);
                         Sell[k] = strdup(__);
                         printf("Sell[%d]: %s\n", k, Sell[k]);
                    }
               }

               ScripCount = atoi(findkey(oRoot, (char *)"Scrip_Count"));
               int _form = 1;

               ExchSegArray = (char **)malloc(ScripCount * sizeof(char *));
               TradingSymblArray = (char **)malloc(ScripCount * sizeof(char *));
               ProductArray = (char **)malloc(ScripCount * sizeof(char *));
               OrderTypeArray = (char **)malloc(ScripCount * sizeof(char *));

               if (ExchSegArray == NULL || TradingSymblArray == NULL || ProductArray == NULL || OrderTypeArray == NULL)
               {
                    printf("Failure to allocate the memory for scrips\n");
                    return 0;
               }

               for (int k = 0; k < ScripCount; k++)
               {
                    char __[64];
                    long _local = _form++;

                    snprintf(__, 64, "TradingSymbol%ld", _local);
                    TradingSymblArray[k] = findkey(oRoot, __);

                    snprintf(__, 64, "ExchangeSegment%ld", _local);
                    ExchSegArray[k] = findkey(oRoot, __);

                    snprintf(__, 64, "Quantity%ld", _local);
                    QtyArray[k] = atol(findkey(oRoot, __));

                    snprintf(__, 64, "Price%ld", _local);
                    PriceArray[k] = atof(findkey(oRoot, __));

                    snprintf(__, 64, "Product%ld", _local);
                    ProductArray[k] = findkey(oRoot, __);

                    snprintf(__, 64, "OrderType%ld", _local);
                    OrderTypeArray[k] = findkey(oRoot, __);
               }

               for (int k = 0; k < ScripCount; k++)
               {
                    printf("%s:%s:%ld:%lf:%s:%s\n", ExchSegArray[k], TradingSymblArray[k],
                           QtyArray[k], PriceArray[k], ProductArray[k], OrderTypeArray[k]);
               }

               acOrderRemarks = findkey(oRoot, (char *)"OrderRemarks");
               pNorenControl->OrderAdminSubscribe(ClientData, nullptr);
               LatencyCheck(OrderRate, TotalSeconds, pNorenControl);
               sleep(TotalSeconds + 600);
               pNorenControl->OrderAdminUnSubscribe(ClientData, nullptr);
               if (BuyPrefix)
               {
                    free(BuyPrefix);
                    for (int k = 0; k < Invcount; k++)
                    {
                         free(Buy[k]);
                    }
               }

               if (SellPrefix)
               {
                    free(SellPrefix);
                    for (int k = 0; k < Invcount; k++)
                    {
                         free(Sell[k]);
                    }
               }

               free(Buy);
               free(Sell);

               free(ExchSegArray);
               free(TradingSymblArray);
               free(ProductArray);
               free(OrderTypeArray);
          }
          else if (Mode == 1)
          {
               // Orderadminsub
               pNorenControl->OrderAdminSubscribe(ClientData, nullptr);
          }
          else if (Mode == 2)
          {
               // PositionSub
               pNorenControl->PositionAdminSubscribe(ClientData);
          }
          char *version = nullptr;
          pNorenControl->GetApiVersion(version);
          std::cout << "VERSION :" << version << std::endl;

          // sleep(180);
     }

     pNorenControl->shutdown_Control();
     delete pNorenControl;

     std::cout << "shutdown !! \n";
     return 0;
}
