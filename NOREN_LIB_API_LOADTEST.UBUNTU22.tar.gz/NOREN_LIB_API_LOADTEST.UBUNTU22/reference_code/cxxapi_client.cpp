
//*************************************************************************************************
// Copyright © Kambala Solutions Private Limited All rights reserved.
//
//*************************************************************************************************

#include "cxxapi_client.hpp"
#include <time.h>
#include <fstream>
#include <iomanip>
#define BUFFER_SIZE 4096
using std::ofstream;
extern char *timeLogFilePath;
long s_get_time_in_micro_seconds() noexcept
{
     struct timespec tCurrentTime;
     clock_gettime(CLOCK_REALTIME, &tCurrentTime);

     return tCurrentTime.tv_sec * (int)1e6 + (tCurrentTime.tv_nsec / 1000);
}

long s_get_time_in_nano_seconds() noexcept
{
     struct timespec tCurrentTime;
     clock_gettime(CLOCK_REALTIME, &tCurrentTime);

     return tCurrentTime.tv_sec * (int)1e9 + (tCurrentTime.tv_nsec);
}

long s_get_time_in_seconds() noexcept
{
     struct timespec tCurrentTime;
     clock_gettime(CLOCK_REALTIME, &tCurrentTime);

     return tCurrentTime.tv_sec;
}

CXXAPINorenClient::CXXAPINorenClient()
{
     std::clog << __PRETTY_FUNCTION__ << std::endl;
}

CXXAPINorenClient::~CXXAPINorenClient()
{
     std::clog << __PRETTY_FUNCTION__ << std::endl;
}

// int CXXAPINorenClient::LoginResponse(void *pEchoBackData,
//                                      tsLoginRespParams *pOrderParams)
// {
// #ifdef ENABLE_TIME_LOG
//      long starttime = s_get_time_in_micro_seconds();
// #endif
//      std::string logString;
//      char buffer[BUFFER_SIZE];
//      snprintf(buffer,sizeof(buffer),
//               "LoginResponse\n{"
//               "\nEchoBackData [%s]\nStatus [%s]\nPassword Reset [%d]\n"
//               "Login Time [%ld]\nWrong Attempt Count [%d]\nSessionID [%s]\n"
//               "Days Left [%d]\nDevicePinFlag[%d]\n}",
//               (char *)pEchoBackData,
//               pOrderParams->acStatus,
//               pOrderParams->bPasswordReset,
//               pOrderParams->lLoginTime ,
//               pOrderParams->iLstAtmptcount,
//               pOrderParams->acSessId ,
//               pOrderParams->iDaysLeft,
//               pOrderParams->bDevicePin);
//      logString += buffer;

//      logString +=  " \nExchange Segment : [";
//      for (int i = 0; i < pOrderParams->iExchSegSize; i++)
//      {
//           logString +=  pOrderParams->ppcExchSeg[i];
//           logString += ' ';

//      }
//      logString += ']';
//      logString += " \nProduct : [";
//      for (int i = 0; i < pOrderParams->iProductSize; i++)
//      {
//           logString += pOrderParams->ppcProduct[i];
//           logString += ' ';
//      }
//      logString += "]\n}";
//      std::clog << logString << std::endl;

// #ifdef ENABLE_TIME_LOG
//      long endtime = s_get_time_in_micro_seconds();
//      long res = endtime-starttime;
//      std::clog <<"ENABLE_TIME_LOG|" << __FUNCTION__ << "|"<< endtime<<"|"<<starttime<< "|"<<res<<std::endl;
// #endif
//      return 0;
// }

// int CXXAPINorenClient::LogoutResponse(void *pEchoBackData,
//                                       short siLogoutStatus)
// {
// #ifdef ENABLE_TIME_LOG
//      long starttime = s_get_time_in_micro_seconds();
// #endif

//      char buffer[BUFFER_SIZE];
//      snprintf(buffer,sizeof(buffer),"LogoutResponse  EchoBackData: %s | Status :%hd|",
//               (char *)pEchoBackData,
//               siLogoutStatus);
//      std::clog << buffer << std::endl;

// #ifdef ENABLE_TIME_LOG
//      long endtime = s_get_time_in_micro_seconds();
//      long res = endtime-starttime;
//      std::clog <<"ENABLE_TIME_LOG|" << __FUNCTION__ << "|"<< endtime<<"|"<<starttime<< "|"<<res<<std::endl;
// #endif
//      return 0;
// }

int CXXAPINorenClient::CNorenClientOConnected(CNorenControl *pCNorenControl)
{

#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     std::clog << "CNorenClientOConnected [" << pCNorenControl << ']' << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::CNorenClientOReConnected(CNorenControl *pCNorenControl)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     std::clog << "CNorenClientOReConnected [" << pCNorenControl << ']' << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::CNorenClientODisConnected(CNorenControl *pCNorenControl)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::clog << "CNorenClientODisConnected [" << pCNorenControl << ']' << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::CNorenClientRConnected(CNorenControl *pCNorenControl)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::clog << "CNorenClientRConnected [" << pCNorenControl << ']' << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::CNorenClientRReConnected(CNorenControl *pCNorenControl)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     std::clog << "CNorenClientRReConnected [" << pCNorenControl << ']' << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::CNorenClientRDisConnected(CNorenControl *pCNorenControl)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::clog << "CNorenClientRDisConnected [" << pCNorenControl << ']' << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::CNorenClientFConnected(CNorenControl *pCNorenControl)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::clog << "CNorenClientFConnected [" << pCNorenControl << ']' << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::CNorenClientFReConnected(CNorenControl *pCNorenControl)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::clog << "CNorenClientFReConnected [" << pCNorenControl << ']' << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::CNorenClientFDisConnected(CNorenControl *pCNorenControl)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::clog << "CNorenClientFDisConnected [" << pCNorenControl << ']' << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::CNorenClientSConnected(CNorenControl *pCNorenControl)
{

#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     std::clog << "CNorenClientSConnected [" << pCNorenControl << ']' << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::CNorenClientSReConnected(CNorenControl *pCNorenControl)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     std::clog << "CNorenClientSReConnected [" << pCNorenControl << ']' << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::CNorenClientSDisConnected(CNorenControl *pCNorenControl)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::clog << "CNorenClientSDisConnected [" << pCNorenControl << ']' << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::CNorenClientStartUp(CNorenControl *pCNorenControl)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     std::clog << "CNorenClientStartUp [" << pCNorenControl << ']' << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::CNorenClientCleanUp(CNorenControl *pCNorenControl)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::clog << "CNorenClientCleanUp [" << pCNorenControl << ']' << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
// int CXXAPINorenClient::PutOrderResponse(void *pEchoBackData,
//                                         char *pNorenOrd,
//                                         char *pGuiOrdId,
//                                         char *pReqStatus,
//                                         char *pRejReason,
//                                         char *pExternalRemarks,
//                                         char *pUser)
// {
// #ifdef ENABLE_TIME_LOG
//      long starttime = s_get_time_in_micro_seconds();

// #endif

//      char buffer[BUFFER_SIZE];
//      snprintf(buffer,sizeof(buffer),"PlaceOrderResponse EchoBackData: %s NorenOrd: %s GuiOrderID: %s pReqStatus: %s pRejReason: %s pExternalRemarks: %s User: %s",
//               (char *)pEchoBackData,
//               pNorenOrd,
//               pGuiOrdId,
//               pReqStatus,
//               pRejReason,
//               pExternalRemarks,
//               pUser);

//      std::clog << buffer << std::endl;

// #ifdef ENABLE_TIME_LOG
//      long endtime = s_get_time_in_micro_seconds();
//      long res = endtime-starttime;
//      std::clog <<"ENABLE_TIME_LOG|" << __FUNCTION__ << "|"<< endtime<<"|"<<starttime<< "|"<<res<<std::endl;
// #endif
//      return 0;
// }

int CXXAPINorenClient::ModifyOrderResponse(void *pEchoBackData,
                                           char *pNorenOrd,
                                           char *pGuiOrdId,
                                           char *pReqStatus,
                                           char *pRejReason,
                                           char *pExternalRemarks,
                                           char *pUser)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ModifyOrderResponse EchoBackData: %s NorenOrd: %s GuiOrderID: %s pReqStatus: %s pRejReason: %s pExternalRemarks: %s User: %s",
              (char *)pEchoBackData,
              pNorenOrd,
              pGuiOrdId,
              pReqStatus,
              pRejReason,
              pExternalRemarks,
              pUser);

     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::CancelOrderResponse(void *pEchoBackData,
                                           char *pNorenOrd,
                                           char *pGuiOrdId,
                                           char *pReqStatus,
                                           char *pRejReason,
                                           char *pExternalRemarks,
                                           char *pUser)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "CancelOrderResponse EchoBackData: %s NorenOrd: %s GuiOrderID: %s pReqStatus: %s pRejReason: %s pExternalRemarks: %s User: %s",
              (char *)pEchoBackData,
              pNorenOrd,
              pGuiOrdId,
              pReqStatus,
              pRejReason,
              pExternalRemarks,
              pUser);

     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

// int CXXAPINorenClient::OrderAdminUnSubscribeResponse(void *pEchoBackData,
//                                                      char *pStatus)
// {
// #ifdef ENABLE_TIME_LOG
//      long starttime = s_get_time_in_micro_seconds();
// #endif

//      char buffer[BUFFER_SIZE];
//      snprintf(buffer,sizeof(buffer),"OrderAdminUnSubscribeResponse : EchoBackData: %s Status :%s",
//               (char *)pEchoBackData,
//               pStatus);
//      std::clog << buffer << std::endl;
// #ifdef ENABLE_TIME_LOG
//      long endtime = s_get_time_in_micro_seconds();
//      long res = endtime-starttime;
//      std::clog <<"ENABLE_TIME_LOG|" << __FUNCTION__ << "|"<< endtime<<"|"<<starttime<< "|"<<res<<std::endl;
// #endif
//      return 0;
// }

int CXXAPINorenClient::OrderAdminGroupUnSubscribeResponse(void *pEchoBackData,
                                                          char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OrderAdminGroupUnSubscribeResponse : EchoBackData: %s Status :%s",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetOrdersStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOrderstart  EchoBackData :%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetOrdersEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOrderend  EchoBackData :%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetOrders(void *pEchoBackData,
                                 tsOrderHistory *pGetOrders)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOrders EchoBackData :%s|  Exch :%s | Act Id :%s | Ord Duration :%s |"
                                      " CustomFirm :%s | Product :%s | Ord Type :%s | Trd Symbol :%s | Trans Type :%s | acGuiOrdId :%s | Token :%s | Price :%f | TriggerPrice :%f|"
                                      "Quantity :%ld |  DiscQuantity :%ld | CancelledSize :%ld | User :%s | acVendorCode :%s | acOrdSrc :%s|"
                                      "acOrdRemarks :%s| BookProfitPrice :%d | BookLossPrice :%d | TrailingPrice :%d | SnoOrdType :%d | ExternalRemarks :%s |"
                                      " AlgoName :%s | AlgoId :%s | AlgoCategory :%s | FilledShares :%ld | UnfilledSize :%ld | AvgPrice :%f | ExchOrdId :%s |"
                                      " Text :%s | acNorenUpdateTime :%s | lNorenUpdateTimeNanoSec :%ld | acOrgExchTime :%s | ExchTime :%s | ExchTimeNanoSec :%ld|"
                                      "  RejectionBy :%s | Rejection Reason :%s | OrderGenType :%s | NorenOrdNum :%s | acNorenTimeSec :%s | acNorenTimeMiliSec : %s|"
                                      " lNorenTimeNanoSec :%ld | acReqId :%s  |acReportType:%s | cRepTyp :%c | acOrdStatus :%s | cStatus :%c | dRmsPrice :%f | BasketId :%ld |InstName:%s|"
                                      "OptionType :%s | StrikePrice :%s |ExpiryDate :%s  |FillId :%s | Symbol :%s | FillTime :%s| Pan :%s| acIpAddr :%s | acChannel :%s|"
                                      " acUserAgent :%s |acAppInstallId :%s|",
              (char *)pEchoBackData,
              pGetOrders->sOrderUpdate.sOrderParams.acExchSeg,
              pGetOrders->sOrderUpdate.sOrderParams.acAccountId,
              pGetOrders->sOrderUpdate.sOrderParams.acOrdDuration,
              pGetOrders->sOrderUpdate.sOrderParams.acCustomerFirm,
              pGetOrders->sOrderUpdate.sOrderParams.acProduct,
              pGetOrders->sOrderUpdate.sOrderParams.acOrderType,
              pGetOrders->sOrderUpdate.sOrderParams.acTrdSymbol,
              pGetOrders->sOrderUpdate.sOrderParams.acTransType,
              pGetOrders->sOrderUpdate.sOrderParams.acGuiOrdId,
              pGetOrders->sOrderUpdate.sOrderParams.acToken,
              pGetOrders->sOrderUpdate.sOrderParams.dPrice,
              pGetOrders->sOrderUpdate.sOrderParams.dTriggerPrice,
              pGetOrders->sOrderUpdate.sOrderParams.lQuantity,
              pGetOrders->sOrderUpdate.sOrderParams.lDiscQuantity,
              pGetOrders->sOrderUpdate.sOrderParams.lCancelledSize,
              pGetOrders->sOrderUpdate.sOrderParams.acUser,
              pGetOrders->sOrderUpdate.sOrderParams.acVendorCode,
              pGetOrders->sOrderUpdate.sOrderParams.acOrdSrc,
              pGetOrders->sOrderUpdate.sOrderParams.acOrdRemarks,
              pGetOrders->sOrderUpdate.sOrderParams.iBookProfitPrice,
              pGetOrders->sOrderUpdate.sOrderParams.iBookLossPrice,
              pGetOrders->sOrderUpdate.sOrderParams.iTrailingPrice,
              pGetOrders->sOrderUpdate.sOrderParams.iSnoOrdType,
              pGetOrders->sOrderUpdate.sOrderParams.acExternalRemarks,
              pGetOrders->sOrderUpdate.sOrderParams.acAlgoName,
              pGetOrders->sOrderUpdate.sOrderParams.acAlgoId,
              pGetOrders->sOrderUpdate.sOrderParams.acAlgoCategory,
              pGetOrders->sOrderUpdate.lFilledShares,
              pGetOrders->sOrderUpdate.lUnfilledSize,
              pGetOrders->sOrderUpdate.dAvgPrice,
              pGetOrders->sOrderUpdate.acExchOrdId,
              pGetOrders->sOrderUpdate.acText,
              pGetOrders->sOrderUpdate.acNorenUpdateTime,
              pGetOrders->sOrderUpdate.lNorenUpdateTimeNanoSec,
              pGetOrders->sOrderUpdate.acOrgExchTime,
              pGetOrders->sOrderUpdate.acExchTime,
              pGetOrders->sOrderUpdate.lExchTimeNanoSec,
              pGetOrders->sOrderUpdate.acRejectionBy,
              pGetOrders->sOrderUpdate.acRejReason,
              pGetOrders->sOrderUpdate.acOrderGenType,
              pGetOrders->sOrderUpdate.acNorenOrdNum,
              pGetOrders->sOrderUpdate.acNorenTimeSec,
              pGetOrders->sOrderUpdate.acNorenTimeMiliSec,
              pGetOrders->sOrderUpdate.lNorenTimeNanoSec,
              pGetOrders->sOrderUpdate.acReqId,
              pGetOrders->sOrderUpdate.acReportType,
              pGetOrders->sOrderUpdate.cRepTyp,
              pGetOrders->sOrderUpdate.acOrdStatus,
              pGetOrders->sOrderUpdate.cStatus,
              pGetOrders->sOrderUpdate.dRmsPrice,
              pGetOrders->sOrderUpdate.lBasketId,
              pGetOrders->acInstName,
              pGetOrders->acOptionType,
              pGetOrders->acStrikePrice,
              pGetOrders->acExpiryDate,
              pGetOrders->acFillId,
              pGetOrders->acSymbol,
              pGetOrders->acFillTime,
              pGetOrders->sOrderUpdate.acPan,
              pGetOrders->sOrderUpdate.sOrderParams.acIpAddr,
              pGetOrders->sOrderUpdate.sOrderParams.acChannel,
              pGetOrders->sOrderUpdate.sOrderParams.acUserAgent,
              pGetOrders->sOrderUpdate.sOrderParams.acAppInstallId);
     logString += buffer;

     if (pGetOrders->sMultiLegUpdate.sMultiLegParams.dPrice_Leg2 == DBL_MIN)
     {
          logString += "pass: Price_Leg2 == DBL_MIN";
     }
     if (pGetOrders->sMultiLegUpdate.siLeg == 2)
     {
          snprintf(buffer, sizeof(buffer), " TrdSymbol_Leg2 : %s| TransType_Leg2 :%s| Token_Leg2 :%s| Price_Leg2 :%f|"
                                           " Quantity_Leg2 :%ld | DiscQuantity_Leg2 :%ld | AvgPrice_Leg2 :%f| FilledShares_Leg2 :%ld|"
                                           " UnfilledSize_Leg2 :%ld |",
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.acTrdSymbol_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.acTransType_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.acToken_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.dPrice_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.lQuantity_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.lDiscQuantity_Leg2,
                   pGetOrders->sMultiLegUpdate.dAvgPrice_Leg2,
                   pGetOrders->sMultiLegUpdate.lFilledShares_Leg2,
                   pGetOrders->sMultiLegUpdate.lUnfilledSize_Leg2);
          logString += buffer;
          if (pGetOrders->sOrderUpdate.sOrderParams.acSpreadTrdSymbol)
          {
               snprintf(buffer, sizeof(buffer), " acSpreadTrdSymbol: %s", pGetOrders->sOrderUpdate.sOrderParams.acSpreadTrdSymbol);
               logString += buffer;
          }

          if (pGetOrders->sOrderUpdate.sOrderParams.acSpreadToken)
          {
               snprintf(buffer, sizeof(buffer), " acSpreadToken: %s", pGetOrders->sOrderUpdate.sOrderParams.acSpreadToken);
               logString += buffer;
          }
     }
     else if (pGetOrders->sMultiLegUpdate.siLeg == 3)
     {
          snprintf(buffer, sizeof(buffer), " TrdSymbol_Leg2 :%s | TrdSymbol_Leg3 :%s | TransType_Leg2 :%s | TransType_Leg3 :%s|"
                                           " Token_Leg2 :%s | Token_Leg3 :%s | Price_Leg2 :%f | Price_Leg3 :%f | Quantity_Leg2 :%ld | Quantity_Leg3 :%ld|"
                                           " DiscQuantity_Leg2 :%ld | DiscQuantity_Leg3: %ld | AvgPrice_Leg2 :%f | AvgPrice_Leg3 :%f | FilledShares_Leg2 :%ld|"
                                           " FilledShares_Leg3 :%ld | UnfilledSize_Leg2 :%ld | UnfilledSize_Leg3 :%ld|",
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.acTrdSymbol_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.acTrdSymbol_Leg3,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.acTransType_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.acTransType_Leg3,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.acToken_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.acToken_Leg3,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.dPrice_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.dPrice_Leg3,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.lQuantity_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.lQuantity_Leg3,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.lDiscQuantity_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.lDiscQuantity_Leg3,
                   pGetOrders->sMultiLegUpdate.dAvgPrice_Leg2,
                   pGetOrders->sMultiLegUpdate.dAvgPrice_Leg3,
                   pGetOrders->sMultiLegUpdate.lFilledShares_Leg2,
                   pGetOrders->sMultiLegUpdate.lFilledShares_Leg3,
                   pGetOrders->sMultiLegUpdate.lUnfilledSize_Leg2,
                   pGetOrders->sMultiLegUpdate.lUnfilledSize_Leg3);
          logString += buffer;
     }
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetAllOrdersStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllOrdersStart  EchoBackData :%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetAllOrdersEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllOrdersEnd  EchoBackData :%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetAllOrders(void *pEchoBackData,
                                    tsOrderHistory *pGetOrders)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllOrders EchoBackData :%s|  Exch :%s | Act Id :%s | Ord Duration :%s |"
                                      " CustomFirm :%s | Product :%s | Ord Type :%s | Trd Symbol :%s | Trans Type :%s | acGuiOrdId :%s | Token :%s | Price :%f | TriggerPrice :%f|"
                                      "Quantity :%ld | DiscQuantity :%ld | CancelledSize :%ld | User :%s | acVendorCode :%s | acOrdSrc :%s|"
                                      "acOrdRemarks :%s| BookProfitPrice :%d | BookLossPrice :%d | TrailingPrice :%d | iSnoOrdType :%d | ExternalRemarks :%s |"
                                      " AlgoName :%s | AlgoId :%s | AlgoCategory :%s | FilledShares :%ld | UnfilledSize :%ld | AvgPrice :%f | ExchOrdId :%s |"
                                      " Text :%s | acNorenUpdateTime :%s | lNorenUpdateTimeNanoSec :%ld | acOrgExchTime :%s | ExchTime :%s | ExchTimeNanoSec :%ld|"
                                      "  RejectionBy :%s | Rejection Reason :%s | OrderGenType :%s | NorenOrdNum :%s | acNorenTimeSec :%s | acNorenTimeMiliSec : %s|"
                                      " lNorenTimeNanoSec :%ld | acReqId :%s  |acReportType:%s | cRepTyp :%c | acOrdStatus :%s | cStatus :%c | dRmsPrice :%f | BasketId :%ld |InstName:%s|"
                                      "OptionType :%s | StrikePrice :%s |ExpiryDate :%s  |FillId :%s | Symbol :%s | FillTime :%s| Pan :%s| acIpAddr :%s | acChannel :%s|"
                                      " acUserAgent :%s |acAppInstallId :%s|",
              (char *)pEchoBackData,
              pGetOrders->sOrderUpdate.sOrderParams.acExchSeg,
              pGetOrders->sOrderUpdate.sOrderParams.acAccountId,
              pGetOrders->sOrderUpdate.sOrderParams.acOrdDuration,
              pGetOrders->sOrderUpdate.sOrderParams.acCustomerFirm,
              pGetOrders->sOrderUpdate.sOrderParams.acProduct,
              pGetOrders->sOrderUpdate.sOrderParams.acOrderType,
              pGetOrders->sOrderUpdate.sOrderParams.acTrdSymbol,
              pGetOrders->sOrderUpdate.sOrderParams.acTransType,
              pGetOrders->sOrderUpdate.sOrderParams.acGuiOrdId,
              pGetOrders->sOrderUpdate.sOrderParams.acToken,
              pGetOrders->sOrderUpdate.sOrderParams.dPrice,
              pGetOrders->sOrderUpdate.sOrderParams.dTriggerPrice,
              pGetOrders->sOrderUpdate.sOrderParams.lQuantity,
              pGetOrders->sOrderUpdate.sOrderParams.lDiscQuantity,
              pGetOrders->sOrderUpdate.sOrderParams.lCancelledSize,
              pGetOrders->sOrderUpdate.sOrderParams.acUser,
              pGetOrders->sOrderUpdate.sOrderParams.acVendorCode,
              pGetOrders->sOrderUpdate.sOrderParams.acOrdSrc,
              pGetOrders->sOrderUpdate.sOrderParams.acOrdRemarks,
              pGetOrders->sOrderUpdate.sOrderParams.iBookProfitPrice,
              pGetOrders->sOrderUpdate.sOrderParams.iBookLossPrice,
              pGetOrders->sOrderUpdate.sOrderParams.iTrailingPrice,
              pGetOrders->sOrderUpdate.sOrderParams.iSnoOrdType,
              pGetOrders->sOrderUpdate.sOrderParams.acExternalRemarks,
              pGetOrders->sOrderUpdate.sOrderParams.acAlgoName,
              pGetOrders->sOrderUpdate.sOrderParams.acAlgoId,
              pGetOrders->sOrderUpdate.sOrderParams.acAlgoCategory,
              pGetOrders->sOrderUpdate.lFilledShares,
              pGetOrders->sOrderUpdate.lUnfilledSize,
              pGetOrders->sOrderUpdate.dAvgPrice,
              pGetOrders->sOrderUpdate.acExchOrdId,
              pGetOrders->sOrderUpdate.acText,
              pGetOrders->sOrderUpdate.acNorenUpdateTime,
              pGetOrders->sOrderUpdate.lNorenUpdateTimeNanoSec,
              pGetOrders->sOrderUpdate.acOrgExchTime,
              pGetOrders->sOrderUpdate.acExchTime,
              pGetOrders->sOrderUpdate.lExchTimeNanoSec,
              pGetOrders->sOrderUpdate.acRejectionBy,
              pGetOrders->sOrderUpdate.acRejReason,
              pGetOrders->sOrderUpdate.acOrderGenType,
              pGetOrders->sOrderUpdate.acNorenOrdNum,
              pGetOrders->sOrderUpdate.acNorenTimeSec,
              pGetOrders->sOrderUpdate.acNorenTimeMiliSec,
              pGetOrders->sOrderUpdate.lNorenTimeNanoSec,
              pGetOrders->sOrderUpdate.acReqId,
              pGetOrders->sOrderUpdate.acReportType,
              pGetOrders->sOrderUpdate.cRepTyp,
              pGetOrders->sOrderUpdate.acOrdStatus,
              pGetOrders->sOrderUpdate.cStatus,
              pGetOrders->sOrderUpdate.dRmsPrice,
              pGetOrders->sOrderUpdate.lBasketId,
              pGetOrders->acInstName,
              pGetOrders->acOptionType,
              pGetOrders->acStrikePrice,
              pGetOrders->acExpiryDate,
              pGetOrders->acFillId,
              pGetOrders->acSymbol,
              pGetOrders->acFillTime,
              pGetOrders->sOrderUpdate.acPan,
              pGetOrders->sOrderUpdate.sOrderParams.acIpAddr,
              pGetOrders->sOrderUpdate.sOrderParams.acChannel,
              pGetOrders->sOrderUpdate.sOrderParams.acUserAgent,
              pGetOrders->sOrderUpdate.sOrderParams.acAppInstallId);
     logString += buffer;

     if (pGetOrders->sMultiLegUpdate.sMultiLegParams.dPrice_Leg2 == DBL_MIN)
     {
          logString += "pass: Price_Leg2 == DBL_MIN";
     }
     if (pGetOrders->sMultiLegUpdate.siLeg == 2)
     {
          snprintf(buffer, sizeof(buffer), " TrdSymbol_Leg2 :%s| TransType_Leg2 :%s| Token_Leg2 :%s| Price_Leg2 :%f|"
                                           " Quantity_Leg2 :%ld | DiscQuantity_Leg2 :%ld | AvgPrice_Leg2 :%f | FilledShares_Leg2 :%ld|"
                                           " UnfilledSize_Leg2 :%ld | ",
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.acTrdSymbol_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.acTransType_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.acToken_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.dPrice_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.lQuantity_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.lDiscQuantity_Leg2,
                   pGetOrders->sMultiLegUpdate.dAvgPrice_Leg2,
                   pGetOrders->sMultiLegUpdate.lFilledShares_Leg2,
                   pGetOrders->sMultiLegUpdate.lUnfilledSize_Leg2);
          logString += buffer;
          if (pGetOrders->sOrderUpdate.sOrderParams.acSpreadTrdSymbol)
          {
               snprintf(buffer, sizeof(buffer), " acSpreadTrdSymbol: %s", pGetOrders->sOrderUpdate.sOrderParams.acSpreadTrdSymbol);
               logString += buffer;
          }

          if (pGetOrders->sOrderUpdate.sOrderParams.acSpreadToken)
          {
               snprintf(buffer, sizeof(buffer), " acSpreadToken: %s", pGetOrders->sOrderUpdate.sOrderParams.acSpreadToken);
               logString += buffer;
          }
     }
     else if (pGetOrders->sMultiLegUpdate.siLeg == 3)
     {
          snprintf(buffer, sizeof(buffer), " TrdSymbol_Leg2 :%s | TrdSymbol_Leg3 :%s | TransType_Leg2 :%s | TransType_Leg3 :%s|"
                                           " Token_Leg2 :%s | Token_Leg3 :%s | Price_Leg2 :%f | Price_Leg3 :%f | Quantity_Leg2 :%ld | Quantity_Leg3 :%ld|"
                                           " DiscQuantity_Leg2 :%ld | DiscQuantity_Leg3: %ld | AvgPrice_Leg2 :%f | AvgPrice_Leg3 : %f | FilledShares_Leg2 :%ld|"
                                           " FilledShares_Leg3 :%ld | UnfilledSize_Leg2 :%ld | UnfilledSize_Leg3 :%ld|",
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.acTrdSymbol_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.acTrdSymbol_Leg3,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.acTransType_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.acTransType_Leg3,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.acToken_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.acToken_Leg3,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.dPrice_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.dPrice_Leg3,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.lQuantity_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.lQuantity_Leg3,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.lDiscQuantity_Leg2,
                   pGetOrders->sMultiLegUpdate.sMultiLegParams.lDiscQuantity_Leg3,
                   pGetOrders->sMultiLegUpdate.dAvgPrice_Leg2,
                   pGetOrders->sMultiLegUpdate.dAvgPrice_Leg3,
                   pGetOrders->sMultiLegUpdate.lFilledShares_Leg2,
                   pGetOrders->sMultiLegUpdate.lFilledShares_Leg3,
                   pGetOrders->sMultiLegUpdate.lUnfilledSize_Leg2,
                   pGetOrders->sMultiLegUpdate.lUnfilledSize_Leg3);
          logString += buffer;
     }
     std::clog << logString << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

// int CXXAPINorenClient::FillReport(tsFillReport *pFillReport,
//                                   void *pEchoBackData)
// {
// #ifdef ENABLE_TIME_LOG
//      long starttime = s_get_time_in_micro_seconds();
// #endif

//      std::string logString;
//      char buffer[BUFFER_SIZE];
//      snprintf(buffer,sizeof(buffer)," Fill Report: pEchoBackData :%s |  Fill Price :%f | FillLeg :%d |"
//               " FillSize :%ld | OrdStatus :%s | cStatus :%c | Id :%s | Symbol :%s | Exch Time :%s | ExchTimeNanoSec :%ld|"
//               " Exch Seg :%s | GuiOrdId :%s | Acct Id :%s | Customfirm :%s | Product :%s | Trd Symbol :%s|"
//               " GuiOrgOrdId :%s | FillDate :%s | Fill Time :%s | Noren Ord No. :%s | Exch Ord Id :%s | Trans Type :%s|"
//               " Report Type :%s | cRepTyp :%c | FillStatus :%s | PriceType :%s | User :%s | OrderGenType :%s | SyomOrderId :%s|"
//               " NorenTimeMiliSec :%s | lNorenTimeNanoSec :%ld | NorenTimeSec :%s | Pan no :%s | Quantity :%ld|"
//               " UnfilledSize :%ld | OrdSrc :%s | BookProfitPrice :%d | BookLossPrice :%d | TrailingPrice :%d|"
//               " iSnoOrdType :%d | ExternalRemarks :%s | AlgoName :%s | AlgoId :%s | AlgoCategory :%s | BasketId :%ld|" ,
//               (char*)pEchoBackData,
//               pFillReport->dFillPrice,
//               pFillReport->siFillLeg,
//               pFillReport->lFillSize ,
//               pFillReport->acOrdStatus,
//               pFillReport->cStatus,
//               pFillReport->acFillId,
//               pFillReport->acSymbol ,
//               pFillReport->acExchTime,
//               pFillReport->lExchTimeNanoSec,
//               pFillReport->acExchSeg,
//               pFillReport->acGuiOrdId ,
//               pFillReport->acAccountId ,
//               pFillReport->acCustomerFirm ,
//               pFillReport->acProduct ,
//               pFillReport->acTrdSymbol,
//               pFillReport->acGuiOrgOrdId  ,
//               pFillReport->acFillDate  ,
//               pFillReport->acFillTime ,
//               pFillReport->acNorenOrdNum  ,
//               pFillReport->acExchOrdId,
//               pFillReport->acTransType  ,
//               pFillReport->acReportType ,
//               pFillReport->cRepTyp ,
//               pFillReport->acFillStatus ,
//               pFillReport->acPriceType ,
//               pFillReport->acUser ,
//               pFillReport->acOrderGenType ,
//               pFillReport->acSyomOrderId,
//               pFillReport->acNorenTimeMiliSec ,
//               pFillReport->lNorenTimeNanoSec,
//               pFillReport->acNorenTimeSec ,
//               pFillReport->acPan ,
//               pFillReport->lQuantity ,
//               pFillReport->lUnfilledSize  ,
//               pFillReport->acOrdSrc,
//               pFillReport->iBookProfitPrice  ,
//               pFillReport->iBookLossPrice,
//               pFillReport->iTrailingPrice ,
//               pFillReport->iSnoOrdType,
//               pFillReport->acExternalRemarks,
//               pFillReport->acAlgoName ,
//               pFillReport->acAlgoId,
//               pFillReport->acAlgoCategory ,
//               pFillReport->lBasketId);
//      std::clog<<buffer<<std::endl;

// #ifdef ENABLE_TIME_LOG
//      long endtime = s_get_time_in_micro_seconds();
//      long res = endtime-starttime;
//      std::clog <<"ENABLE_TIME_LOG|" << __FUNCTION__ << "|"<< endtime<<"|"<<starttime<< "|"<<res<<std::endl;
// #endif
//      return 0;
// }

// int CXXAPINorenClient::OrderUpdate(tsOrderUpdate *pOrderUpdate,
//                                    void *pEchoBackData)
// {

// #ifdef ENABLE_TIME_LOG
//      long starttime = s_get_time_in_micro_seconds();

// #endif

//      std::string logString;
//      char buffer[BUFFER_SIZE];
//      snprintf(buffer,sizeof(buffer), "OrderUpdate:1st :pEchoBackData :%s| Exch :%s | Act Id :%s| Ord Duration :%s|"
//               " CustomFirm :%s | Product :%s | Ord Type :%s | Trd Symbol :%s | Trans Type :%s | acGuiOrdId :%s|"
//               " Token :%s  |Price :%f  |TriggerPrice :%f |Quantity :%ld |DiscQuantity :%ld |CancelledSize :%ld|"
//               " OrdSrc :%s |acOrdRemarks :%s  |BookProfitPrice :%d | BookLossPrice :%d |TrailingPrice :%d|"
//               " iSnoOrdType :%d |ExternalRemarks :%s | AlgoName :%s | AlgoId :%s | AlgoCategory :%s |User :%s|"
//               " VendorCode  :%s |  AvgPrice :%f | FilledShares :%ld |UnfilledSize :%ld |  NorenOrdNum :%s|"
//               "ReqId :%s | ExchOrdId :%s |Text :%s |OrdStatus :%s |Status :%c | ReportType :%s | RepTyp :%c|"
//               " NorenTime Sec :%s|  NorenUpdateTime :%s | lNorenUpdateTimeNanoSec :%ld | ExchTime :%s | ExchTimeNanoSec :%ld|"
//               " ExchOrdUpdateTime :%s| RejectionBy :%s | Rejection Reason :%s | OrderGenType :%s | NorenTime MiliSec :%s|"
//               " lNorenTimeNanoSec :%ld | lRejQty :%ld| RejOrdSrc :%s| RejPriceType :%s|"
//               "  dRmsPrice :%f |BasketId :%ld |acIpAddr :%s| acChannel :%s |acUserAgent :%s |acAppInstallId :%s|",
//               (char*)pEchoBackData,
//               pOrderUpdate->sOrderParams.acExchSeg,
//               pOrderUpdate->sOrderParams.acAccountId,
//               pOrderUpdate->sOrderParams.acOrdDuration,
//               pOrderUpdate->sOrderParams.acCustomerFirm ,
//               pOrderUpdate->sOrderParams.acProduct,
//               pOrderUpdate->sOrderParams.acOrderType,
//               pOrderUpdate->sOrderParams.acTrdSymbol,
//               pOrderUpdate->sOrderParams.acTransType,
//               pOrderUpdate->sOrderParams.acGuiOrdId,
//               pOrderUpdate->sOrderParams.acToken,
//               pOrderUpdate->sOrderParams.dPrice,
//               pOrderUpdate->sOrderParams.dTriggerPrice,
//               pOrderUpdate->sOrderParams.lQuantity,
//               pOrderUpdate->sOrderParams.lDiscQuantity,
//               pOrderUpdate->sOrderParams.lCancelledSize,
//               pOrderUpdate->sOrderParams.acOrdSrc,
//               pOrderUpdate->sOrderParams.acOrdRemarks,
//               pOrderUpdate->sOrderParams.iBookProfitPrice,
//               pOrderUpdate->sOrderParams.iBookLossPrice,
//               pOrderUpdate->sOrderParams.iTrailingPrice,
//               pOrderUpdate->sOrderParams.iSnoOrdType,
//               pOrderUpdate->sOrderParams.acExternalRemarks,
//               pOrderUpdate->sOrderParams.acAlgoName,
//               pOrderUpdate->sOrderParams.acAlgoId,
//               pOrderUpdate->sOrderParams.acAlgoCategory,
//               //                    " Pan "
//               //                    << pOrderUpdate->acPan <<

//               pOrderUpdate->sOrderParams.acUser,
//               pOrderUpdate->sOrderParams.acVendorCode,
//               pOrderUpdate->dAvgPrice,
//               pOrderUpdate->lFilledShares,
//               pOrderUpdate->lUnfilledSize,
//               pOrderUpdate->acNorenOrdNum,
//               pOrderUpdate->acReqId,
//               pOrderUpdate->acExchOrdId,
//               pOrderUpdate->acText,
//               pOrderUpdate->acOrdStatus,
//               pOrderUpdate->cStatus,
//               pOrderUpdate->acReportType,
//               pOrderUpdate->cRepTyp,
//               pOrderUpdate->acNorenTimeSec,
//               pOrderUpdate->acNorenUpdateTime,
//               pOrderUpdate->lNorenUpdateTimeNanoSec,
//               pOrderUpdate->acExchTime,
//               pOrderUpdate->lExchTimeNanoSec,
//               pOrderUpdate->acOrgExchTime,
//               pOrderUpdate->acRejectionBy,
//               pOrderUpdate->acRejReason,
//               pOrderUpdate->acOrderGenType,
//               pOrderUpdate->acNorenTimeMiliSec,
//               pOrderUpdate->lNorenTimeNanoSec,
//               pOrderUpdate->lRejQty,
//               pOrderUpdate->acRejOrdSrc,
//               pOrderUpdate->acRejPriceType,
//               pOrderUpdate->dRmsPrice,
//               pOrderUpdate->lBasketId,
//               pOrderUpdate->sOrderParams.acIpAddr,
//               pOrderUpdate->sOrderParams.acChannel,
//               pOrderUpdate->sOrderParams.acUserAgent,
//               pOrderUpdate->sOrderParams.acAppInstallId);
//      logString+=buffer;

//      if (pOrderUpdate->sOrderParams.acIpAddr)
//      {
//           snprintf(buffer,sizeof(buffer), "acIpAddr :%s |",pOrderUpdate->sOrderParams.acIpAddr);
//           logString+=buffer;
//      }
//      if (pOrderUpdate->sOrderParams.acChannel)
//      {
//           snprintf(buffer,sizeof(buffer), "acChannel :%s |",pOrderUpdate->sOrderParams.acChannel);
//           logString+=buffer;
//      }
//      if (pOrderUpdate->sOrderParams.acUserAgent)
//      {
//           snprintf(buffer,sizeof(buffer), "acUserAgent :%s |",pOrderUpdate->sOrderParams.acUserAgent);
//           logString+=buffer;
//      }
//      if (pOrderUpdate->sOrderParams.acAppInstallId)
//      {
//           snprintf(buffer,sizeof(buffer), "acAppInstallId :%s |",pOrderUpdate->sOrderParams.acAppInstallId);
//           logString+=buffer;
//      }
//      std::clog<<logString<<std::endl;

// #ifdef ENABLE_TIME_LOG
//      long endtime = s_get_time_in_micro_seconds();
//      long res = endtime-starttime;
//      std::clog <<"ENABLE_TIME_LOG|" << __FUNCTION__ << "|"<< endtime<<"|"<<starttime<< "|"<<res<<std::endl;
// #endif

//      return 0;
// }

int CXXAPINorenClient::MultiLegOrderUpdate(tsOrderUpdate *pOrderUpdate,
                                           tsMultiLegUpdate *pMultiLegUpdate,
                                           void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "MultiLegOrderUpdate: 1st :pEchoBackData : %s | ExchSeg: %s | Act Id :%s | Ord Duration :%s|"
                                      "CustomFirm :%s | Product :%s | Ord Type : %s | Trd Symbol :%s | Trans Type :%s | acGuiOrdId :%s|"
                                      " Token :%s | Price :%f | TriggerPrice :%f | Quantity :%ld | DiscQuantity :%ld | CancelledSize :%ld|"
                                      " User :%s | acVendorCode :%s | OrdSrc :%s | acOrdRemarks :%s | BookProfitPrice :%d | BookLossPrice :%d|"
                                      " TrailingPrice :%d | iSnoOrdType :%d | ExternalRemarks :%s | AlgoName :%s | AlgoId :%s | AlgoCategory:%s|"
                                      "Pan :%s | FilledShares: %ld | UnfilledSize :%ld | AvgPrice :%f  | ExchOrdId :%s | Text :%s | acNorenTimeSec :%s|"
                                      "acNorenUpdateTime :%s | lNorenUpdateTimeNanoSec :%ld | ExchTime :%s | ExchTimeNanoSec :%ld | ExchOrdUpdateTime :%s|"
                                      " RejectionBy :%s  Rejection Reason :%s | OrderGenType:%s | NorenOrdNum :%s | acNorenTimeSec :%s | acNorenTimeMiliSec :%s|"
                                      " lNorenTimeNanoSec :%ld | acReqId :%s | acOrdStatus :%s | cStatus:%c | acReportType :%s | cRepTyp:%c | dRmsPrice :%f |"
                                      "BasketId :%ld | acIpAddr :%s | acChannel :%s | acUserAgent :%s | acAppInstallId :%s|",
              (char *)pEchoBackData,
              pOrderUpdate->sOrderParams.acExchSeg,
              pOrderUpdate->sOrderParams.acAccountId,
              pOrderUpdate->sOrderParams.acOrdDuration,
              pOrderUpdate->sOrderParams.acCustomerFirm,
              pOrderUpdate->sOrderParams.acProduct,
              pOrderUpdate->sOrderParams.acOrderType,
              pOrderUpdate->sOrderParams.acTrdSymbol,
              pOrderUpdate->sOrderParams.acTransType,
              pOrderUpdate->sOrderParams.acGuiOrdId,
              pOrderUpdate->sOrderParams.acToken,
              pOrderUpdate->sOrderParams.dPrice,
              pOrderUpdate->sOrderParams.dTriggerPrice,
              pOrderUpdate->sOrderParams.lQuantity,
              pOrderUpdate->sOrderParams.lDiscQuantity,
              pOrderUpdate->sOrderParams.lCancelledSize,
              pOrderUpdate->sOrderParams.acUser,
              pOrderUpdate->sOrderParams.acVendorCode,
              pOrderUpdate->sOrderParams.acOrdSrc,
              pOrderUpdate->sOrderParams.acOrdRemarks,
              pOrderUpdate->sOrderParams.iBookProfitPrice,
              pOrderUpdate->sOrderParams.iBookLossPrice,
              pOrderUpdate->sOrderParams.iTrailingPrice,
              pOrderUpdate->sOrderParams.iSnoOrdType,
              pOrderUpdate->sOrderParams.acExternalRemarks,
              pOrderUpdate->sOrderParams.acAlgoName,
              pOrderUpdate->sOrderParams.acAlgoId,
              pOrderUpdate->sOrderParams.acAlgoCategory,
              pOrderUpdate->acPan,
              pOrderUpdate->lFilledShares,
              pOrderUpdate->lUnfilledSize,
              pOrderUpdate->dAvgPrice,
              pOrderUpdate->acExchOrdId,
              pOrderUpdate->acText,
              pOrderUpdate->acNorenTimeSec,
              pOrderUpdate->acNorenUpdateTime,
              pOrderUpdate->lNorenUpdateTimeNanoSec,
              pOrderUpdate->acExchTime,
              pOrderUpdate->lExchTimeNanoSec,
              pOrderUpdate->acOrgExchTime,
              pOrderUpdate->acRejectionBy,
              pOrderUpdate->acRejReason,
              pOrderUpdate->acOrderGenType,
              pOrderUpdate->acNorenOrdNum,
              pOrderUpdate->acNorenTimeSec,
              pOrderUpdate->acNorenTimeMiliSec,
              pOrderUpdate->lNorenTimeNanoSec,
              pOrderUpdate->acReqId,
              pOrderUpdate->acOrdStatus,
              pOrderUpdate->cStatus,
              pOrderUpdate->acReportType,
              pOrderUpdate->cRepTyp,
              pOrderUpdate->dRmsPrice,
              pOrderUpdate->lBasketId,
              pOrderUpdate->sOrderParams.acIpAddr,
              pOrderUpdate->sOrderParams.acChannel,
              pOrderUpdate->sOrderParams.acUserAgent,
              pOrderUpdate->sOrderParams.acAppInstallId);
     logString += buffer;
     if (pMultiLegUpdate->siLeg == 2)
     {
          snprintf(buffer, 4096, " TrdSymbol_Leg2 :%s | TransType_Leg2 :%s | Token_Leg2 :%s | Price_Leg2 :%f|"
                                 "Quantity_Leg2 :%ld | DiscQuantity_Leg2 :%ld | AvgPrice_Leg2 :%f | FilledShares_Leg2 :%ld|"
                                 "UnfilledSize_Leg2 :%ld |",
                   pMultiLegUpdate->sMultiLegParams.acTrdSymbol_Leg2,
                   pMultiLegUpdate->sMultiLegParams.acTransType_Leg2,
                   pMultiLegUpdate->sMultiLegParams.acToken_Leg2,
                   pMultiLegUpdate->sMultiLegParams.dPrice_Leg2,
                   pMultiLegUpdate->sMultiLegParams.lQuantity_Leg2,
                   pMultiLegUpdate->sMultiLegParams.lDiscQuantity_Leg2,
                   pMultiLegUpdate->dAvgPrice_Leg2,
                   pMultiLegUpdate->lFilledShares_Leg2,
                   pMultiLegUpdate->lUnfilledSize_Leg2);
          if (pOrderUpdate->sOrderParams.acSpreadTrdSymbol)
          {
               snprintf(buffer, 4096, " acSpreadTrdSymbol :%s ", pOrderUpdate->sOrderParams.acSpreadTrdSymbol);
               logString += buffer;
          }
          if (pOrderUpdate->sOrderParams.acSpreadToken)
          {
               snprintf(buffer, 4096, " acSpreadToken :%s ", pOrderUpdate->sOrderParams.acSpreadToken);
               logString += buffer;
          }

          logString += buffer;
     }
     else if (pMultiLegUpdate->siLeg == 3)
     {
          snprintf(buffer, 4096, " TrdSymbol_Leg2 :%s | TransType_Leg2 :%s | Token_Leg2 :%s | Price_Leg2 :%f |"
                                 " Quantity_Leg2 :%ld | DiscQuantity_Leg2 :%ld | AvgPrice_Leg2 :%f | FilledShares_Leg2 :%ld |"
                                 "UnfilledSize_Leg2 :%ld | TrdSymbol_Leg3 :%s | TransType_Leg3 :%s | Token_Leg3 :%s|"
                                 " Price_Leg3 :%f | Quantity_Leg3 :%ld | DiscQuantity_Leg3 :%ld | AvgPrice_Leg3 :%f | FilledShares_Leg3 :%ld|"
                                 " UnfilledSize_Leg3 :%ld|",
                   pMultiLegUpdate->sMultiLegParams.acTrdSymbol_Leg2,
                   pMultiLegUpdate->sMultiLegParams.acTransType_Leg2,
                   pMultiLegUpdate->sMultiLegParams.acToken_Leg2,
                   pMultiLegUpdate->sMultiLegParams.dPrice_Leg2,
                   pMultiLegUpdate->sMultiLegParams.lQuantity_Leg2,
                   pMultiLegUpdate->sMultiLegParams.lDiscQuantity_Leg2,
                   pMultiLegUpdate->dAvgPrice_Leg2,
                   pMultiLegUpdate->lFilledShares_Leg2,
                   pMultiLegUpdate->lUnfilledSize_Leg2,
                   pMultiLegUpdate->sMultiLegParams.acTrdSymbol_Leg3,
                   pMultiLegUpdate->sMultiLegParams.acTransType_Leg3,
                   pMultiLegUpdate->sMultiLegParams.acToken_Leg3,
                   pMultiLegUpdate->sMultiLegParams.dPrice_Leg3,
                   pMultiLegUpdate->sMultiLegParams.lQuantity_Leg3,
                   pMultiLegUpdate->sMultiLegParams.lDiscQuantity_Leg3,
                   pMultiLegUpdate->dAvgPrice_Leg3,
                   pMultiLegUpdate->lFilledShares_Leg3,
                   pMultiLegUpdate->lUnfilledSize_Leg3);
          logString += buffer;
     }
     std::cout << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif

     return 0;
}

int CXXAPINorenClient::PositionUpdate(tsPosData **pPositionUpdate,
                                      int PositionUpdateSize,
                                      void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     std::string logString;
     char buffer[BUFFER_SIZE];
     std::clog << " PositionUpdate:  EchoBackData " << pEchoBackData;
     for (int i = 0; i < PositionUpdateSize; i++)
     {
          snprintf(buffer, sizeof(buffer), " Exchange Segment :%s | Symbol :%s |  Account Id : %s | Product : %s |"
                                           " Trading symbol :%s | Buy quantity : %.0f | Sell quantity : %.0f |  Buy Amount : %.2f |  Sell Amount : %.2f |"
                                           " CF Buy Quantity : %.0f | CF Sell Quantity : %.0f |  CF Buy Amount : %.2f |  CF Sell Amount : %.2f |  Open Buy quantity : %.0f |"
                                           " Open Sell quantity : %.0f |  Open Buy Amount : %.2f |  Open Sell Amount : %.2f |",
                   pPositionUpdate[i]->pExchSeg,
                   pPositionUpdate[i]->pSymbol,
                   pPositionUpdate[i]->pAccId,
                   pPositionUpdate[i]->pProduct,
                   pPositionUpdate[i]->pTrdSymbol,
                   pPositionUpdate[i]->dBuyQty,
                   pPositionUpdate[i]->dSellQty,
                   pPositionUpdate[i]->dBuyAmount,
                   pPositionUpdate[i]->dSellAmount,
                   pPositionUpdate[i]->dCfBuyQty,
                   pPositionUpdate[i]->dCfSellQty,
                   pPositionUpdate[i]->dCfBuyAmount,
                   pPositionUpdate[i]->dCfSellAmount,
                   pPositionUpdate[i]->dOpenBuyQty,
                   pPositionUpdate[i]->dOpenSellQty,
                   pPositionUpdate[i]->dOpenBuyAmount,
                   pPositionUpdate[i]->dOpenSellAmount);
          logString += buffer;
          if (pPositionUpdate[i]->acInterOPKey)
          {
               snprintf(buffer, sizeof(buffer), " acInterOPKey :%s",
                        pPositionUpdate[i]->acInterOPKey);
               logString += buffer;
          }
          if (pPositionUpdate[i]->acInterOPExchSeg)
          {
               snprintf(buffer, sizeof(buffer), " acInterOPExchSeg :%s |",
                        pPositionUpdate[i]->acInterOPExchSeg);
               logString += buffer;
          }
     }
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::PositionAdminUnSubscribeResponse(void *pEchoBackData,
                                                        char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PositionAdminUnSubscribeResponse : EchoBackData :%s Status :%s",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::PositionAdminGroupUnSubscribeResponse(void *pEchoBackData,
                                                             char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PositionAdminGroupUnSubscribeResponse : EchoBackData :%s Status :%s",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::TradeHistoryStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "TradeHistoryStart  EchoBackData :%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::TradeHistory(void *pEchoBackData,
                                    tsFillReport *pFillReport)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "TradeHistory  EchoBackData: %s | Fill Price :%f | Leg: %hd | FillQty: %ld |"
                                      " TotalFillQty: %ld | OrderStatus : %s | Status: %c | Id: %s | Symbol: %s | Exch Time :%s | ExchTimeNanoSec :%ld |"
                                      " Exch Seg :%s | Acct Id : %s | Customfirm : %s | Product: %s | Trd Symbol :%s | Fill Time :%s | Fill Date:%s |"
                                      " Noren Ord No. :%s | Exch Ord Id :%s | Trans Type :%s | Report Type :%s | RepTyp: %c | User :%s | OrderGenType:%s |"
                                      " NorenTimeMiliSec: %s | lNorenTimeNanoSec: %ld | NorenTimeSec : %s | Pan no. : %s | Quantity :%ld | UnfilledSize :%ld |"
                                      " acOrdSrc : %s | BookProfitPrice : %d | BookLossPrice : %d | TrailingPrice :%d | iSnoOrdType :%d |"
                                      " ExternalRemarks :%s | AlgoName: %s | AlgoId : %s | AlgoCategory :%s | BasketId :%ld |",
              (char *)pEchoBackData,
              pFillReport->dFillPrice,
              pFillReport->siFillLeg,
              pFillReport->lFillSize,
              pFillReport->lFilledShares,
              pFillReport->acOrdStatus,
              pFillReport->cStatus,
              pFillReport->acFillId,
              pFillReport->acSymbol,
              pFillReport->acExchTime,
              pFillReport->lExchTimeNanoSec,
              pFillReport->acExchSeg,
              pFillReport->acAccountId,
              pFillReport->acCustomerFirm,
              pFillReport->acProduct,
              pFillReport->acTrdSymbol,
              pFillReport->acFillTime,
              pFillReport->acFillDate,
              pFillReport->acNorenOrdNum,
              pFillReport->acExchOrdId,
              pFillReport->acTransType,
              pFillReport->acReportType,
              pFillReport->cRepTyp,
              pFillReport->acUser,
              pFillReport->acOrderGenType,
              pFillReport->acNorenTimeMiliSec,
              pFillReport->lNorenTimeNanoSec,
              pFillReport->acNorenTimeSec,
              pFillReport->acPan,
              pFillReport->lQuantity,
              pFillReport->lUnfilledSize,
              pFillReport->acOrdSrc,
              pFillReport->iBookProfitPrice,
              pFillReport->iBookLossPrice,
              pFillReport->iTrailingPrice,
              pFillReport->iSnoOrdType,
              pFillReport->acExternalRemarks,
              pFillReport->acAlgoName,
              pFillReport->acAlgoId,
              pFillReport->acAlgoCategory,
              pFillReport->lBasketId);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::TradeHistoryEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "TradeHistoryEnd  EchoBackData :%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::ofstream timeLogFile;
     timeLogFile.open(timeLogFilePath, std::ios_base::app); // Open in append mode
     if (timeLogFile.is_open())
     {
          timeLogFile << std::left << std::setw(20) << __FUNCTION__
                      << "," << "-"
                      << "," << "-"
                      << "," << endtime
                      << "," << starttime
                      << "," << res << "\n";
          timeLogFile.close();
     }
     else
     {
          std::cerr << "Failed to open timeLogFilePath for writing" << std::endl;
     }
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::AllTradeHistoryStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AllTradeHistoryStart  EchoBackData :%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::AllTradeHistory(void *pEchoBackData,
                                       tsFillReport *pFillReport)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), " AllTradeHistory  EchoBackData: %s | Fill Price :%f | Leg :%hd | FillQty: %ld |"
                                      " TotalFillQty: %ld |  Order Status :%s | Status :%c | Id :%s | Symbol :%s | Exch Time :%s | ExchTimeNanoSec: %ld |"
                                      " Exch Seg :%s | Acct Id :%s | Customfirm :%s | Product:%s | Trd Symbol :%s | Fill Time :%s | Fill Date :%s |"
                                      " Noren Ord No. :%s | Exch Ord Id :%s | Trans Type :%s | Report Type :%s | RepTyp:%c | User :%s | OrderGenType :%s | NorenTimeMiliSec: %s|"
                                      " lNorenTimeNanoSec :%ld | NorenTimeSec :%s | Pan no. %s | Quantity :%ld | UnfilledSize :%ld | acOrdSrc :%s | BookProfitPrice :%d |"
                                      " BookLossPrice: %d | TrailingPrice :%d | iSnoOrdType :%d | ExternalRemarks:%s | AlgoName:%s | AlgoId :%s | AlgoCategory :%s |"
                                      " BasketId :%ld |",
              (char *)pEchoBackData,
              pFillReport->dFillPrice,
              pFillReport->siFillLeg,
              pFillReport->lFillSize,
              pFillReport->lFilledShares,
              pFillReport->acOrdStatus,
              pFillReport->cStatus,
              pFillReport->acFillId,
              pFillReport->acSymbol,
              pFillReport->acExchTime,
              pFillReport->lExchTimeNanoSec,
              pFillReport->acExchSeg,
              pFillReport->acAccountId,
              pFillReport->acCustomerFirm,
              pFillReport->acProduct,
              pFillReport->acTrdSymbol,
              pFillReport->acFillTime,
              pFillReport->acFillDate,
              pFillReport->acNorenOrdNum,
              pFillReport->acExchOrdId,
              pFillReport->acTransType,
              pFillReport->acReportType,
              pFillReport->cRepTyp,
              pFillReport->acUser,
              pFillReport->acOrderGenType,
              pFillReport->acNorenTimeMiliSec,
              pFillReport->lNorenTimeNanoSec,
              pFillReport->acNorenTimeSec,
              pFillReport->acPan,
              pFillReport->lQuantity,
              pFillReport->lUnfilledSize,
              pFillReport->acOrdSrc,
              pFillReport->iBookProfitPrice,
              pFillReport->iBookLossPrice,
              pFillReport->iTrailingPrice,
              pFillReport->iSnoOrdType,
              pFillReport->acExternalRemarks,
              pFillReport->acAlgoName,
              pFillReport->acAlgoId,
              pFillReport->acAlgoCategory,
              pFillReport->lBasketId);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::AllTradeHistoryEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AllTradeHistoryEnd  EchoBackData :%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetClientsStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetClientsStart EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetClients(void *pEchoBackData,
                                  tsClientData *pClntData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), " Get Clients:  EchoBackData: %s",
              (char *)pEchoBackData);
     logString += buffer;
     for (int i = 0; i < pClntData->iNumOfAcc; i++)
     {
          snprintf(buffer, sizeof(buffer), " Account Id :%s | Account Name :%s |",
                   pClntData->ppAccId[i],
                   pClntData->ppAccName[i]);
          logString += buffer;
     }
     std::clog << logString << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetClientsEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetClientsEnd EchoBackData:%s ", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetPositionsStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetPositionsStart  EchoBackData :%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetPositions(tsPosData **pPositionUpdate,
                                    int PositionUpdateSize,
                                    void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     std::string logString;
     snprintf(buffer, sizeof(buffer), " Get Positions:   EchoBackData: %s", (char *)pEchoBackData);
     logString += buffer;
     for (int i = 0; i < PositionUpdateSize; i++)
     {
          snprintf(buffer, 1024, " Exchange Segment  :%s |  Symbol :%s| Account Id :%s| Product :%s|"
                                 " Trading symbol :%s | Buy quantity :%.0f | Sell quantity :%.0f | Buy Amount :%.2f | Sell Amount :%.2f|"
                                 " CF Buy Quantity :%.0f | CF Sell Quantity :%.0f | CF Buy Amount :%.2f | CF Sell Amount :%.2f|"
                                 " Open Buy quantity :%.2e | Open Sell quantity :%.2e | Open Buy Amount :%.2e | Open Sell Amount :%.2e|",
                   pPositionUpdate[i]->pExchSeg,
                   pPositionUpdate[i]->pSymbol,
                   pPositionUpdate[i]->pAccId,
                   pPositionUpdate[i]->pProduct,
                   pPositionUpdate[i]->pTrdSymbol,
                   pPositionUpdate[i]->dBuyQty,
                   pPositionUpdate[i]->dSellQty,
                   pPositionUpdate[i]->dBuyAmount,
                   pPositionUpdate[i]->dSellAmount,
                   pPositionUpdate[i]->dCfBuyQty,
                   pPositionUpdate[i]->dCfSellQty,
                   pPositionUpdate[i]->dCfBuyAmount,
                   pPositionUpdate[i]->dCfSellAmount,
                   pPositionUpdate[i]->dOpenBuyQty,
                   pPositionUpdate[i]->dOpenSellQty,
                   pPositionUpdate[i]->dOpenBuyAmount,
                   pPositionUpdate[i]->dOpenSellAmount);
          logString += buffer;
          if (pPositionUpdate[i]->acInterOPKey)
          {
               snprintf(buffer, sizeof(buffer), " acInterOPKey :%s ",
                        pPositionUpdate[i]->acInterOPKey);
               logString += buffer;
          }
          if (pPositionUpdate[i]->acInterOPExchSeg)
          {
               snprintf(buffer, sizeof(buffer), " acInterOPExchSeg :%s",
                        pPositionUpdate[i]->acInterOPExchSeg);
               logString += buffer;
          }
          logString += '\n';
     }
     std::clog << logString;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetPositionsEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetPositionsEnd  EchoBackData :%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetAllPositionsStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllPositionsStart  EchoBackData :%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetAllPositions(tsPosData **pPositionUpdate,
                                       int PositionUpdateSize,
                                       void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     std::string logString;
     snprintf(buffer, sizeof(buffer), " GetAllPositions:   EchoBackData: %s", (char *)pEchoBackData);
     logString += buffer;
     for (int i = 0; i < PositionUpdateSize; i++)
     {
          snprintf(buffer, 2048, "  Exchange Segment  :%s |  Symbol :%s| Account Id :%s| Product :%s|"
                                 " Trading symbol :%s | Buy quantity :%.0f | Sell quantity :%.0f | Buy Amount :%.2f | Sell Amount :%.2f|"
                                 " CF Buy Quantity :%.0f | CF Sell Quantity :%.0f | CF Buy Amount :%.2f | CF Sell Amount :%.2f|"
                                 " Open Buy quantity :%.0f | Open Sell quantity :%.0f | Open Buy Amount :%.2f | Open Sell Amount :%.2f|",
                   pPositionUpdate[i]->pExchSeg,
                   pPositionUpdate[i]->pSymbol,
                   pPositionUpdate[i]->pAccId,
                   pPositionUpdate[i]->pProduct,
                   pPositionUpdate[i]->pTrdSymbol,
                   pPositionUpdate[i]->dBuyQty,
                   pPositionUpdate[i]->dSellQty,
                   pPositionUpdate[i]->dBuyAmount,
                   pPositionUpdate[i]->dSellAmount,
                   pPositionUpdate[i]->dCfBuyQty,
                   pPositionUpdate[i]->dCfSellQty,
                   pPositionUpdate[i]->dCfBuyAmount,
                   pPositionUpdate[i]->dCfSellAmount,
                   pPositionUpdate[i]->dOpenBuyQty,
                   pPositionUpdate[i]->dOpenSellQty,
                   pPositionUpdate[i]->dOpenBuyAmount,
                   pPositionUpdate[i]->dOpenSellAmount);
          logString += buffer;
          if (pPositionUpdate[i]->acInterOPKey)
          {
               snprintf(buffer, sizeof(buffer), " acInterOPKey :%s ",
                        pPositionUpdate[i]->acInterOPKey);
               logString += buffer;
          }
          if (pPositionUpdate[i]->acInterOPExchSeg)
          {
               snprintf(buffer, sizeof(buffer), " acInterOPExchSeg :%s",
                        pPositionUpdate[i]->acInterOPExchSeg);
               logString += buffer;
          }
          logString += '\n';
     }
     std::clog << logString;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetAllPositionsEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllPositionsEnd  EchoBackData :%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetAllSymbolsStart(void *pEchoBackData,
                                          char *pExchSeg)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllSymbolsStart  EchoBackData:%s | pExchSeg: %s |",
              (char *)pEchoBackData,
              pExchSeg);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetAllSymbols(void *pEchoBackData,
                                     tsSymbolData *pSymbolData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     std::string logString;
     snprintf(buffer, sizeof(buffer), " Get All Symbols:  EchoBackData: %s |  Symbol: %s |  Exchange segment: %s |"
                                      " InstType :%s|  Symbol name :%s|  Trading symbol :%s|  Option type :%s|  ISIN :%s|"
                                      " Company Name :%s | Tick Size :%.5e | Lot Size :%ld | Expiry Date :%ld | Multiplier :%ld|"
                                      " Precision : %ld | Strike Price : %.5e | Price Multiplier : %.0f | dPriceNum: %.0f | dGenDen :%.0f|"
                                      "dGenNum :%.0f | dPriceDen:%.0f|",
              (char *)pEchoBackData,
              pSymbolData->pSymbol,
              //<<" Group "
              //<< pSymbolData->pGroup
              pSymbolData->pExchSeg,
              pSymbolData->pInstType,
              pSymbolData->pSymbolName,
              pSymbolData->pTrdSymbol,
              pSymbolData->pOptionType,
              //<<" Scrip ref key "
              //<< pSymbolData->pScripRefKey
              pSymbolData->pISIN,
              //<<" Asset Code "
              //<< pSymbolData->pAssetCode
              //<<" Sub Group "
              //<< pSymbolData->pSubGroup
              //<<" Combined Symbol "
              //<< pSymbolData->pCombinedSymbol
              pSymbolData->pDesc,
              //<<" Amc Code "
              //<< pSymbolData->pAmcCode
              //<<" Contract Id "
              //<< pSymbolData->pContractId
              pSymbolData->dTickSize,
              pSymbolData->lLotSize,
              pSymbolData->lExpiryDate,
              pSymbolData->lMultiplier,
              pSymbolData->lPrecision,
              pSymbolData->dStrikePrice,
              pSymbolData->dPriceMultiplier,
              pSymbolData->dPriceNum,
              pSymbolData->dGenDen,
              pSymbolData->dGenNum,
              pSymbolData->dPriceDen);
     logString += buffer;
     if (pSymbolData->pUnderlyingSymbol)
     {
          snprintf(buffer, sizeof(buffer), " Underlying Symbol :%s |", pSymbolData->pUnderlyingSymbol);
          logString += buffer;
     }
     if (pSymbolData->pUnderlyingExchSeg)
     {
          snprintf(buffer, sizeof(buffer), " Underlying Exchange segment :%s|", pSymbolData->pUnderlyingExchSeg);
          logString += buffer;
     }
     if (pSymbolData->pInterOPKey)
     {
          snprintf(buffer, sizeof(buffer), " InterOp Key :%s | ", pSymbolData->pInterOPKey);
          logString += buffer;
     }

     if (pSymbolData->pExchange)
     {
          snprintf(buffer, sizeof(buffer), " pExchange :%s| ", pSymbolData->pExchange);
          logString += buffer;
     }
     if (pSymbolData->pMaturityDate)
     {
          snprintf(buffer, sizeof(buffer), " pMaturityDate :%s| ", pSymbolData->pMaturityDate);
          logString += buffer;
     }
     if (pSymbolData->pSegment)
     {
          snprintf(buffer, sizeof(buffer), " pSegment :%s| ", pSymbolData->pSegment);
          logString += buffer;
     }
     if (pSymbolData->pInterOPExchSeg)
     {
          snprintf(buffer, sizeof(buffer), " InterOp Exch : %s |", pSymbolData->pInterOPExchSeg);
          logString += buffer;
     }
     if (pSymbolData->pExchSymblName)
     {
          snprintf(buffer, sizeof(buffer), " pExchSymblName :%s |", pSymbolData->pExchSymblName);
          logString += buffer;
     }

     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetAllSymbolsEnd(void *pEchoBackData,
                                        char *pExchSeg)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     std::string logString;
     snprintf(buffer, sizeof(buffer), "GetAllSymbolsEnd  EchoBackData :%s |pExchSeg: %s |",
              (char *)pEchoBackData,
              pExchSeg);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetGroupSettingsStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), " GetGroupSettingsStart  EchoBackData: %s ",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::SendGroupSettings(void *pEchoBackData,
                                         int MWsize,
                                         char **pMarketWatch)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     std::string logString;
     snprintf(buffer, sizeof(buffer), " SendGroupSettings EchoBackData: %s|",
              (char *)pEchoBackData);
     logString += buffer;
     logString += " Market Watch data is:";

     for (int i = 0; i < MWsize; i++)
     {
          logString += "\n";
          logString += pMarketWatch[i];
     }
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetGroupSettingsEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), " GetGroupSettingsEnd  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::SetGroupSettingsResp(void *pEchoBackData,
                                            char *pComment)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "SetGroupSettingsResp EchoBackData: %s | pComment :%s | ",
              (char *)pEchoBackData,
              pComment);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::ValidateUidPwdResp(void *pEchoBackData,
                                          char *pComment)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ValidateUidPwdResp EchoBackData :%s| pComment :%s |",
              (char *)pEchoBackData,
              pComment);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::OrderBookSnapQuote(char *pSymbol,
                                          char *pExchSeg,
                                          char *pExchTimeStamp,
                                          int iDepthSize,
                                          double *adAskPrice,
                                          double *adBidPrice,
                                          long *alAskSize,
                                          long *alBidSize,
                                          long *alAskNumOfOrders,
                                          long *alBidNumOfOrders)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "orderbooksnapquote  Symbol :%s | ExchSeg :%s | ExchTimeStamp :%s |"
                                      " Ask Price1 :%.0f |  Bid Price1 : %.0f | Ask Size1 :%ld | Bid Size1 :%ld | Ask No. Of Orders1 :%ld |"
                                      " Bid No.Of Orders1 :%ld | Ask Price2 :%.0f | Bid Price2 :%f | Ask Size2 :%ld | Bid Size2 :%ld |"
                                      "  Ask No. Of Orders2 :%ld | Bid No.Of Orders2 :%ld | Ask Price3 :%.0f | Bid Price3 :%.0f |"
                                      " Ask Size3 :%ld | Bid Size3 :%ld | Ask No. Of Orders3 :%ld | Bid No.Of Orders3 :%ld |"
                                      " Ask Price4 :%.0f| Bid Price4 :%.0f |  Ask Size4 :%ld | Bid Size4 :%ld | Ask No. Of Orders4 :%ld |"
                                      " Bid No.Of Orders4 :%ld | Ask Price5 :%.0f | Bid Price5 :%.0f | Ask Size5 :%ld | Bid Size5 :%ld |"
                                      " Ask No. Of Orders5 :%ld | Bid No.Of Orders5 :%ld|",
              pSymbol,
              pExchSeg,
              pExchTimeStamp,
              adAskPrice[0],
              adBidPrice[0],
              alAskSize[0],
              alBidSize[0],
              alAskNumOfOrders[0],
              alBidNumOfOrders[0],
              adAskPrice[1],
              adBidPrice[1],
              alAskSize[1],
              alBidSize[1],
              alAskNumOfOrders[1],
              alBidNumOfOrders[1],
              adAskPrice[2],
              adBidPrice[2],
              alAskSize[2],
              alBidSize[2],
              alAskNumOfOrders[2],
              alBidNumOfOrders[2],
              adAskPrice[3],
              adBidPrice[3],
              alAskSize[3],
              alBidSize[3],
              alAskNumOfOrders[3],
              alBidNumOfOrders[3],
              adAskPrice[4],
              adBidPrice[4],
              alAskSize[4],
              alBidSize[4],
              alAskNumOfOrders[4],
              alBidNumOfOrders[4]);
     logString += buffer;
     if (iDepthSize == 20)
     {
          snprintf(buffer, sizeof(buffer), " Ask Price6 :%f | Bid Price6 :%f | Ask Size6 :%ld | Bid Size6 :%ld |"
                                           " Ask No. Of Orders6 :%ld | Bid No.Of Orders6 :%ld | Ask Price7 :%f | Bid Price7 :%f |"
                                           " Ask Size7 :%ld | Bid Size7 :%ld | Ask No. Of Orders7 :%ld | Bid No.Of Orders7 :%ld |"
                                           " Ask Price8 :%f | Bid Price8 :%f | Ask Size8 :%ld | Bid Size8 :%ld | Ask No. Of Orders8 :%ld |"
                                           " Bid No.Of Orders8 :%ld | Ask Price9 :%f | Bid Price9 :%f | Ask Size9 :%ld | Bid Size9 :%ld |"
                                           " Ask No. Of Orders9 :%ld | Bid No.Of Orders9 :%ld | Ask Price10 :%f | Bid Price10 :%f |"
                                           " Ask Size10 :%ld | Bid Size10 :%ld | Ask No. Of Orders10 :%ld | Bid No.Of Orders10 :%ld |"
                                           " Ask Price11 :%f | Bid Price11 :%f | Ask Size11 :%ld | Bid Size11 :%ld | Ask No. Of Orders11 :%ld |"
                                           " Bid No.Of Orders11 :%ld | Ask Price12 :%f | Bid Price12 :%f | Ask Size12 :%ld | Bid Size12 :%ld |"
                                           " Ask No. Of Orders12 :%ld | Bid No.Of Orders12 :%ld | Ask Price13 :%f | Bid Price13 :%f |"
                                           " Ask Size13 :%ld | Bid Size13 :%ld | Ask No. Of Orders13 :%ld | Bid No.Of Orders13 :%ld |"
                                           " Ask Price14 :%f | Bid Price14 :%f | Ask Size14 :%ld | Bid Size14 :%ld | Ask No. Of Orders14 :%ld |"
                                           " Bid No.Of Orders14 :%ld | Ask Price15 :%f | Bid Price15 :%f | Ask Size15 :%ld | Bid Size15 :%ld |"
                                           " Ask No. Of Orders15 :%ld | Bid No.Of Orders15 :%ld | Ask Price16 :%f | Bid Price16 :%f | Ask Size16 :%ld |"
                                           " Bid Size16 :%ld | Ask No. Of Orders16 :%ld | Bid No.Of Orders16 :%ld | Ask Price17 :%f | Bid Price17 :%f |"
                                           " Ask Size17 :%ld | Bid Size17 :%ld | Ask No. Of Orders17 :%ld | Bid No.Of Orders17 :%ld | Ask Price18 :%f |"
                                           " Bid Price18 :%f | Ask Size18 :%ld | Bid Size18 :%ld | Ask No. Of Orders18 :%ld | Bid No.Of Orders18 :%ld |"
                                           " Ask Price19 :%f | Bid Price19 :%f | Ask Size19 :%ld | Bid Size19 :%ld | Ask No. Of Orders19 :%ld |"
                                           " Bid No.Of Orders19 :%ld | Ask Price20 :%f | Bid Price20 :%f | Ask Size20 :%ld | Bid Size20 :%ld |"
                                           " Ask No. Of Orders20 :%ld | Bid No.Of Orders20 :%ld |",
                   adAskPrice[5],
                   adBidPrice[5],
                   alAskSize[5],
                   alBidSize[5],
                   alAskNumOfOrders[5],
                   alBidNumOfOrders[5],
                   adAskPrice[6],
                   adBidPrice[6],
                   alAskSize[6],
                   alBidSize[6],
                   alAskNumOfOrders[6],
                   alBidNumOfOrders[6],
                   adAskPrice[7],
                   adBidPrice[7],
                   alAskSize[7],
                   alBidSize[7],
                   alAskNumOfOrders[7],
                   alBidNumOfOrders[7],
                   adAskPrice[8],
                   adBidPrice[8],
                   alAskSize[8],
                   alBidSize[8],
                   alAskNumOfOrders[8],
                   alBidNumOfOrders[8],
                   adAskPrice[9],
                   adBidPrice[9],
                   alAskSize[9],
                   alBidSize[9],
                   alAskNumOfOrders[9],
                   alBidNumOfOrders[9],
                   adAskPrice[10],
                   adBidPrice[10],
                   alAskSize[10],
                   alBidSize[10],
                   alAskNumOfOrders[10],
                   alBidNumOfOrders[10],
                   adAskPrice[11],
                   adBidPrice[11],
                   alAskSize[11],
                   alBidSize[11],
                   alAskNumOfOrders[11],
                   alBidNumOfOrders[11],
                   adAskPrice[12],
                   adBidPrice[12],
                   alAskSize[12],
                   alBidSize[12],
                   alAskNumOfOrders[12],
                   alBidNumOfOrders[12],
                   adAskPrice[13],
                   adBidPrice[13],
                   alAskSize[13],
                   alBidSize[13],
                   alAskNumOfOrders[13],
                   alBidNumOfOrders[13],
                   adAskPrice[14],
                   adBidPrice[14],
                   alAskSize[14],
                   alBidSize[14],
                   alAskNumOfOrders[14],
                   alBidNumOfOrders[14],
                   adAskPrice[15],
                   adBidPrice[15],
                   alAskSize[15],
                   alBidSize[15],
                   alAskNumOfOrders[15],
                   alBidNumOfOrders[15],
                   adAskPrice[16],
                   adBidPrice[16],
                   alAskSize[16],
                   alBidSize[16],
                   alAskNumOfOrders[16],
                   alBidNumOfOrders[16],
                   adAskPrice[17],
                   adBidPrice[17],
                   alAskSize[17],
                   alBidSize[17],
                   alAskNumOfOrders[17],
                   alBidNumOfOrders[17],
                   adAskPrice[18],
                   adBidPrice[18],
                   alAskSize[18],
                   alBidSize[18],
                   alAskNumOfOrders[18],
                   alBidNumOfOrders[18],
                   adAskPrice[19],
                   adBidPrice[19],
                   alAskSize[19],
                   alBidSize[19],
                   alAskNumOfOrders[19],
                   alBidNumOfOrders[19]);
          logString += buffer;
     }
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::UnSubscribeFeedResponse(void *pEchoBackData,
                                               char *pStatus,
                                               char *pExchSeg,
                                               char *pSymbol)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "UnSubscribeFeedResponse  EchoBackData: %s | Status :%s | ExchSeg :%s | Symbol :%s |",
              (char *)pEchoBackData,
              pStatus,
              pExchSeg,
              pSymbol);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::ExitCoverOrderResp(void *pEchoBackData,
                                          char *pComments)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ExitCoverOrderResp  EchoBackData: %s | pComments :%s |",
              (char *)pEchoBackData,
              pComments);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::ExitBracketOrderResp(void *pEchoBackData,
                                            char *pComments)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ExitBracketOrderResp  EchoBackData: %s |  pComments :%s |",
              (char *)pEchoBackData,
              pComments);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::RegenerateCoverOrderResp(void *pEchoBackData,
                                                char *pComments)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "RegenerateCoverOrderResp  EchoBackData: %s | pComments :%s |",
              (char *)pEchoBackData,
              pComments);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::ofstream timeLogFile;
     timeLogFile.open(timeLogFilePath, std::ios_base::app); // Open in append mode
     if (timeLogFile.is_open())
     {
          timeLogFile << std::left << std::setw(20) << __FUNCTION__
                      << "," << "-"
                      << "," << "-"
                      << "," << endtime
                      << "," << starttime
                      << "," << res << "\n";
          timeLogFile.close();
     }
     else
     {
          std::cerr << "Failed to open timeLogFilePath for writing" << std::endl;
     }
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::RegenerateBracketOrderResp(void *pEchoBackData,
                                                  char *pComments)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "RegenerateBracketOrderResp EchoBackData: %s |pComments :%s|",
              (char *)pEchoBackData,
              pComments);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::ofstream timeLogFile;
     timeLogFile.open(timeLogFilePath, std::ios_base::app); // Open in append mode
     if (timeLogFile.is_open())
     {
          timeLogFile << std::left << std::setw(20) << __FUNCTION__
                      << "," << "-"
                      << "," << "-"
                      << "," << endtime
                      << "," << starttime
                      << "," << res << "\n";
          timeLogFile.close();
     }
     else
     {
          std::cerr << "Failed to open timeLogFilePath for writing" << std::endl;
     }
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::PartialPosConResponse(void *pEchoBackData,
                                             char *pText)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PartialPosConResponse  EchoBackData: %s | pText :%s| ",
              (char *)pEchoBackData,
              pText);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetRmsLimitsStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetRmsLimitsStart EchoBackData:%s ", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::SendRmsLimits(tsRmsLimits *pRmsLimits,
                                     void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     /*   std::clog << "SendRmsLimits "
               << " EchoBackData: " << (char *)pEchoBackData << " acct id "
               << pRmsLimits->acAcctId
               << " pCategory "
               << pRmsLimits->pCategory
               << " pSegment "
               << pRmsLimits->pSegment
               << " acExchSeg "
               << pRmsLimits->acExchSeg
               << " acProduct "
               << pRmsLimits->acProduct
               << " CollateralValue "
               << pRmsLimits->dCollateralValue
               << " Collateral "
               << pRmsLimits->dCollateral
               << " BrokerCollateral "
               << pRmsLimits->dRmsCollateral
               << " DaylongCash "
               << pRmsLimits->dAdhocMargin
               << " UnclearedCash "
               << pRmsLimits->dNotionalCash
               << " AmountUtilizedPrsnt "
               << pRmsLimits->dAmountUtilizedPrsnt
               << " UnrealizedMtomPrsnt "
               << pRmsLimits->dUnrealizedMtomPrsnt
               << " RealizedMtomPrsnt "
               << pRmsLimits->dRealizedMtomPrsnt
               << " ExposureMarginPrsnt "
               << pRmsLimits->dExposureMarginPrsnt
               << " SpanMarginPrsnt "
               << pRmsLimits->dSpanMarginPrsnt
               << " PremiumPrsnt "
               << pRmsLimits->dPremiumPrsnt
               << " MarginVarPrsnt "
               << pRmsLimits->dMarginVarPrsnt
               << " MarginScripBasketPrsnt "
               << pRmsLimits->dMarginScripBasketPrsnt <<
               //                    "dMtomWarningPrcntPrsnt "<<pRmsLimits->dMtomWarningPrcntPrsnt<<
               //                    "dMtomSquareOffWarningPrcntPrsnt "<<pRmsLimits->dMtomSquareOffWarningPrcntPrsnt<<
               " MarginUsed "
               << pRmsLimits->dMarginUsed
               << " RmsPayInAmt "
               << pRmsLimits->dRmsPayInAmt
               << " RmsPayOutAmt "
               << pRmsLimits->dRmsPayOutAmt
               << " CurExpMrgnNrmlPrsnt "
               << pRmsLimits->dCurExpMrgnNrmlPrsnt
               << " CurExpMrgnMisPrsnt "
               << pRmsLimits->dCurExpMrgnMisPrsnt
               << " CurPremiumNrmlPrsnt "
               << pRmsLimits->dCurPremiumNrmlPrsnt
               << " CurPremiumMisPrsnt "
               << pRmsLimits->dCurPremiumMisPrsnt
               << " CurSpanMrgnNrmlPrsnt "
               << pRmsLimits->dCurSpanMrgnNrmlPrsnt
               << " CurSpanMrgnMisPrsnt "
               << pRmsLimits->dCurSpanMrgnMisPrsnt
               << " FoExpMrgnNrmlPrsnt "
               << pRmsLimits->dFoExpMrgnNrmlPrsnt
               << " FoExpMrgnMisPrsnt "
               << pRmsLimits->dFoExpMrgnMisPrsnt
               << " FoPremiumNrmlPrsnt "
               << pRmsLimits->dFoPremiumNrmlPrsnt
               << " FoPremiumMisPrsnt "
               << pRmsLimits->dFoPremiumMisPrsnt
               << " FoSpanrgnNrmlPrsnt "
               << pRmsLimits->dFoSpanrgnNrmlPrsnt
               << " FoSpanrgnMisPrsnt "
               << pRmsLimits->dFoSpanrgnMisPrsnt
               << " MrgnScrpBsktNrmlPrsnt "
               << pRmsLimits->dMrgnScrpBsktNrmlPrsnt
               << " MrgnScrpBsktMisPrsnt "
               << pRmsLimits->dMrgnScrpBsktMisPrsnt
               <<
               //                    "dMrgnScrpBsktCncPrsnt "<<pRmsLimits->dMrgnScrpBsktCncPrsnt<<
               " MrgnVarNrmlPrsnt "
               << pRmsLimits->dMrgnVarNrmlPrsnt
               << " MrgnVarMisPrsnt "
               << pRmsLimits->dMrgnVarMisPrsnt
               << " AmtUntilizedPrsnt "
               << pRmsLimits->dAmtUntilizedPrsnt
               << " CncMrgnVarPrsnt "
               << pRmsLimits->dCncMrgnVarPrsnt
               << " MarginUsedPrsnt "
               << pRmsLimits->dMarginUsedPrsnt
               << " AuxBrokerCollateral "
               << pRmsLimits->dAuxRmsCollateral
               << " AuxDaylongCash "
               << pRmsLimits->dAuxAdhocMargin
               << " AuxUnclearedCash "
               << pRmsLimits->dAuxNotionalCash
               << " AvailableMargin "
               << pRmsLimits->dAvailableMargin
               << " dBrokerage "
               << pRmsLimits->dBrokerage
               << " dMrgnProtection "
               << pRmsLimits->dMrgnProtection
               << " dFoPremium "
               << pRmsLimits->dFoPremium
               << " dCurPremium "
               << pRmsLimits->dCurPremium
               << " dComPremium "
               << pRmsLimits->dComPremium
               << " dMtomCurrentPerc "
               << pRmsLimits->dMtomCurrentPerc
               << " dMarginCurrentPerc "
               << pRmsLimits->dMarginCurrentPerc
               << " dLiquidCashCollateral "
               << pRmsLimits->dLiquidCashCollateral
               << " dMfCollateral "
               << pRmsLimits->dMfCollateral
               << " dMfCashCollateral "
               << pRmsLimits->dMfCashCollateral
               << " dAddMrgnPrsnt "
               << pRmsLimits->dAddMrgnPrsnt
               << " dTenderMrgnPrsnt "
               << pRmsLimits->dTenderMrgnPrsnt
               << " dDeliveryMrgnPrsnt "
               << pRmsLimits->dDeliveryMrgnPrsnt
               << " dBrokerageCnc "
               << pRmsLimits->dBrokerageCnc
               << " dBrokerageMis "
               << pRmsLimits->dBrokerageMis
               << " dBrokerageNrml "
               << pRmsLimits->dBrokerageNrml
               << " dBrokerageCO "
               << pRmsLimits->dBrokerageCO
               << " dBrokerageBO "
               << pRmsLimits->dBrokerageBO
               << " dFoBrokerageMis "
               << pRmsLimits->dFoBrokerageMis
               << " dFoBrokerageNrml "
               << pRmsLimits->dFoBrokerageNrml
               << " dFoBrokerageCO "
               << pRmsLimits->dFoBrokerageCO
               << " dFoBrokerageBO "
               << pRmsLimits->dFoBrokerageBO
               << " dCurBrokerageMis "
               << pRmsLimits->dCurBrokerageMis
               << " dCurBrokerageNrml "
               << pRmsLimits->dCurBrokerageNrml
               << " dCurBrokerageCO "
               << pRmsLimits->dCurBrokerageCO
               << " dCurBrokerageBO "
               << pRmsLimits->dCurBrokerageBO
               << " dComBrokerageMis "
               << pRmsLimits->dComBrokerageMis
               << " dComBrokerageNrml "
               << pRmsLimits->dComBrokerageNrml
               << " dComBrokerageCO "
               << pRmsLimits->dComBrokerageCO
               << " dComBrokerageBO "
               << pRmsLimits->dComBrokerageBO
               << " dMrgnProtectionCO "
               << pRmsLimits->dMrgnProtectionCO
               << " dMrgnProtectionBO "
               << pRmsLimits->dMrgnProtectionBO
               << " dFoMrgnProtectionCO "
               << pRmsLimits->dFoMrgnProtectionCO
               << " dFoMrgnProtectionBO "
               << pRmsLimits->dFoMrgnProtectionBO
               << " dCurMrgnProtectionCO "
               << pRmsLimits->dCurMrgnProtectionCO
               << " dCurMrgnProtectionBO "
               << pRmsLimits->dCurMrgnProtectionBO
               << " dComMrgnProtectionCO "
               << pRmsLimits->dComMrgnProtectionCO
               << " dComMrgnProtectionBO "
               << pRmsLimits->dComMrgnProtectionBO
               << " dComPremiumMisPrsnt "
               << pRmsLimits->dComPremiumMisPrsnt
               << " dComPremiumNrmlPrsnt "
               << pRmsLimits->dComPremiumNrmlPrsnt
               << " dExchMrgn "
               << pRmsLimits->dExchMrgn
               << " dFoExchMrgn "
               << pRmsLimits->dFoExchMrgn
               << " dCurExchMrgn "
               << pRmsLimits->dCurExchMrgn
               << " dComExchMrgn "
               << pRmsLimits->dComExchMrgn
               << " dExchMrgnSellCrd "
               << pRmsLimits->dExchMrgnSellCrd
               << " dExchMrgnT1SellCrd "
               << pRmsLimits->dExchMrgnT1SellCrd
               << " dAlloc "
               << pRmsLimits->dAlloc
               << " dFoAlloc "
               << pRmsLimits->dFoAlloc
               << " dCurAlloc "
               << pRmsLimits->dCurAlloc
               << " dComAlloc "
               << pRmsLimits->dComAlloc
               << " dBlockAmt "
               << pRmsLimits->dBlockAmt
               << std::endl;
      */
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "SendRmsLimits  EchoBackData :%s|  acct id :%s |pCategory :%s| "
                                      " pSegment :%s |acExchSeg :%s | acProduct :%s | CollateralValue :%e | Collateral :%.2f | BrokerCollateral :%.2f|"
                                      " DaylongCash :%.2f | UnclearedCash :%.2f| AmountUtilizedPrsnt :%.2f | UnrealizedMtomPrsnt :%.2f | RealizedMtomPrsnt :%.2f|"
                                      "ExposureMarginPrsnt :%.2f | SpanMarginPrsnt :%.2f | PremiumPrsnt :%.2f | MarginVarPrsnt :%.2f | MarginScripBasketPrsnt :%.2f|"
                                      " MarginUsed :%.2f | RmsPayInAmt :%.2f| RmsPayOutAmt :%.2f| CurExpMrgnNrmlPrsnt :%.2f | CurExpMrgnNrmlPrsnt :%.2f|"
                                      " CurPremiumNrmlPrsnt :%.2f|  CurPremiumMisPrsnt :%.2f| CurSpanMrgnNrmlPrsnt:%.2f | CurSpanMrgnMisPrsnt :%.2f|"
                                      " FoExpMrgnNrmlPrsnt :%.2f |FoExpMrgnMisPrsnt :%.2f |FoPremiumNrmlPrsnt :%.2f| FoPremiumMisPrsnt :%.2f | FoSpanrgnNrmlPrsnt :%.2f|"
                                      " FoSpanrgnMisPrsnt :%.2f | MrgnScrpBsktNrmlPrsnt :%.2f| MrgnScrpBsktMisPrsnt :%.2f | MrgnVarNrmlPrsnt :%.2f| MrgnVarMisPrsnt:%.2f|"
                                      " AmtUntilizedPrsnt :%.2f | CncMrgnVarPrsnt :%.2f | MarginUsedPrsnt :%.2f |AuxBrokerCollateral :%.2f| AuxDaylongCash :%.2f|"
                                      "AuxUnclearedCash :%.2f | AvailableMargin :%.2e | dBrokerage :%.2f |dMrgnProtection :%.2f | dFoPremium :%.2f  |dCurPremium :%.2f|"
                                      "dComPremium :%.2f |dMtomCurrentPerc :%e |dMarginCurrentPerc :%e  |dLiquidCashCollateral :%e |dMfCollateral :%e|"
                                      " dMfCashCollateral :%e | dAddMrgnPrsnt:%e | dTenderMrgnPrsnt :%e| dDeliveryMrgnPrsnt:%e |dBrokerageCnc:%e | dBrokerageMis :%e|"
                                      "dBrokerageNrml :%e | dBrokerageCO :%e | dBrokerageBO :%e  |dFoBrokerageMis :%e | dFoBrokerageNrml :%e | dFoBrokerageCO:%e |"
                                      " dFoBrokerageBO :%e |  dCurBrokerageMis :%e | dCurBrokerageNrml :%e |dCurBrokerageCO :%e |dCurBrokerageBO :%e|"
                                      " dComBrokerageMis :%e| dComBrokerageNrml:%e | dComBrokerageCO :%e|  dComBrokerageBO :%e| dMrgnProtectionCO  :%e|"
                                      " dMrgnProtectionBO :%e | dFoMrgnProtectionCO :%e  |dFoMrgnProtectionBO :%e|dCurMrgnProtectionCO :%e| dCurMrgnProtectionBO :%e"
                                      "dComMrgnProtectionCO :%e |dComMrgnProtectionBO :%e| dComPremiumMisPrsnt :%e|  dComPremiumNrmlPrsnt :%e |dExchMrgn :%.2f |dFoExchMrgn :%e|"
                                      " dCurExchMrgn :%e |dComExchMrgn :%e|dExchMrgnSellCrd :%e |dExchMrgnT1SellCrd :%e | dAlloc :%e |dFoAlloc :%e | dCurAlloc :%e |"
                                      " dComAlloc :%e| dBlockAmt :%e| dRemarksAmt :%e",
              (char *)pEchoBackData,
              pRmsLimits->acAcctId,
              pRmsLimits->pCategory,
              pRmsLimits->pSegment,
              pRmsLimits->acExchSeg,
              pRmsLimits->acProduct,
              pRmsLimits->dCollateralValue,
              pRmsLimits->dCollateral,
              pRmsLimits->dRmsCollateral,
              pRmsLimits->dAdhocMargin,
              pRmsLimits->dNotionalCash,
              pRmsLimits->dAmountUtilizedPrsnt,
              pRmsLimits->dUnrealizedMtomPrsnt,
              pRmsLimits->dRealizedMtomPrsnt,
              pRmsLimits->dExposureMarginPrsnt,
              pRmsLimits->dSpanMarginPrsnt,
              pRmsLimits->dPremiumPrsnt,
              pRmsLimits->dMarginVarPrsnt,
              pRmsLimits->dMarginScripBasketPrsnt,
              //                    "dMtomWarningPrcntPrsnt "<<pRmsLimits->dMtomWarningPrcntPrsnt<<
              //                    "dMtomSquareOffWarningPrcntPrsnt "<<pRmsLimits->dMtomSquareOffWarningPrcntPrsnt<<
              pRmsLimits->dMarginUsed,
              pRmsLimits->dRmsPayInAmt,
              pRmsLimits->dRmsPayOutAmt,
              pRmsLimits->dCurExpMrgnNrmlPrsnt,
              pRmsLimits->dCurExpMrgnMisPrsnt,
              pRmsLimits->dCurPremiumNrmlPrsnt,
              pRmsLimits->dCurPremiumMisPrsnt,
              pRmsLimits->dCurSpanMrgnNrmlPrsnt,
              pRmsLimits->dCurSpanMrgnMisPrsnt,
              pRmsLimits->dFoExpMrgnNrmlPrsnt,
              pRmsLimits->dFoExpMrgnMisPrsnt,
              pRmsLimits->dFoPremiumNrmlPrsnt,
              pRmsLimits->dFoPremiumMisPrsnt,
              pRmsLimits->dFoSpanrgnNrmlPrsnt,
              pRmsLimits->dFoSpanrgnMisPrsnt,
              pRmsLimits->dMrgnScrpBsktNrmlPrsnt,
              pRmsLimits->dMrgnScrpBsktMisPrsnt,
              //                    "dMrgnScrpBsktCncPrsnt "<<pRmsLimits->dMrgnScrpBsktCncPrsnt<<
              pRmsLimits->dMrgnVarNrmlPrsnt,
              pRmsLimits->dMrgnVarMisPrsnt,
              pRmsLimits->dAmtUntilizedPrsnt,
              pRmsLimits->dCncMrgnVarPrsnt,
              pRmsLimits->dMarginUsedPrsnt,
              pRmsLimits->dAuxRmsCollateral,
              pRmsLimits->dAuxAdhocMargin,
              pRmsLimits->dAuxNotionalCash,
              pRmsLimits->dAvailableMargin,
              pRmsLimits->dBrokerage,
              pRmsLimits->dMrgnProtection,
              pRmsLimits->dFoPremium,
              pRmsLimits->dCurPremium,
              pRmsLimits->dComPremium,
              pRmsLimits->dMtomCurrentPerc,
              pRmsLimits->dMarginCurrentPerc,
              pRmsLimits->dLiquidCashCollateral,
              pRmsLimits->dMfCollateral,
              pRmsLimits->dMfCashCollateral,
              pRmsLimits->dAddMrgnPrsnt,
              pRmsLimits->dTenderMrgnPrsnt,
              pRmsLimits->dDeliveryMrgnPrsnt,
              pRmsLimits->dBrokerageCnc,
              pRmsLimits->dBrokerageMis,
              pRmsLimits->dBrokerageNrml,
              pRmsLimits->dBrokerageCO,
              pRmsLimits->dBrokerageBO,
              pRmsLimits->dFoBrokerageMis,
              pRmsLimits->dFoBrokerageNrml,
              pRmsLimits->dFoBrokerageCO,
              pRmsLimits->dFoBrokerageBO,
              pRmsLimits->dCurBrokerageMis,
              pRmsLimits->dCurBrokerageNrml,
              pRmsLimits->dCurBrokerageCO,
              pRmsLimits->dCurBrokerageBO,
              pRmsLimits->dComBrokerageMis,
              pRmsLimits->dComBrokerageNrml,
              pRmsLimits->dComBrokerageCO,
              pRmsLimits->dComBrokerageBO,
              pRmsLimits->dMrgnProtectionCO,
              pRmsLimits->dMrgnProtectionBO,
              pRmsLimits->dFoMrgnProtectionCO,
              pRmsLimits->dFoMrgnProtectionBO,
              pRmsLimits->dCurMrgnProtectionCO,
              pRmsLimits->dCurMrgnProtectionBO,
              pRmsLimits->dComMrgnProtectionCO,
              pRmsLimits->dComMrgnProtectionBO,
              pRmsLimits->dComPremiumMisPrsnt,
              pRmsLimits->dComPremiumNrmlPrsnt,
              pRmsLimits->dExchMrgn,
              pRmsLimits->dFoExchMrgn,
              pRmsLimits->dCurExchMrgn,
              pRmsLimits->dComExchMrgn,
              pRmsLimits->dExchMrgnSellCrd,
              pRmsLimits->dExchMrgnT1SellCrd,
              pRmsLimits->dAlloc,
              pRmsLimits->dFoAlloc,
              pRmsLimits->dCurAlloc,
              pRmsLimits->dComAlloc,
              pRmsLimits->dBlockAmt,
              pRmsLimits->dRemarksAmt);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetRmsLimitsEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetRmsLimitsEnd  EchoBackData: %s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetAllRmsLimitsStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllRmsLimitsStart EchoBackData:%s ", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::SendAllRmsLimits(tsRmsLimits *pRmsLimits,
                                        void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "SendAllRmsLimits  EchoBackData: %s | acct id :%s | pCategory :%s | pSegment:%s |"
                                      " acExchSeg :%s | acProduct :%s | CollateralValue :%.2e | Collateral :%.2f | BrokerCollateral :%.2f |"
                                      " DaylongCash :%.2f | UnclearedCash :%.2f | AmountUtilizedPrsnt :%.2f | UnrealizedMtomPrsnt:%.2f | RealizedMtomPrsnt :%.2f |"
                                      " ExposureMarginPrsnt :%.2f | SpanMarginPrsnt :%.2f | PremiumPrsnt :%.2f | MarginVarPrsnt :%.2f | MarginScripBasketPrsnt :%.2f |"
                                      " MarginUsed :%.2f | RmsPayInAmt:%.2f | RmsPayOutAmt:%.2f | CurExpMrgnNrmlPrsnt :%.2f | CurExpMrgnMisPrsnt :%.2f | CurPremiumNrmlPrsnt:%.2f |"
                                      " CurPremiumMisPrsnt :%.2f | CurSpanMrgnNrmlPrsnt :%.2f | CurSpanMrgnMisPrsnt:%.2f | FoExpMrgnNrmlPrsnt :%.2f | FoExpMrgnMisPrsnt :%.2f |"
                                      " FoPremiumNrmlPrsnt :%.2f | FoPremiumMisPrsnt :%.2f | FoSpanrgnNrmlPrsnt :%.2f | FoSpanrgnMisPrsnt :%.2f | MrgnScrpBsktNrmlPrsnt :%.2f |"
                                      " MrgnScrpBsktMisPrsnt :%.2f | MrgnVarNrmlPrsnt :%.2f | MrgnVarMisPrsnt :%.2f | AmtUntilizedPrsnt :%.2f | CncMrgnVarPrsnt :%.2f | MarginUsedPrsnt :%.2f |"
                                      " AuxBrokerCollateral :%.2f | AuxDaylongCash :%.2f | AuxUnclearedCash :%.2f | AvailableMargin :%.2e | dBrokerage :%.2f | dMrgnProtection :%.2f |"
                                      " dFoPremium :%.2f | dCurPremium :%.2f | dComPremium :%.2f | dMtomCurrentPerc :%.2e | dMarginCurrentPerc :%.2e | dLiquidCashCollateral :%.2e |"
                                      " dMfCollateral :%.2e | dMfCashCollateral :%.2e | dAddMrgnPrsnt :%.2e| dTenderMrgnPrsnt :%.2e | dDeliveryMrgnPrsnt :%.2e | dBrokerageCnc :%.2e |"
                                      " dBrokerageMis :%.2e | dBrokerageNrml :%.2e | dBrokerageCO :%.2e | dBrokerageBO :%.2e | dFoBrokerageMis :%.2e | dFoBrokerageNrml :%.2e | dFoBrokerageCO :%.2e |"
                                      " dFoBrokerageBO :%.2e| dCurBrokerageMis :%.2e | dCurBrokerageNrml :%.2e | dCurBrokerageCO :%.2e | dCurBrokerageBO :%.2e | dComBrokerageMis :%.2e | dComBrokerageNrml :%.2e |"
                                      " dComBrokerageCO :%.2e| dComBrokerageBO :%.2e | dMrgnProtectionCO :%.2e | dMrgnProtectionBO :%.2e | dFoMrgnProtectionCO :%.2e |  dFoMrgnProtectionBO :%.2e | dCurMrgnProtectionCO :%.2e |"
                                      " dCurMrgnProtectionBO :%.2e | dComMrgnProtectionCO :%.2e | dComMrgnProtectionBO :%.2e | dComPremiumMisPrsnt :%.2e | dComPremiumNrmlPrsnt :%.2e | dExchMrgn :%.2f | dFoExchMrgn :%.2e |"
                                      "dCurExchMrgn :%.2e | dComExchMrgn :%.2e | dExchMrgnSellCrd :%.2e | dExchMrgnT1SellCrd :%.2e | dAlloc :%.2e | dFoAlloc :%.2e| dCurAlloc :%.2e | dComAlloc :%.2e| dBlockAmt :%.2e | dMtfLimit :%.0f |"
                                      "dSlbmLimit :%.0f | dRemarksAmt :%.2e",
              (char *)pEchoBackData,
              pRmsLimits->acAcctId,
              pRmsLimits->pCategory,
              pRmsLimits->pSegment,
              pRmsLimits->acExchSeg,
              pRmsLimits->acProduct,
              pRmsLimits->dCollateralValue,
              pRmsLimits->dCollateral,
              pRmsLimits->dRmsCollateral,
              pRmsLimits->dAdhocMargin,
              pRmsLimits->dNotionalCash,
              pRmsLimits->dAmountUtilizedPrsnt,
              pRmsLimits->dUnrealizedMtomPrsnt,
              pRmsLimits->dRealizedMtomPrsnt,
              pRmsLimits->dExposureMarginPrsnt,
              pRmsLimits->dSpanMarginPrsnt,
              pRmsLimits->dPremiumPrsnt,
              pRmsLimits->dMarginVarPrsnt,
              pRmsLimits->dMarginScripBasketPrsnt, //<<
              //                    "dMtomWarningPrcntPrsnt "<<pRmsLimits->dMtomWarningPrcntPrsnt<<
              //                    "dMtomSquareOffWarningPrcntPrsnt "<<pRmsLimits->dMtomSquareOffWarningPrcntPrsnt<<
              pRmsLimits->dMarginUsed,
              pRmsLimits->dRmsPayInAmt,
              pRmsLimits->dRmsPayOutAmt,
              pRmsLimits->dCurExpMrgnNrmlPrsnt,
              pRmsLimits->dCurExpMrgnMisPrsnt,
              pRmsLimits->dCurPremiumNrmlPrsnt,
              pRmsLimits->dCurPremiumMisPrsnt,
              pRmsLimits->dCurSpanMrgnNrmlPrsnt,
              pRmsLimits->dCurSpanMrgnMisPrsnt,
              pRmsLimits->dFoExpMrgnNrmlPrsnt,
              pRmsLimits->dFoExpMrgnMisPrsnt,
              pRmsLimits->dFoPremiumNrmlPrsnt,
              pRmsLimits->dFoPremiumMisPrsnt,
              pRmsLimits->dFoSpanrgnNrmlPrsnt,
              pRmsLimits->dFoSpanrgnMisPrsnt,
              pRmsLimits->dMrgnScrpBsktNrmlPrsnt,
              pRmsLimits->dMrgnScrpBsktMisPrsnt,
              // <<
              //                    "dMrgnScrpBsktCncPrsnt "<<pRmsLimits->dMrgnScrpBsktCncPrsnt<<

              pRmsLimits->dMrgnVarNrmlPrsnt,
              pRmsLimits->dMrgnVarMisPrsnt,
              pRmsLimits->dAmtUntilizedPrsnt,
              pRmsLimits->dCncMrgnVarPrsnt,
              pRmsLimits->dMarginUsedPrsnt,
              pRmsLimits->dAuxRmsCollateral,
              pRmsLimits->dAuxAdhocMargin,
              pRmsLimits->dAuxNotionalCash,
              pRmsLimits->dAvailableMargin,
              pRmsLimits->dBrokerage,
              pRmsLimits->dMrgnProtection,
              pRmsLimits->dFoPremium,
              pRmsLimits->dCurPremium,
              pRmsLimits->dComPremium,
              pRmsLimits->dMtomCurrentPerc,
              pRmsLimits->dMarginCurrentPerc,
              pRmsLimits->dLiquidCashCollateral,
              pRmsLimits->dMfCollateral,
              pRmsLimits->dMfCashCollateral,
              pRmsLimits->dAddMrgnPrsnt,
              pRmsLimits->dTenderMrgnPrsnt,
              pRmsLimits->dDeliveryMrgnPrsnt,
              pRmsLimits->dBrokerageCnc,
              pRmsLimits->dBrokerageMis,
              pRmsLimits->dBrokerageNrml,
              pRmsLimits->dBrokerageCO,
              pRmsLimits->dBrokerageBO,
              pRmsLimits->dFoBrokerageMis,
              pRmsLimits->dFoBrokerageNrml,
              pRmsLimits->dFoBrokerageCO,
              pRmsLimits->dFoBrokerageBO,
              pRmsLimits->dCurBrokerageMis,
              pRmsLimits->dCurBrokerageNrml,
              pRmsLimits->dCurBrokerageCO,
              pRmsLimits->dCurBrokerageBO,
              pRmsLimits->dComBrokerageMis,
              pRmsLimits->dComBrokerageNrml,
              pRmsLimits->dComBrokerageCO,
              pRmsLimits->dComBrokerageBO,
              pRmsLimits->dMrgnProtectionCO,
              pRmsLimits->dMrgnProtectionBO,
              pRmsLimits->dFoMrgnProtectionCO,
              pRmsLimits->dFoMrgnProtectionBO,
              pRmsLimits->dCurMrgnProtectionCO,
              pRmsLimits->dCurMrgnProtectionBO,
              pRmsLimits->dComMrgnProtectionCO,
              pRmsLimits->dComMrgnProtectionBO,
              pRmsLimits->dComPremiumMisPrsnt,
              pRmsLimits->dComPremiumNrmlPrsnt,
              pRmsLimits->dExchMrgn,
              pRmsLimits->dFoExchMrgn,
              pRmsLimits->dCurExchMrgn,
              pRmsLimits->dComExchMrgn,
              pRmsLimits->dExchMrgnSellCrd,
              pRmsLimits->dExchMrgnT1SellCrd,
              pRmsLimits->dAlloc,
              pRmsLimits->dFoAlloc,
              pRmsLimits->dCurAlloc,
              pRmsLimits->dComAlloc,
              pRmsLimits->dBlockAmt,
              pRmsLimits->dMtfLimit,
              pRmsLimits->dSlbmLimit,
              pRmsLimits->dRemarksAmt);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetAllRmsLimitsEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllRmsLimitsEnd EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::ChangePasswordResponse(char *pText,
                                              int iPwdStatus,
                                              void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ChangePasswordResponse EchoBackData: %s | PwdStatus :%d | pText: %s |",
              (char *)pEchoBackData,
              iPwdStatus,
              pText);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::AfterMktOrderResponse(void *pEchoBackData,
                                             char *pNorenOrd,
                                             char *pGuiOrdId,
                                             char *pReqStatus,
                                             char *pRejReason,
                                             char *pExternalRemarks,
                                             char *pUser)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AfterMktOrderResponse EchoBackData: %s| NorenOrd : %s | GuiOrderID : %s |"
                                      "pReqStatus: %s | pRejReason : %s | pExternalRemarks : %s | User : %s |",
              (char *)pEchoBackData,
              pNorenOrd,
              pGuiOrdId,
              pReqStatus,
              pRejReason,
              pExternalRemarks,
              pUser);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::AfterMktModifyOrderResponse(void *pEchoBackData,
                                                   char *pNorenOrd,
                                                   char *pGuiOrdId,
                                                   char *pReqStatus,
                                                   char *pRejReason,
                                                   char *pExternalRemarks,
                                                   char *pUser)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AfterMktModifyOrderResponse  EchoBackData: %s | NorenOrd :%s | GuiOrderID :%s | pReqStatus :%s |"
                                      " pRejReason :%s | pExternalRemarks :%s | User :%s|",
              (char *)pEchoBackData,
              pNorenOrd,
              pGuiOrdId,
              pReqStatus,
              pRejReason,
              pExternalRemarks,
              pUser);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::AfterMktMultiLegOrderResponse(void *pEchoBackData,
                                                     char *pNorenOrd,
                                                     char *pGuiOrdId,
                                                     char *pReqStatus,
                                                     char *pRejReason,
                                                     char *pExternalRemarks,
                                                     char *pUser)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AfterMktMultiLegOrderResponse  EchoBackData: %s | NorenOrd :%s | GuiOrderID :%s | pReqStatus :%s |  pRejReason :%s | pExternalRemarks :%s | User :%s |",
              (char *)pEchoBackData,
              pNorenOrd,
              pGuiOrdId,
              pReqStatus,
              pRejReason,
              pExternalRemarks,
              pUser);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetIndexNamesStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetIndexNamesStart  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetIndexName(tsIndexName *pIndexName,
                                    void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetIndexName  EchoBackData: %s | ExchSeg:%s |\n",
              (char *)pEchoBackData,
              pIndexName->pExchSeg);
     logString += buffer;
     logString += " IndexName:\n";
     for (int i = 0; i < pIndexName->iIndexNameSize; i++)
     {
          snprintf(buffer, sizeof(buffer), "%s\n",
                   pIndexName->ppIndexName[i]);
          logString += buffer;
     }
     logString += " IndexToken:\n";

     for (int i = 0; i < pIndexName->iIndexTokenSize; i++)
     {
          snprintf(buffer, sizeof(buffer), "%s\n", pIndexName->ppIndexToken[i]);
          logString += buffer;
     }
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetIndexNamesEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     logString += "GetIndexNamesEnd ";
     snprintf(buffer, sizeof(buffer), "EchoBackData :%s",
              (char *)pEchoBackData);
     logString += buffer;
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetProductListStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetProductListStart EchoBackData :%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetProductList(void *pEchoBackData,
                                      char *pExchSeg,
                                      char *pProduct)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetProductList  EchoBackData: %s | ExchSeg :%s | Product :%s |",
              (char *)pEchoBackData,
              pExchSeg,
              pProduct);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetProductListEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetProductListEnd  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetUserProfileStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetUserProfileStart  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::SendUserProfile(tsUserProfile *pUserProfile,
                                       void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "SendUserProfile  EchoBackData: %s | EmailAddress: %s | CellAddress :%s | AccountName :%s | AccountId :%s |"
                                      " ExchSeg: %s | Product: %s | OrderType :%s | Broker: %s | Pan: %s | ResidencePhone: %s | StatusIndicator: %s | OfficePhone: %s |"
                                      " OfficeAddress: %s | BankId: %s | Address: %s | DpId: %s | DpName: %s | Depository:%s |",
              (char *)pEchoBackData,
              pUserProfile->pEmailAddress,
              pUserProfile->pCellAddress,
              pUserProfile->pAccountName,
              pUserProfile->pAccountId,
              pUserProfile->pExchSeg,
              pUserProfile->pProduct,
              pUserProfile->pOrderType,
              pUserProfile->pBroker,
              pUserProfile->pPan,
              pUserProfile->pResidencePhone,
              pUserProfile->pStatusIndicator,
              pUserProfile->pOfficephone,
              pUserProfile->pOfficeAddress,
              pUserProfile->pBankId,
              pUserProfile->pAddress,
              pUserProfile->pDpId,
              pUserProfile->pDpName,
              pUserProfile->pDepository);
     logString += buffer;
     if (pUserProfile->pBankName)
     {
          snprintf(buffer, sizeof(buffer), " BankName :%s | BankAcctNo :%s | BankBranchName :%s | pBankIFSCcode :%s |",
                   pUserProfile->pBankName,
                   pUserProfile->pBankAcctNo,
                   pUserProfile->pBankBranchName,
                   pUserProfile->pBankIFSCcode);
          logString += buffer;
     }
     if (pUserProfile->pBankName2)
     {
          snprintf(buffer, sizeof(buffer), " BankName2 :%s | BankAcctNo2 :%s | BankBranchName2 :%s | pBankIFSCcode2 :%s |",
                   pUserProfile->pBankName2,
                   pUserProfile->pBankAcctNo2,
                   pUserProfile->pBankBranchName2,
                   pUserProfile->pBankIFSCcode2);
          logString += buffer;
     }
     if (pUserProfile->pBankName3)
     {
          snprintf(buffer, sizeof(buffer), " BankName3 :%s | BankAcctNo3 :%s | BankBranchName3 :%s | pBankIFSCcode3 :%s |",
                   pUserProfile->pBankName3,
                   pUserProfile->pBankAcctNo3,
                   pUserProfile->pBankBranchName3,
                   pUserProfile->pBankIFSCcode3);
          logString += buffer;
     }
     if (pUserProfile->pBankName4)
     {
          snprintf(buffer, sizeof(buffer), "  BankName4 :%s | BankAcctNo4: %s | BankBranchName4: %s | pBankIFSCcode4: %s |",
                   pUserProfile->pBankName4,
                   pUserProfile->pBankAcctNo4,
                   pUserProfile->pBankBranchName4,
                   pUserProfile->pBankIFSCcode4);
          logString += buffer;
     }
     if (pUserProfile->pBankName5)
     {
          snprintf(buffer, sizeof(buffer), " BankName5 :%s | BankAcctNo5: %s | BankBranchName5: %s | pBankIFSCcode5: %s |",
                   pUserProfile->pBankName5,
                   pUserProfile->pBankAcctNo5,
                   pUserProfile->pBankBranchName5,
                   pUserProfile->pBankIFSCcode5);
          logString += buffer;
     }
     if (pUserProfile->pBankName6)
     {
          snprintf(buffer, sizeof(buffer), " BankName6 :%s | BankAcctNo6 :%s | BankBranchName6 :%s | pBankIFSCcode6 :%s |",
                   pUserProfile->pBankName6,
                   pUserProfile->pBankAcctNo6,
                   pUserProfile->pBankBranchName6,
                   pUserProfile->pBankIFSCcode6);
          logString += buffer;
     }
     snprintf(buffer, sizeof(buffer), " DpAcctNo :%s \n",
              pUserProfile->pDpAcctNo);
     logString += buffer;
     snprintf(buffer, sizeof(buffer), " DpAcctNo2 :%s\n",
              pUserProfile->pDpAcctNo2);
     logString += buffer;
     snprintf(buffer, sizeof(buffer), " DpAcctNo3 :%s\n",
              pUserProfile->pDpAcctNo3);
     logString += buffer;
     std::clog << logString << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetUserProfileEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetUserProfileEnd  EchoBackData:%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::SecurityInfoStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "SecurityInfoStart EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::SendSecurityInfo(tsSecurityInfo *pSecurityInfo,
                                        void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "SendSecurityInfo EchoBackData :%s | Symbol :%s | Exchange :%s | ExchSeg :%s |"
                                      " Group: %s | InstName :%s | ExpiryDate: %s | IssueDate :%s | MaturityDate :%s | ListingDate :%s |"
                                      " NoDelStartDate :%s | NoDelEndDate: %s | BookClsStartDate: %s | BookClsEndDate: %s | RecordDate: %s |"
                                      " ReAdminDate :%s | ExpulsionDate :%s | LocalUpdateTime: %s | DeliveryUnits: %s | PriceUnits: %s |"
                                      " LastTradingDate:%s | TenderPeridEndDate: %ld | TenderPeridStartDate: %ld | SellVarMargin: %s |"
                                      " BuyVarMargin: :%s | InstrumentInfo: %s | RemarksText: %s | CreditRating: %s | Segment: %s |"
                                      " Nav: %s | MfAmt:%s | SipSecurity: %s | Isin: %s | FaceValue: %s | TrdUnits: %s | ExerciseStartDate:%s |"
                                      " ExerciseEndDate:%s | ElmMargin: %s | VarMargin:%s | TotProposedLimitValue: :%s | ScripBasePrice: %s |"
                                      " CombinedSymbol:%s | SettlementType: %s | PermittedToTrade: %d |  BoardLotQty: %d | MaxOrderSize:%d | OpenInterest:%f |"
                                      " HighPriceRange: %f | LowPriceRange: %f | PriceNum: %f | GenDen: %f | GenNum: %f | PriceQuatation:%f | Issuerate: :%f |"
                                      " PriceDen:%f | TickSize: %f | WarningQty: %f | IssueCapital: %f | ExposureMargin: %f | MinRedemptionQty: %f | FreezeQty: %ld |"
                                      " SymbolName: %s| TrdSymbol:%s | OptionType: %s | ScripRefKey: %s | AssetCode:%s | SubGroup: %s | Desc: %s | AmcCode: %s |"
                                      "ContractId:%s | LotSize:%ld | ExpiryDate:%ld | Precision: %ld | StrikePrice: %f | OrdMsg: %s | dPrevOi:%f | dTotalOi: %f |",
              (char *)pEchoBackData,
              pSecurityInfo->pSymbol,
              pSecurityInfo->pExchange,
              pSecurityInfo->pExchSeg,
              pSecurityInfo->pGroup,
              pSecurityInfo->pInstName,
              pSecurityInfo->pExpiryDate,
              pSecurityInfo->pIssueDate,
              pSecurityInfo->pMaturityDate,
              pSecurityInfo->pListingDate,
              pSecurityInfo->pNoDelStartDate,
              pSecurityInfo->pNoDelEndDate,
              pSecurityInfo->pBookClsStartDate,
              pSecurityInfo->pBookClsEndDate,
              pSecurityInfo->pRecordDate,
              pSecurityInfo->pReAdminDate,
              pSecurityInfo->pExpulsionDate,
              pSecurityInfo->pLocalUpdateTime,
              pSecurityInfo->pDeliveryUnits,
              pSecurityInfo->pPriceUnits,
              pSecurityInfo->pLastTradingDate,
              pSecurityInfo->lTenderPeridEndDate,
              pSecurityInfo->lTenderPeridStartDate,
              pSecurityInfo->pSellVarMargin,
              pSecurityInfo->pBuyVarMargin,
              pSecurityInfo->pInstrumentInfo,
              pSecurityInfo->pRemarksText,
              pSecurityInfo->pCreditRating,
              pSecurityInfo->pSegment,
              pSecurityInfo->pNav,
              pSecurityInfo->pMfAmt,
              pSecurityInfo->pSipSecurity,
              pSecurityInfo->pIsin,
              pSecurityInfo->pFaceValue,
              pSecurityInfo->pTrdUnits,
              pSecurityInfo->pExerciseStartDate,
              pSecurityInfo->pExerciseEndDate,
              pSecurityInfo->pElmMargin,
              pSecurityInfo->pVarMargin,
              pSecurityInfo->pTotProposedLimitValue,
              pSecurityInfo->pScripBasePrice,
              pSecurityInfo->pCombinedSymbol,
              pSecurityInfo->pSettlementType,
              pSecurityInfo->iPermittedToTrade,
              pSecurityInfo->iBoardLotQty,
              pSecurityInfo->iMaxOrderSize,
              pSecurityInfo->dOpenInterest,
              pSecurityInfo->dHighPriceRange,
              pSecurityInfo->dLowPriceRange,
              pSecurityInfo->dPriceNum,
              pSecurityInfo->dGenDen,
              pSecurityInfo->dGenNum,
              pSecurityInfo->dPriceQuatation,
              pSecurityInfo->dIssuerate,
              pSecurityInfo->dPriceDen,
              pSecurityInfo->dTickSize,
              pSecurityInfo->dWarningQty,
              pSecurityInfo->dIssueCapital,
              pSecurityInfo->dExposureMargin,
              pSecurityInfo->dMinRedemptionQty,
              pSecurityInfo->lFreezeQty,
              pSecurityInfo->pSymbolName,
              pSecurityInfo->pTrdSymbol,
              pSecurityInfo->pOptionType,
              pSecurityInfo->pScripRefKey,
              pSecurityInfo->pAssetCode,
              pSecurityInfo->pSubGroup,
              pSecurityInfo->pDesc,
              pSecurityInfo->pAmcCode,
              pSecurityInfo->pContractId,
              pSecurityInfo->lLotSize,
              pSecurityInfo->lExpiryDate,
              pSecurityInfo->lPrecision,
              pSecurityInfo->dStrikePrice,
              pSecurityInfo->pOrdMsg,
              pSecurityInfo->dPrevOi,
              pSecurityInfo->dTotalOi);
     logString += buffer;
     if (pSecurityInfo->pUnderlyingSymbol)
     {
          snprintf(buffer, sizeof(buffer), " UnderlyingSymbol:%s | UnderlyingExchSeg: %s |",
                   pSecurityInfo->pUnderlyingSymbol,
                   pSecurityInfo->pUnderlyingExchSeg);
          logString += buffer;
     }
     if (pSecurityInfo->lExcLowRange)
     {
          snprintf(buffer, sizeof(buffer), "ExchangeLowRange:%ld |", pSecurityInfo->lExcLowRange);
          logString += buffer;
     }
     if (pSecurityInfo->lExcHighRange)
     {
          snprintf(buffer, sizeof(buffer), "ExchangeHighRange:%ld |", pSecurityInfo->lExcHighRange);
          logString += buffer;
     }
     snprintf(buffer, sizeof(buffer), " PriceMultiplier:%f\n", pSecurityInfo->dPriceMultiplier);
     logString += buffer;
     std::clog << logString << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::SecurityInfoEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "SecurityInfoEnd  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::OrderHistoryStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OrderHistoryStart  EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::OrderHistory(void *pEchoBackData,
                                    tsOrderHistory *pOrderHistory)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), " OrderHistory:1st :EchoBackData: %s | Exch :%s | Act Id :%s | Ord Duration :%s | CustomFirm :%s |"
                                      " Product :%s | Ord Type :%s | Trd Symbol :%s | Trans Type :%s | acGuiOrdId :%s | Token :%s | Price :%.2f | TriggerPrice :%.2e |"
                                      " Quantity :%ld | DiscQuantity :%ld | CancelledSize :%ld | User:%s | acVendorCode:%s | acOrdSrc:%s | acOrdRemarks:%s | ExternalRemarks :%s |"
                                      " AlgoName :%s | AlgoId :%s | AlgoCategory :%s | Pan:%s | FilledShares :%ld | UnfilledSize :%ld | AvgPrice :%.2e | ExchOrdId :%s | Text :%s |"
                                      " ExchTime :%s | ExchTimeNanoSec :%ld | acNorenUpdateTime :%s | lNorenUpdateTimeNanoSec:%ld | acOrgExchTime :%s | RejectionBy :%s |"
                                      " Rejection Reason :%s | OrderGenType :%s | NorenOrdNum :%s | acNorenTimeSec :%s | acNorenTimeMiliSec :%s | lNorenTimeNanoSec :%ld |"
                                      " acReqId :%s | acOrdStatus :%s | cStatus:%c | acReportType:%s | cRepTyp:%c | dRmsPrice :%.2e | BasketId :%ld | InstName:%s | OptionType:%s |"
                                      " StrikePrice :%s | ExpiryDate :%s | FillId :%s | Symbol:%s | FillTime :%s |",
              (char *)pEchoBackData,
              pOrderHistory->sOrderUpdate.sOrderParams.acExchSeg,
              pOrderHistory->sOrderUpdate.sOrderParams.acAccountId,
              pOrderHistory->sOrderUpdate.sOrderParams.acOrdDuration,
              pOrderHistory->sOrderUpdate.sOrderParams.acCustomerFirm,
              pOrderHistory->sOrderUpdate.sOrderParams.acProduct,
              pOrderHistory->sOrderUpdate.sOrderParams.acOrderType,
              pOrderHistory->sOrderUpdate.sOrderParams.acTrdSymbol,
              pOrderHistory->sOrderUpdate.sOrderParams.acTransType,
              pOrderHistory->sOrderUpdate.sOrderParams.acGuiOrdId,
              pOrderHistory->sOrderUpdate.sOrderParams.acToken,
              pOrderHistory->sOrderUpdate.sOrderParams.dPrice,
              pOrderHistory->sOrderUpdate.sOrderParams.dTriggerPrice,
              pOrderHistory->sOrderUpdate.sOrderParams.lQuantity,
              pOrderHistory->sOrderUpdate.sOrderParams.lDiscQuantity,
              pOrderHistory->sOrderUpdate.sOrderParams.lCancelledSize,
              pOrderHistory->sOrderUpdate.sOrderParams.acUser,
              pOrderHistory->sOrderUpdate.sOrderParams.acVendorCode,
              pOrderHistory->sOrderUpdate.sOrderParams.acOrdSrc,
              pOrderHistory->sOrderUpdate.sOrderParams.acOrdRemarks,
              pOrderHistory->sOrderUpdate.sOrderParams.acExternalRemarks,
              pOrderHistory->sOrderUpdate.sOrderParams.acAlgoName,
              pOrderHistory->sOrderUpdate.sOrderParams.acAlgoId,
              pOrderHistory->sOrderUpdate.sOrderParams.acAlgoCategory,
              pOrderHistory->sOrderUpdate.acPan,
              pOrderHistory->sOrderUpdate.lFilledShares,
              pOrderHistory->sOrderUpdate.lUnfilledSize,
              pOrderHistory->sOrderUpdate.dAvgPrice,
              pOrderHistory->sOrderUpdate.acExchOrdId,
              pOrderHistory->sOrderUpdate.acText,
              pOrderHistory->sOrderUpdate.acExchTime,
              pOrderHistory->sOrderUpdate.lExchTimeNanoSec,
              pOrderHistory->sOrderUpdate.acNorenUpdateTime,
              pOrderHistory->sOrderUpdate.lNorenUpdateTimeNanoSec,
              pOrderHistory->sOrderUpdate.acOrgExchTime,
              pOrderHistory->sOrderUpdate.acRejectionBy,
              pOrderHistory->sOrderUpdate.acRejReason,
              pOrderHistory->sOrderUpdate.acOrderGenType,
              pOrderHistory->sOrderUpdate.acNorenOrdNum,
              pOrderHistory->sOrderUpdate.acNorenTimeSec,
              pOrderHistory->sOrderUpdate.acNorenTimeMiliSec,
              pOrderHistory->sOrderUpdate.lNorenTimeNanoSec,
              pOrderHistory->sOrderUpdate.acReqId,
              pOrderHistory->sOrderUpdate.acOrdStatus,
              pOrderHistory->sOrderUpdate.cStatus,
              pOrderHistory->sOrderUpdate.acReportType,
              pOrderHistory->sOrderUpdate.cRepTyp,
              pOrderHistory->sOrderUpdate.dRmsPrice,
              pOrderHistory->sOrderUpdate.lBasketId,
              pOrderHistory->acInstName,
              pOrderHistory->acOptionType,
              pOrderHistory->acStrikePrice,
              pOrderHistory->acExpiryDate,
              pOrderHistory->acFillId,
              pOrderHistory->acSymbol,
              pOrderHistory->acFillTime);
     logString += buffer;
     if (pOrderHistory->sOrderUpdate.sOrderParams.acIpAddr)
     {
          snprintf(buffer, sizeof(buffer), " IpAddr :%s |",
                   pOrderHistory->sOrderUpdate.sOrderParams.acIpAddr);
          logString += buffer;
     }
     if (pOrderHistory->sOrderUpdate.sOrderParams.acChannel)
     {
          snprintf(buffer, sizeof(buffer), "  acChannel :%s |",
                   pOrderHistory->sOrderUpdate.sOrderParams.acChannel);
          logString += buffer;
     }
     if (pOrderHistory->sOrderUpdate.sOrderParams.acUserAgent)
     {
          snprintf(buffer, sizeof(buffer), " acUserAgent :%s |",
                   pOrderHistory->sOrderUpdate.sOrderParams.acUserAgent);
          logString += buffer;
     }
     if (pOrderHistory->sOrderUpdate.sOrderParams.acAppInstallId)
     {
          snprintf(buffer, sizeof(buffer), "acAppInstallId :%s |",
                   pOrderHistory->sOrderUpdate.sOrderParams.acAppInstallId);
          logString += buffer;
     }
     logString += '\n';

     if (pOrderHistory->sMultiLegUpdate.siLeg == 2)
     {
          snprintf(buffer, sizeof(buffer), " TrdSymbol_Leg2 :%s | TransType_Leg2 :%s | Token_Leg2 :%s | Price_Leg2 :%.2f |"
                                           " Quantity_Leg2 :%ld | DiscQuantity_Leg2 :%ld | AvgPrice_Leg2 :%.2f | FilledShares_Leg2:%ld |"
                                           " UnfilledSize_Leg2 :%ld |\n",
                   pOrderHistory->sMultiLegUpdate.sMultiLegParams.acTrdSymbol_Leg2,
                   pOrderHistory->sMultiLegUpdate.sMultiLegParams.acTransType_Leg2,
                   pOrderHistory->sMultiLegUpdate.sMultiLegParams.acToken_Leg2,
                   pOrderHistory->sMultiLegUpdate.sMultiLegParams.dPrice_Leg2,
                   pOrderHistory->sMultiLegUpdate.sMultiLegParams.lQuantity_Leg2,
                   pOrderHistory->sMultiLegUpdate.sMultiLegParams.lDiscQuantity_Leg2,
                   pOrderHistory->sMultiLegUpdate.dAvgPrice_Leg2,
                   pOrderHistory->sMultiLegUpdate.lFilledShares_Leg2,
                   pOrderHistory->sMultiLegUpdate.lUnfilledSize_Leg2);

          logString += buffer;

          if (pOrderHistory->sOrderUpdate.sOrderParams.acSpreadTrdSymbol)
          {
               snprintf(buffer, sizeof(buffer), "acSpreadTrdSymbol :%s", pOrderHistory->sOrderUpdate.sOrderParams.acSpreadTrdSymbol);
               logString += buffer;
          }

          if (pOrderHistory->sOrderUpdate.sOrderParams.acSpreadToken)
          {

               snprintf(buffer, sizeof(buffer), "acSpreadToken :%s", pOrderHistory->sOrderUpdate.sOrderParams.acSpreadToken);
               logString += buffer;
          }
     }
     else if (pOrderHistory->sMultiLegUpdate.siLeg == 3)
     {
          snprintf(buffer, sizeof(buffer), " TrdSymbol_Leg2 :%s | TrdSymbol_Leg3 :%s | TransType_Leg2 :%s |"
                                           " TransType_Leg3 :%s | Token_Leg2 :%s | Token_Leg3 :%s | Price_Leg2 :%.2f | Price_Leg3 :%.2f | Quantity_Leg2:%ld |"
                                           " Quantity_Leg3:%ld | DiscQuantity_Leg2:%ld | DiscQuantity_Leg3:%ld | AvgPrice_Leg2 :%.2f | AvgPrice_Leg3:%.2f |"
                                           " FilledShares_Leg2 :%ld | FilledShares_Leg3 :%ld | UnfilledSize_Leg2 :%ld | UnfilledSize_Leg3:%ld\n",
                   pOrderHistory->sMultiLegUpdate.sMultiLegParams.acTrdSymbol_Leg2,
                   pOrderHistory->sMultiLegUpdate.sMultiLegParams.acTrdSymbol_Leg3,
                   pOrderHistory->sMultiLegUpdate.sMultiLegParams.acTransType_Leg2,
                   pOrderHistory->sMultiLegUpdate.sMultiLegParams.acTransType_Leg3,
                   pOrderHistory->sMultiLegUpdate.sMultiLegParams.acToken_Leg2,
                   pOrderHistory->sMultiLegUpdate.sMultiLegParams.acToken_Leg3,
                   pOrderHistory->sMultiLegUpdate.sMultiLegParams.dPrice_Leg2,
                   pOrderHistory->sMultiLegUpdate.sMultiLegParams.dPrice_Leg3,
                   pOrderHistory->sMultiLegUpdate.sMultiLegParams.lQuantity_Leg2,
                   pOrderHistory->sMultiLegUpdate.sMultiLegParams.lQuantity_Leg3,
                   pOrderHistory->sMultiLegUpdate.sMultiLegParams.lDiscQuantity_Leg2,
                   pOrderHistory->sMultiLegUpdate.sMultiLegParams.lDiscQuantity_Leg3,
                   pOrderHistory->sMultiLegUpdate.dAvgPrice_Leg2,
                   pOrderHistory->sMultiLegUpdate.dAvgPrice_Leg3,
                   pOrderHistory->sMultiLegUpdate.lFilledShares_Leg2,
                   pOrderHistory->sMultiLegUpdate.lFilledShares_Leg3,
                   pOrderHistory->sMultiLegUpdate.lUnfilledSize_Leg2,
                   pOrderHistory->sMultiLegUpdate.lUnfilledSize_Leg3);
          logString += buffer;
     }
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::OrderHistoryEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OrderHistoryEnd EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::ViewHoldingsStart(void *pEchoBackData,
                                         char *pAccountId)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ViewHoldingsStart EchoBackData:%s | AccountId :%s |",
              (char *)pEchoBackData,
              pAccountId);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::ViewHoldings(void *pEchoBackData,
                                    tsViewHoldings *pViewHoldings)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ViewHoldings EchoBackData: %s|\n", (char *)pEchoBackData);
     logString += buffer;

     if (pViewHoldings->pExchSeg1)
     {
          snprintf(buffer, sizeof(buffer), "pExchSeg1: %s|", pViewHoldings->pExchSeg1);
          logString += buffer;
     }
     if (pViewHoldings->pExchSeg2)
     {
          snprintf(buffer, sizeof(buffer), "pExchSeg2: %s|", pViewHoldings->pExchSeg2);
          logString += buffer;
     }
     if (pViewHoldings->pExchSeg3)
     {
          snprintf(buffer, sizeof(buffer), "pExchSeg3: %s|", pViewHoldings->pExchSeg3);
          logString += buffer;
     }
     if (pViewHoldings->pToken1)
     {
          snprintf(buffer, sizeof(buffer), "Token1: %s|", pViewHoldings->pToken1);
          logString += buffer;
     }
     if (pViewHoldings->pToken2)
     {
          snprintf(buffer, sizeof(buffer), "Token2: %s|", pViewHoldings->pToken2);
          logString += buffer;
     }
     if (pViewHoldings->pToken3)
     {
          snprintf(buffer, sizeof(buffer), " Token3:  %s|", pViewHoldings->pToken3);
          logString += buffer;
     }
     if (pViewHoldings->acInterOPKey)
     {
          snprintf(buffer, sizeof(buffer), " acInterOPKey: %s|", pViewHoldings->acInterOPKey);
          logString += buffer;
     }

     if (pViewHoldings->acInterOPExchSeg)
     {
          snprintf(buffer, sizeof(buffer), " acInterOPExchSeg: %s|", pViewHoldings->acInterOPExchSeg);
          logString += buffer;
     }
     snprintf(buffer, sizeof(buffer), " AccountId: %s | Product: %s | CollateralType: %s | ClosePrice: %f | UploadPrice:%f | dT1UploadPrice: %f |"
                                      " HairCut: %f | CollateralQty: %f | dCollUpdateQty:%f | dHoldUpdateQty:%f | dWithheldHoldQty: %f | dQty: %f | UsedQty: %f |"
                                      " T1Qty: %f | dNpoaQty: %f | dT1NpoaQty:%f | dUnplgdQty:%f | dEQTCollUpdateQty: %f | dCOMCollUpdateQty: :%f | dBrokerHairCut:%f |"
                                      " bIsCollateral: %d |",
              pViewHoldings->pAccountId,
              pViewHoldings->pProduct,
              pViewHoldings->pCollateralType,
              pViewHoldings->dClosePrice,
              pViewHoldings->dUploadPrice,
              pViewHoldings->dT1UploadPrice,
              pViewHoldings->dHairCut,
              pViewHoldings->dCollateralQty,
              pViewHoldings->dCollUpdateQty,
              pViewHoldings->dHoldUpdateQty,
              pViewHoldings->dWithheldHoldQty,
              pViewHoldings->dQty,
              pViewHoldings->dUsedQty,
              pViewHoldings->dT1Qty,
              pViewHoldings->dNpoaQty,
              pViewHoldings->dT1NpoaQty,
              pViewHoldings->dUnplgdQty,
              pViewHoldings->dEQTCollUpdateQty,
              pViewHoldings->dCOMCollUpdateQty,
              pViewHoldings->dBrokerHairCut,
              pViewHoldings->bIsCollateral);
     logString += buffer;
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::ViewHoldingsEnd(void *pEchoBackData,
                                       char *pAccountId)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), " ViewHoldingsEnd EchoBackData: %s | AccountId :%s |",
              (char *)pEchoBackData,
              pAccountId);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetTopnKeysStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetTopnKeysStart  EchoBackData: %s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::SendTopnKeys(void *pEchoBackData,
                                    char *pTopnCriteria,
                                    char *pTopnBasket)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "SendTopnKeys EchoBackData: %s | TopnCriteria: %s | TopnBasket: %s|",
              (char *)pEchoBackData,
              pTopnCriteria,
              pTopnBasket);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetTopnKeysEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetTopnKeysEnd  EchoBackData: %s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetTopnValuesStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetTopnValuesStart EchoBackData:%s ", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::SendTopnValues(void *pEchoBackData,
                                      tsTopnValues *pTopnValues)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "SendTopnValues EchoBackData:%s | TopnCriteria :%s|\n TopnBasket :%s|\n ExchSeg :%s|\n SymbolTopn1 :%s|\n SymbolTopn2 :%s|\n"
                                      "SymbolTopn3 :%s|\nSymbolTopn4 :%s|\n SymbolTopn5 :%s|\n SymbolTopn6 :%s|\n SymbolTopn7 :%s|\n SymbolTopn8 :%s|\n SymbolTopn9 :%s|\nSymbolTopn10 :%s|\n"
                                      "SymbolBotn1:%s|\n SymbolBotn2 :%s|\n  SymbolBotn3 :%s|\n  SymbolBotn4 :%s|\n  SymbolBotn5 :%s|\n SymbolBotn6 :%s|\n SymbolBotn7 :%s|\n SymbolBotn8 :%s|\n"
                                      "SymbolBotn9 :%s|\n SymbolBotn10 :%s|\n LTPTopn1 :%f|\n LTPTopn2 :%f|\n LTPTopn3 :%f|\n LTPTopn4 :%f|\n LTPTopn5 :%f|\n LTPTopn6 :%f|\n LTPTopn7 :%f|\n"
                                      "LTPTopn8 :%f|\n LTPTopn9 :%f|\n LTPTopn10 :%f|\n LTPBotn1 :%f|\n LTPBotn2 :%f|\n LTPBotn3 :%f|\n LTPBotn4 :%f|\n LTPBotn5 :%f|\n LTPBotn6 :%f|\n LTPBotn7 :%f|\n"
                                      "LTPBotn8 :%f|\n LTPBotn9:%f|\n LTPBotn10 :%f|\n PrevCloseTopn1 :%f|\n PrevCloseTopn2:%f|\n PrevCloseTopn3:%f|\n PrevCloseTopn4:%f|\n PrevCloseTopn5:%f|\n"
                                      "PrevCloseTopn6:%f|\n PrevCloseTopn7:%f|\n PrevCloseTopn8:%f|\n PrevCloseTopn9:%f|\n PrevCloseTopn10:%f|\n PrevCloseBotn1:%f|\n PrevCloseBotn2:%f|\n"
                                      "PrevCloseBotn3:%f|\n PrevCloseBotn4:%f|\n PrevCloseBotn5:%f|\n PrevCloseBotn6:%f|\n PrevCloseBotn7:%f|\n PrevCloseBotn8:%f|\n PrevCloseBotn9:%f|\n PrevCloseBotn10:%f|\n"
                                      "VolumeTopn1 :%f|\n VolumeTopn2 :%f|\n VolumeTopn3 :%f|\n VolumeTopn4 :%f|\n VolumeTopn5 :%f|\n VolumeTopn6 :%f|\n VolumeTopn7 :%f|\nVolumeTopn8 :%f|\n VolumeTopn9:%f |\n"
                                      "VolumeTopn10 :%f|\n VolumeBotn1:%f|\n VolumeBotn2:%f|\n VolumeBotn3:%f|\n VolumeBotn4:%f|\n VolumeBotn5:%f|\n VolumeBotn6:%f|\n VolumeBotn7:%f|\n VolumeBotn8:%f|\n VolumeBotn9:%f|\n "
                                      "VolumeBotn10:%f|\n OITopn1:%f|\n OITopn2:%f|\n OITopn3:%f OITopn4:%f|\n OITopn5:%f|\n OITopn6:%f|\n OITopn7:%f|\n OITopn8:%f|\n OITopn9:%f|\n OITopn10:%f|\n OIBotn1:%f|\n OIBotn2:%f|\n"
                                      "OIBotn3:%f|\n OIBotn4:%f|\n OIBotn5:%f|\n OIBotn6:%f|\n OIBotn7:%f|\n OIBotn8:%f|\n OIBotn9:%f|\n OIBotn10:%f|\n ValueTopn1:%f|\n  ValueTopn2:%f|\n  ValueTopn3:%f|\n  ValueTopn4:%f|\n "
                                      " ValueTopn5:%f|\n  ValueTopn6:%f|\n  ValueTopn7:%f|\n  ValueTopn8:%f|\n  ValueTopn9:%f|\n  ValueTopn10:%f|\n ValueBotn1:%f|\n  ValueBotn2:%f|\n  ValueBotn3:%f|\n ValueBotn4:%f|\n"
                                      " ValueBotn5:%f|\n ValueBotn6:%f|\n  ValueBotn7:%f|\n ValueBotn8:%f|\n ValueBotn9:%f|\n  ValueBotn10:%f|\n LTPChangePercTopn1:%f|\n LTPChangePercTopn2:%f|\n LTPChangePercTopn3:%f|\n"
                                      "LTPChangePercTopn4:%f|\n LTPChangePercTopn5:%f|\n LTPChangePercTopn6:%f|\n LTPChangePercTopn7:%f|\n LTPChangePercTopn8:%f|\n LTPChangePercTopn9:%f|\n LTPChangePercTopn10:%f|\n"
                                      "LTPChangePercBotn1:%f|\n LTPChangePercBotn2:%f|\n LTPChangePercBotn3:%f|\n LTPChangePercBotn4:%f|\n LTPChangePercBotn5:%f|\n LTPChangePercBotn6:%f|\n LTPChangePercBotn7:%f|\n"
                                      "LTPChangePercBotn8:%f|\n LTPChangePercBotn9:%f|\n LTPChangePercBotn10:%f|\n",
              (char *)pEchoBackData,
              pTopnValues->pTopnCriteria,
              pTopnValues->pTopnBasket,
              pTopnValues->pExchSeg,
              pTopnValues->pSymbolTopn1,
              pTopnValues->pSymbolTopn2,
              pTopnValues->pSymbolTopn3,
              pTopnValues->pSymbolTopn4,
              pTopnValues->pSymbolTopn5,
              pTopnValues->pSymbolTopn6,
              pTopnValues->pSymbolTopn7,
              pTopnValues->pSymbolTopn8,
              pTopnValues->pSymbolTopn9,
              pTopnValues->pSymbolTopn10,
              pTopnValues->pSymbolBotn1,
              pTopnValues->pSymbolBotn2,
              pTopnValues->pSymbolBotn3,
              pTopnValues->pSymbolBotn4,
              pTopnValues->pSymbolBotn5,
              pTopnValues->pSymbolBotn6,
              pTopnValues->pSymbolBotn7,
              pTopnValues->pSymbolBotn8,
              pTopnValues->pSymbolBotn9,
              pTopnValues->pSymbolBotn10,
              pTopnValues->dLTPTopn1,
              pTopnValues->dLTPTopn2,
              pTopnValues->dLTPTopn3,
              pTopnValues->dLTPTopn4,
              pTopnValues->dLTPTopn5,
              pTopnValues->dLTPTopn6,
              pTopnValues->dLTPTopn7,
              pTopnValues->dLTPTopn8,
              pTopnValues->dLTPTopn9,
              pTopnValues->dLTPTopn10,
              pTopnValues->dLTPBotn1,
              pTopnValues->dLTPBotn2,
              pTopnValues->dLTPBotn3,
              pTopnValues->dLTPBotn4,
              pTopnValues->dLTPBotn5,
              pTopnValues->dLTPBotn6,
              pTopnValues->dLTPBotn7,
              pTopnValues->dLTPBotn8,
              pTopnValues->dLTPBotn9,
              pTopnValues->dLTPBotn10,
              pTopnValues->dPrevCloseTopn1,
              pTopnValues->dPrevCloseTopn2,
              pTopnValues->dPrevCloseTopn3,
              pTopnValues->dPrevCloseTopn4,
              pTopnValues->dPrevCloseTopn5,
              pTopnValues->dPrevCloseTopn6,
              pTopnValues->dPrevCloseTopn7,
              pTopnValues->dPrevCloseTopn8,
              pTopnValues->dPrevCloseTopn9,
              pTopnValues->dPrevCloseTopn10,
              pTopnValues->dPrevCloseBotn1,
              pTopnValues->dPrevCloseBotn2,
              pTopnValues->dPrevCloseBotn3,
              pTopnValues->dPrevCloseBotn4,
              pTopnValues->dPrevCloseBotn5,
              pTopnValues->dPrevCloseBotn6,
              pTopnValues->dPrevCloseBotn7,
              pTopnValues->dPrevCloseBotn8,
              pTopnValues->dPrevCloseBotn9,
              pTopnValues->dPrevCloseBotn10,
              pTopnValues->dVolumeTopn1,
              pTopnValues->dVolumeTopn2,
              pTopnValues->dVolumeTopn3,
              pTopnValues->dVolumeTopn4,
              pTopnValues->dVolumeTopn5,
              pTopnValues->dVolumeTopn6,
              pTopnValues->dVolumeTopn7,
              pTopnValues->dVolumeTopn8,
              pTopnValues->dVolumeTopn9,
              pTopnValues->dVolumeTopn10,
              pTopnValues->dVolumeBotn1,
              pTopnValues->dVolumeBotn2,
              pTopnValues->dVolumeBotn3,
              pTopnValues->dVolumeBotn4,
              pTopnValues->dVolumeBotn5,
              pTopnValues->dVolumeBotn6,
              pTopnValues->dVolumeBotn7,
              pTopnValues->dVolumeBotn8,
              pTopnValues->dVolumeBotn9,
              pTopnValues->dVolumeBotn10,
              pTopnValues->dOITopn1,
              pTopnValues->dOITopn2,
              pTopnValues->dOITopn3,
              pTopnValues->dOITopn4,
              pTopnValues->dOITopn5,
              pTopnValues->dOITopn6,
              pTopnValues->dOITopn7,
              pTopnValues->dOITopn8,
              pTopnValues->dOITopn9,
              pTopnValues->dOITopn10,
              pTopnValues->dOIBotn1,
              pTopnValues->dOIBotn2,
              pTopnValues->dOIBotn3,
              pTopnValues->dOIBotn4,
              pTopnValues->dOIBotn5,
              pTopnValues->dOIBotn6,
              pTopnValues->dOIBotn7,
              pTopnValues->dOIBotn8,
              pTopnValues->dOIBotn9,
              pTopnValues->dOIBotn10,
              pTopnValues->dValueTopn1,
              pTopnValues->dValueTopn2,
              pTopnValues->dValueTopn3,
              pTopnValues->dValueTopn4,
              pTopnValues->dValueTopn5,
              pTopnValues->dValueTopn6,
              pTopnValues->dValueTopn7,
              pTopnValues->dValueTopn8,
              pTopnValues->dValueTopn9,
              pTopnValues->dValueTopn10,
              pTopnValues->dValueBotn1,
              pTopnValues->dValueBotn2,
              pTopnValues->dValueBotn3,
              pTopnValues->dValueBotn4,
              pTopnValues->dValueBotn5,
              pTopnValues->dValueBotn6,
              pTopnValues->dValueBotn7,
              pTopnValues->dValueBotn8,
              pTopnValues->dValueBotn9,
              pTopnValues->dValueBotn10,
              pTopnValues->dLTPChangePercTopn1,
              pTopnValues->dLTPChangePercTopn2,
              pTopnValues->dLTPChangePercTopn3,
              pTopnValues->dLTPChangePercTopn4,
              pTopnValues->dLTPChangePercTopn5,
              pTopnValues->dLTPChangePercTopn6,
              pTopnValues->dLTPChangePercTopn7,
              pTopnValues->dLTPChangePercTopn8,
              pTopnValues->dLTPChangePercTopn9,
              pTopnValues->dLTPChangePercTopn10,
              pTopnValues->dLTPChangePercBotn1,
              pTopnValues->dLTPChangePercBotn2,
              pTopnValues->dLTPChangePercBotn3,
              pTopnValues->dLTPChangePercBotn4,
              pTopnValues->dLTPChangePercBotn5,
              pTopnValues->dLTPChangePercBotn6,
              pTopnValues->dLTPChangePercBotn7,
              pTopnValues->dLTPChangePercBotn8,
              pTopnValues->dLTPChangePercBotn9,
              pTopnValues->dLTPChangePercBotn10);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetTopnValuesEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetTopnValuesEnd EchoBackData :%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetAllVwapDataStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllVwapDataStart EchoBackData :%s ",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetAllVwapData(void *pEchoBackData,
                                      long lStartTime,
                                      long lEndTime,
                                      tsVwapData *pVwapData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllVwapData EchoBackData :%s | StartTime :%ld | EndTime :%ld | Symbol :%s |"
                                      " ExchSeg :%s | DateTime :%ld | Price :%f | Open :%f | High :%f | Low :%f | Volume :%f |"
                                      " OpenInterest :%f | VwapCloseRate :%f | Vwap :%f | Periodicity :%d |",
              (char *)pEchoBackData,
              lStartTime,
              lEndTime,
              pVwapData->pSymbol,
              pVwapData->pExchSeg,
              pVwapData->lDateTime,
              pVwapData->dPrice,
              pVwapData->dOpen,
              pVwapData->dHigh,
              pVwapData->dLow,
              pVwapData->dVolume,
              pVwapData->dOpenInterest,
              pVwapData->dVwapCloseRate,
              pVwapData->dVwap,
              pVwapData->iPeriodicity);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetAllVwapDataEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllVwapDataEnd EchoBackData:%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetMarketDataStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetMarketDataStart EchoBackData: %s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int glbCountEnd = 1;
int CXXAPINorenClient::GetMarketDataEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetMarketDataEnd EchoBackData: %d\n", /*(char*)pEchoBackData*/ glbCountEnd++);
     std::clog << std::fixed << buffer;
     snprintf(buffer, sizeof(buffer), "pEchoBackData %s\n", (char *)pEchoBackData);

     std::clog << std::fixed << buffer;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetMarketData(tsMarketData *pMarketData,
                                     void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetMarketData EchoBackData: %s| ExchSeg:%s| Symbol:%s | TradeTime:%s | ExchFeedTime:%s | OpenPrice:%f |"
                                      " HighPrice:%f | LowPrice:%f | ClosePrice:%f | TradePrice:%f | PrevClose:%f | LowPriceRange:%f | HighPriceRange:%f | AvgPrice:%f |"
                                      " ImpVolCM :%f | ImpVolFO:%f | ImpVolBuyCM:%f | ImpVolBuyFO:%f | ImpVolSellCM:%f | ImpVolSellFO:%f | OpnInterest:%f | HiOpenInterest:%f |"
                                      " LowOpenInterest:%f | TradeVolume:%ld | TotBuyQuan:%ld | TotSellQuan:%ld | LastTradeQty:%ld | YearlyHigh:%ld | YearlyLow:%ld | dPrevOi:%f |"
                                      " dTotalOi:%f | acIssueDate:%s | acListingDate:%s | acNoDelStartDate:%s | acNoDelEndDate:%s | acBookClsStartDate:%s | acBookClsEndDate:%s |"
                                      " acRecordDate:%s | acCreditRating:%s | acReAdminDate:%s | acExpulsionDate:%s | acDeliveryUnits:%s | acDeliveryUnits:%s | acLastTradingDate:%s |"
                                      " lTenderPeridEndDate:%ld | lTenderPeridStartDate:%ld | acInstrumentInfo:%s | acRemarksText:%s | acNav:%s | acNavDate:%s | acTrdUnits:%s |"
                                      " acExerciseStartDate:%s | acExerciseEndDate:%s | acElmMargin:%s | acVarMargin:%s | acScripBasePrice:%s | acSettlementType:%s | dIssueCapital:%f |"
                                      " dExposureMargin:%f | lFreezeQty:%ld | acOrdMsg:%s |ExchangeLowRange :%ld | ExchangeHighRange :%ld |",
              (char *)pEchoBackData,
              pMarketData->acExchSeg,
              pMarketData->acSymbol,
              pMarketData->acTradeTime,
              pMarketData->acExchFeedTime,
              pMarketData->dOpenPrice,
              pMarketData->dHighPrice,
              pMarketData->dLowPrice,
              pMarketData->dClosePrice,
              pMarketData->dTradePrice,
              pMarketData->dPrevClose,
              pMarketData->dLowPriceRange,
              pMarketData->dHighPriceRange,
              pMarketData->dAvgPrice,
              pMarketData->dImpVolCM,
              pMarketData->dImpVolFO,
              pMarketData->dImpVolBuyCM,
              pMarketData->dImpVolBuyFO,
              pMarketData->dImpVolSellCM,
              pMarketData->dImpVolSellFO,
              pMarketData->dOpnInterest,
              pMarketData->dHiOpenInterest,
              pMarketData->dLowOpenInterest,
              pMarketData->lTradeVolume,
              pMarketData->lTotBuyQuan,
              pMarketData->lTotSellQuan,
              pMarketData->lLastTradeQty,
              pMarketData->lYearlyHigh,
              pMarketData->lYearlyLow,
              pMarketData->dPrevOi,
              pMarketData->dTotalOi,
              pMarketData->acIssueDate,
              pMarketData->acListingDate,
              pMarketData->acNoDelStartDate,
              pMarketData->acNoDelEndDate,
              pMarketData->acBookClsStartDate,
              pMarketData->acBookClsEndDate,
              pMarketData->acRecordDate,
              pMarketData->acCreditRating,
              pMarketData->acReAdminDate,
              pMarketData->acExpulsionDate,
              pMarketData->acDeliveryUnits,
              pMarketData->acPriceUnits,
              pMarketData->acLastTradingDate,
              pMarketData->lTenderPeridEndDate,
              pMarketData->lTenderPeridStartDate,
              pMarketData->acInstrumentInfo,
              pMarketData->acRemarksText,
              pMarketData->acNav,
              pMarketData->acNavDate,
              pMarketData->acTrdUnits,
              pMarketData->acExerciseStartDate,
              pMarketData->acExerciseEndDate,
              pMarketData->acElmMargin,
              pMarketData->acVarMargin,
              pMarketData->acScripBasePrice,
              pMarketData->acSettlementType,
              pMarketData->dIssueCapital,
              pMarketData->dExposureMargin,
              pMarketData->lFreezeQty,
              pMarketData->acOrdMsg,
              pMarketData->lExcLowRange,
              pMarketData->lExcHighRange);
     logString += buffer;
     if (pMarketData->iDepthSize == 5)
     {
          snprintf(buffer, sizeof(buffer),
                   "DepthSize :%d | BuyQty1 :%ld | BuyQty2 :%ld | BuyQty3 :%ld | BuyQty4 :%ld | BuyQty5 :%ld | "
                   "BuyPrice1 :%f | BuyPrice2 :%f | BuyPrice3 :%f | BuyPrice4 :%f | BuyPrice5 :%f | "
                   "BuyNoOfOrders1 :%ld | BuyNoOfOrders2 :%ld | BuyNoOfOrders3 :%ld | BuyNoOfOrders4 :%ld | BuyNoOfOrders5 :%ld | "
                   "SellQty1 :%ld | SellQty2 :%ld | SellQty3 :%ld | SellQty4 :%ld | SellQty5 :%ld | "
                   "SellPrice1 :%f | SellPrice2 :%f | SellPrice3 :%f | SellPrice4 :%f | SellPrice5 :%f | "
                   "SellNoOfOrders1 :%ld | SellNoOfOrders2 :%ld | SellNoOfOrders3 :%ld | SellNoOfOrders4 :%ld | SellNoOfOrders5 :%ld\n",
                   pMarketData->iDepthSize,
                   pMarketData->BestBuy[0].lQty,
                   pMarketData->BestBuy[1].lQty,
                   pMarketData->BestBuy[2].lQty,
                   pMarketData->BestBuy[3].lQty,
                   pMarketData->BestBuy[4].lQty,
                   pMarketData->BestBuy[0].dPrice,
                   pMarketData->BestBuy[1].dPrice,
                   pMarketData->BestBuy[2].dPrice,
                   pMarketData->BestBuy[3].dPrice,
                   pMarketData->BestBuy[4].dPrice,
                   pMarketData->BestBuy[0].lNoOfOrders,
                   pMarketData->BestBuy[1].lNoOfOrders,
                   pMarketData->BestBuy[2].lNoOfOrders,
                   pMarketData->BestBuy[3].lNoOfOrders,
                   pMarketData->BestBuy[4].lNoOfOrders,
                   pMarketData->BestSell[0].lQty,
                   pMarketData->BestSell[1].lQty,
                   pMarketData->BestSell[2].lQty,
                   pMarketData->BestSell[3].lQty,
                   pMarketData->BestSell[4].lQty,
                   pMarketData->BestSell[0].dPrice,
                   pMarketData->BestSell[1].dPrice,
                   pMarketData->BestSell[2].dPrice,
                   pMarketData->BestSell[3].dPrice,
                   pMarketData->BestSell[4].dPrice,
                   pMarketData->BestSell[0].lNoOfOrders,
                   pMarketData->BestSell[1].lNoOfOrders,
                   pMarketData->BestSell[2].lNoOfOrders,
                   pMarketData->BestSell[3].lNoOfOrders,
                   pMarketData->BestSell[4].lNoOfOrders);
          logString += buffer;
     }
     else if (pMarketData->iDepthSize == 20)
     {
          snprintf(buffer, sizeof(buffer), "DepthSize %d | BuyQty1 %ld | BuyQty2 %ld | BuyQty3 %ld | BuyQty4 %ld | BuyQty5 %ld | BuyQty6 %ld | BuyQty7 %ld | BuyQty8 %ld | BuyQty9 %ld | BuyQty10 %ld | "
                                           "BuyQty11 %ld | BuyQty12 %ld | BuyQty13 %ld | BuyQty14 %ld | BuyQty15 %ld | BuyQty16 %ld | BuyQty17 %ld | BuyQty18 %ld | BuyQty19 %ld | BuyQty20 %ld | "
                                           "BuyPrice1 %.2f | BuyPrice2 %.2f | BuyPrice3 %.2f | BuyPrice4 %.2f | BuyPrice5 %.2f | BuyPrice6 %.2f | BuyPrice7 %.2f | BuyPrice8 %.2f | BuyPrice9 %.2f | BuyPrice10 %.2f | "
                                           "BuyPrice11 %.2f | BuyPrice12 %.2f | BuyPrice13 %.2f | BuyPrice14 %.2f | BuyPrice15 %.2f | BuyPrice16 %.2f | BuyPrice17 %.2f | BuyPrice18 %.2f | BuyPrice19 %.2f | BuyPrice20 %.2f | "
                                           "BuyNoOfOrders1 %ld | BuyNoOfOrders2 %ld | BuyNoOfOrders3 %ld | BuyNoOfOrders4 %ld | BuyNoOfOrders5 %ld | BuyNoOfOrders6 %ld | BuyNoOfOrders7 %ld | BuyNoOfOrders8 %ld | BuyNoOfOrders9 %ld | BuyNoOfOrders10 %ld | "
                                           "BuyNoOfOrders11 %ld | BuyNoOfOrders12 %ld | BuyNoOfOrders13 %ld | BuyNoOfOrders14 %ld | BuyNoOfOrders15 %ld | BuyNoOfOrders16 %ld | BuyNoOfOrders17 %ld | BuyNoOfOrders18 %ld | BuyNoOfOrders19 %ld | BuyNoOfOrders20 %ld | "
                                           "SellQty1 %ld | SellQty2 %ld | SellQty3 %ld | SellQty4 %ld | SellQty5 %ld | SellQty6 %ld | SellQty7 %ld | SellQty8 %ld | SellQty9 %ld | SellQty10 %ld | "
                                           "SellQty11 %ld | SellQty12 %ld | SellQty13 %ld | SellQty14 %ld | SellQty15 %ld | SellQty16 %ld | SellQty17 %ld | SellQty18 %ld | SellQty19 %ld | SellQty20 %ld | "
                                           "SellPrice1 %.2f | SellPrice2 %.2f | SellPrice3 %.2f | SellPrice4 %.2f | SellPrice5 %.2f | SellPrice6 %.2f | SellPrice7 %.2f | SellPrice8 %.2f | SellPrice9 %.2f | SellPrice10 %.2f | "
                                           "SellPrice11 %.2f | SellPrice12 %.2f | SellPrice13 %.2f | SellPrice14 %.2f | SellPrice15 %.2f | SellPrice16 %.2f | SellPrice17 %.2f | SellPrice18 %.2f | SellPrice19 %.2f | SellPrice20 %.2f | "
                                           "SellNoOfOrders1 %ld | SellNoOfOrders2 %ld | SellNoOfOrders3 %ld | SellNoOfOrders4 %ld | SellNoOfOrders5 %ld | SellNoOfOrders6 %ld | SellNoOfOrders7 %ld | SellNoOfOrders8 %ld | SellNoOfOrders9 %ld | SellNoOfOrders10 %ld | "
                                           "SellNoOfOrders11 %ld | SellNoOfOrders12 %ld | SellNoOfOrders13 %ld | SellNoOfOrders14 %ld | SellNoOfOrders15 %ld | SellNoOfOrders16 %ld | SellNoOfOrders17 %ld | SellNoOfOrders18 %ld | SellNoOfOrders19 %ld | SellNoOfOrders20 %ld\n",
                   pMarketData->iDepthSize,
                   pMarketData->BestBuy[0].lQty,
                   pMarketData->BestBuy[1].lQty,
                   pMarketData->BestBuy[2].lQty,
                   pMarketData->BestBuy[3].lQty,
                   pMarketData->BestBuy[4].lQty,
                   pMarketData->BestBuy[5].lQty,
                   pMarketData->BestBuy[6].lQty,
                   pMarketData->BestBuy[7].lQty,
                   pMarketData->BestBuy[8].lQty,
                   pMarketData->BestBuy[9].lQty,
                   pMarketData->BestBuy[10].lQty,
                   pMarketData->BestBuy[11].lQty,
                   pMarketData->BestBuy[12].lQty,
                   pMarketData->BestBuy[13].lQty,
                   pMarketData->BestBuy[14].lQty,
                   pMarketData->BestBuy[15].lQty,
                   pMarketData->BestBuy[16].lQty,
                   pMarketData->BestBuy[17].lQty,
                   pMarketData->BestBuy[18].lQty,
                   pMarketData->BestBuy[19].lQty,
                   pMarketData->BestBuy[0].dPrice,
                   pMarketData->BestBuy[1].dPrice,
                   pMarketData->BestBuy[2].dPrice,
                   pMarketData->BestBuy[3].dPrice,
                   pMarketData->BestBuy[4].dPrice,
                   pMarketData->BestBuy[5].dPrice,
                   pMarketData->BestBuy[6].dPrice,
                   pMarketData->BestBuy[7].dPrice,
                   pMarketData->BestBuy[8].dPrice,
                   pMarketData->BestBuy[9].dPrice,
                   pMarketData->BestBuy[10].dPrice,
                   pMarketData->BestBuy[11].dPrice,
                   pMarketData->BestBuy[12].dPrice,
                   pMarketData->BestBuy[13].dPrice,
                   pMarketData->BestBuy[14].dPrice,
                   pMarketData->BestBuy[15].dPrice,
                   pMarketData->BestBuy[16].dPrice,
                   pMarketData->BestBuy[17].dPrice,
                   pMarketData->BestBuy[18].dPrice,
                   pMarketData->BestBuy[19].dPrice,
                   pMarketData->BestBuy[0].lNoOfOrders,
                   pMarketData->BestBuy[1].lNoOfOrders,
                   pMarketData->BestBuy[2].lNoOfOrders,
                   pMarketData->BestBuy[3].lNoOfOrders,
                   pMarketData->BestBuy[4].lNoOfOrders,
                   pMarketData->BestBuy[5].lNoOfOrders,
                   pMarketData->BestBuy[6].lNoOfOrders,
                   pMarketData->BestBuy[7].lNoOfOrders,
                   pMarketData->BestBuy[8].lNoOfOrders,
                   pMarketData->BestBuy[9].lNoOfOrders,
                   pMarketData->BestBuy[10].lNoOfOrders,
                   pMarketData->BestBuy[11].lNoOfOrders,
                   pMarketData->BestBuy[12].lNoOfOrders,
                   pMarketData->BestBuy[13].lNoOfOrders,
                   pMarketData->BestBuy[14].lNoOfOrders,
                   pMarketData->BestBuy[15].lNoOfOrders,
                   pMarketData->BestBuy[16].lNoOfOrders,
                   pMarketData->BestBuy[17].lNoOfOrders,
                   pMarketData->BestBuy[18].lNoOfOrders,
                   pMarketData->BestBuy[19].lNoOfOrders,
                   pMarketData->BestSell[0].lQty,
                   pMarketData->BestSell[1].lQty,
                   pMarketData->BestSell[2].lQty,
                   pMarketData->BestSell[3].lQty,
                   pMarketData->BestSell[4].lQty,
                   pMarketData->BestSell[5].lQty,
                   pMarketData->BestSell[6].lQty,
                   pMarketData->BestSell[7].lQty,
                   pMarketData->BestSell[8].lQty,
                   pMarketData->BestSell[9].lQty,
                   pMarketData->BestSell[10].lQty,
                   pMarketData->BestSell[11].lQty,
                   pMarketData->BestSell[12].lQty,
                   pMarketData->BestSell[13].lQty,
                   pMarketData->BestSell[14].lQty,
                   pMarketData->BestSell[15].lQty,
                   pMarketData->BestSell[16].lQty,
                   pMarketData->BestSell[17].lQty,
                   pMarketData->BestSell[18].lQty,
                   pMarketData->BestSell[19].lQty,
                   pMarketData->BestSell[0].dPrice,
                   pMarketData->BestSell[1].dPrice,
                   pMarketData->BestSell[2].dPrice,
                   pMarketData->BestSell[3].dPrice,
                   pMarketData->BestSell[4].dPrice,
                   pMarketData->BestSell[5].dPrice,
                   pMarketData->BestSell[6].dPrice,
                   pMarketData->BestSell[7].dPrice,
                   pMarketData->BestSell[8].dPrice,
                   pMarketData->BestSell[9].dPrice,
                   pMarketData->BestSell[10].dPrice,
                   pMarketData->BestSell[11].dPrice,
                   pMarketData->BestSell[12].dPrice,
                   pMarketData->BestSell[13].dPrice,
                   pMarketData->BestSell[14].dPrice,
                   pMarketData->BestSell[15].dPrice,
                   pMarketData->BestSell[16].dPrice,
                   pMarketData->BestSell[17].dPrice,
                   pMarketData->BestSell[18].dPrice,
                   pMarketData->BestSell[19].dPrice,
                   pMarketData->BestSell[0].lNoOfOrders,
                   pMarketData->BestSell[1].lNoOfOrders,
                   pMarketData->BestSell[2].lNoOfOrders,
                   pMarketData->BestSell[3].lNoOfOrders,
                   pMarketData->BestSell[4].lNoOfOrders,
                   pMarketData->BestSell[5].lNoOfOrders,
                   pMarketData->BestSell[6].lNoOfOrders,
                   pMarketData->BestSell[7].lNoOfOrders,
                   pMarketData->BestSell[8].lNoOfOrders,
                   pMarketData->BestSell[9].lNoOfOrders,
                   pMarketData->BestSell[10].lNoOfOrders,
                   pMarketData->BestSell[11].lNoOfOrders,
                   pMarketData->BestSell[12].lNoOfOrders,
                   pMarketData->BestSell[13].lNoOfOrders,
                   pMarketData->BestSell[14].lNoOfOrders,
                   pMarketData->BestSell[15].lNoOfOrders,
                   pMarketData->BestSell[16].lNoOfOrders,
                   pMarketData->BestSell[17].lNoOfOrders,
                   pMarketData->BestSell[18].lNoOfOrders,
                   pMarketData->BestSell[19].lNoOfOrders);
          logString += buffer;
     }
     std::cout << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::MarketStatusNotifyStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "MarketStatusNotifyStart  EchoBackData: %s", (char *)pEchoBackData);
     std::cout << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::MarketStatusNotify(char *pExchSeg,
                                          char *pMktStatus,
                                          char *pMktType,
                                          void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "MarketStatusNotify EchoBackData:%s | pExchSeg:%s | pMktStatus:%s |"
                                      "pMktType:%s |",
              (char *)pEchoBackData,
              pExchSeg,
              pMktStatus,
              pMktType);
     std::cout << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::MarketStatusNotifyEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "MarketStatusNotifyEnd EchoBackData:%s",
              (char *)pEchoBackData);
     std::cout << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::MarketStatusUpdate(char *pExchSeg,
                                          char *pMktStatus,
                                          char *pMktType,
                                          void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "MarketStatusUpdate  EchoBackData: %s | pExchSeg: %s | pMktStatus: %s |"
                                      "pMktType:%s |",
              (char *)pEchoBackData,
              pExchSeg,
              pMktStatus,
              pMktType);
     std::cout << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::MktStatusUnSubscribeResponse(char *pStatus,
                                                    void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "MktStatusUnSubscribeResponse EchoBackData: %s pStatus: %s",
              (char *)pEchoBackData,
              pStatus);
     std::cout << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::ExchangeMessageStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ExchangeMessageStart EchoBackData: %s",
              (char *)pEchoBackData);
     std::cout << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::ExchangeMessage(char *pExchSeg,
                                       char *pMessage,
                                       void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ExchangeMessage EchoBackData: %s | pExchSeg: %s | pMessage: %s |",
              (char *)pEchoBackData,
              pExchSeg,
              pMessage);
     std::cout << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::ExchangeMessageEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ExchangeMessageEnd EchoBackData: %s ", (char *)pEchoBackData);
     std::cout << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::ExchangeMessageUpdate(char *pExchSeg,
                                             char *pMessage,
                                             long lExchTime,
                                             void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ExchangeMessageUpdate EchoBackData:%s ExchSeg:%s Message:%s ExchTime:%ld",
              (char *)pEchoBackData,
              pExchSeg,
              pMessage,
              lExchTime);
     std::cout << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::ExchangeMessageUnSubscribeResponse(char *pStatus,
                                                          void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ExchangeMessageUnSubscribeResponse EchoBackData:%s | Status:%s |",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::AddFundResponse(char *pStatus,
                                       char *pRemarks,
                                       void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AddFundResponse  EchoBackData :%s | Status :%s |  EchoBackData :%s |",
              (char *)pEchoBackData,
              pStatus,
              (char *)pEchoBackData);
     logString += buffer;

     if (pRemarks)
     {
          snprintf(buffer, sizeof(buffer), " Remarks:%s ", pRemarks);
          logString += buffer;
     }

     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetOrderMarginStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOrderMarginStart pEchoBackData:%s ",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetOrderMarginResponse(char *pRemarks,
                                              double TotalCash,
                                              double MarginOnNewOrder,
                                              double AvailableMarginForTheOrder,
                                              void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOrderMarginResponse Remarks :%s | TotalCash :%f | MarginOnNewOrder :%f |"
                                      "AvailableMarginForTheOrder :%f | EchoBackData:%s |",
              pRemarks,
              TotalCash,
              MarginOnNewOrder,
              AvailableMarginForTheOrder,
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetOrderMarginResponse(char *pRemarks,
                                              double TotalCash,
                                              double MarginOnNewOrder,
                                              double AvailableMarginForTheOrder,
                                              void *pEchoBackData,
                                              long lNorenUpdateTimeEpoch,
                                              long lNorenUpdateTimeNanoSec)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOrderMarginResponse  Remarks :%s | TotalCash:%f | MarginOnNewOrder: %f | AvailableMarginForTheOrder: %f |"
                                      "EchoBackData:%s | lNorenUpdateTimeEpoch:%ld | lNorenUpdateTimeNanoSec:%ld |",
              pRemarks,
              TotalCash,
              MarginOnNewOrder,
              AvailableMarginForTheOrder,
              (char *)pEchoBackData,
              lNorenUpdateTimeEpoch,
              lNorenUpdateTimeNanoSec);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetOrderMarginEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOrderMarginEnd pEchoBackData :%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetOrderMargin2Start(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOrderMarginStart pEchoBackData:%s ",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetOrderMargin2Response(char *pRemarks,
                                               double TotalCash,
                                               double MarginOnNewOrder,
                                               double AvailableMarginForTheOrder,
                                               double OrderMarginUsed,
                                               void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOrderMarginResponse  Remarks :%s | TotalCash:%f | MarginOnNewOrder: %f | AvailableMarginForTheOrder: %f |OrderMarginUsed: %f |"
                                      "EchoBackData:%s |",
              pRemarks,
              TotalCash,
              MarginOnNewOrder,
              AvailableMarginForTheOrder,
              OrderMarginUsed,
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetOrderMargin2End(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOrderMarginEnd pEchoBackData :%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetOrderMarginLimits2(void *pEchoBackData,
                                             tsRmsLimits *pRmsLimits,
                                             double &dTotalRmsValue,
                                             double &dRmsMarginUsed)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOrderMarginLimits2  EchoBackData: %s | acct id :%s | pCategory :%s | pSegment:%s |"
                                      " acExchSeg :%s | acProduct :%s | CollateralValue :%f | Collateral :%f | BrokerCollateral :%f |"
                                      " DaylongCash :%f | UnclearedCash :%f | AmountUtilizedPrsnt :%f | UnrealizedMtomPrsnt:%f | RealizedMtomPrsnt :%f |"
                                      " ExposureMarginPrsnt :%f | SpanMarginPrsnt :%f | PremiumPrsnt :%f | MarginVarPrsnt :%f | MarginScripBasketPrsnt :%f |"
                                      " MarginUsed :%f | RmsPayInAmt:%f | RmsPayOutAmt:%f | CurExpMrgnNrmlPrsnt :%f | CurExpMrgnMisPrsnt :%f | CurPremiumNrmlPrsnt:%f |"
                                      " CurPremiumMisPrsnt :%f | CurSpanMrgnNrmlPrsnt :%f | CurSpanMrgnMisPrsnt:%f | FoExpMrgnNrmlPrsnt :%f | FoExpMrgnMisPrsnt :%f |"
                                      " FoPremiumNrmlPrsnt :%f | FoPremiumMisPrsnt :%f | FoSpanrgnNrmlPrsnt :%f | FoSpanrgnMisPrsnt :%f | MrgnScrpBsktNrmlPrsnt :%f |"
                                      " MrgnScrpBsktMisPrsnt :%f | MrgnVarNrmlPrsnt :%f | MrgnVarMisPrsnt :%f | AmtUntilizedPrsnt :%f | CncMrgnVarPrsnt :%f | MarginUsedPrsnt :%.2f |"
                                      " AuxBrokerCollateral :%f | AuxDaylongCash :%f | AuxUnclearedCash :%f | AvailableMargin :%.2e | dBrokerage :%f | dMrgnProtection :%f |"
                                      " dFoPremium :%f | dCurPremium :%f | dComPremium :%f | dMtomCurrentPerc :%.2e | dMarginCurrentPerc :%f | dLiquidCashCollateral :%.2e |"
                                      " dMfCollateral :%.2e | dMfCashCollateral :%.2e | dAddMrgnPrsnt :%.2e| dTenderMrgnPrsnt :%.2e | dDeliveryMrgnPrsnt :%.2e | dBrokerageCnc :%.2e|"
                                      " dBrokerageMis :%.2e | dBrokerageNrml :%.2e | dBrokerageCO :%.2e | dBrokerageBO :%.2e | dFoBrokerageMis :%.2e| dFoBrokerageNrml :%.2e | dFoBrokerageCO :%.2e |"
                                      " dFoBrokerageBO :%.2e | dCurBrokerageMis :%.2e | dCurBrokerageNrml :%.2e | dCurBrokerageCO :%.2e | dCurBrokerageBO :%.2e | dComBrokerageMis :%.2e | dComBrokerageNrml :%.2e |"
                                      " dComBrokerageCO :%.2e | dComBrokerageBO :%.2e| dMrgnProtectionCO :%.2e | dMrgnProtectionBO :%.2e | dFoMrgnProtectionCO :%.2e |  dFoMrgnProtectionBO :%.2e| dCurMrgnProtectionCO :%.2e|"
                                      " dCurMrgnProtectionBO :%.2e | dComMrgnProtectionCO :%.2e | dComMrgnProtectionBO :%.2e | dComPremiumMisPrsnt :%.2e | dComPremiumNrmlPrsnt :%.2e | dExchMrgn :%.2f | dFoExchMrgn :%.2e |"
                                      " dCurExchMrgn :%.2e  | dComExchMrgn :%.2e | dExchMrgnSellCrd :%.2e | dExchMrgnT1SellCrd :%.2e | dAlloc :%.2e | dFoAlloc :%.2e | dCurAlloc :%.2e | dComAlloc :%.2e | dBlockAmt :%.2e | dMtfLimit :%.0f |"
                                      " dSlbmLimit :%.0f | dTotalRmsValue:%.0f|dRmsMarginUsed :%.0f | dBlockAmt :%.2e",
              (char *)pEchoBackData,
              pRmsLimits->acAcctId,
              pRmsLimits->pCategory,
              pRmsLimits->pSegment,
              pRmsLimits->acExchSeg,
              pRmsLimits->acProduct,
              pRmsLimits->dCollateralValue,
              pRmsLimits->dCollateral,
              pRmsLimits->dRmsCollateral,
              pRmsLimits->dAdhocMargin,
              pRmsLimits->dNotionalCash,
              pRmsLimits->dAmountUtilizedPrsnt,
              pRmsLimits->dUnrealizedMtomPrsnt,
              pRmsLimits->dRealizedMtomPrsnt,
              pRmsLimits->dExposureMarginPrsnt,
              pRmsLimits->dSpanMarginPrsnt,
              pRmsLimits->dPremiumPrsnt,
              pRmsLimits->dMarginVarPrsnt,
              pRmsLimits->dMarginScripBasketPrsnt, //<<
              //                    "dMtomWarningPrcntPrsnt "<<pRmsLimits->dMtomWarningPrcntPrsnt<<
              //                    "dMtomSquareOffWarningPrcntPrsnt "<<pRmsLimits->dMtomSquareOffWarningPrcntPrsnt<<
              pRmsLimits->dMarginUsed,
              pRmsLimits->dRmsPayInAmt,
              pRmsLimits->dRmsPayOutAmt,
              pRmsLimits->dCurExpMrgnNrmlPrsnt,
              pRmsLimits->dCurExpMrgnMisPrsnt,
              pRmsLimits->dCurPremiumNrmlPrsnt,
              pRmsLimits->dCurPremiumMisPrsnt,
              pRmsLimits->dCurSpanMrgnNrmlPrsnt,
              pRmsLimits->dCurSpanMrgnMisPrsnt,
              pRmsLimits->dFoExpMrgnNrmlPrsnt,
              pRmsLimits->dFoExpMrgnMisPrsnt,
              pRmsLimits->dFoPremiumNrmlPrsnt,
              pRmsLimits->dFoPremiumMisPrsnt,
              pRmsLimits->dFoSpanrgnNrmlPrsnt,
              pRmsLimits->dFoSpanrgnMisPrsnt,
              pRmsLimits->dMrgnScrpBsktNrmlPrsnt,
              pRmsLimits->dMrgnScrpBsktMisPrsnt,
              // <<
              //                    "dMrgnScrpBsktCncPrsnt "<<pRmsLimits->dMrgnScrpBsktCncPrsnt<<

              pRmsLimits->dMrgnVarNrmlPrsnt,
              pRmsLimits->dMrgnVarMisPrsnt,
              pRmsLimits->dAmtUntilizedPrsnt,
              pRmsLimits->dCncMrgnVarPrsnt,
              pRmsLimits->dMarginUsedPrsnt,
              pRmsLimits->dAuxRmsCollateral,
              pRmsLimits->dAuxAdhocMargin,
              pRmsLimits->dAuxNotionalCash,
              pRmsLimits->dAvailableMargin,
              pRmsLimits->dBrokerage,
              pRmsLimits->dMrgnProtection,
              pRmsLimits->dFoPremium,
              pRmsLimits->dCurPremium,
              pRmsLimits->dComPremium,
              pRmsLimits->dMtomCurrentPerc,
              pRmsLimits->dMarginCurrentPerc,
              pRmsLimits->dLiquidCashCollateral,
              pRmsLimits->dMfCollateral,
              pRmsLimits->dMfCashCollateral,
              pRmsLimits->dAddMrgnPrsnt,
              pRmsLimits->dTenderMrgnPrsnt,
              pRmsLimits->dDeliveryMrgnPrsnt,
              pRmsLimits->dBrokerageCnc,
              pRmsLimits->dBrokerageMis,
              pRmsLimits->dBrokerageNrml,
              pRmsLimits->dBrokerageCO,
              pRmsLimits->dBrokerageBO,
              pRmsLimits->dFoBrokerageMis,
              pRmsLimits->dFoBrokerageNrml,
              pRmsLimits->dFoBrokerageCO,
              pRmsLimits->dFoBrokerageBO,
              pRmsLimits->dCurBrokerageMis,
              pRmsLimits->dCurBrokerageNrml,
              pRmsLimits->dCurBrokerageCO,
              pRmsLimits->dCurBrokerageBO,
              pRmsLimits->dComBrokerageMis,
              pRmsLimits->dComBrokerageNrml,
              pRmsLimits->dComBrokerageCO,
              pRmsLimits->dComBrokerageBO,
              pRmsLimits->dMrgnProtectionCO,
              pRmsLimits->dMrgnProtectionBO,
              pRmsLimits->dFoMrgnProtectionCO,
              pRmsLimits->dFoMrgnProtectionBO,
              pRmsLimits->dCurMrgnProtectionCO,
              pRmsLimits->dCurMrgnProtectionBO,
              pRmsLimits->dComMrgnProtectionCO,
              pRmsLimits->dComMrgnProtectionBO,
              pRmsLimits->dComPremiumMisPrsnt,
              pRmsLimits->dComPremiumNrmlPrsnt,
              pRmsLimits->dExchMrgn,
              pRmsLimits->dFoExchMrgn,
              pRmsLimits->dCurExchMrgn,
              pRmsLimits->dComExchMrgn,
              pRmsLimits->dExchMrgnSellCrd,
              pRmsLimits->dExchMrgnT1SellCrd,
              pRmsLimits->dAlloc,
              pRmsLimits->dFoAlloc,
              pRmsLimits->dCurAlloc,
              pRmsLimits->dComAlloc,
              pRmsLimits->dBlockAmt,
              pRmsLimits->dMtfLimit,
              pRmsLimits->dSlbmLimit,
              dTotalRmsValue,
              dRmsMarginUsed,
              pRmsLimits->dRemarksAmt);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetBasketMarginStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetBasketMarginStart EchoBackData :%s ",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::BlockUserResponse(char *pStatus,
                                         void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "BlockUserResponse EchoBackData: %s | pStatus: %s",
              (char *)pEchoBackData,
              pStatus);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetBasketMarginResponse(char *pRemarks,
                                               double MarginOnNewOrder,
                                               double TradedMargin,
                                               double PreviousMargin,
                                               double *BasketMargin,
                                               int BasketSize,
                                               void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetBasketMarginResponse pRemarks:%s | MarginOnNewOrder:%.2f | TradedMargin:%.2f |"
                                      "PreviousMargin:%.2f |",
              pRemarks,
              MarginOnNewOrder,
              TradedMargin,
              PreviousMargin);
     logString += buffer;
     for (int i = 0; i < BasketSize; i++)
     {
          snprintf(buffer, sizeof(buffer), " BasketMargin %d: %.2f |", i, BasketMargin[i]);
          logString += buffer;
     }
     snprintf(buffer, BUFFER_SIZE, " BasketSize: %d | EchoBackData: %s |", BasketSize, (char *)pEchoBackData);
     logString += buffer;
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetBasketMarginEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetBasketMarginEnd pEchoBackData :%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetWithdrawalAmtStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetWithdrawalAmtStart pEchoBackData :%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetWithdrawalAmtResponse(double MaxWithdrawalAmt,
                                                void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetWithdrawalAmtResponse MaxWithdrawalAmt :%f | EchoBackData: %s |",
              MaxWithdrawalAmt,
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetWithdrawalAmtEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetWithdrawalAmtEnd pEchoBackData :%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetWithdrawFundStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetWithdrawFundStart pEchoBackData :%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetWithdrawFund(char *pStatus,
                                       char *pRemarks,
                                       void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     std::clog << std::fixed << "GetWithdrawFund ";
     if (pRemarks)
     {
          snprintf(buffer, sizeof(buffer), " Remarks:%s |", pRemarks);
          logString += buffer;
     }

     if (pStatus)
     {
          snprintf(buffer, sizeof(buffer), " Status:%s |", pStatus);
          logString += buffer;
     }
     snprintf(buffer, sizeof(buffer), " EchoBackData:%s |", (char *)pEchoBackData);
     logString += buffer;
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetWithdrawFundEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];

     snprintf(buffer, sizeof(buffer), "GetWithdrawFundEnd pEchoBackData :%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetWithdrawFund2Start(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetWithdrawFund2Start pEchoBackData:%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetWithdrawFund2(char *pAccountId,
                                        long lTranRefNumber,
                                        double dAmount,
                                        char *pTranStatus,
                                        char *pRemarks,
                                        void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetWithdrawFund2 AccountId: %s| TranRefNumber: %ld | Amount: %.2f |",
              pAccountId, lTranRefNumber, dAmount);
     logString += buffer;
     if (pRemarks)
     {
          snprintf(buffer, sizeof(buffer), " Remarks :%s |", pRemarks);
          logString += buffer;
     }

     if (pTranStatus)
     {
          snprintf(buffer, sizeof(buffer), " Status :%s |", pTranStatus);
          logString += buffer;
     }
     snprintf(buffer, sizeof(buffer), " EchoBackData :%s |", (char *)pEchoBackData);
     logString += buffer;
     std::clog << logString << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetWithdrawFund2End(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetWithdrawFund2End pEchoBackData :%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::M2MAlertUpdate(tsM2MAlert *pM2MAlert,
                                      void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "M2MAlertUpdate  EchoBackData :%s | acAcctId :%s | AlertType :%d |"
                                      "acText :%s|",
              (char *)pEchoBackData,
              pM2MAlert->acAcctId,
              pM2MAlert->iAlertType,
              pM2MAlert->acText);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::M2MAlertUnSubscribeResponse(char *pStatus,
                                                   void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "M2MAlertUnSubscribeResponse  EchoBackData: %s | pStatus: %s",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::IpoListStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "IpoListStart  EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::IpoListResp(void *pEchoBackData,
                                   tsIpoList *pIpoList)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "IpoListResp  EchoBackData:%s | SymbolName:%s | LotSize:%d | CompanyName:%s | InstName:%s |"
                                      " MinLotSize :%d | FaceValue :%ld | UprCkt:%ld | LwrCkt:%ld | TickSize:%d | StartDate:%s | EndDate:%s | StartTime:%s |"
                                      " EndTime:%s | Series:%s | AppStartNum:%s | AppEndNum:%s | CurAppNum:%s | CategoryList:%s | ISIN:%s | CategoryName:%s |"
                                      " CatStartTime:%s | CatEndTime:%s | DiscountValue:%s | DiscountPercent:%s |",
              (char *)pEchoBackData,
              pIpoList->pSymbolName,
              pIpoList->iLotSize,
              pIpoList->pCompanyName,
              pIpoList->pInstName,
              pIpoList->iMinLotSize,
              pIpoList->lFaceValue,
              pIpoList->lUprCkt,
              pIpoList->lLwrCkt,
              pIpoList->iTickSize,
              pIpoList->pStartDate,
              pIpoList->pEndDate,
              pIpoList->pStartTime,
              pIpoList->pEndTime,
              pIpoList->pSeries,
              pIpoList->pAppStartNum,
              pIpoList->pAppEndNum,
              pIpoList->pCurAppNum,
              pIpoList->pCategoryList,
              pIpoList->pISIN,
              pIpoList->pCategoryName,
              pIpoList->pCatStartTime,
              pIpoList->pCatEndTime,
              pIpoList->pDiscountValue,
              pIpoList->pDiscountPercent);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::IpoListEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "IpoListEnd EchoBackData:%s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::IpoOrderUpdate(tsIpoOrdBook *pIpoOrderUpdate,
                                      void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "IpoOrderUpdate :pEchoBackData: %s | RejectionQty :%ld |"
                                      " RejectionOrdSrc :%s | RejectionPriceType:%s | PurchaseType :%s | DpTrans:%s |"
                                      " FolioNum:%s | Euin:%s | IpAddr:%s | Exch:%s | Act Id :%s | Ord Duration :%s |"
                                      " CustomFirm:%s | Product:%s | Ord Type :%s | Trd Symbol :%s | Trans Type :%s |"
                                      " acGuiOrdId:%s | Token:%s | Price:%f | TriggerPrice:%f | Quantity:%ld | DiscQuantity:%ld |"
                                      " CancelledSize:%ld | OrdSrc:%s | acOrdRemarks:%s | acExternalRemarks:%s | acAlgoName:%s |"
                                      " acAlgoId:%s | acAlgoCategory:%s | User:%s | AvgPrice:%f | FilledShares:%ld | UnfilledSize:%ld |"
                                      " NorenOrdNum:%s | ReqId:%s | ExchOrdId:%s | Text:%s | OrdStatus:%s | Status:%c | acReportType:%s |"
                                      " cRepTyp:%c | NorenTime Sec :%s | NorenUpdateTime :%s | lNorenUpdateTimeNanoSec :%ld |"
                                      " ExchTime :%s | ExchTimeNanoSec:%ld | ExchOrdUpdateTime :%s | RejectionBy:%s | Rejection Reason :%s |"
                                      " OrderGenType :%s | NorenTime MiliSec :%s | lNorenTimeNanoSec :%ld | dRmsPrice:%f |",
              (char *)pEchoBackData,
              pIpoOrderUpdate->lRejectionQty,
              pIpoOrderUpdate->acRejectionOrdSrc,
              pIpoOrderUpdate->acRejectionPriceType,
              pIpoOrderUpdate->acPurchaseType,
              pIpoOrderUpdate->acDpTrans,
              pIpoOrderUpdate->acFolioNum,
              pIpoOrderUpdate->acEuin,
              pIpoOrderUpdate->acIpAddr,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.acExchSeg,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.acAccountId,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.acOrdDuration,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.acCustomerFirm,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.acProduct,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.acOrderType,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.acTrdSymbol,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.acTransType,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.acGuiOrdId,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.acToken,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.dPrice,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.dTriggerPrice,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.lQuantity,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.lDiscQuantity,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.lCancelledSize,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.acOrdSrc,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.acOrdRemarks,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.acExternalRemarks,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.acAlgoName,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.acAlgoId,
              pIpoOrderUpdate->sOrderUpdate.sOrderParams.acAlgoCategory,
              //                    " Pan "
              //                    << pIpoOrderUpdate->sOrderUpdate.acPan <<

              pIpoOrderUpdate->sOrderUpdate.sOrderParams.acUser,
              //                    " VendorCode "
              //                    << pIpoOrderUpdate->sOrderUpdate.sOrderParams.acVendorCode <<

              pIpoOrderUpdate->sOrderUpdate.dAvgPrice,
              pIpoOrderUpdate->sOrderUpdate.lFilledShares,
              pIpoOrderUpdate->sOrderUpdate.lUnfilledSize,
              pIpoOrderUpdate->sOrderUpdate.acNorenOrdNum,
              pIpoOrderUpdate->sOrderUpdate.acReqId,
              pIpoOrderUpdate->sOrderUpdate.acExchOrdId,
              pIpoOrderUpdate->sOrderUpdate.acText,
              pIpoOrderUpdate->sOrderUpdate.acOrdStatus,
              pIpoOrderUpdate->sOrderUpdate.cStatus,
              pIpoOrderUpdate->sOrderUpdate.acReportType,
              pIpoOrderUpdate->sOrderUpdate.cRepTyp,
              pIpoOrderUpdate->sOrderUpdate.acNorenTimeSec,
              pIpoOrderUpdate->sOrderUpdate.acNorenUpdateTime,
              pIpoOrderUpdate->sOrderUpdate.lNorenUpdateTimeNanoSec,
              pIpoOrderUpdate->sOrderUpdate.acExchTime,
              pIpoOrderUpdate->sOrderUpdate.lExchTimeNanoSec,
              pIpoOrderUpdate->sOrderUpdate.acOrgExchTime,
              pIpoOrderUpdate->sOrderUpdate.acRejectionBy,
              pIpoOrderUpdate->sOrderUpdate.acRejReason,
              pIpoOrderUpdate->sOrderUpdate.acOrderGenType,
              pIpoOrderUpdate->sOrderUpdate.acNorenTimeMiliSec,
              pIpoOrderUpdate->sOrderUpdate.lNorenTimeNanoSec,
              pIpoOrderUpdate->sOrderUpdate.dRmsPrice);
     logString += buffer;
     if (pIpoOrderUpdate->sMultiLegUpdate.siLeg == 2)
     {
          snprintf(buffer, sizeof(buffer), " TrdSymbol_Leg2 :%s | TransType_Leg2 :%s | Token_Leg2 :%s |"
                                           " Price_Leg2:%f | Quantity_Leg2 :%ld | DiscQuantity_Leg2:%ld | AvgPrice_Leg2 :%f |"
                                           " FilledShares_Leg2:%ld | UnfilledSize_Leg2:%ld|\n",
                   pIpoOrderUpdate->sMultiLegUpdate.sMultiLegParams.acTrdSymbol_Leg2,
                   pIpoOrderUpdate->sMultiLegUpdate.sMultiLegParams.acTransType_Leg2,
                   pIpoOrderUpdate->sMultiLegUpdate.sMultiLegParams.acToken_Leg2,
                   pIpoOrderUpdate->sMultiLegUpdate.sMultiLegParams.dPrice_Leg2,
                   pIpoOrderUpdate->sMultiLegUpdate.sMultiLegParams.lQuantity_Leg2,
                   pIpoOrderUpdate->sMultiLegUpdate.sMultiLegParams.lDiscQuantity_Leg2,
                   pIpoOrderUpdate->sMultiLegUpdate.dAvgPrice_Leg2,
                   pIpoOrderUpdate->sMultiLegUpdate.lFilledShares_Leg2,
                   pIpoOrderUpdate->sMultiLegUpdate.lUnfilledSize_Leg2);
          logString += buffer;
     }
     else if (pIpoOrderUpdate->sMultiLegUpdate.siLeg == 3)
     {
          snprintf(buffer, sizeof(buffer), " TrdSymbol_Leg2 :%s | TransType_Leg2 :%s | Token_Leg2 :%s |"
                                           " Price_Leg2 :%f | Quantity_Leg2 :%ld | DiscQuantity_Leg2:%ld | AvgPrice_Leg2 :%f |"
                                           " FilledShares_Leg2 :%ld | UnfilledSize_Leg2:%ld | TrdSymbol_Leg3:%s | TransType_Leg3:%s |"
                                           " Token_Leg3:%s | Price_Leg3 :%f | Quantity_Leg3:%ld | DiscQuantity_Leg3 :%ld | AvgPrice_Leg3:%f |"
                                           " FilledShares_Leg3 :%ld | UnfilledSize_Leg3 :%ld|\n",
                   pIpoOrderUpdate->sMultiLegUpdate.sMultiLegParams.acTrdSymbol_Leg2,
                   pIpoOrderUpdate->sMultiLegUpdate.sMultiLegParams.acTransType_Leg2,
                   pIpoOrderUpdate->sMultiLegUpdate.sMultiLegParams.acToken_Leg2,
                   pIpoOrderUpdate->sMultiLegUpdate.sMultiLegParams.dPrice_Leg2,
                   pIpoOrderUpdate->sMultiLegUpdate.sMultiLegParams.lQuantity_Leg2,
                   pIpoOrderUpdate->sMultiLegUpdate.sMultiLegParams.lDiscQuantity_Leg2,
                   pIpoOrderUpdate->sMultiLegUpdate.dAvgPrice_Leg2,
                   pIpoOrderUpdate->sMultiLegUpdate.lFilledShares_Leg2,
                   pIpoOrderUpdate->sMultiLegUpdate.lUnfilledSize_Leg2,
                   pIpoOrderUpdate->sMultiLegUpdate.sMultiLegParams.acTrdSymbol_Leg3,
                   pIpoOrderUpdate->sMultiLegUpdate.sMultiLegParams.acTransType_Leg3,
                   pIpoOrderUpdate->sMultiLegUpdate.sMultiLegParams.acToken_Leg3,
                   pIpoOrderUpdate->sMultiLegUpdate.sMultiLegParams.dPrice_Leg3,
                   pIpoOrderUpdate->sMultiLegUpdate.sMultiLegParams.lQuantity_Leg3,
                   pIpoOrderUpdate->sMultiLegUpdate.sMultiLegParams.lDiscQuantity_Leg3,
                   pIpoOrderUpdate->sMultiLegUpdate.dAvgPrice_Leg3,
                   pIpoOrderUpdate->sMultiLegUpdate.lFilledShares_Leg3,
                   pIpoOrderUpdate->sMultiLegUpdate.lUnfilledSize_Leg3);
          logString += buffer;
     }
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::IpoOrderAdminUnSubscribeResponse(void *pEchoBackData,
                                                        char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "IpoOrderAdminUnSubscribeResponse EchoBackData: %s | Status:%s |",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::IpoOrderBookStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "IpoOrderBookStart EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::IpoOrderBookResp(void *pEchoBackData,
                                        tsIpoOrdBook *pIpoOrdBookResp)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "IpoOrderBookResp :pEchoBackData:%s | RejectionQty :%ld | RejectionOrdSrc :%s |"
                                      " RejectionPriceType :%s | PurchaseType :%s | DpTrans:%s | FolioNum :%s | Euin:%s | IpAddr :%s |"
                                      " Exch :%s | Act Id :%s | Ord Duration :%s | CustomFirm :%s | Product :%s | Ord Type :%s |"
                                      " Trd Symbol :%s | Trans Type :%s | acGuiOrdId:%s | Token:%s | Price :%f | TriggerPrice :%f |"
                                      " Quantity:%ld | DiscQuantity :%ld | CancelledSize :%ld | OrdSrc:%s | acOrdRemarks :%s |"
                                      " acExternalRemarks :%s | acAlgoName :%s | acAlgoId :%s | acAlgoCategory:%s | User :%s |"
                                      " VendorCode :%s | AvgPrice :%f | FilledShares :%ld | UnfilledSize :%ld | NorenOrdNum:%s | ReqId:%s |"
                                      " ExchOrdId:%s | Text :%s | OrdStatus:%s | Status:%c | ReportType :%s | RepTyp:%c | NorenTime Sec :%s | NorenUpdateTime :%s |"
                                      " lNorenUpdateTimeNanoSec:%ld | ExchTime:%s | ExchTimeNanoSec :%ld | ExchOrdUpdateTime:%s | RejectionBy:%s | Rejection Reason :%s |"
                                      " OrderGenType :%s | NorenTime MiliSec :%s | lNorenTimeNanoSec :%ld | acGuiOrgOrdId:%s | dMktProtectionPrice:%f | acOrderGenType:%s |"
                                      " dRmsPrice:%f |\n ",
              (char *)pEchoBackData,
              pIpoOrdBookResp->lRejectionQty,
              pIpoOrdBookResp->acRejectionOrdSrc,
              pIpoOrdBookResp->acRejectionPriceType,
              pIpoOrdBookResp->acPurchaseType,
              pIpoOrdBookResp->acDpTrans,
              pIpoOrdBookResp->acFolioNum,
              pIpoOrdBookResp->acEuin,
              pIpoOrdBookResp->acIpAddr,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acExchSeg,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acAccountId,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acOrdDuration,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acCustomerFirm,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acProduct,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acOrderType,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acTrdSymbol,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acTransType,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acGuiOrdId,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acToken,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.dPrice,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.dTriggerPrice,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.lQuantity,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.lDiscQuantity,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.lCancelledSize,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acOrdSrc,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acOrdRemarks,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acExternalRemarks,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acAlgoName,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acAlgoId,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acAlgoCategory,
              //                    " Pan "
              //                    << pIpoOrdBookResp->sOrderUpdate.acPan <<

              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acUser,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acVendorCode,
              pIpoOrdBookResp->sOrderUpdate.dAvgPrice,
              pIpoOrdBookResp->sOrderUpdate.lFilledShares,
              pIpoOrdBookResp->sOrderUpdate.lUnfilledSize,
              pIpoOrdBookResp->sOrderUpdate.acNorenOrdNum,
              pIpoOrdBookResp->sOrderUpdate.acReqId,
              pIpoOrdBookResp->sOrderUpdate.acExchOrdId,
              pIpoOrdBookResp->sOrderUpdate.acText,
              pIpoOrdBookResp->sOrderUpdate.acOrdStatus,
              pIpoOrdBookResp->sOrderUpdate.cStatus,
              pIpoOrdBookResp->sOrderUpdate.acReportType,
              pIpoOrdBookResp->sOrderUpdate.cRepTyp,
              pIpoOrdBookResp->sOrderUpdate.acNorenTimeSec,
              pIpoOrdBookResp->sOrderUpdate.acNorenUpdateTime,
              pIpoOrdBookResp->sOrderUpdate.lNorenUpdateTimeNanoSec,
              pIpoOrdBookResp->sOrderUpdate.acExchTime,
              pIpoOrdBookResp->sOrderUpdate.lExchTimeNanoSec,
              pIpoOrdBookResp->sOrderUpdate.acOrgExchTime,
              pIpoOrdBookResp->sOrderUpdate.acRejectionBy,
              pIpoOrdBookResp->sOrderUpdate.acRejReason,
              pIpoOrdBookResp->sOrderUpdate.acOrderGenType,
              pIpoOrdBookResp->sOrderUpdate.acNorenTimeMiliSec,
              pIpoOrdBookResp->sOrderUpdate.lNorenTimeNanoSec,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acGuiOrgOrdId,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.dMktProtectionPrice,
              pIpoOrdBookResp->sOrderUpdate.acOrderGenType,
              pIpoOrdBookResp->sOrderUpdate.dRmsPrice);
     logString += buffer;
     if (pIpoOrdBookResp->sMultiLegUpdate.siLeg == 2)
     {
          snprintf(buffer, sizeof(buffer), " TrdSymbol_Leg2 :%s | TransType_Leg2 :%s | Token_Leg2:%s | Price_Leg2 :%f | Quantity_Leg2:%ld |"
                                           " DiscQuantity_Leg2 :%ld | AvgPrice_Leg2 :%f | FilledShares_Leg2 :%ld | UnfilledSize_Leg2:%ld |\n",
                   pIpoOrdBookResp->sMultiLegUpdate.sMultiLegParams.acTrdSymbol_Leg2,
                   pIpoOrdBookResp->sMultiLegUpdate.sMultiLegParams.acTransType_Leg2,
                   pIpoOrdBookResp->sMultiLegUpdate.sMultiLegParams.acToken_Leg2,
                   pIpoOrdBookResp->sMultiLegUpdate.sMultiLegParams.dPrice_Leg2,
                   pIpoOrdBookResp->sMultiLegUpdate.sMultiLegParams.lQuantity_Leg2,
                   pIpoOrdBookResp->sMultiLegUpdate.sMultiLegParams.lDiscQuantity_Leg2,
                   pIpoOrdBookResp->sMultiLegUpdate.dAvgPrice_Leg2,
                   pIpoOrdBookResp->sMultiLegUpdate.lFilledShares_Leg2,
                   pIpoOrdBookResp->sMultiLegUpdate.lUnfilledSize_Leg2);
          logString += buffer;
     }
     else if (pIpoOrdBookResp->sMultiLegUpdate.siLeg == 3)
     {
          snprintf(buffer, sizeof(buffer), " TrdSymbol_Leg2 :%s | TransType_Leg2 :%s | Token_Leg2:%s | Price_Leg2:%f | Quantity_Leg2:%ld |"
                                           " DiscQuantity_Leg2:%ld | AvgPrice_Leg2:%f | FilledShares_Leg2 :%ld | UnfilledSize_Leg2:%ld | TrdSymbol_Leg3 :%s |"
                                           " TransType_Leg3:%s | Token_Leg3 :%s | Price_Leg3 :%f | Quantity_Leg3:%ld | DiscQuantity_Leg3 :%ld | AvgPrice_Leg3 :%f |"
                                           " FilledShares_Leg3 :%ld | UnfilledSize_Leg3 :%ld |\n",
                   pIpoOrdBookResp->sMultiLegUpdate.sMultiLegParams.acTrdSymbol_Leg2,
                   pIpoOrdBookResp->sMultiLegUpdate.sMultiLegParams.acTransType_Leg2,
                   pIpoOrdBookResp->sMultiLegUpdate.sMultiLegParams.acToken_Leg2,
                   pIpoOrdBookResp->sMultiLegUpdate.sMultiLegParams.dPrice_Leg2,
                   pIpoOrdBookResp->sMultiLegUpdate.sMultiLegParams.lQuantity_Leg2,
                   pIpoOrdBookResp->sMultiLegUpdate.sMultiLegParams.lDiscQuantity_Leg2,
                   pIpoOrdBookResp->sMultiLegUpdate.dAvgPrice_Leg2,
                   pIpoOrdBookResp->sMultiLegUpdate.lFilledShares_Leg2,
                   pIpoOrdBookResp->sMultiLegUpdate.lUnfilledSize_Leg2,
                   pIpoOrdBookResp->sMultiLegUpdate.sMultiLegParams.acTrdSymbol_Leg3,
                   pIpoOrdBookResp->sMultiLegUpdate.sMultiLegParams.acTransType_Leg3,
                   pIpoOrdBookResp->sMultiLegUpdate.sMultiLegParams.acToken_Leg3,
                   pIpoOrdBookResp->sMultiLegUpdate.sMultiLegParams.dPrice_Leg3,
                   pIpoOrdBookResp->sMultiLegUpdate.sMultiLegParams.lQuantity_Leg3,
                   pIpoOrdBookResp->sMultiLegUpdate.sMultiLegParams.lDiscQuantity_Leg3,
                   pIpoOrdBookResp->sMultiLegUpdate.dAvgPrice_Leg3,
                   pIpoOrdBookResp->sMultiLegUpdate.lFilledShares_Leg3,
                   pIpoOrdBookResp->sMultiLegUpdate.lUnfilledSize_Leg3);
          logString += buffer;
     }
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::IpoOrderBookEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "IpoOrderBookEnd EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::MfOrderBookStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "MfOrderBookStart EchoBackData: %s ",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::MfOrderBookResp(void *pEchoBackData,
                                       tsMfOrdBook *pMfOrdBookResp)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "MfOrderBookResp :pEchoBackData:%s | RejectionQty:%ld | RejectionOrdSrc :%s | RejectionPriceType:%s | PurchaseType:%s |"
                                      "DpTrans:%s | StreamId :%s | KycStatus :%d | AllRedeem :%d | Exch :%s | Act Id :%s | Ord Duration :%s | CustomFirm :%s | Product :%s | Ord Type :%s |"
                                      " Trd Symbol :%s | Trans Type :%s | acGuiOrdId :%s | Token:%s | Price :%f | TriggerPrice :%f | Quantity :%ld | DiscQuantity :%ld | CancelledSize:%ld | OrdSrc:%s |"
                                      " acOrdRemarks:%s | acOrdRemarks:%s | acAlgoName:%s | acAlgoId :%s | acAlgoCategory:%s | Pan:%s | User :%s | VendorCode:%s | AvgPrice:%f | FilledShares :%ld | FilledShares :%ld |"
                                      " NorenOrdNum:%s | ReqId :%s | ExchOrdId:%s | Text :%s | OrdStatus :%s | Status:%c | ReportType:%s | RepTyp :%c | NorenTime Sec :%s | NorenUpdateTime:%s | lNorenUpdateTimeNanoSec:%ld |"
                                      " ExchTime:%s | ExchTimeNanoSec :%ld | ExchOrdUpdateTime:%s | RejectionBy:%s | Rejection Reason :%s | OrderGenType:%s | NorenTime MiliSec :%s | lNorenTimeNanoSec :%ld | acGuiOrgOrdId:%s |"
                                      " dMktProtectionPrice:%f | acOrderGenType :%s | dRmsPrice :%f |",
              (char *)pEchoBackData,
              pMfOrdBookResp->lRejectionQty,
              pMfOrdBookResp->acRejectionOrdSrc,
              pMfOrdBookResp->acRejectionPriceType,
              pMfOrdBookResp->acPurchaseType,
              pMfOrdBookResp->acDpTrans,
              pMfOrdBookResp->acStreamId,
              pMfOrdBookResp->bKycStatus,
              pMfOrdBookResp->bAllRedeem,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acExchSeg,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acAccountId,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acOrdDuration,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acCustomerFirm,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acProduct,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acOrderType,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acTrdSymbol,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acTransType,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acGuiOrdId,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acToken,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.dPrice,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.dTriggerPrice,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.lQuantity,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.lDiscQuantity,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.lCancelledSize,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acOrdSrc,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acOrdRemarks,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acExternalRemarks,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acAlgoName,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acAlgoId,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acAlgoCategory,
              pMfOrdBookResp->sOrderUpdate.acPan,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acUser,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acVendorCode,
              pMfOrdBookResp->sOrderUpdate.dAvgPrice,
              pMfOrdBookResp->sOrderUpdate.lFilledShares,
              pMfOrdBookResp->sOrderUpdate.lUnfilledSize,
              pMfOrdBookResp->sOrderUpdate.acNorenOrdNum,
              pMfOrdBookResp->sOrderUpdate.acReqId,
              pMfOrdBookResp->sOrderUpdate.acExchOrdId,
              pMfOrdBookResp->sOrderUpdate.acText,
              pMfOrdBookResp->sOrderUpdate.acOrdStatus,
              pMfOrdBookResp->sOrderUpdate.cStatus,
              pMfOrdBookResp->sOrderUpdate.acReportType,
              pMfOrdBookResp->sOrderUpdate.cRepTyp,
              pMfOrdBookResp->sOrderUpdate.acNorenTimeSec,
              pMfOrdBookResp->sOrderUpdate.acNorenUpdateTime,
              pMfOrdBookResp->sOrderUpdate.lNorenUpdateTimeNanoSec,
              pMfOrdBookResp->sOrderUpdate.acExchTime,
              pMfOrdBookResp->sOrderUpdate.lExchTimeNanoSec,
              pMfOrdBookResp->sOrderUpdate.acOrgExchTime,
              pMfOrdBookResp->sOrderUpdate.acRejectionBy,
              pMfOrdBookResp->sOrderUpdate.acRejReason,
              pMfOrdBookResp->sOrderUpdate.acOrderGenType,
              pMfOrdBookResp->sOrderUpdate.acNorenTimeMiliSec,
              pMfOrdBookResp->sOrderUpdate.lNorenTimeNanoSec,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.acGuiOrgOrdId,
              pMfOrdBookResp->sOrderUpdate.sOrderParams.dMktProtectionPrice,
              pMfOrdBookResp->sOrderUpdate.acOrderGenType,
              pMfOrdBookResp->sOrderUpdate.dRmsPrice);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::MfOrderBookEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "MfOrderBookEnd  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::AddHoldingsResponse(char *pStatus,
                                           void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AddHoldingsResponse Status :%s | EchoBackData :%s ",
              pStatus,
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::AddT1HoldingsResponse(char *pStatus,
                                             void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AddT1HoldingsResponse  Status :%s | EchoBackData :%s",
              pStatus,
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::ModifyHoldingsResponse(char *pStatus,
                                              char *pRejReason,
                                              void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ModifyHoldingsResponse Status :%s | RejReason :%s | EchoBackData :%s |",
              pStatus,
              pRejReason,
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GTTPlaceResponse(void *pEchoBackData,
                                        char *pGTTid,
                                        char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GTTPlaceResponse  GTTid: :%s | Status:%s | EchoBackData: %s |",
              pGTTid,
              pStatus,
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GTTModifyResponse(void *pEchoBackData,
                                         char *pGTTid,
                                         char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GTTModifyResponse GTTid:%s | Status: :%s | EchoBackData: %s |",
              pGTTid,
              pStatus,
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GTTCancelResponse(void *pEchoBackData,
                                         char *pGTTid,
                                         char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GTTCancelResponse GTTid:%s | Status:%s | EchoBackData:%s |",
              pGTTid,
              pStatus,
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GTTOrdersStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GTTOrdersStart EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GTTOrdersResp(void *pEchoBackData,
                                     tsGTTParams *pGTTParams)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GTTOrdersResp pEchoBackData :%s | SrcUserId :%s | SrcBrokerId :%s | AlName :%s | ExchSeg :%s | Token :%s |"
                                      " Validity :%s | RemarksText :%s | TrdSymbol :%s | Precision :%d | Multiplier :%d | GTTid :%s | GTTVariableName :%s | GTTVariableValue :%ld |"
                                      " acStatus :%s | lUpdateTime :%ld | lUpdateTimeNanoSec :%ld | TransType :%s | Product :%s | OrdDuration :%s | AccountId :%s | User :%s | OrdSrc :%s |"
                                      " CustomerFirm :%s | Quantity :%ld | Price :%.2f | DiscQuantity :%ld | OrdRemarks :%s | GuiOrdId :%s | BookLossPrice :%d | BookProfitPrice :%d |"
                                      " TrailingPrice :%d | iSnoOrdType :%d | ExternalRemarks :%s | AlgoName :%s | acAlgoId :%s | acAlgoCategory :%s |",
              (char *)pEchoBackData,
              pGTTParams->acSrcUserId,
              pGTTParams->acSrcBrokerId,
              pGTTParams->acAlName,
              pGTTParams->acExchSeg,
              pGTTParams->acToken,
              pGTTParams->acValidity,
              pGTTParams->acRemarksText,
              pGTTParams->acTrdSymbol,
              pGTTParams->iPrecision,
              pGTTParams->iMultiplier,
              pGTTParams->acGTTid,
              pGTTParams->acVariableName,
              pGTTParams->lVariableValue,
              pGTTParams->acStatus,
              pGTTParams->lUpdateTime,
              pGTTParams->lUpdateTimeNanoSec,
              pGTTParams->sOrderParams.acTransType,
              pGTTParams->sOrderParams.acProduct,
              pGTTParams->sOrderParams.acOrdDuration,
              pGTTParams->sOrderParams.acAccountId,
              pGTTParams->sOrderParams.acUser,
              pGTTParams->sOrderParams.acOrdSrc,
              pGTTParams->sOrderParams.acCustomerFirm,
              pGTTParams->sOrderParams.lQuantity,
              pGTTParams->sOrderParams.dPrice,
              pGTTParams->sOrderParams.lDiscQuantity,
              pGTTParams->sOrderParams.acOrdRemarks,
              pGTTParams->sOrderParams.acGuiOrdId,
              pGTTParams->sOrderParams.iBookLossPrice,
              pGTTParams->sOrderParams.iBookProfitPrice,
              pGTTParams->sOrderParams.iTrailingPrice,
              pGTTParams->sOrderParams.iSnoOrdType,
              pGTTParams->sOrderParams.acExternalRemarks,
              pGTTParams->sOrderParams.acAlgoName,
              pGTTParams->sOrderParams.acAlgoId,
              pGTTParams->sOrderParams.acAlgoCategory);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GTTOrdersEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GTTOrdersEnd EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::AllGTTOrdersStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AllGTTOrdersStart EchoBackData: %s ",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::AllGTTOrdersResp(void *pEchoBackData,
                                        tsGTTParams *pGTTParams)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AllGTTOrdersResp :pEchoBackData :%s | SrcUserId :%s | SrcBrokerId :%s | AlName :%s | ExchSeg :%s | Token :%s | Validity :%s | RemarksText :%s |"
                                      " TrdSymbol :%s | Precision :%d | Multiplier :%d | GTTid :%s | GTTVariableName :%s | GTTVariableValue :%ld | acStatus :%s | lUpdateTime :%ld | lUpdateTimeNanoSec :%ld |"
                                      " TransType :%s | Product :%s | OrdDuration :%s | AccountId :%s | User :%s | OrdSrc :%s | CustomerFirm :%s | Quantity :%ld | Price :%.2f |"
                                      " DiscQuantity :%ld | OrdRemarks :%s | GuiOrdId :%s | BookLossPrice :%d | BookProfitPrice :%d | TrailingPrice :%d | iSnoOrdType :%d |"
                                      " ExternalRemarks :%s | AlgoName :%s | acAlgoId :%s | acAlgoCategory :%s |",
              (char *)pEchoBackData,
              pGTTParams->acSrcUserId,
              pGTTParams->acSrcBrokerId,
              pGTTParams->acAlName,
              pGTTParams->acExchSeg,
              pGTTParams->acToken,
              pGTTParams->acValidity,
              pGTTParams->acRemarksText,
              pGTTParams->acTrdSymbol,
              pGTTParams->iPrecision,
              pGTTParams->iMultiplier,
              pGTTParams->acGTTid,
              pGTTParams->acVariableName,
              pGTTParams->lVariableValue,
              pGTTParams->acStatus,
              pGTTParams->lUpdateTime,
              pGTTParams->lUpdateTimeNanoSec,
              pGTTParams->sOrderParams.acTransType,
              pGTTParams->sOrderParams.acProduct,
              pGTTParams->sOrderParams.acOrdDuration,
              pGTTParams->sOrderParams.acAccountId,
              pGTTParams->sOrderParams.acUser,
              pGTTParams->sOrderParams.acOrdSrc,
              pGTTParams->sOrderParams.acCustomerFirm,
              pGTTParams->sOrderParams.lQuantity,
              pGTTParams->sOrderParams.dPrice,
              pGTTParams->sOrderParams.lDiscQuantity,
              pGTTParams->sOrderParams.acOrdRemarks,
              pGTTParams->sOrderParams.acGuiOrdId,
              pGTTParams->sOrderParams.iBookLossPrice,
              pGTTParams->sOrderParams.iBookProfitPrice,
              pGTTParams->sOrderParams.iTrailingPrice,
              pGTTParams->sOrderParams.iSnoOrdType,
              pGTTParams->sOrderParams.acExternalRemarks,
              pGTTParams->sOrderParams.acAlgoName,
              pGTTParams->sOrderParams.acAlgoId,
              pGTTParams->sOrderParams.acAlgoCategory);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::AllGTTOrdersEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AllGTTOrdersEnd EchoBackData :%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::TriggeredGTTOrdersStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "TriggeredGTTOrdersStart EchoBackData :%s ",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::TriggeredGTTOrdersResp(void *pEchoBackData,
                                              tsGTTParams *pGTTParams,
                                              char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "TriggeredGTTOrdersResp :pEchoBackData :%s | pStatus :%s | SrcUserId :%s | SrcBrokerId :%s |"
                                      "AlName :%s | ExchSeg :%s | Token :%s | Validity :%s | RemarksText :%s | TrdSymbol :%s | Precision :%d | Multiplier :%d |"
                                      "GTTid :%s | GTTVariableName :%s | GTTVariableValue :%ld | acStatus :%s | lUpdateTime :%ld | lUpdateTimeNanoSec :%ld |"
                                      "TransType :%s | Product :%s | OrdDuration :%s | AccountId :%s | User :%s | OrdSrc :%s | CustomerFirm :%s | Quantity :%ld |"
                                      "Price :%f | DiscQuantity :%ld | OrdRemarks :%s | GuiOrdId :%s | BookLossPrice :%d | BookProfitPrice :%d | TrailingPrice :%d |"
                                      "iSnoOrdType :%d | ExternalRemarks :%s | AlgoName :%s | acAlgoId :%s | acAlgoCategory :%s |",
              (char *)pEchoBackData,
              pStatus,
              pGTTParams->acSrcUserId,
              pGTTParams->acSrcBrokerId,
              pGTTParams->acAlName,
              pGTTParams->acExchSeg,
              pGTTParams->acToken,
              pGTTParams->acValidity,
              pGTTParams->acRemarksText,
              pGTTParams->acTrdSymbol,
              pGTTParams->iPrecision,
              pGTTParams->iMultiplier,
              pGTTParams->acGTTid,
              pGTTParams->acVariableName,
              pGTTParams->lVariableValue,
              pGTTParams->acStatus,
              pGTTParams->lUpdateTime,
              pGTTParams->lUpdateTimeNanoSec,
              pGTTParams->sOrderParams.acTransType,
              pGTTParams->sOrderParams.acProduct,
              pGTTParams->sOrderParams.acOrdDuration,
              pGTTParams->sOrderParams.acAccountId,
              pGTTParams->sOrderParams.acUser,
              pGTTParams->sOrderParams.acOrdSrc,
              pGTTParams->sOrderParams.acCustomerFirm,
              pGTTParams->sOrderParams.lQuantity,
              pGTTParams->sOrderParams.dPrice,
              pGTTParams->sOrderParams.lDiscQuantity,
              pGTTParams->sOrderParams.acOrdRemarks,
              pGTTParams->sOrderParams.acGuiOrdId,
              pGTTParams->sOrderParams.iBookLossPrice,
              pGTTParams->sOrderParams.iBookProfitPrice,
              pGTTParams->sOrderParams.iTrailingPrice,
              pGTTParams->sOrderParams.iSnoOrdType,
              pGTTParams->sOrderParams.acExternalRemarks,
              pGTTParams->sOrderParams.acAlgoName,
              pGTTParams->sOrderParams.acAlgoId,
              pGTTParams->sOrderParams.acAlgoCategory);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::TriggeredGTTOrdersEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "TriggeredGTTOrdersEnd EchoBackData: %s ",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::AllTriggeredGTTOrdersStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AllTriggeredGTTOrdersStart EchoBackData:%s ",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::AllTriggeredGTTOrdersResp(void *pEchoBackData,
                                                 tsGTTParams *pGTTParams,
                                                 char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AllTriggeredGTTOrdersResp :pEchoBackData :%s | pStatus :%s | SrcUserId :%s | SrcBrokerId :%s | AlName :%s | ExchSeg :%s | Token :%s |"
                                      "Validity :%s | RemarksText :%s | TrdSymbol :%s | Precision :%d | Multiplier :%d | GTTid :%s | GTTVariableName :%s | GTTVariableValue :%ld | acStatus :%s|"
                                      "lUpdateTime :%ld | lUpdateTimeNanoSec :%ld | TransType :%s | Product :%s | OrdDuration :%s | AccountId :%s | User :%s | OrdSrc :%s | CustomerFirm :%s |"
                                      "Quantity :%ld | Price :%f | DiscQuantity:%ld | OrdRemarks :%s | GuiOrdId :%s | BookLossPrice :%d | BookProfitPrice :%d | TrailingPrice :%d |"
                                      "iSnoOrdType :%d | ExternalRemarks :%s | AlgoName:%s | acAlgoId:%s | acAlgoCategory:%s |",
              (char *)pEchoBackData,
              pStatus,
              pGTTParams->acSrcUserId,
              pGTTParams->acSrcBrokerId,
              pGTTParams->acAlName,
              pGTTParams->acExchSeg,
              pGTTParams->acToken,
              pGTTParams->acValidity,
              pGTTParams->acRemarksText,
              pGTTParams->acTrdSymbol,
              pGTTParams->iPrecision,
              pGTTParams->iMultiplier,
              pGTTParams->acGTTid,
              pGTTParams->acVariableName,
              pGTTParams->lVariableValue,
              pGTTParams->acStatus,
              pGTTParams->lUpdateTime,
              pGTTParams->lUpdateTimeNanoSec,
              pGTTParams->sOrderParams.acTransType,
              pGTTParams->sOrderParams.acProduct,
              pGTTParams->sOrderParams.acOrdDuration,
              pGTTParams->sOrderParams.acAccountId,
              pGTTParams->sOrderParams.acUser,
              pGTTParams->sOrderParams.acOrdSrc,
              pGTTParams->sOrderParams.acCustomerFirm,
              pGTTParams->sOrderParams.lQuantity,
              pGTTParams->sOrderParams.dPrice,
              pGTTParams->sOrderParams.lDiscQuantity,
              pGTTParams->sOrderParams.acOrdRemarks,
              pGTTParams->sOrderParams.acGuiOrdId,
              pGTTParams->sOrderParams.iBookLossPrice,
              pGTTParams->sOrderParams.iBookProfitPrice,
              pGTTParams->sOrderParams.iTrailingPrice,
              pGTTParams->sOrderParams.iSnoOrdType,
              pGTTParams->sOrderParams.acExternalRemarks,
              pGTTParams->sOrderParams.acAlgoName,
              pGTTParams->sOrderParams.acAlgoId,
              pGTTParams->sOrderParams.acAlgoCategory);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::AllTriggeredGTTOrdersEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AllTriggeredGTTOrdersEnd EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::OCOPlaceResponse(void *pEchoBackData,
                                        char *pOCOid,
                                        char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OCOPlaceResponse OCOid: %s | Status: %s | EchoBackData:%s |",
              pOCOid,
              pStatus,
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::OCOModifyResponse(void *pEchoBackData,
                                         char *pOCOid,
                                         char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OCOModifyResponse  OCOid: %s | Status: %s | EchoBackData: %s|",
              pOCOid,
              pStatus,
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::OCOCancelResponse(void *pEchoBackData,
                                         char *pOCOid,
                                         char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OCOCancelResponse  OCOid:%s | Status: %s | EchoBackData: %s|",
              pOCOid,
              pStatus,
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::OCOOrdersStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OCOOrdersStart EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::OCOOrdersResp(void *pEchoBackData,
                                     tsOCOParams *pOCOParams)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OCOOrdersResp :pEchoBackData :%s | SrcUserId :%s | SrcBrokerId :%s | AlName :%s | ExchSeg :%s | Token :%s | Validity :%s | RemarksText :%s |"
                                      "TrdSymbol :%s | Precision :%d | Multiplier :%d | OCOid :%s | acStatus :%s | lUpdateTime :%ld | lUpdateTimeNanoSec :%ld | OCOVariableNameLeg1 :%s | OCOVariableValueLeg1 :%ld |"
                                      "OCOVariableNameLeg2 :%s | OCOVariableValueLeg2 :%ld | TransTypeLeg1 :%s | Product :%s | OrdDuration :%s | AccountId :%s | User :%s | OrdSrc :%s | CustomerFirm :%s | QuantityLeg1 :%ld |"
                                      "PriceLeg1 :%f | DiscQuantityLeg1 :%ld | OrdRemarks :%s | GuiOrdId :%s | BookLossPrice :%d | BookProfitPrice :%d | TrailingPrice :%d | iSnoOrdType :%d | ExternalRemarks1 :%s | AlgoName1 :%s |"
                                      "acAlgoId1 :%s | acAlgoCategory1 :%s | TransTypeLeg2 :%s | QuantityLeg2 :%ld | PriceLeg2 :%f | DiscQuantityLeg2 :%ld | AlgoName2 :%s | ExternalRemarks2 :%s | acAlgoId2 :%s | acAlgoCategory2 :%s |",
              (char *)pEchoBackData,
              pOCOParams->acSrcUserId,
              pOCOParams->acSrcBrokerId,
              pOCOParams->acAlName,
              pOCOParams->acExchSeg,
              pOCOParams->acToken,
              pOCOParams->acValidity,
              pOCOParams->acRemarksText,
              pOCOParams->acTrdSymbol,
              pOCOParams->iPrecision,
              pOCOParams->iMultiplier,
              pOCOParams->acOCOid,
              pOCOParams->acStatus,
              pOCOParams->lUpdateTime,
              pOCOParams->lUpdateTimeNanoSec,
              pOCOParams->acVariableNameLeg1,
              pOCOParams->lVariableValueLeg1,
              pOCOParams->acVariableNameLeg2,
              pOCOParams->lVariableValueLeg2,
              pOCOParams->sOrderParamsLeg1.acTransType,
              pOCOParams->sOrderParamsLeg1.acProduct,
              pOCOParams->sOrderParamsLeg1.acOrdDuration,
              pOCOParams->sOrderParamsLeg1.acAccountId,
              pOCOParams->sOrderParamsLeg1.acUser,
              pOCOParams->sOrderParamsLeg1.acOrdSrc,
              pOCOParams->sOrderParamsLeg1.acCustomerFirm,
              pOCOParams->sOrderParamsLeg1.lQuantity,
              pOCOParams->sOrderParamsLeg1.dPrice,
              pOCOParams->sOrderParamsLeg1.lDiscQuantity,
              pOCOParams->sOrderParamsLeg1.acOrdRemarks,
              pOCOParams->sOrderParamsLeg1.acGuiOrdId,
              pOCOParams->sOrderParamsLeg1.iBookLossPrice,
              pOCOParams->sOrderParamsLeg1.iBookProfitPrice,
              pOCOParams->sOrderParamsLeg1.iTrailingPrice,
              pOCOParams->sOrderParamsLeg1.iSnoOrdType,
              pOCOParams->sOrderParamsLeg1.acExternalRemarks,
              pOCOParams->sOrderParamsLeg1.acAlgoName,
              pOCOParams->sOrderParamsLeg1.acAlgoId,
              pOCOParams->sOrderParamsLeg1.acAlgoCategory,
              pOCOParams->sOrderParamsLeg2.acTransType,
              pOCOParams->sOrderParamsLeg2.lQuantity,
              pOCOParams->sOrderParamsLeg2.dPrice,
              pOCOParams->sOrderParamsLeg2.lDiscQuantity,
              pOCOParams->sOrderParamsLeg2.acAlgoName,
              pOCOParams->sOrderParamsLeg2.acExternalRemarks,
              pOCOParams->sOrderParamsLeg2.acAlgoId,
              pOCOParams->sOrderParamsLeg2.acAlgoCategory);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::OCOOrdersEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OCOOrdersEnd EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::AllOCOOrdersStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AllOCOOrdersStart EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::AllOCOOrdersResp(void *pEchoBackData,
                                        tsOCOParams *pOCOParams)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AllOCOOrdersResp :pEchoBackData :%s | SrcUserId :%s | SrcBrokerId :%s | AlName :%s | ExchSeg :%s | Token :%s | Validity :%s | RemarksText :%s |"
                                      "TrdSymbol :%s | Precision :%d | Multiplier :%d | OCOid :%s | acStatus :%s | lUpdateTime :%ld | lUpdateTimeNanoSec :%ld | OCOVariableNameLeg1 :%s | OCOVariableValueLeg1 :%ld |"
                                      "OCOVariableNameLeg2 :%s | OCOVariableValueLeg2 :%ld | TransTypeLeg1 :%s | Product :%s | OrdDuration :%s | AccountId :%s | User :%s | OrdSrc :%s | CustomerFirm :%s | QuantityLeg1 :%ld |"
                                      "PriceLeg1 :%f | DiscQuantityLeg1 :%ld | OrdRemarks :%s | GuiOrdId :%s | BookLossPrice :%d | BookProfitPrice :%d | TrailingPrice :%d | iSnoOrdType :%d | ExternalRemarks1 :%s | AlgoName1 :%s |"
                                      "acAlgoId1 :%s | acAlgoCategory1 :%s | TransTypeLeg2 :%s | QuantityLeg2 :%ld | PriceLeg2 :%f | DiscQuantityLeg2 :%ld | AlgoName2 :%s | ExternalRemarks2 :%s | acAlgoId2 :%s | acAlgoCategory2 :%s |",
              (char *)pEchoBackData,
              pOCOParams->acSrcUserId,
              pOCOParams->acSrcBrokerId,
              pOCOParams->acAlName,
              pOCOParams->acExchSeg,
              pOCOParams->acToken,
              pOCOParams->acValidity,
              pOCOParams->acRemarksText,
              pOCOParams->acTrdSymbol,
              pOCOParams->iPrecision,
              pOCOParams->iMultiplier,
              pOCOParams->acOCOid,
              pOCOParams->acStatus,
              pOCOParams->lUpdateTime,
              pOCOParams->lUpdateTimeNanoSec,
              pOCOParams->acVariableNameLeg1,
              pOCOParams->lVariableValueLeg1,
              pOCOParams->acVariableNameLeg2,
              pOCOParams->lVariableValueLeg2,
              pOCOParams->sOrderParamsLeg1.acTransType,
              pOCOParams->sOrderParamsLeg1.acProduct,
              pOCOParams->sOrderParamsLeg1.acOrdDuration,
              pOCOParams->sOrderParamsLeg1.acAccountId,
              pOCOParams->sOrderParamsLeg1.acUser,
              pOCOParams->sOrderParamsLeg1.acOrdSrc,
              pOCOParams->sOrderParamsLeg1.acCustomerFirm,
              pOCOParams->sOrderParamsLeg1.lQuantity,
              pOCOParams->sOrderParamsLeg1.dPrice,
              pOCOParams->sOrderParamsLeg1.lDiscQuantity,
              pOCOParams->sOrderParamsLeg1.acOrdRemarks,
              pOCOParams->sOrderParamsLeg1.acGuiOrdId,
              pOCOParams->sOrderParamsLeg1.iBookLossPrice,
              pOCOParams->sOrderParamsLeg1.iBookProfitPrice,
              pOCOParams->sOrderParamsLeg1.iTrailingPrice,
              pOCOParams->sOrderParamsLeg1.iSnoOrdType,
              pOCOParams->sOrderParamsLeg1.acExternalRemarks,
              pOCOParams->sOrderParamsLeg1.acAlgoName,
              pOCOParams->sOrderParamsLeg1.acAlgoId,
              pOCOParams->sOrderParamsLeg1.acAlgoCategory,
              pOCOParams->sOrderParamsLeg2.acTransType,
              pOCOParams->sOrderParamsLeg2.lQuantity,
              pOCOParams->sOrderParamsLeg2.dPrice,
              pOCOParams->sOrderParamsLeg2.lDiscQuantity,
              pOCOParams->sOrderParamsLeg2.acAlgoName,
              pOCOParams->sOrderParamsLeg2.acExternalRemarks,
              pOCOParams->sOrderParamsLeg2.acAlgoId,
              pOCOParams->sOrderParamsLeg2.acAlgoCategory);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::AllOCOOrdersEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AllOCOOrdersEnd  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::TriggeredOCOOrdersStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "TriggeredOCOOrdersStart EchoBackData: %s ",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::TriggeredOCOOrdersResp(void *pEchoBackData,
                                              tsOCOParams *pOCOParams,
                                              char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "TriggeredOCOOrdersResp :pEchoBackData :%s |pStatus :%s | SrcUserId :%s | SrcBrokerId :%s | AlName :%s | ExchSeg :%s | Token :%s | Validity :%s | RemarksText :%s |"
                                      "TrdSymbol :%s | Precision :%d | Multiplier :%d | OCOid :%s | acStatus :%s | lUpdateTime :%ld | lUpdateTimeNanoSec :%ld | OCOVariableNameLeg1 :%s | OCOVariableValueLeg1 :%ld |"
                                      "OCOVariableNameLeg2 :%s | OCOVariableValueLeg2 :%ld | TransTypeLeg1 :%s | Product :%s | OrdDuration :%s | AccountId :%s | User :%s | OrdSrc :%s | CustomerFirm :%s | QuantityLeg1 :%ld |"
                                      "PriceLeg1 :%f | DiscQuantityLeg1 :%ld | OrdRemarks :%s | GuiOrdId :%s | BookLossPrice :%d | BookProfitPrice :%d | TrailingPrice :%d | iSnoOrdType :%d | ExternalRemarks1 :%s | AlgoName1 :%s |"
                                      "acAlgoId1 :%s | acAlgoCategory1 :%s | TransTypeLeg2 :%s | QuantityLeg2 :%ld | PriceLeg2 :%f | DiscQuantityLeg2 :%ld | AlgoName2 :%s | ExternalRemarks2 :%s | acAlgoId2 :%s | acAlgoCategory2 :%s |",
              (char *)pEchoBackData,
              pStatus,
              pOCOParams->acSrcUserId,
              pOCOParams->acSrcBrokerId,
              pOCOParams->acAlName,
              pOCOParams->acExchSeg,
              pOCOParams->acToken,
              pOCOParams->acValidity,
              pOCOParams->acRemarksText,
              pOCOParams->acTrdSymbol,
              pOCOParams->iPrecision,
              pOCOParams->iMultiplier,
              pOCOParams->acOCOid,
              pOCOParams->acStatus,
              pOCOParams->lUpdateTime,
              pOCOParams->lUpdateTimeNanoSec,
              pOCOParams->acVariableNameLeg1,
              pOCOParams->lVariableValueLeg1,
              pOCOParams->acVariableNameLeg2,
              pOCOParams->lVariableValueLeg2,
              pOCOParams->sOrderParamsLeg1.acTransType,
              pOCOParams->sOrderParamsLeg1.acProduct,
              pOCOParams->sOrderParamsLeg1.acOrdDuration,
              pOCOParams->sOrderParamsLeg1.acAccountId,
              pOCOParams->sOrderParamsLeg1.acUser,
              pOCOParams->sOrderParamsLeg1.acOrdSrc,
              pOCOParams->sOrderParamsLeg1.acCustomerFirm,
              pOCOParams->sOrderParamsLeg1.lQuantity,
              pOCOParams->sOrderParamsLeg1.dPrice,
              pOCOParams->sOrderParamsLeg1.lDiscQuantity,
              pOCOParams->sOrderParamsLeg1.acOrdRemarks,
              pOCOParams->sOrderParamsLeg1.acGuiOrdId,
              pOCOParams->sOrderParamsLeg1.iBookLossPrice,
              pOCOParams->sOrderParamsLeg1.iBookProfitPrice,
              pOCOParams->sOrderParamsLeg1.iTrailingPrice,
              pOCOParams->sOrderParamsLeg1.iSnoOrdType,
              pOCOParams->sOrderParamsLeg1.acExternalRemarks,
              pOCOParams->sOrderParamsLeg1.acAlgoName,
              pOCOParams->sOrderParamsLeg1.acAlgoId,
              pOCOParams->sOrderParamsLeg1.acAlgoCategory,
              pOCOParams->sOrderParamsLeg2.acTransType,
              pOCOParams->sOrderParamsLeg2.lQuantity,
              pOCOParams->sOrderParamsLeg2.dPrice,
              pOCOParams->sOrderParamsLeg2.lDiscQuantity,
              pOCOParams->sOrderParamsLeg2.acAlgoName,
              pOCOParams->sOrderParamsLeg2.acExternalRemarks,
              pOCOParams->sOrderParamsLeg2.acAlgoId,
              pOCOParams->sOrderParamsLeg2.acAlgoCategory);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::TriggeredOCOOrdersEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "TriggeredOCOOrdersEnd  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::AllTriggeredOCOOrdersStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AllTriggeredOCOOrdersStart EchoBackData:%s ",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::AllTriggeredOCOOrdersResp(void *pEchoBackData,
                                                 tsOCOParams *pOCOParams,
                                                 char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AllTriggeredOCOOrdersResp :pEchoBackData :%s |pStatus :%s | SrcUserId :%s | SrcBrokerId :%s | AlName :%s | ExchSeg :%s | Token :%s | Validity :%s | RemarksText :%s |"
                                      "TrdSymbol :%s | Precision :%d | Multiplier :%d | OCOid :%s | acStatus :%s | lUpdateTime :%ld | lUpdateTimeNanoSec :%ld | OCOVariableNameLeg1 :%s | OCOVariableValueLeg1 :%ld |"
                                      "OCOVariableNameLeg2 :%s | OCOVariableValueLeg2 :%ld | TransTypeLeg1 :%s | Product :%s | OrdDuration :%s | AccountId :%s | User :%s | OrdSrc :%s | CustomerFirm :%s | QuantityLeg1 :%ld |"
                                      "PriceLeg1 :%f | DiscQuantityLeg1 :%ld | OrdRemarks :%s | GuiOrdId :%s | BookLossPrice :%d | BookProfitPrice :%d | TrailingPrice :%d | iSnoOrdType :%d | ExternalRemarks1 :%s | AlgoName1 :%s |"
                                      "acAlgoId1 :%s | acAlgoCategory1 :%s | TransTypeLeg2 :%s | QuantityLeg2 :%ld | PriceLeg2 :%f | DiscQuantityLeg2 :%ld | AlgoName2 :%s | ExternalRemarks2 :%s | acAlgoId2 :%s | acAlgoCategory2 :%s |",
              (char *)pEchoBackData,
              pStatus,
              pOCOParams->acSrcUserId,
              pOCOParams->acSrcBrokerId,
              pOCOParams->acAlName,
              pOCOParams->acExchSeg,
              pOCOParams->acToken,
              pOCOParams->acValidity,
              pOCOParams->acRemarksText,
              pOCOParams->acTrdSymbol,
              pOCOParams->iPrecision,
              pOCOParams->iMultiplier,
              pOCOParams->acOCOid,
              pOCOParams->acStatus,
              pOCOParams->lUpdateTime,
              pOCOParams->lUpdateTimeNanoSec,
              pOCOParams->acVariableNameLeg1,
              pOCOParams->lVariableValueLeg1,
              pOCOParams->acVariableNameLeg2,
              pOCOParams->lVariableValueLeg2,
              pOCOParams->sOrderParamsLeg1.acTransType,
              pOCOParams->sOrderParamsLeg1.acProduct,
              pOCOParams->sOrderParamsLeg1.acOrdDuration,
              pOCOParams->sOrderParamsLeg1.acAccountId,
              pOCOParams->sOrderParamsLeg1.acUser,
              pOCOParams->sOrderParamsLeg1.acOrdSrc,
              pOCOParams->sOrderParamsLeg1.acCustomerFirm,
              pOCOParams->sOrderParamsLeg1.lQuantity,
              pOCOParams->sOrderParamsLeg1.dPrice,
              pOCOParams->sOrderParamsLeg1.lDiscQuantity,
              pOCOParams->sOrderParamsLeg1.acOrdRemarks,
              pOCOParams->sOrderParamsLeg1.acGuiOrdId,
              pOCOParams->sOrderParamsLeg1.iBookLossPrice,
              pOCOParams->sOrderParamsLeg1.iBookProfitPrice,
              pOCOParams->sOrderParamsLeg1.iTrailingPrice,
              pOCOParams->sOrderParamsLeg1.iSnoOrdType,
              pOCOParams->sOrderParamsLeg1.acExternalRemarks,
              pOCOParams->sOrderParamsLeg1.acAlgoName,
              pOCOParams->sOrderParamsLeg1.acAlgoId,
              pOCOParams->sOrderParamsLeg1.acAlgoCategory,
              pOCOParams->sOrderParamsLeg2.acTransType,
              pOCOParams->sOrderParamsLeg2.lQuantity,
              pOCOParams->sOrderParamsLeg2.dPrice,
              pOCOParams->sOrderParamsLeg2.lDiscQuantity,
              pOCOParams->sOrderParamsLeg2.acAlgoName,
              pOCOParams->sOrderParamsLeg2.acExternalRemarks,
              pOCOParams->sOrderParamsLeg2.acAlgoId,
              pOCOParams->sOrderParamsLeg2.acAlgoCategory);

     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::AllTriggeredOCOOrdersEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AllTriggeredOCOOrdersEnd EchoBackData :%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GTTOCOOrdersStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GTTOCOOrdersStart  EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GTTOCOOrdersResp(void *pEchoBackData,
                                        tsOCOParams *pOCOParams)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GTTOCOOrdersResp :pEchoBackData :%s | SrcUserId :%s | SrcBrokerId :%s | AlName :%s | ExchSeg :%s | Token :%s | Validity :%s | RemarksText :%s |"
                                      "TrdSymbol :%s | Precision :%d | Multiplier :%d | OCOid :%s | acStatus :%s | lUpdateTime :%ld | lUpdateTimeNanoSec :%ld | OCOVariableNameLeg1 :%s | OCOVariableValueLeg1 :%ld |"
                                      " TransTypeLeg1 :%s | Product :%s | OrdDuration :%s | AccountId :%s | User :%s | OrdSrc :%s | CustomerFirm :%s | QuantityLeg1 :%ld |"
                                      "PriceLeg1 :%f | DiscQuantityLeg1 :%ld | OrdRemarks :%s | GuiOrdId :%s | BookLossPrice :%d | BookProfitPrice :%d | TrailingPrice :%d | iSnoOrdType :%d | ExternalRemarks1 :%s | AlgoName1 :%s |"
                                      "acAlgoId1 :%s | acAlgoCategory1 :%s\n|",
              (char *)pEchoBackData,
              pOCOParams->acSrcUserId,
              pOCOParams->acSrcBrokerId,
              pOCOParams->acAlName,
              pOCOParams->acExchSeg,
              pOCOParams->acToken,
              pOCOParams->acValidity,
              pOCOParams->acRemarksText,
              pOCOParams->acTrdSymbol,
              pOCOParams->iPrecision,
              pOCOParams->iMultiplier,
              pOCOParams->acOCOid,
              pOCOParams->acStatus,
              pOCOParams->lUpdateTime,
              pOCOParams->lUpdateTimeNanoSec,
              pOCOParams->acVariableNameLeg1,
              pOCOParams->lVariableValueLeg1,
              pOCOParams->sOrderParamsLeg1.acTransType,
              pOCOParams->sOrderParamsLeg1.acProduct,
              pOCOParams->sOrderParamsLeg1.acOrdDuration,
              pOCOParams->sOrderParamsLeg1.acAccountId,
              pOCOParams->sOrderParamsLeg1.acUser,
              pOCOParams->sOrderParamsLeg1.acOrdSrc,
              pOCOParams->sOrderParamsLeg1.acCustomerFirm,
              pOCOParams->sOrderParamsLeg1.lQuantity,
              pOCOParams->sOrderParamsLeg1.dPrice,
              pOCOParams->sOrderParamsLeg1.lDiscQuantity,
              pOCOParams->sOrderParamsLeg1.acOrdRemarks,
              pOCOParams->sOrderParamsLeg1.acGuiOrdId,
              pOCOParams->sOrderParamsLeg1.iBookLossPrice,
              pOCOParams->sOrderParamsLeg1.iBookProfitPrice,
              pOCOParams->sOrderParamsLeg1.iTrailingPrice,
              pOCOParams->sOrderParamsLeg1.iSnoOrdType,
              pOCOParams->sOrderParamsLeg1.acExternalRemarks,
              pOCOParams->sOrderParamsLeg1.acAlgoName,
              pOCOParams->sOrderParamsLeg1.acAlgoId,
              pOCOParams->sOrderParamsLeg1.acAlgoCategory);
     logString += buffer;

     if (pOCOParams->acVariableNameLeg2)
     {
          snprintf(buffer, sizeof(buffer), " OCOVariableNameLeg2 :%s | OCOVariableValueLeg2 :%ld | TransTypeLeg2 :%s | QuantityLeg2 :%ld |"
                                           " PriceLeg2 :%f | DiscQuantityLeg2 :%ld | AlgoName2 :%s | ExternalRemarks2 :%s | acAlgoId2 :%s | acAlgoCategory2 :%s \n|",
                   pOCOParams->acVariableNameLeg2,
                   pOCOParams->lVariableValueLeg2,
                   pOCOParams->sOrderParamsLeg2.acTransType,
                   pOCOParams->sOrderParamsLeg2.lQuantity,
                   pOCOParams->sOrderParamsLeg2.dPrice,
                   pOCOParams->sOrderParamsLeg2.lDiscQuantity,
                   pOCOParams->sOrderParamsLeg2.acAlgoName,
                   pOCOParams->sOrderParamsLeg2.acExternalRemarks,
                   pOCOParams->sOrderParamsLeg2.acAlgoId,
                   pOCOParams->sOrderParamsLeg2.acAlgoCategory);
          logString += buffer;
     }
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GTTOCOOrdersEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GTTOCOOrdersEnd  EchoBackData: %s ",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::TriggeredGTTOCOOrdersStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "TriggeredGTTOCOOrdersStart  EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::TriggeredGTTOCOOrdersResp(void *pEchoBackData,
                                                 tsOCOParams *pOCOParams,
                                                 char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "TriggeredGTTOCOOrdersResp :pEchoBackData :%s | pStatus :%s |  SrcUserId :%s | SrcBrokerId :%s | AlName :%s | ExchSeg :%s | Token :%s | Validity :%s | RemarksText :%s |"
                                      "TrdSymbol :%s | Precision :%d | Multiplier :%d | OCOid :%s | acStatus :%s | lUpdateTime :%ld | lUpdateTimeNanoSec :%ld | OCOVariableNameLeg1 :%s | OCOVariableValueLeg1 :%ld |"
                                      " TransTypeLeg1 :%s | Product :%s | OrdDuration :%s | AccountId :%s | User :%s | OrdSrc :%s | CustomerFirm :%s | QuantityLeg1 :%ld |"
                                      "PriceLeg1 :%f | DiscQuantityLeg1 :%ld | OrdRemarks :%s | GuiOrdId :%s | BookLossPrice :%d | BookProfitPrice :%d | TrailingPrice :%d | iSnoOrdType :%d | ExternalRemarks1 :%s | AlgoName1 :%s |"
                                      "acAlgoId1 :%s | acAlgoCategory1 :%s\n|",
              (char *)pEchoBackData,
              pStatus,
              pOCOParams->acSrcUserId,
              pOCOParams->acSrcBrokerId,
              pOCOParams->acAlName,
              pOCOParams->acExchSeg,
              pOCOParams->acToken,
              pOCOParams->acValidity,
              pOCOParams->acRemarksText,
              pOCOParams->acTrdSymbol,
              pOCOParams->iPrecision,
              pOCOParams->iMultiplier,
              pOCOParams->acOCOid,
              pOCOParams->acStatus,
              pOCOParams->lUpdateTime,
              pOCOParams->lUpdateTimeNanoSec,
              pOCOParams->acVariableNameLeg1,
              pOCOParams->lVariableValueLeg1,
              pOCOParams->sOrderParamsLeg1.acTransType,
              pOCOParams->sOrderParamsLeg1.acProduct,
              pOCOParams->sOrderParamsLeg1.acOrdDuration,
              pOCOParams->sOrderParamsLeg1.acAccountId,
              pOCOParams->sOrderParamsLeg1.acUser,
              pOCOParams->sOrderParamsLeg1.acOrdSrc,
              pOCOParams->sOrderParamsLeg1.acCustomerFirm,
              pOCOParams->sOrderParamsLeg1.lQuantity,
              pOCOParams->sOrderParamsLeg1.dPrice,
              pOCOParams->sOrderParamsLeg1.lDiscQuantity,
              pOCOParams->sOrderParamsLeg1.acOrdRemarks,
              pOCOParams->sOrderParamsLeg1.acGuiOrdId,
              pOCOParams->sOrderParamsLeg1.iBookLossPrice,
              pOCOParams->sOrderParamsLeg1.iBookProfitPrice,
              pOCOParams->sOrderParamsLeg1.iTrailingPrice,
              pOCOParams->sOrderParamsLeg1.iSnoOrdType,
              pOCOParams->sOrderParamsLeg1.acExternalRemarks,
              pOCOParams->sOrderParamsLeg1.acAlgoName,
              pOCOParams->sOrderParamsLeg1.acAlgoId,
              pOCOParams->sOrderParamsLeg1.acAlgoCategory);
     logString += buffer;

     if (pOCOParams->acVariableNameLeg2)
     {
          snprintf(buffer, sizeof(buffer), " OCOVariableNameLeg2 :%s | OCOVariableValueLeg2 :%ld | TransTypeLeg2 :%s | QuantityLeg2 :%ld |"
                                           " PriceLeg2 :%f | DiscQuantityLeg2 :%ld | AlgoName2 :%s | ExternalRemarks2 :%s | acAlgoId2 :%s | acAlgoCategory2 :%s \n|",
                   pOCOParams->acVariableNameLeg2,
                   pOCOParams->lVariableValueLeg2,
                   pOCOParams->sOrderParamsLeg2.acTransType,
                   pOCOParams->sOrderParamsLeg2.lQuantity,
                   pOCOParams->sOrderParamsLeg2.dPrice,
                   pOCOParams->sOrderParamsLeg2.lDiscQuantity,
                   pOCOParams->sOrderParamsLeg2.acAlgoName,
                   pOCOParams->sOrderParamsLeg2.acExternalRemarks,
                   pOCOParams->sOrderParamsLeg2.acAlgoId,
                   pOCOParams->sOrderParamsLeg2.acAlgoCategory);
          logString += buffer;
     }
     std::clog << logString << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::TriggeredGTTOCOOrdersEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "TriggeredGTTOCOOrdersEnd EchoBackData:%s ",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::ModifyUserResponse(char *pUserId,
                                          void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ModifyUserResponse EchoBackData: %s | UserId: %s ",
              (char *)pEchoBackData,
              pUserId);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::ModifyUserUnSubscribeResponse(char *pStatus,
                                                     void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ModifyUserUnSubscribeResponse EchoBackData:%s | pStatus:%s",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::PeakMarginUpdate(char *pAcctId,
                                        double dAmount,
                                        void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PeakMarginUpdate EchoBackData: %s | AcctId: %s | dAmount:%f",
              (char *)pEchoBackData,
              pAcctId,
              dAmount);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::PeakMarginUnSubscribeResponse(char *pStatus,
                                                     void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PeakMarginUnSubscribeResponse  pEchoBackData :%s| pStatus: %s|",
              (char *)pEchoBackData, pStatus);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::ExpiryMarginUpdate(char *pAcctId,
                                          double dAmount,
                                          void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ExpiryMarginUpdate  EchoBackData :%s | AcctId: %s | dAmount: %f |",
              (char *)pEchoBackData,
              pAcctId,
              dAmount);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::ExpiryMarginUnSubscribeResponse(char *pStatus,
                                                       void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ExpiryMarginUnSubscribeResponse EchoBackData: %s| pStatus: %s",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::RiskDashBoardUpdate(tsRiskDasBoard *pRiskDasBoardResp,
                                           void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::clog << std::fixed << "RiskDashBoardUpdate "
               << " EchoBackData: "
               << (char *)pEchoBackData
               << " AcctId: "
               << pRiskDasBoardResp->acAcctId
               << " TotalCash: "
               << pRiskDasBoardResp->dTotalCash
               << " TotalMtoM: "
               << pRiskDasBoardResp->dTotalMtoM
               << " MtoMWarningPercentage: "
               << pRiskDasBoardResp->dMtoMWarningPercentage
               << " MtoMWarningIncrPercentage: "
               << pRiskDasBoardResp->dMtoMWarningIncrPercentage
               << " MtoMSqrOffPercentage: "
               << pRiskDasBoardResp->dMtoMSqrOffPercentage
               << " ProfileName: "
               << pRiskDasBoardResp->acProfileName
               << " MtoMWarningFollowPercentage: "
               << pRiskDasBoardResp->dMtoMWarningFollowPercentage
               << " TotalMarginCash: "
               << pRiskDasBoardResp->dTotalMarginCash
               << " TotalMargin: "
               << pRiskDasBoardResp->dTotalMargin
               << " MarginWarningPercentage: "
               << pRiskDasBoardResp->dMarginWarningPercentage
               << " MarginWarningIncrPercentage: "
               << pRiskDasBoardResp->dMarginWarningIncrPercentage
               << " MarginSqrOffPercentage: "
               << pRiskDasBoardResp->dMarginSqrOffPercentage
               << " MarginCurrentPercentage: "
               << pRiskDasBoardResp->dMarginCurrentPercentage
               << " MarginWarningFollowPercentage: "
               << pRiskDasBoardResp->dMarginWarningFollowPercentage
               << " MarginUsed: "
               << pRiskDasBoardResp->dMarginUsed
               << " Span: "
               << pRiskDasBoardResp->dSpan
               << " SpanDerIntraday: "
               << pRiskDasBoardResp->dSpanDerIntraday
               << " Exposure: "
               << pRiskDasBoardResp->dExposure
               << " ExposureDerIntraday: "
               << pRiskDasBoardResp->dExposureDerIntraday
               << " TurnOver: "
               << pRiskDasBoardResp->dTurnOver
               << " PeakMargin: "
               << pRiskDasBoardResp->dPeakMargin
               << " ExpiryMargin: "
               << pRiskDasBoardResp->dExpiryMargin
               << " dCollateralValue: "
               << pRiskDasBoardResp->dCollateralValue
               << " dNotionalCash: "
               << pRiskDasBoardResp->dNotionalCash
               << " dCollateral: "
               << pRiskDasBoardResp->dCollateral
               << " dRmsPayInAmt: "
               << pRiskDasBoardResp->dRmsPayInAmt
               << " dRealizedMtomPrsnt: "
               << pRiskDasBoardResp->dRealizedMtomPrsnt
               << " dUnrealizedMtomPrsnt: "
               << pRiskDasBoardResp->dUnrealizedMtomPrsnt
               << " dPremiumPrsnt: "
               << pRiskDasBoardResp->dPremiumPrsnt
               << " dCncBuyUsed: "
               << pRiskDasBoardResp->dCncBuyUsed
               << " dCncSellcrdPresent: "
               << pRiskDasBoardResp->dCncSellcrdPresent
               << " dAddMrgnNrmlPrsnt: "
               << pRiskDasBoardResp->dAddMrgnNrmlPrsnt
               << " dTenderMrgnNrmlPrsnt: "
               << pRiskDasBoardResp->dTenderMrgnNrmlPrsnt
               << " dSplMrgnNrmlPrsnt: "
               << pRiskDasBoardResp->dSplMrgnNrmlPrsnt
               << " dDeliveryMarginPresent: "
               << pRiskDasBoardResp->dDeliveryMarginPresent
               << " dMarginScripBasketPrsnt: "
               << pRiskDasBoardResp->dMarginScripBasketPrsnt
               << " dMrgnProtection: "
               << pRiskDasBoardResp->dMrgnProtection
               << " dFoPremium: "
               << pRiskDasBoardResp->dFoPremium
               << " dCurPremium: "
               << pRiskDasBoardResp->dCurPremium
               << " dComPremium: "
               << pRiskDasBoardResp->dComPremium
               << " dMtomCurrentPerc: "
               << pRiskDasBoardResp->dMtomCurrentPerc
               << " dLiquidCashCollateral: "
               << pRiskDasBoardResp->dLiquidCashCollateral
               << " dMfCollateral: "
               << pRiskDasBoardResp->dMfCollateral
               << " dMfCashCollateral: "
               << pRiskDasBoardResp->dMfCashCollateral
               << " dExchMrgn "
               << pRiskDasBoardResp->dExchMrgn
               << " dFoExchMrgn "
               << pRiskDasBoardResp->dFoExchMrgn
               << " dCurExchMrgn "
               << pRiskDasBoardResp->dCurExchMrgn
               << " dComExchMrgn "
               << pRiskDasBoardResp->dComExchMrgn
               << " dExchMrgnSellCrd "
               << pRiskDasBoardResp->dExchMrgnSellCrd
               << " dExchMrgnT1SellCrd "
               << pRiskDasBoardResp->dExchMrgnT1SellCrd
               << " dAlloc "
               << pRiskDasBoardResp->dAlloc
               << " dFoAlloc "
               << pRiskDasBoardResp->dFoAlloc
               << " dCurAlloc "
               << pRiskDasBoardResp->dCurAlloc
               << " dComAlloc "
               << pRiskDasBoardResp->dComAlloc
               << " dBlockAmt "
               << pRiskDasBoardResp->dBlockAmt
               << " acNorenUpdateTime "
               << pRiskDasBoardResp->acNorenUpdateTime
               << " lNorenUpdateTimeEpoch "
               << pRiskDasBoardResp->lNorenUpdateTimeEpoch
               << " lNorenUpdateTimeNanoSec "
               << pRiskDasBoardResp->lNorenUpdateTimeNanoSec
               << " dRemarksAmt "
               << pRiskDasBoardResp->dRemarksAmt
               << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::RiskDashBoardUnSubscribeResponse(char *pStatus,
                                                        void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "RiskDashBoardUnSubscribeResponse  EchoBackData: %s pStatus: %s",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GTTUpdates(tsGTTUpdateParams *pGTTUpdateResp,
                                  void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GTTUpdates Type:%s | Status: %s | RemarksText: %s | ExchSeg: %s |"
                                      " TrdSymbol :%s | GTTid: %s | SrcUserId: %s |",
              pGTTUpdateResp->acType,
              pGTTUpdateResp->acStatus,
              pGTTUpdateResp->acRemarksText,
              pGTTUpdateResp->acExchSeg,
              pGTTUpdateResp->acTrdSymbol,
              pGTTUpdateResp->acGTTid,
              pGTTUpdateResp->acSrcUserId);
     logString += buffer;

     if (pEchoBackData)
     {
          snprintf(buffer, sizeof(buffer), " EchoBackData: %s ", (char *)pEchoBackData);
          logString += buffer;
     }
     std::clog << logString << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GTTUpdatesUnSubscribeResponse(char *pStatus,
                                                     void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GTTUpdatesUnSubscribeResponse pEchoBackData :%s | pStatus: %s\n", (char *)pEchoBackData, pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::SqroffAlertUpdate(char *AlertMessage,
                                         void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "SqroffAlertUpdate EchoBackData:%s | AlertMessage: :%s |",
              (char *)pEchoBackData,
              AlertMessage);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::PreSqroffAlertUpdate(char *AlertMessage,
                                            void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PreSqroffAlertUpdate  EchoBackData: %s | AlertMessage: %s",
              (char *)pEchoBackData,
              AlertMessage);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::SqroffAlertsUnSubscribeResponse(char *pStatus,
                                                       void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "SqroffAlertsUnSubscribeResponse EchoBackData: %s pStatus :%s",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::LimitsUpdate(tsLimitUpdatesParams *pLimitUpdateResp,
                                    void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "LimitsUpdate  EchoBackData :%s | acAcctId :%s | acProfileName :%s | acSegment :%s|"
                                      " acExchSeg :%s | acProduct :%s | dCollateralValue :%f | dRmsPayInAmt :%f | dRmsPayOutAmt :%f | dAdhocMargin :%f |"
                                      " dNotionalCash :%f | dRmsCollateral :%f |",
              (char *)pEchoBackData,
              pLimitUpdateResp->acAcctId,
              pLimitUpdateResp->acProfileName,
              pLimitUpdateResp->acSegment,
              pLimitUpdateResp->acExchSeg,
              pLimitUpdateResp->acProduct,
              pLimitUpdateResp->dCollateralValue,
              pLimitUpdateResp->dRmsPayInAmt,
              pLimitUpdateResp->dRmsPayOutAmt,
              pLimitUpdateResp->dAdhocMargin,
              pLimitUpdateResp->dNotionalCash,
              pLimitUpdateResp->dRmsCollateral);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::LimitsUpdateUnSubscribeResponse(char *pStatus,
                                                       void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "LimitsUpdateUnSubscribeResponse pEchoBackData:%s | pStatus: %s |", (char *)pEchoBackData, pStatus);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::HoldingsUpdate(tsViewHoldings *pViewHoldings,
                                      void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "HoldingsUpdate EchoBackData: %s|\n", (char *)pEchoBackData);
     logString += buffer;

     if (pViewHoldings->pExchSeg1)
     {
          snprintf(buffer, sizeof(buffer), "pExchSeg1: %s|", pViewHoldings->pExchSeg1);
          logString += buffer;
     }
     if (pViewHoldings->pExchSeg2)
     {
          snprintf(buffer, sizeof(buffer), "pExchSeg2: %s|", pViewHoldings->pExchSeg2);
          logString += buffer;
     }
     if (pViewHoldings->pExchSeg3)
     {
          snprintf(buffer, sizeof(buffer), "pExchSeg3: %s|", pViewHoldings->pExchSeg3);
          logString += buffer;
     }
     if (pViewHoldings->pToken1)
     {
          snprintf(buffer, sizeof(buffer), "Token1: %s|", pViewHoldings->pToken1);
          logString += buffer;
     }
     if (pViewHoldings->pToken2)
     {
          snprintf(buffer, sizeof(buffer), "Token2: %s|", pViewHoldings->pToken2);
          logString += buffer;
     }
     if (pViewHoldings->pToken3)
     {
          snprintf(buffer, sizeof(buffer), " Token3:  %s|", pViewHoldings->pToken3);
          logString += buffer;
     }
     if (pViewHoldings->acInterOPKey)
     {
          snprintf(buffer, sizeof(buffer), " acInterOPKey: %s|", pViewHoldings->acInterOPKey);
          logString += buffer;
     }

     if (pViewHoldings->acInterOPExchSeg)
     {
          snprintf(buffer, sizeof(buffer), " acInterOPExchSeg: %s|", pViewHoldings->acInterOPExchSeg);
          logString += buffer;
     }
     snprintf(buffer, sizeof(buffer), " AccountId: %s | Product: %s | CollateralType: %s | ClosePrice: %f | UploadPrice:%f | dT1UploadPrice: %f |"
                                      " HairCut: %f | CollateralQty: %f | dCollUpdateQty:%f | dHoldUpdateQty:%f | dWithheldHoldQty: %f | dQty: %f | UsedQty: %f |"
                                      " T1Qty: %f | dNpoaQty: %f | dT1NpoaQty:%f | dUnplgdQty:%f | dEQTCollUpdateQty: %f | dCOMCollUpdateQty: :%f | dBrokerHairCut:%f |"
                                      " bIsCollateral: %d |",
              pViewHoldings->pAccountId,
              pViewHoldings->pProduct,
              pViewHoldings->pCollateralType,
              pViewHoldings->dClosePrice,
              pViewHoldings->dUploadPrice,
              pViewHoldings->dT1UploadPrice,
              pViewHoldings->dHairCut,
              pViewHoldings->dCollateralQty,
              pViewHoldings->dCollUpdateQty,
              pViewHoldings->dHoldUpdateQty,
              pViewHoldings->dWithheldHoldQty,
              pViewHoldings->dQty,
              pViewHoldings->dUsedQty,
              pViewHoldings->dT1Qty,
              pViewHoldings->dNpoaQty,
              pViewHoldings->dT1NpoaQty,
              pViewHoldings->dUnplgdQty,
              pViewHoldings->dEQTCollUpdateQty,
              pViewHoldings->dCOMCollUpdateQty,
              pViewHoldings->dBrokerHairCut,
              pViewHoldings->bIsCollateral);
     logString += buffer;
     std::clog << logString << std::endl;

     //     std::string logString;
//     char buffer[BUFFER_SIZE];
//     snprintf(buffer, sizeof(buffer),"HoldingsUpdate  EchoBackData: %s | pExchSeg1: %s | pToken1: %s | pAccountId:%s |"
//              " pProduct:%s | pCollateralType: %s | dClosePrice:%f | dUploadPrice:%f | dT1UploadPrice: %f | dHairCut: %f | dCollateralQty:%f |"
//              " dCollUpdateQty:%f | dHoldUpdateQty: %f | dWithheldHoldQty: %f | dQty:%f | dUsedQty:%f | dT1Qty:%f | dNpoaQty: %f |"
//              " dT1NpoaQty:%f | dUnplgdQty :%f | dEQTCollUpdateQty: %f | dCOMCollUpdateQty:%f\n",
//              (char *)pEchoBackData,
//              pViewHoldings->pExchSeg1,
//              pViewHoldings->pToken1,
//              pViewHoldings->pAccountId,
//              pViewHoldings->pProduct,
//              pViewHoldings->pCollateralType,
//              pViewHoldings->dClosePrice,
//              pViewHoldings->dUploadPrice,
//              pViewHoldings->dT1UploadPrice,
//              pViewHoldings->dHairCut,
//              pViewHoldings->dCollateralQty,
//              pViewHoldings->dCollUpdateQty,
//              pViewHoldings->dHoldUpdateQty,
//              pViewHoldings->dWithheldHoldQty,
//              pViewHoldings->dQty,
//              pViewHoldings->dUsedQty,
//              pViewHoldings->dT1Qty,
//              pViewHoldings->dNpoaQty,
//              pViewHoldings->dT1NpoaQty,
//              pViewHoldings->dUnplgdQty,
//              pViewHoldings->dEQTCollUpdateQty,
//              pViewHoldings->dCOMCollUpdateQty);
//     logString+= buffer;
//     if (pViewHoldings->pExchSeg2)
//     {
//          snprintf(buffer, sizeof(buffer)," pExchSeg2: %s | pToken2:%s |\n",
//                   pViewHoldings->pExchSeg2,
//                   pViewHoldings->pToken2);
//          logString+= buffer;
//     }
//     if (pViewHoldings->pExchSeg3)
//     {
//          snprintf(buffer, sizeof(buffer),"pExchSeg3: %s | pToken3:%s|\n",
//                   pViewHoldings->pExchSeg3,
//                   pViewHoldings->pToken3);
//          logString+= buffer;
//     }
//     std::clog<<logString<<std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::HoldingsUpdateUnSubscribeResponse(char *pStatus,
                                                         void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "HoldingsUpdateUnSubscribeResponse  EchoBackData :%s | pStatus :%s |",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::FundsUpdate(tsFundsUpdatesParams *pFundsUpdatesParams,
                                   void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "tsFundsUpdatesParams EchoBackData: %s | acAcctId:%s | acSrcUserId:%s | acBrokerId:%s |"
                                      " lTranRefNumber: %ld | dAmount: %f | acRemarks:%s | acBankName:%s | acSegment:%s | acExchSeg: %s | acProduct: %s |",
              (char *)pEchoBackData,
              pFundsUpdatesParams->acAcctId,
              pFundsUpdatesParams->acSrcUserId,
              pFundsUpdatesParams->acBrokerId,
              pFundsUpdatesParams->lTranRefNumber,
              pFundsUpdatesParams->dAmount,
              pFundsUpdatesParams->acRemarks,
              pFundsUpdatesParams->acBankName,
              pFundsUpdatesParams->acSegment,
              pFundsUpdatesParams->acExchSeg,
              pFundsUpdatesParams->acProduct);

     std::clog << buffer << std::endl;
     //     pNorenControl->GetRmsLimits((char*)"KSPL",
     //                                 pFundsUpdatesParams->acAcctId,
     //                                 nullptr,
     //                                 nullptr,
     //                                 nullptr,
     //                                 (char*)"Cli",
     //                                 pFundsUpdatesParams->acAcctId);
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::FundsUpdateUnSubscribeResponse(char *pStatus,
                                                      void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "FundsUpdateUnSubscribeResponses  EchoBackData:%s | pStatus: %s",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::PlaceEquitySipOrderResp(void *pEchoBackData,
                                               char *pReqStatus,
                                               long lSipId)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PlaceEquitySipOrderResp pReqStatus:%s | lSipId:%ld |",
              pReqStatus,
              lSipId);
     logString += buffer;
     if (pEchoBackData)
     {
          snprintf(buffer, sizeof(buffer), "pEchoBackData :%s |\n ", (char *)pEchoBackData);
          logString += buffer;
     }
     std::clog << logString << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::ModifyEquitySipOrderResp(void *pEchoBackData,
                                                char *pReqStatus,
                                                long lSipId)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ModifyEquitySipOrderResp pReqStatus:%s | lSipId: %ld |",
              pReqStatus,
              lSipId);
     logString += buffer;
     if (pEchoBackData)
     {
          snprintf(buffer, sizeof(buffer), "pEchoBackData :%s |\n ", (char *)pEchoBackData);
          logString += buffer;
     }
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::CancelSipOrderResp(void *pEchoBackData,
                                          char *pReqStatus,
                                          long lSipId)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "CancelSipOrderResp pReqStatus:%s | lSipId:%ld |",
              pReqStatus,
              lSipId);
     logString += buffer;
     if (pEchoBackData)
     {
          snprintf(buffer, sizeof(buffer), "pEchoBackData :%s |\n ", (char *)pEchoBackData);
          logString += buffer;
     }
     std::clog << logString << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetEquitySipOrderStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetEquitySipOrderStart pEchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetEquitySipOrderResp(void *pEchoBackData,
                                             tsSipOrderUpdate *pSipOrderUpdate)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetEquitySipOrderResp  pEchoBackData: %s | lPrevExecDate:%ld | lDueDate:%ld | lExecDate:%ld | lSipId: %ld |"
                                      " iPeriod:%d | acSipState: %s | acAcctId:%s | acUser: %s | acBrokerId: %s | lRegDate: %ld | lStartDate: %ld |  iFrequency:%d |"
                                      " iEndPeriod:%d | acSipName:%s |",
              (char *)pEchoBackData,
              pSipOrderUpdate->lPrevExecDate,
              pSipOrderUpdate->lDueDate,
              pSipOrderUpdate->lExecDate,
              pSipOrderUpdate->lSipId,
              pSipOrderUpdate->iPeriod,
              pSipOrderUpdate->acSipState,
              pSipOrderUpdate->sSipOrderParams.acAcctId,
              pSipOrderUpdate->sSipOrderParams.acUser,
              pSipOrderUpdate->sSipOrderParams.acBrokerId,
              pSipOrderUpdate->sSipOrderParams.lRegDate,
              pSipOrderUpdate->sSipOrderParams.lStartDate,
              pSipOrderUpdate->sSipOrderParams.iFrequency,
              pSipOrderUpdate->sSipOrderParams.iEndPeriod,
              pSipOrderUpdate->sSipOrderParams.acSipName);
     logString += buffer;
     for (int i = 0; i < pSipOrderUpdate->sSipOrderParams.iScripParamSize; i++)
     {
          snprintf(buffer, sizeof(buffer), "acExchSeg:%s | acToken:%s | acTrdSymbol:%s | acProduct: %s | dPrice:%f | lQuantity:%ld |",
                   pSipOrderUpdate->sSipOrderParams.pSipScripParams[i].acExchSeg,
                   pSipOrderUpdate->sSipOrderParams.pSipScripParams[i].acToken,
                   pSipOrderUpdate->sSipOrderParams.pSipScripParams[i].acTrdSymbol,
                   pSipOrderUpdate->sSipOrderParams.pSipScripParams[i].acProduct,
                   pSipOrderUpdate->sSipOrderParams.pSipScripParams[i].dPrice,
                   pSipOrderUpdate->sSipOrderParams.pSipScripParams[i].lQuantity);
          logString += buffer;
     }
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetEquitySipOrderEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetEquitySipOrderEnd pEchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::MasterMsgUpdate(sMasterMsgParams *pMasterMsgParams,
                                       void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];

     snprintf(buffer, sizeof(buffer), "MasterMsgUpdate EchoBackData :%s", (char *)pEchoBackData);
     logString += buffer;

     if (pMasterMsgParams->acMsgString)
     {
          snprintf(buffer, sizeof(buffer), "acMsgString: %s", pMasterMsgParams->acMsgString);
          logString += buffer;
     }

     if (pMasterMsgParams->acRecoPrice)
     {

          snprintf(buffer, sizeof(buffer), "acRecoPrice: %s", pMasterMsgParams->acRecoPrice);
          logString += buffer;
     }

     if (pMasterMsgParams->acStopPrice)
     {
          snprintf(buffer, sizeof(buffer), "acStopPrice: %s", pMasterMsgParams->acStopPrice);
          logString += buffer;
     }

     if (pMasterMsgParams->acProfitPrice)
     {
          snprintf(buffer, sizeof(buffer), "acProfitPrice: %s", pMasterMsgParams->acProfitPrice);
          logString += buffer;
     }

     if (pMasterMsgParams->acDisclaimerString)
     {
          snprintf(buffer, sizeof(buffer), "acDisclaimerString: %s", pMasterMsgParams->acDisclaimerString);
          logString += buffer;
     }

     if (pMasterMsgParams->acUserId)
     {
          snprintf(buffer, sizeof(buffer), "acUserId: %s", pMasterMsgParams->acUserId);
          logString += buffer;
     }
     snprintf(buffer, sizeof(buffer), "lDateTime: %ld", pMasterMsgParams->lDateTime);
     logString += buffer;

     if (pMasterMsgParams->acRemarks)
     {
          snprintf(buffer, sizeof(buffer), "acRemarks:%s", pMasterMsgParams->acRemarks);
          logString += buffer;
     }

     if (pMasterMsgParams->acSubType)
     {
          snprintf(buffer, sizeof(buffer), " acSubType :%s", pMasterMsgParams->acSubType);
          logString += buffer;
     }

     if (pMasterMsgParams->acExchSeg)
     {
          snprintf(buffer, sizeof(buffer), " acExchSeg :%s", pMasterMsgParams->acExchSeg);
          logString += buffer;
     }
     if (pMasterMsgParams->acTrdSymbol)
     {
          snprintf(buffer, sizeof(buffer), " acTrdSymbol :%s", pMasterMsgParams->acTrdSymbol);
          logString += buffer;
     }

     if (pMasterMsgParams->acTransType)
     {
          snprintf(buffer, sizeof(buffer), " acTransType :%s", pMasterMsgParams->acTransType);
          logString += buffer;
     }

     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::UnSubscribeMasterMsgResponse(char *pStatus,
                                                    void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "UnSubscribeMasterMsgResponse  EchoBackData: %s | pStatus: %s|",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::PosConvUpdate(tsPosConvParams *pPosConvParams,
                                     void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PosConvUpdate EchoBackData: %s", (char *)pEchoBackData);
     logString += buffer;
     if (pPosConvParams->acAccountId)
     {
          snprintf(buffer, sizeof(buffer), "acAccountId: %s|", pPosConvParams->acAccountId);
          logString += buffer;
     }

     if (pPosConvParams->acTrdSymbol)
     {
          snprintf(buffer, sizeof(buffer), "acTrdSymbol: %s|", pPosConvParams->acTrdSymbol);
          logString += buffer;
     }

     if (pPosConvParams->acExchSeg)
     {
          snprintf(buffer, sizeof(buffer), " acExchSeg: %s|", pPosConvParams->acExchSeg);
          logString += buffer;
     }

     if (pPosConvParams->acOldProduct)
     {
          snprintf(buffer, sizeof(buffer), " acOldProduct: %s|", pPosConvParams->acOldProduct);
          logString += buffer;
     }

     if (pPosConvParams->acNewProduct)
     {
          snprintf(buffer, sizeof(buffer), " acNewProduct: %s|", pPosConvParams->acNewProduct);
          logString += buffer;
     }

     if (pPosConvParams->acOrderSrc)
     {
          snprintf(buffer, sizeof(buffer), " acOrderSrc: %s|", pPosConvParams->acOrderSrc);
          logString += buffer;
     }
     snprintf(buffer, sizeof(buffer), " lQuanToFill: %ld | iMsgFlag:%d | dPriceToFill:%f |", pPosConvParams->lQuanToFill, pPosConvParams->iMsgFlag, pPosConvParams->dPriceToFill);
     logString += buffer;

     if (pPosConvParams->acSrcUserId)
     {
          snprintf(buffer, sizeof(buffer), " acSrcUserId: %s|", pPosConvParams->acSrcUserId);
          logString += buffer;
     }

     if (pPosConvParams->acToken)
     {
          snprintf(buffer, sizeof(buffer), " acToken: %s|", pPosConvParams->acToken);
          logString += buffer;
     }

     if (pPosConvParams->acBrokerId)
     {
          snprintf(buffer, sizeof(buffer), " acBrokerId: %s|", pPosConvParams->acBrokerId);
          logString += buffer;
     }

     if (pPosConvParams->acTransType)
     {
          snprintf(buffer, sizeof(buffer), " acTransType: %s|", pPosConvParams->acTransType);
          logString += buffer;
     }

     if (pPosConvParams->acSegment)
     {
          snprintf(buffer, sizeof(buffer), " acSegment: %s|", pPosConvParams->acSegment);
          logString += buffer;
     }

     if (pPosConvParams->acInterOPKey)
     {
          snprintf(buffer, sizeof(buffer), " acInterOPKey: %s|", pPosConvParams->acInterOPKey);
          logString += buffer;
     }

     if (pPosConvParams->acInterOPExchSeg)
     {
          snprintf(buffer, sizeof(buffer), " acInterOPExchSeg: %s|", pPosConvParams->acInterOPExchSeg);
          logString += buffer;
     }

     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::PosConvUnSubscribeResponse(char *pStatus,
                                                  void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PosConvUnSubscribeResponse  EchoBackData:%s | pStatus: %s |",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::AddMfHoldingsResponse(char *pStatus,
                                             void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AddMfHoldingsResponse EchoBackData:%s | Status:%s ",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::ViewMfHoldingsStart(void *pEchoBackData,
                                           char *pAccountId)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ViewMfHoldingsStart EchoBackData: %s |AccountId:%s ",
              (char *)pEchoBackData,
              pAccountId);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::ViewMfHoldings(void *pEchoBackData,
                                      tsViewHoldings *pViewHoldings)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ViewMfHoldings EchoBackData: %s |",
              (char *)pEchoBackData);
     logString += buffer;
     if (pViewHoldings->pExchSeg1)
     {
          snprintf(buffer, sizeof(buffer), "pExchSeg1: %s|",
                   pViewHoldings->pExchSeg1);
          logString += buffer;
     }
     if (pViewHoldings->pExchSeg2)
     {
          snprintf(buffer, sizeof(buffer), "pExchSeg2: %s|",
                   pViewHoldings->pExchSeg2);
          logString += buffer;
     }
     if (pViewHoldings->pExchSeg3)
     {
          snprintf(buffer, sizeof(buffer), "pExchSeg3: %s|",
                   pViewHoldings->pExchSeg3);

          logString += buffer;
     }
     if (pViewHoldings->pToken1)
     {
          snprintf(buffer, sizeof(buffer), "Token1: %s|",
                   pViewHoldings->pToken1);
          logString += buffer;
     }
     if (pViewHoldings->pToken2)
     {
          snprintf(buffer, sizeof(buffer), "Token2: %s|",
                   pViewHoldings->pToken2);
          logString += buffer;
     }
     if (pViewHoldings->pToken3)
     {
          snprintf(buffer, sizeof(buffer), "Token3: %s|",
                   pViewHoldings->pToken3);
          logString += buffer;
     }
     snprintf(buffer, sizeof(buffer), " AccountId: %s | Product: %s | CollateralType: %s | ClosePrice: %f | UploadPrice: %f |"
                                      " HairCut : %f | CollateralQty: %f | dCollUpdateQty: %f | dHoldUpdateQty: %f | dWithheldHoldQty: %f |"
                                      " dQty: %f | UsedQty: %f | dNpoaQty: %f | dUnplgdQty: %f | dEQTCollUpdateQty: %f | dCOMCollUpdateQty: %f |"
                                      " dBrokerHairCut: %f | bIsCollateral: %d |",
              pViewHoldings->pAccountId,
              pViewHoldings->pProduct,
              pViewHoldings->pCollateralType,
              pViewHoldings->dClosePrice,
              pViewHoldings->dUploadPrice,
              pViewHoldings->dHairCut,
              pViewHoldings->dCollateralQty,
              pViewHoldings->dCollUpdateQty,
              pViewHoldings->dHoldUpdateQty,
              pViewHoldings->dWithheldHoldQty,
              pViewHoldings->dQty,
              pViewHoldings->dUsedQty,
              pViewHoldings->dNpoaQty,
              pViewHoldings->dUnplgdQty,
              pViewHoldings->dEQTCollUpdateQty,
              pViewHoldings->dCOMCollUpdateQty,
              pViewHoldings->dBrokerHairCut,
              pViewHoldings->bIsCollateral);
     logString += buffer;
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::ViewMfHoldingsEnd(void *pEchoBackData,
                                         char *pAccountId)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ViewMfHoldingsEnd EchoBackData:%s | AccountId :%s |",
              (char *)pEchoBackData,
              pAccountId);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetBrokerageStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetBrokerageStart EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetBrokerageResp(void *pEchoBackData,
                                        tsBrokerageRespParams *pBrokerageRespParams)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetBrokerageResp EchoBackData:%s\n",
              (char *)pEchoBackData);
     logString += buffer;
     snprintf(buffer, sizeof(buffer), "lBrokerage: %ld | lSttCtt:%ld | lExchangeCharge:%ld | lSebiCharge: :%ld |"
                                      " lGST:%ld | lStampDuty:%ld | ",
              pBrokerageRespParams->lBrokerage,
              pBrokerageRespParams->lSttCtt,
              pBrokerageRespParams->lExchangeCharge,
              pBrokerageRespParams->lSebiCharge,
              pBrokerageRespParams->lGST,
              pBrokerageRespParams->lStampDuty);
     logString += buffer;
     if (pBrokerageRespParams->acUrl)
     {
          snprintf(buffer, sizeof(buffer), " acUrl: %s\n ", pBrokerageRespParams->acUrl);
          logString += buffer;
     }
     if (pBrokerageRespParams->acRemarks)
     {

          snprintf(buffer, sizeof(buffer), " acRemarks: %s\n ", pBrokerageRespParams->acRemarks);
          logString += buffer;
     }
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetBrokerageEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetBrokerageEnd  EchoBackData: %s ",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::BlockAmtUpdate(char *pAccountId,
                                      char *pSrcUserId,
                                      char *pSrcBrokerId,
                                      double dBlockAmount,
                                      void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "BlockAmtUpdate EchoBackData: %s | pAccountId: %s | pSrcUserId: %s |"
                                      " pSrcBrokerId: %s | dBlockAmount: %f |",
              (char *)pEchoBackData,
              pAccountId,
              pSrcUserId,
              pSrcBrokerId,
              dBlockAmount);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::BlockAmtUpdateUnSubscribeResponse(char *pStatus,
                                                         void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "BlockAmtUpdateUnSubscribeResponse EchoBackData: %s | Status: %s |",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::PayInUpdate(char *pAccountId,
                                   char *pSrcUserId,
                                   char *pSrcBrokerId,
                                   double dPayIn,
                                   void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PayInUpdate EchoBackData :%s | pAccountId :%s | pSrcUserId :%s | pSrcBrokerId :%s |"
                                      "dPayIn :%f |",
              (char *)pEchoBackData,
              pAccountId,
              pSrcUserId,
              pSrcBrokerId,
              dPayIn);
     std::clog << buffer << std::endl;

     //     pNorenControl->GetRmsLimits((char*)"KSPL",
     //                                 pAccountId,
     //                                 nullptr,
     //                                 nullptr,
     //                                 nullptr,
     //                                 (char*)"Cli",
     //                                 pAccountId);
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::PayInUpdateUnSubscribeResponse(char *pStatus,
                                                      void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PayInUpdateUnSubscribeResponse EchoBackData:%s | Status: %s|",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::PayOutUpdate(char *pAccountId,
                                    char *pSrcUserId,
                                    char *pSrcBrokerId,
                                    double dPayOut,
                                    void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PayOutUpdate  EchoBackData:%s | pAccountId:%s | pSrcUserId: %s |"
                                      "pSrcBrokerId:%s | dPayOut: %f|",
              (char *)pEchoBackData,
              pAccountId,
              pSrcUserId,
              pSrcBrokerId,
              dPayOut);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::PayOutUpdateUnSubscribeResponse(char *pStatus,
                                                       void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PayOutUpdateUnSubscribeResponse EchoBackData: %s | Status: %s|",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::IncrCASHUpdate(char *pAccountId,
                                      char *pSrcUserId,
                                      char *pSrcBrokerId,
                                      double dCash,
                                      void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "IncrCASHUpdate EchoBackData :%s | pAccountId :%s | pSrcUserId :%s |"
                                      "pSrcBrokerId:%s | dCash: %f |",
              (char *)pEchoBackData,
              pAccountId,
              pSrcUserId,
              pSrcBrokerId,
              dCash);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::IncrCASHUpdateUnSubscribeResponse(char *pStatus,
                                                         void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "IncrCASHUpdateUnSubscribeResponse  EchoBackData: %s  Status: %s",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::AmoStatusStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AmoStatusStart EchoBackData:%s ",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::AmoStatusResponse(void *pEchoBackData,
                                         char *pExchSeg,
                                         char *pAmoStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), " AmoStatusResponse  EchoBackData: %s | pExchSeg: %s | pAmoStatus:%s |",
              (char *)pEchoBackData,
              pExchSeg,
              pAmoStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::AmoStatusEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AmoStatusEnd EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetOrderMarginLimits(void *pEchoBackData,
                                            tsRmsLimits *pRmsLimits,
                                            double &dTotalRmsValue,
                                            double &dRmsMarginUsed)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOrderMarginLimits  EchoBackData: %s | acct id :%s | pCategory :%s | pSegment:%s |"
                                      " acExchSeg :%s | acProduct :%s | CollateralValue :%f | Collateral :%f | BrokerCollateral :%f |"
                                      " DaylongCash :%f | UnclearedCash :%f | AmountUtilizedPrsnt :%f | UnrealizedMtomPrsnt:%f | RealizedMtomPrsnt :%f |"
                                      " ExposureMarginPrsnt :%f | SpanMarginPrsnt :%f | PremiumPrsnt :%f | MarginVarPrsnt :%f | MarginScripBasketPrsnt :%f |"
                                      " MarginUsed :%f | RmsPayInAmt:%f | RmsPayOutAmt:%f | CurExpMrgnNrmlPrsnt :%f | CurExpMrgnMisPrsnt :%f | CurPremiumNrmlPrsnt:%f |"
                                      " CurPremiumMisPrsnt :%f | CurSpanMrgnNrmlPrsnt :%f | CurSpanMrgnMisPrsnt:%f | FoExpMrgnNrmlPrsnt :%f | FoExpMrgnMisPrsnt :%f |"
                                      " FoPremiumNrmlPrsnt :%f | FoPremiumMisPrsnt :%f | FoSpanrgnNrmlPrsnt :%f | FoSpanrgnMisPrsnt :%f | MrgnScrpBsktNrmlPrsnt :%f |"
                                      " MrgnScrpBsktMisPrsnt :%f | MrgnVarNrmlPrsnt :%f | MrgnVarMisPrsnt :%f | AmtUntilizedPrsnt :%f | CncMrgnVarPrsnt :%f | MarginUsedPrsnt :%.2f |"
                                      " AuxBrokerCollateral :%f | AuxDaylongCash :%f | AuxUnclearedCash :%f | AvailableMargin :%.2e | dBrokerage :%f | dMrgnProtection :%f |"
                                      " dFoPremium :%f | dCurPremium :%f | dComPremium :%f | dMtomCurrentPerc :%.2e | dMarginCurrentPerc :%f | dLiquidCashCollateral :%.2e |"
                                      " dMfCollateral :%.2e | dMfCashCollateral :%.2e | dAddMrgnPrsnt :%.2e| dTenderMrgnPrsnt :%.2e | dDeliveryMrgnPrsnt :%.2e | dBrokerageCnc :%.2e|"
                                      " dBrokerageMis :%.2e | dBrokerageNrml :%.2e | dBrokerageCO :%.2e | dBrokerageBO :%.2e | dFoBrokerageMis :%.2e| dFoBrokerageNrml :%.2e | dFoBrokerageCO :%.2e |"
                                      " dFoBrokerageBO :%.2e | dCurBrokerageMis :%.2e | dCurBrokerageNrml :%.2e | dCurBrokerageCO :%.2e | dCurBrokerageBO :%.2e | dComBrokerageMis :%.2e | dComBrokerageNrml :%.2e |"
                                      " dComBrokerageCO :%.2e | dComBrokerageBO :%.2e| dMrgnProtectionCO :%.2e | dMrgnProtectionBO :%.2e | dFoMrgnProtectionCO :%.2e |  dFoMrgnProtectionBO :%.2e| dCurMrgnProtectionCO :%.2e|"
                                      " dCurMrgnProtectionBO :%.2e | dComMrgnProtectionCO :%.2e | dComMrgnProtectionBO :%.2e | dComPremiumMisPrsnt :%.2e | dComPremiumNrmlPrsnt :%.2e | dExchMrgn :%.2f | dFoExchMrgn :%.2e |"
                                      " dCurExchMrgn :%.2e  | dComExchMrgn :%.2e | dExchMrgnSellCrd :%.2e | dExchMrgnT1SellCrd :%.2e | dAlloc :%.2e | dFoAlloc :%.2e | dCurAlloc :%.2e | dComAlloc :%.2e | dBlockAmt :%.2e | dMtfLimit :%.0f |"
                                      " dSlbmLimit :%.0f | dTotalRmsValue:%.0f|dRmsMarginUsed :%.0f | dBlockAmt :%.2e",
              (char *)pEchoBackData,
              pRmsLimits->acAcctId,
              pRmsLimits->pCategory,
              pRmsLimits->pSegment,
              pRmsLimits->acExchSeg,
              pRmsLimits->acProduct,
              pRmsLimits->dCollateralValue,
              pRmsLimits->dCollateral,
              pRmsLimits->dRmsCollateral,
              pRmsLimits->dAdhocMargin,
              pRmsLimits->dNotionalCash,
              pRmsLimits->dAmountUtilizedPrsnt,
              pRmsLimits->dUnrealizedMtomPrsnt,
              pRmsLimits->dRealizedMtomPrsnt,
              pRmsLimits->dExposureMarginPrsnt,
              pRmsLimits->dSpanMarginPrsnt,
              pRmsLimits->dPremiumPrsnt,
              pRmsLimits->dMarginVarPrsnt,
              pRmsLimits->dMarginScripBasketPrsnt, //<<
              //                    "dMtomWarningPrcntPrsnt "<<pRmsLimits->dMtomWarningPrcntPrsnt<<
              //                    "dMtomSquareOffWarningPrcntPrsnt "<<pRmsLimits->dMtomSquareOffWarningPrcntPrsnt<<
              pRmsLimits->dMarginUsed,
              pRmsLimits->dRmsPayInAmt,
              pRmsLimits->dRmsPayOutAmt,
              pRmsLimits->dCurExpMrgnNrmlPrsnt,
              pRmsLimits->dCurExpMrgnMisPrsnt,
              pRmsLimits->dCurPremiumNrmlPrsnt,
              pRmsLimits->dCurPremiumMisPrsnt,
              pRmsLimits->dCurSpanMrgnNrmlPrsnt,
              pRmsLimits->dCurSpanMrgnMisPrsnt,
              pRmsLimits->dFoExpMrgnNrmlPrsnt,
              pRmsLimits->dFoExpMrgnMisPrsnt,
              pRmsLimits->dFoPremiumNrmlPrsnt,
              pRmsLimits->dFoPremiumMisPrsnt,
              pRmsLimits->dFoSpanrgnNrmlPrsnt,
              pRmsLimits->dFoSpanrgnMisPrsnt,
              pRmsLimits->dMrgnScrpBsktNrmlPrsnt,
              pRmsLimits->dMrgnScrpBsktMisPrsnt,
              // <<
              //                    "dMrgnScrpBsktCncPrsnt "<<pRmsLimits->dMrgnScrpBsktCncPrsnt<<

              pRmsLimits->dMrgnVarNrmlPrsnt,
              pRmsLimits->dMrgnVarMisPrsnt,
              pRmsLimits->dAmtUntilizedPrsnt,
              pRmsLimits->dCncMrgnVarPrsnt,
              pRmsLimits->dMarginUsedPrsnt,
              pRmsLimits->dAuxRmsCollateral,
              pRmsLimits->dAuxAdhocMargin,
              pRmsLimits->dAuxNotionalCash,
              pRmsLimits->dAvailableMargin,
              pRmsLimits->dBrokerage,
              pRmsLimits->dMrgnProtection,
              pRmsLimits->dFoPremium,
              pRmsLimits->dCurPremium,
              pRmsLimits->dComPremium,
              pRmsLimits->dMtomCurrentPerc,
              pRmsLimits->dMarginCurrentPerc,
              pRmsLimits->dLiquidCashCollateral,
              pRmsLimits->dMfCollateral,
              pRmsLimits->dMfCashCollateral,
              pRmsLimits->dAddMrgnPrsnt,
              pRmsLimits->dTenderMrgnPrsnt,
              pRmsLimits->dDeliveryMrgnPrsnt,
              pRmsLimits->dBrokerageCnc,
              pRmsLimits->dBrokerageMis,
              pRmsLimits->dBrokerageNrml,
              pRmsLimits->dBrokerageCO,
              pRmsLimits->dBrokerageBO,
              pRmsLimits->dFoBrokerageMis,
              pRmsLimits->dFoBrokerageNrml,
              pRmsLimits->dFoBrokerageCO,
              pRmsLimits->dFoBrokerageBO,
              pRmsLimits->dCurBrokerageMis,
              pRmsLimits->dCurBrokerageNrml,
              pRmsLimits->dCurBrokerageCO,
              pRmsLimits->dCurBrokerageBO,
              pRmsLimits->dComBrokerageMis,
              pRmsLimits->dComBrokerageNrml,
              pRmsLimits->dComBrokerageCO,
              pRmsLimits->dComBrokerageBO,
              pRmsLimits->dMrgnProtectionCO,
              pRmsLimits->dMrgnProtectionBO,
              pRmsLimits->dFoMrgnProtectionCO,
              pRmsLimits->dFoMrgnProtectionBO,
              pRmsLimits->dCurMrgnProtectionCO,
              pRmsLimits->dCurMrgnProtectionBO,
              pRmsLimits->dComMrgnProtectionCO,
              pRmsLimits->dComMrgnProtectionBO,
              pRmsLimits->dComPremiumMisPrsnt,
              pRmsLimits->dComPremiumNrmlPrsnt,
              pRmsLimits->dExchMrgn,
              pRmsLimits->dFoExchMrgn,
              pRmsLimits->dCurExchMrgn,
              pRmsLimits->dComExchMrgn,
              pRmsLimits->dExchMrgnSellCrd,
              pRmsLimits->dExchMrgnT1SellCrd,
              pRmsLimits->dAlloc,
              pRmsLimits->dFoAlloc,
              pRmsLimits->dCurAlloc,
              pRmsLimits->dComAlloc,
              pRmsLimits->dBlockAmt,
              pRmsLimits->dMtfLimit,
              pRmsLimits->dSlbmLimit,
              dTotalRmsValue,
              dRmsMarginUsed,
              pRmsLimits->dRemarksAmt);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::DPRMsgUpdate(char *pUserId,
                                    char *pMsgString,
                                    long lDateTime,
                                    void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "DPRMsgUpdate  pUserId: %s | pMsgString: %s | lDateTime: %ld |",
              pUserId,
              pMsgString,
              lDateTime);
     logString += buffer;
     if (pEchoBackData)
     {
          snprintf(buffer, sizeof(buffer), "EchoBackData:%s", (char *)pEchoBackData);
          logString += buffer;
     }
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::DPRMsgUnSubscribeResponse(char *pStatus,
                                                 void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "DPRMsgUnSubscribeResponse  Status: %s ",
              pStatus);
     logString += buffer;
     if (pEchoBackData)
     {
          snprintf(buffer, sizeof(buffer), "EchoBackData:%s", (char *)pEchoBackData);
          logString += buffer;
     }
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::PayinStatusStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PayinStatusStart EchoBackData: %s ",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::PayinStatusResponse(void *pEchoBackData,
                                           tsPayinStatusRespParams *pPayinStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PayinStatusResponse EchoBackData: %s |", (char *)pEchoBackData);
     logString += buffer;
     snprintf(buffer, sizeof(buffer), "lTranRefNumber: %ld | pAccountId: %s | pTranStatus: %s | pUser: %s | pVendor:%s | dAmt: %f |"
                                      " lNorenTimeStamp: %ld |",
              pPayinStatus->lTranRefNumber,
              pPayinStatus->pAccountId,
              pPayinStatus->pTranStatus,
              pPayinStatus->pUser,
              pPayinStatus->pVendor,
              pPayinStatus->dAmt,
              pPayinStatus->lNorenTimeStamp);
     logString += buffer;
     if (pPayinStatus->pBankName)
     {
          snprintf(buffer, sizeof(buffer), "pBankName : %s|", pPayinStatus->pBankName);
          logString += buffer;
     }
     if (pPayinStatus->pBankActNum)
     {
          snprintf(buffer, sizeof(buffer), "pBankActNum : %s|", pPayinStatus->pBankActNum);
          logString += buffer;
     }
     if (pPayinStatus->pBankRefNum)
     {
          snprintf(buffer, sizeof(buffer), "pBankRefNum : %s|", pPayinStatus->pBankRefNum);
          logString += buffer;
     }
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::PayinStatusEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PayinStatusEnd  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::HSTokenStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "HSTokenStart EchoBackData: %s", (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::HSTokenResponse(void *pEchoBackData,
                                       char *pUser,
                                       char *pHsToken)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     std::string logString;
     snprintf(buffer, sizeof(buffer), "HSTokenResponse EchoBackData:%s|",
              (char *)pEchoBackData);
     logString += buffer;
     snprintf(buffer, sizeof(buffer), " pHsToken:%s | pUser:%s",
              pHsToken,
              pUser);
     logString += buffer;
     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::HSTokenEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "HSTokenEnd EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::UpdateBlockAmountStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "UpdateBlockAmountStart EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::UpdateBlockAmountResponse(void *pEchoBackData,
                                                 char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "UpdateBlockAmountResponse  EchoBackData: %s | Status: %s |",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::UpdateBlockAmountEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "UpdateBlockAmountEnd  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetOptimizedBasketSequenceStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOptimizedBasketSequenceStart  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetOptimizedBasketSequenceResponse(void *pEchoBackData,
                                                          double dMarginUsed,
                                                          double dMarginUsedTrade,
                                                          double dMarginUsedPrev,
                                                          char *acOptimumSequence,
                                                          double dBasketMaginList[50],
                                                          int iBasketMaginListSize)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::clog << std::fixed << "GetOptimizedBasketSequenceResponse "
               << " EchoBackData: "
               << (char *)pEchoBackData
               << " dMarginUsed: "
               << dMarginUsed
               << " dMarginUsedTrade: "
               << dMarginUsedTrade
               << " dMarginUsedPrev: "
               << dMarginUsedPrev
               << " acOptimumSequence: "
               << acOptimumSequence
               << " BasketMargins: ";

     for (int i = 0; i < iBasketMaginListSize; i++)
     {
          std::clog << std::fixed << dBasketMaginList[i] << "\t";
     }
     std::clog << std::fixed << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetOptimizedBasketSequenceEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOptimizedBasketSequenceEnd  EchoBackData: %s ",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::FreezeAccountStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "FreezeAccountStart  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::FreezeAccountResponse(void *pEchoBackData,
                                             char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "FreezeAccountResponse  EchoBackData: %s pStatus:%s",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::FreezeAccountEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "FreezeAccountEnd EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::ResolutionTimeResp(void *pEchoBackData,
                                          long lUpdateTimeSec,
                                          long lUpdateTimeNsec,
                                          long lResolutionTime)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ResolutionTimeResp EchoBackData:%s | lUpdateTimeSec: %ld | lUpdateTimeNsec: %ld |"
                                      " lResolutionTime: %ld |",
              (char *)pEchoBackData,
              lUpdateTimeSec,
              lUpdateTimeNsec,
              lResolutionTime);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::DeFreezeAccountStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "DeFreezeAccountStart  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::DeFreezeAccountResponse(void *pEchoBackData,
                                               char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "DeFreezeAccountResponse EchoBackData:%s | pStatus: %s|",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::DeFreezeAccountEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "DeFreezeAccountEnd EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetMasterMsgStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetMasterMsgStart  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetMasterMsgResponse(void *pEchoBackData,
                                            sMasterMsgParams *pMasterMsgParams)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     std::string logString;
     logString += "GetMasterMsgResponse :";

     //                    << " EchoBackData: "
     //                    << (char *)pEchoBackData;

     if (pEchoBackData)
     {
          snprintf(buffer, sizeof(buffer), "EchoBackData: %s ",
                   (char *)pEchoBackData);
          logString += buffer;
     }
     if (pMasterMsgParams->acMsgString)
     {
          snprintf(buffer, sizeof(buffer), "MsgString: %s ",
                   pMasterMsgParams->acMsgString);
          logString += buffer;
     }
     if (pMasterMsgParams->acRecoPrice)
     {
          snprintf(buffer, sizeof(buffer), "RecoPrice: %s ",
                   pMasterMsgParams->acRecoPrice);
          logString += buffer;
     }
     if (pMasterMsgParams->acStopPrice)
     {
          snprintf(buffer, sizeof(buffer), "StopPrice: %s ",
                   pMasterMsgParams->acStopPrice);
          logString += buffer;
     }
     if (pMasterMsgParams->acProfitPrice)
     {
          snprintf(buffer, sizeof(buffer), "ProfitPrice: %s",
                   pMasterMsgParams->acProfitPrice);
          logString += buffer;
     }
     if (pMasterMsgParams->acDisclaimerString)
     {
          snprintf(buffer, sizeof(buffer), "DisclaimerString: %s ",
                   pMasterMsgParams->acDisclaimerString);
          logString += buffer;
     }
     if (pMasterMsgParams->acUserId)
     {
          snprintf(buffer, sizeof(buffer), "UserId: %s ",
                   pMasterMsgParams->acUserId);
          logString += buffer;
     }
     if (pMasterMsgParams->lDateTime)
     {
          snprintf(buffer, sizeof(buffer), "DateTime: %ld",
                   pMasterMsgParams->lDateTime);
          logString += buffer;
     }
     if (pMasterMsgParams->acRemarks)
     {
          snprintf(buffer, sizeof(buffer), "Remarks: %s ",
                   pMasterMsgParams->acRemarks);
          logString += buffer;
     }
     if (pMasterMsgParams->acSubType)
     {
          snprintf(buffer, sizeof(buffer), "SubType: %s ",
                   pMasterMsgParams->acSubType);
          logString += buffer;
     }
     if (pMasterMsgParams->iMsgType)
     {
          snprintf(buffer, sizeof(buffer), "MsgType: %d ",
                   pMasterMsgParams->iMsgType);
          logString += buffer;
     }
     if (pMasterMsgParams->acExchSeg)
     {
          snprintf(buffer, sizeof(buffer), "ExchSeg: %s ",
                   pMasterMsgParams->acExchSeg);
     }
     if (pMasterMsgParams->acTrdSymbol)
     {
          snprintf(buffer, sizeof(buffer), "TrdSymbol: %s ",
                   pMasterMsgParams->acTrdSymbol);

          logString += buffer;
     }
     if (pMasterMsgParams->acTransType)
     {
          snprintf(buffer, sizeof(buffer), "TransType: %s ",
                   pMasterMsgParams->acTransType);
          logString += buffer;
     }

     std::clog << logString << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetMasterMsgEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     std::string logString;

     logString += "GetMasterMsgEnd ";
     if (pEchoBackData)
     {
          snprintf(buffer, sizeof(buffer), "EchoBackData: %s",
                   (char *)pEchoBackData);
          logString += buffer;
     }

     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetPositionConvStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetPositionConvStart  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetPositionConvResponse(void *pEchoBackData,
                                               tsPosConvParams *pPosConvParams)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetPositionConvResponse EchoBackData: %s", (char *)pEchoBackData);
     logString += buffer;
     if (pPosConvParams->acAccountId)
     {
          snprintf(buffer, sizeof(buffer), "acAccountId: %s|", pPosConvParams->acAccountId);
          logString += buffer;
     }

     if (pPosConvParams->acTrdSymbol)
     {
          snprintf(buffer, sizeof(buffer), "acTrdSymbol: %s|", pPosConvParams->acTrdSymbol);
          logString += buffer;
     }

     if (pPosConvParams->acExchSeg)
     {
          snprintf(buffer, sizeof(buffer), " acExchSeg: %s|", pPosConvParams->acExchSeg);
          logString += buffer;
     }

     if (pPosConvParams->acOldProduct)
     {
          snprintf(buffer, sizeof(buffer), " acOldProduct: %s|", pPosConvParams->acOldProduct);
          logString += buffer;
     }

     if (pPosConvParams->acNewProduct)
     {
          snprintf(buffer, sizeof(buffer), " acNewProduct: %s|", pPosConvParams->acNewProduct);
          logString += buffer;
     }

     if (pPosConvParams->acOrderSrc)
     {
          snprintf(buffer, sizeof(buffer), " acOrderSrc: %s|", pPosConvParams->acOrderSrc);
          logString += buffer;
     }
     snprintf(buffer, sizeof(buffer), " lQuanToFill: %ld | iMsgFlag:%d | dPriceToFill:%f |", pPosConvParams->lQuanToFill, pPosConvParams->iMsgFlag, pPosConvParams->dPriceToFill);
     logString += buffer;

     if (pPosConvParams->acSrcUserId)
     {
          snprintf(buffer, sizeof(buffer), " acSrcUserId: %s|", pPosConvParams->acSrcUserId);
          logString += buffer;
     }

     if (pPosConvParams->acToken)
     {
          snprintf(buffer, sizeof(buffer), " acToken: %s|", pPosConvParams->acToken);
          logString += buffer;
     }

     if (pPosConvParams->acBrokerId)
     {
          snprintf(buffer, sizeof(buffer), " acBrokerId: %s|", pPosConvParams->acBrokerId);
          logString += buffer;
     }

     if (pPosConvParams->acTransType)
     {
          snprintf(buffer, sizeof(buffer), " acTransType: %s|", pPosConvParams->acTransType);
          logString += buffer;
     }

     if (pPosConvParams->acSegment)
     {
          snprintf(buffer, sizeof(buffer), " acSegment: %s|", pPosConvParams->acSegment);
          logString += buffer;
     }

     if (pPosConvParams->acInterOPKey)
     {
          snprintf(buffer, sizeof(buffer), " acInterOPKey: %s|", pPosConvParams->acInterOPKey);
          logString += buffer;
     }

     if (pPosConvParams->acInterOPExchSeg)
     {
          snprintf(buffer, sizeof(buffer), " acInterOPExchSeg: %s|", pPosConvParams->acInterOPExchSeg);
          logString += buffer;
     }

     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetPositionConvEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetPositionConvEnd EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::AbsIsinHoldingsResponse(char *pStatus,
                                               void *pEchoBackData)
{

#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "AbsIsinHoldingsResponse  Status: %s |",
              pStatus);
     logString += buffer;
     if (pEchoBackData)
     {
          snprintf(buffer, sizeof(buffer), "EchoBackData:%s", (char *)pEchoBackData);
          logString += buffer;
     }
     std::clog << logString << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::TradeEnhancementReport(tsTradeReport *pTradeReport,
                                              void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), " TradeEnhancement Report: pEchoBackData :%s |  Fill Price :%f | FillLeg :%d |"
                                      " FillSize :%ld | acFillStatus :%s | Id :%s | Symbol :%s | Exch Time :%s | ExchTimeNanoSec :%ld|"
                                      " Exch Seg :%s | GuiOrdId :%s | Acct Id :%s | Product :%s | Trd Symbol :%s|"
                                      " FillDate :%s | Fill Time :%s | Noren Ord No. :%s | Exch Ord Id :%s | Trans Type :%s|"
                                      " PriceType :%s | User :%s | Pan no :%s | OrdSrc :%s | Text :%s | BasketId :%ld|",
              (char *)pEchoBackData,
              pTradeReport->dFillPrice,
              pTradeReport->siFillLeg,
              pTradeReport->lFillSize,
              pTradeReport->acFillStatus,
              pTradeReport->acFillId,
              pTradeReport->acSymbol,
              pTradeReport->acExchTime,
              pTradeReport->lExchTimeNanoSec,
              pTradeReport->acExchSeg,
              pTradeReport->acGuiOrdId,
              pTradeReport->acAccountId,
              pTradeReport->acProduct,
              pTradeReport->acTrdSymbol,
              pTradeReport->acFillDate,
              pTradeReport->acFillTime,
              pTradeReport->acNorenOrdNum,
              pTradeReport->acExchOrdId,
              pTradeReport->acTransType,
              pTradeReport->acPriceType,
              pTradeReport->acUser,
              pTradeReport->acPan,
              pTradeReport->acOrdSrc,
              pTradeReport->acText,
              pTradeReport->lBasketId);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::TradeEnhancementUnSubscribeResponse(void *pEchoBackData,
                                                           char *pStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "TradeEnhancementUnSubscribeResponse : EchoBackData: %s Status :%s",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetExternalRemarksStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetExternalRemarksStart  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetExternalRemarksResponse(void *pEchoBackData,
                                                  char *pNorenOrderNo,
                                                  char *pExternalRemarks)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetExternalRemarksResponse EchoBackData: %s", (char *)pEchoBackData);
     logString += buffer;

     snprintf(buffer, sizeof(buffer), "pNorenOrderNo: %s|", pNorenOrderNo);
     logString += buffer;

     snprintf(buffer, sizeof(buffer), "pExternalRemarks: %s|", pExternalRemarks);
     logString += buffer;

     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetExternalRemarksEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetExternalRemarksEnd EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetOrderNumberStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOrderNumberStart  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetOrderNumberResponse(void *pEchoBackData,
                                              char *pExternalRemarks,
                                              char *pNorenOrderNo)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOrderNumberResponse EchoBackData: %s", (char *)pEchoBackData);
     logString += buffer;

     snprintf(buffer, sizeof(buffer), "pNorenOrderNo: %s|", pNorenOrderNo);
     logString += buffer;

     snprintf(buffer, sizeof(buffer), "pExternalRemarks: %s|", pExternalRemarks);
     logString += buffer;

     std::clog << logString << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetOrderNumberEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOrderNumberEnd EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::TralingOrderResponse(void *pEchoBackData,
                                            long lAQ_ID,
                                            char *pGuiOrdId,
                                            char *pReqStatus,
                                            char *pRejReason,
                                            char *pExternalRemarks,
                                            char *pUser)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "TralingOrderResponse EchoBackData: %s "
                                      "AQ_ID: %ld GuiOrderID: %s pReqStatus: %s pRejReason: %s "
                                      "pExternalRemarks: %s User: %s",
              (char *)pEchoBackData,
              lAQ_ID,
              pGuiOrdId,
              pReqStatus,
              pRejReason,
              pExternalRemarks,
              pUser);

     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::IceBergOrderResponse(void *pEchoBackData,
                                            long lAQ_ID,
                                            char *pGuiOrdId,
                                            char *pReqStatus,
                                            char *pRejReason,
                                            char *pExternalRemarks,
                                            char *pUser)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "IceBergOrderResponse EchoBackData: %s |"
                                      "AQ_ID: %ld | GuiOrderID: %s | pReqStatus: %s | pRejReason: %s |"
                                      "pExternalRemarks: %s | User: %s |",
              (char *)pEchoBackData,
              lAQ_ID,
              pGuiOrdId,
              pReqStatus,
              pRejReason,
              pExternalRemarks,
              pUser);

     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::ModifyIceBergOrderResponse(void *pEchoBackData,
                                                  long lAQ_ID,
                                                  char *pGuiOrdId,
                                                  char *pReqStatus,
                                                  char *pRejReason,
                                                  char *pExternalRemarks,
                                                  char *pUser)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ModifyIceBergOrderResponse EchoBackData: %s AQ_ID: %ld | GuiOrderID: %s | ReqStatus: %s | RejReason: %s | ExternalRemarks: %s | User: %s |",
              (char *)pEchoBackData,
              lAQ_ID,
              pGuiOrdId,
              pReqStatus,
              pRejReason,
              pExternalRemarks,
              pUser);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::CancelIceBergOrderResponse(void *pEchoBackData,
                                                  long lAQ_ID,
                                                  char *pGuiOrdId,
                                                  char *pReqStatus,
                                                  char *pRejReason,
                                                  char *pExternalRemarks,
                                                  char *pUser)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "CancelIceBergOrderResponse EchoBackData: %s | AQ_ID: %ld | GuiOrderID: %s  | ReqStatus: %s | RejReason: %s | ExternalRemarks: %s | User: %s |",
              (char *)pEchoBackData,
              lAQ_ID,
              pGuiOrdId,
              pReqStatus,
              pRejReason,
              pExternalRemarks,
              pUser);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetTrailingOrdersStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetTrailingOrdersStart  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetTrailingOrders(void *pEchoBackData, tsAQParams *pGetOrders)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), " GetTrailingOrders: pEchoBackData :%s | Trd Symbol :%s |Exch :%s | Trans Type :%s |Ord Type :%s  | Product :%s |  Ord Duration :%s|"
                                      "Act Id :%s|User :%s| OrdSrc :%s | CustomFirm :%s | Quantity :%ld |Price :%f | acOrdRemarks:%s | acIpAddr :%s| Token :%s | TrialPrice :%ld |"
                                      "AQ_ID :%ld | UpdateTrialPrice :%ld | PendingQty :%ld | OrdStatus :%s  |AlgoName :%s",
              (char *)pEchoBackData,
              pGetOrders->sOrderParams.acTrdSymbol,
              pGetOrders->sOrderParams.acExchSeg,
              pGetOrders->sOrderParams.acTransType,
              pGetOrders->sOrderParams.acOrderType,
              pGetOrders->sOrderParams.acProduct,
              pGetOrders->sOrderParams.acOrdDuration,
              pGetOrders->sOrderParams.acAccountId,
              pGetOrders->sOrderParams.acUser,
              pGetOrders->sOrderParams.acOrdSrc,
              pGetOrders->sOrderParams.acCustomerFirm,
              pGetOrders->sOrderParams.lQuantity,
              pGetOrders->sOrderParams.dPrice,
              pGetOrders->sOrderParams.acOrdRemarks,
              pGetOrders->sOrderParams.acIpAddr,
              pGetOrders->acToken,
              pGetOrders->lTrialPrice,
              pGetOrders->lAQ_ID,
              pGetOrders->lUpdateTrialPrice,
              pGetOrders->lPendingQty,
              pGetOrders->acOrdStatus,
              pGetOrders->acAlgoName);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetTrailingOrdersEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetTrailingOrdersEnd EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetIceBergOrdersStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetIceBergOrdersStart  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetIceBergOrders(void *pEchoBackData, tsAQParams *pGetOrders)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), " GetIceBergOrders: pEchoBackData :%s | Trd Symbol :%s |Exch :%s | Trans Type :%s |Ord Type :%s  | Product :%s |  Ord Duration :%s|"
                                      "Act Id :%s|User :%s| OrdSrc :%s | CustomFirm :%s | Quantity :%ld |Price :%f | acOrdRemarks:%s | acIpAddr :%s| Token :%s | TrialPrice :%ld |"
                                      "AQ_ID :%ld | UpdateTrialPrice :%ld | PendingQty :%ld | OrdStatus :%s  |AlgoName :%s",
              (char *)pEchoBackData,
              pGetOrders->sOrderParams.acTrdSymbol,
              pGetOrders->sOrderParams.acExchSeg,
              pGetOrders->sOrderParams.acTransType,
              pGetOrders->sOrderParams.acOrderType,
              pGetOrders->sOrderParams.acProduct,
              pGetOrders->sOrderParams.acOrdDuration,
              pGetOrders->sOrderParams.acAccountId,
              pGetOrders->sOrderParams.acUser,
              pGetOrders->sOrderParams.acOrdSrc,
              pGetOrders->sOrderParams.acCustomerFirm,
              pGetOrders->sOrderParams.lQuantity,
              pGetOrders->sOrderParams.dPrice,
              pGetOrders->sOrderParams.acOrdRemarks,
              pGetOrders->sOrderParams.acIpAddr,
              pGetOrders->acToken,
              pGetOrders->lTrialPrice,
              pGetOrders->lAQ_ID,
              pGetOrders->lUpdateTrialPrice,
              pGetOrders->lPendingQty,
              pGetOrders->acOrdStatus,
              pGetOrders->acAlgoName);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetIceBergOrdersEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetIceBergOrdersEnd EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetGroupIdResponse(void *pEchoBackData,
                                          char *pGroupId,
                                          char *pAccount)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetGroupIdResponse EchoBackData: %s | Group: %s | Acct: %s  |",
              (char *)pEchoBackData,
              pGroupId,
              pAccount);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::CancelWithdrawFundStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "CancelWithdrawFundStart  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::CancelWithdrawFundsResponse(char *pAccountId,
                                                   long lTranRefNumber,
                                                   double dAmount,
                                                   int pTranStatus,
                                                   void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "CancelWithdrawFundsResponse EchoBackData: %s | pAccountId: %s|"
                                      " lTranRefNumber: %ld| dAmount: %f| pTranStatus: %d|",
              (char *)pEchoBackData,
              pAccountId,
              lTranRefNumber,
              dAmount,
              pTranStatus);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::CancelWithdrawFundEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "CancelWithdrawFundEnd EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetWithdrawFundsReportStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetWithdrawFundsReportStart  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetWithdrawFundsReportResp(tsFundsReportParams *pFundsReportParams,
                                                   void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), " GetWithdrawFundsReportResp: pEchoBackData :%s |"
                                      "Act Id :%s|lTranRefNumber :%ld| acTranStatus :%s |  dAmount :%f | acRemarks :%s | acBankName :%s |acBankAcctNo :%s | acBankIFSCcode:%s | acBrokerId :%s|"
                                      "acSegment :%s | acExchSeg :%s | acProduct :%s | lInitTimeStamp :%ld |lNorenTimeStamp :%ld",
              (char *)pEchoBackData,
              pFundsReportParams->acAccountId,
              pFundsReportParams->lTranRefNumber,
              pFundsReportParams->acTranStatus,
              pFundsReportParams->dAmount,
              pFundsReportParams->acRemarks,
              pFundsReportParams->acBankName,
              pFundsReportParams->acBankAcctNo,
              pFundsReportParams->acBankIFSCcode,
              pFundsReportParams->acBrokerId,
              pFundsReportParams->acSegment,
              pFundsReportParams->acExchSeg,
              pFundsReportParams->acProduct,
              pFundsReportParams->lInitTimeStamp,
              pFundsReportParams->lNorenTimeStamp);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetWithdrawFundsReportEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetWithdrawFundsReportEnd EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::SqrOffEntityResponse(char *pStatus,
                                            void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "SqrOffEntityResponse EchoBackData: %s | pStatus: %s",
              (char *)pEchoBackData,
              pStatus);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetOrderNumberByGuiStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOrderNumberByGuiStart EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetOrderNumberByGuiResponse(void *pEchoBackData,
                                                   char *pGuiOrdId,
                                                   char *pNorenOrderNo,
                                                   char *pReportType)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOrderNumberByGuiResponse EchoBackData:%s |"
                                      "pGuiOrdId :%s | pNorenOrderNo : %s | pReportType :%s |",
              (char *)pEchoBackData,
              pGuiOrdId,
              pNorenOrderNo,
              pReportType);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetOrderNumberByGuiEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetOrderNumberByGuiEnd EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::PayoutStatusStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PayoutStatusStart  EchoBackData: %s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::PayoutStatusResponse(void *pEchoBackData,
                                            tsPayoutStatusRespParams *pPayinStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), " PayoutStatusResponse: pEchoBackData :%s |"
                                      " lTranRefNumber :%ld | pAccountId :%s | pTranStatus :%s | pUser :%s | pVendor :%s |  dAmt :%f | pBankName :%s |pBankActNum : %s | "
                                      " pBankRefNum :%s | lNorenTimeStamp :%ld |",
              (char *)pEchoBackData,
              pPayinStatus->lTranRefNumber,
              pPayinStatus->pAccountId,
              pPayinStatus->pTranStatus,
              pPayinStatus->pUser,
              pPayinStatus->pVendor,
              pPayinStatus->dAmt,
              pPayinStatus->pBankName,
              pPayinStatus->pBankActNum,
              pPayinStatus->pBankRefNum,
              pPayinStatus->lNorenTimeStamp);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::PayoutStatusEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PayoutStatusEnd EchoBackData:%s",
              (char *)pEchoBackData);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::CallBackError(void *pEchoBackData,
                                     tsCallbackErrorParams *pCallbackErrorParams)
{

#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "CallBackError  EchoBackData: %s| ApiRequest :%d | ErrorCode :%d",
              (char *)pEchoBackData,
              pCallbackErrorParams->Api,
              pCallbackErrorParams->ErrCode);

     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::QueueLoadResp(void *pEchoBackData,
                                     const sQueueLoad &oQueueLoad)
{

#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "QueueLoadResp  EchoBackData: %s| ORD :%d | REQ :%d| SREQ :%d ",
              (char *)pEchoBackData,
              oQueueLoad.ORD,
              oQueueLoad.REQ,
              oQueueLoad.SREQ);

     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::EntityCancelOrderStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer,sizeof(buffer),"EntityCancelOrderStart EchoBackData: %s |",
              (char *)pEchoBackData);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime-starttime;
     std::clog <<"ENABLE_TIME_LOG|" << __FUNCTION__ << "|"<< endtime<<"|"<<starttime<< "|"<<res<<std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::EntityCancelOrderResponse(void *pEchoBackData,
                                    char *pNorenOrderNo) 
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer,sizeof(buffer),"EntityCancelOrderResponse EchoBackData: %s | NorenOrderNo: %s |",
               (char *)pEchoBackData,
               pNorenOrderNo);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime-starttime;
     std::clog <<"ENABLE_TIME_LOG|" << __FUNCTION__ << "|"<< endtime<<"|"<<starttime<< "|"<<res<<std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::EntityCancelOrderEnd(void *pEchoBackData) 
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer,sizeof(buffer),"EntityCancelOrderEnd EchoBackData: %s |",
              (char *)pEchoBackData);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime-starttime;
     std::clog <<"ENABLE_TIME_LOG|" << __FUNCTION__ << "|"<< endtime<<"|"<<starttime<< "|"<<res<<std::endl;
#endif
     return 0;
}


int CXXAPINorenClient::getAllAuctionSymbolsStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllAuctionSymbolsStart EchoBackData: %s |",
              (char *)pEchoBackData);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::getAllAuctionSymbolsResp(void *pEchoBackData,
                                                tsAuctionSymbolsParams *pPayinStatus)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllAuctionSymbolsResp EchoBackData: %s | Token: %s | Exchange Segment: %s | InstType: %s |"
                                      "Symbol Name: %s | Trding Symbol: %s| ISIN: %s | Desc: %s | TickSize: %f | LotSize: %ld | ScripUniqKey: %s | MsgFlag: %d | Segment: %s | InterOPKey: %s |"
                                      "InterOPExchSeg: %s | TradePrice: %f | AskPrice1: %f | BidPrice1: %f | AskSize1: %ld | BidSize1: %ld | AskNumOfOrders1: %ld | BidNumOfOrders1: %ld |"
                                      "HighPriceRange: %f | LowPriceRange: %f | TotBuyQuan: %ld | TotSellQuan: %ld | AuctionNumber: %d |",
              (char *)pEchoBackData,
              pPayinStatus->pSymbol,
              pPayinStatus->pExchSeg,
              pPayinStatus->pInstType,
              pPayinStatus->pSymbolName,
              pPayinStatus->pTrdSymbol,
              pPayinStatus->pISIN,
              pPayinStatus->pDesc,
              pPayinStatus->dTickSize,
              pPayinStatus->lLotSize,
              pPayinStatus->pScripUniqKey,
              pPayinStatus->iMsgFlag,
              pPayinStatus->pSegment,
              pPayinStatus->pInterOPKey,
              pPayinStatus->pInterOPExchSeg,
              pPayinStatus->dTradePrice,
              pPayinStatus->dAskPrice1,
              pPayinStatus->dBidPrice1,
              pPayinStatus->lAskSize1,
              pPayinStatus->lBidSize1,
              pPayinStatus->lAskNumOfOrders1,
              pPayinStatus->lBidNumOfOrders1,
              pPayinStatus->dHighPriceRange,
              pPayinStatus->dLowPriceRange,
              pPayinStatus->lTotBuyQuan,
              pPayinStatus->lTotSellQuan,
              pPayinStatus->iAuctionNumber);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::getAllAuctionSymbolsEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllAuctionSymbolsEnd EchoBackData: %s |",
              (char *)pEchoBackData);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::OfsOrderUpdate(tsOfsOrderBook *pOfsOrderUpdate,
                                   void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OfsOrderUpdate EchoBackData: %s | Exchange Segment: %s | AccountId: %s | Order Duration: %s | Customer Firm: %s |"
                                      "Product: %s | OrderType: %s | TrdSymbol: %s | TransType: %s | GuiOrdId: %s | GuiOrgOrdId: %s | Token: %s | Price: %f | Quantity: %ld | DiscQuantity: %ld |"
                                      "Pan: %s | User: %s | VendorCode: %s | OrdSrc: %s | OrdRemarks: %s | IpAddr: %s | NorenOrdNum: %s | ReqId: %s | ExchOrdId: %s | Status: %c | OrdStatus :%s |"
                                      "NorenUpdateTime: %s | NorenUpdateTimeEpoch: %ld | NorenUpdateTimeNanoSec: %ld | ExchTime: %s | ExchTimeEpoch: %ld | ExchTimeNanoSec: %ld | OrgExchTime: %s |"
                                      "RejectionBy: %s | NorenTimeSec: %s | NorenTimeSecEpoch: %ld | NorenTimeMiliSec: %s | NorenTimeNanoSec: %ld | ReportType: %s | RepTyp: %c| RejReason: %s |"
                                      "RejQty: %ld | RejOrdSrc: %s | RejPriceType: %s | Region: %s | FamilyId: %s | ExchUsrId: %s | BrokerId: %s |",
              (char *)pEchoBackData,
              pOfsOrderUpdate->acExchSeg,
              pOfsOrderUpdate->acAccountId,
              pOfsOrderUpdate->acOrdDuration,
              pOfsOrderUpdate->acCustomerFirm,
              pOfsOrderUpdate->acProduct,
              pOfsOrderUpdate->acOrderType,
              pOfsOrderUpdate->acTrdSymbol,
              pOfsOrderUpdate->acTransType,
              pOfsOrderUpdate->acGuiOrdId,
              pOfsOrderUpdate->acGuiOrgOrdId,
              pOfsOrderUpdate->acToken,
              pOfsOrderUpdate->dPrice,
              pOfsOrderUpdate->lQuantity,
              pOfsOrderUpdate->lDiscQuantity,
              pOfsOrderUpdate->acPan,
              pOfsOrderUpdate->acUser,
              pOfsOrderUpdate->acVendorCode,
              pOfsOrderUpdate->acOrdSrc,
              pOfsOrderUpdate->acOrdRemarks,
              pOfsOrderUpdate->acIpAddr,
              pOfsOrderUpdate->acNorenOrdNum,
              pOfsOrderUpdate->acReqId,
              pOfsOrderUpdate->acExchOrdId,
              pOfsOrderUpdate->cStatus,
              pOfsOrderUpdate->acOrdStatus,
              pOfsOrderUpdate->acNorenUpdateTime,
              pOfsOrderUpdate->lNorenUpdateTimeEpoch,
              pOfsOrderUpdate->lNorenUpdateTimeNanoSec,
              pOfsOrderUpdate->acExchTime,
              pOfsOrderUpdate->lExchTimeEpoch,
              pOfsOrderUpdate->lExchTimeNanoSec,
              pOfsOrderUpdate->acOrgExchTime,
              pOfsOrderUpdate->acRejectionBy,
              pOfsOrderUpdate->acNorenTimeSec,
              pOfsOrderUpdate->lNorenTimeSecEpoch,
              pOfsOrderUpdate->acNorenTimeMiliSec,
              pOfsOrderUpdate->lNorenTimeNanoSec,
              pOfsOrderUpdate->acReportType,
              pOfsOrderUpdate->cRepTyp,
              pOfsOrderUpdate->acRejReason,
              pOfsOrderUpdate->lRejQty,
              pOfsOrderUpdate->acRejOrdSrc,
              pOfsOrderUpdate->acRejPriceType,
              pOfsOrderUpdate->acRegion,
              pOfsOrderUpdate->acFamilyId,
              pOfsOrderUpdate->acExchUsrId,
              pOfsOrderUpdate->acBrokerId);

     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;

}

int CXXAPINorenClient::OfsOrderAdminUnSubscribeResponse(void *pEchoBackData,
                                                       char *pStatus) 
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OfsOrderAdminUnSubscribeResponse : EchoBackData: %s Status :%s",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;

}

int CXXAPINorenClient::OfsOrderHistoryStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OfsOrderHistoryStart EchoBackData: %s |",
              (char *)pEchoBackData);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::OfsOrderHistory(void *pEchoBackData,
                                       tsOfsOrderBook *pOfsOrderBook)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OfsOrderHistory EchoBackData: %s | Exchange Segment: %s | AccountId: %s | Order Duration: %s | Customer Firm: %s |"
                                      "Product: %s | OrderType: %s | TrdSymbol: %s | TransType: %s | GuiOrdId: %s | GuiOrgOrdId: %s | Token: %s | Price: %f | Quantity: %ld | DiscQuantity: %ld |"
                                      "Pan: %s | User: %s | VendorCode: %s | OrdSrc: %s | OrdRemarks: %s | IpAddr: %s | NorenOrdNum: %s | ReqId: %s | ExchOrdId: %s | Status: %c | OrdStatus :%s |"
                                      "NorenUpdateTime: %s | NorenUpdateTimeEpoch: %ld | NorenUpdateTimeNanoSec: %ld | ExchTime: %s | ExchTimeEpoch: %ld | ExchTimeNanoSec: %ld | OrgExchTime: %s |"
                                      "RejectionBy: %s | NorenTimeSec: %s | NorenTimeSecEpoch: %ld | NorenTimeMiliSec: %s | NorenTimeNanoSec: %ld | ReportType: %s | RepTyp: %c| RejReason: %s |"
                                      "RejQty: %ld | RejOrdSrc: %s | RejPriceType: %s | Region: %s | FamilyId: %s | ExchUsrId: %s | BrokerId: %s |",
              (char *)pEchoBackData,
              pOfsOrderBook->acExchSeg,
              pOfsOrderBook->acAccountId,
              pOfsOrderBook->acOrdDuration,
              pOfsOrderBook->acCustomerFirm,
              pOfsOrderBook->acProduct,
              pOfsOrderBook->acOrderType,
              pOfsOrderBook->acTrdSymbol,
              pOfsOrderBook->acTransType,
              pOfsOrderBook->acGuiOrdId,
              pOfsOrderBook->acGuiOrgOrdId,
              pOfsOrderBook->acToken,
              pOfsOrderBook->dPrice,
              pOfsOrderBook->lQuantity,
              pOfsOrderBook->lDiscQuantity,
              pOfsOrderBook->acPan,
              pOfsOrderBook->acUser,
              pOfsOrderBook->acVendorCode,
              pOfsOrderBook->acOrdSrc,
              pOfsOrderBook->acOrdRemarks,
              pOfsOrderBook->acIpAddr,
              pOfsOrderBook->acNorenOrdNum,
              pOfsOrderBook->acReqId,
              pOfsOrderBook->acExchOrdId,
              pOfsOrderBook->cStatus,
              pOfsOrderBook->acOrdStatus,
              pOfsOrderBook->acNorenUpdateTime,
              pOfsOrderBook->lNorenUpdateTimeEpoch,
              pOfsOrderBook->lNorenUpdateTimeNanoSec,
              pOfsOrderBook->acExchTime,
              pOfsOrderBook->lExchTimeEpoch,
              pOfsOrderBook->lExchTimeNanoSec,
              pOfsOrderBook->acOrgExchTime,
              pOfsOrderBook->acRejectionBy,
              pOfsOrderBook->acNorenTimeSec,
              pOfsOrderBook->lNorenTimeSecEpoch,
              pOfsOrderBook->acNorenTimeMiliSec,
              pOfsOrderBook->lNorenTimeNanoSec,
              pOfsOrderBook->acReportType,
              pOfsOrderBook->cRepTyp,
              pOfsOrderBook->acRejReason,
              pOfsOrderBook->lRejQty,
              pOfsOrderBook->acRejOrdSrc,
              pOfsOrderBook->acRejPriceType,
              pOfsOrderBook->acRegion,
              pOfsOrderBook->acFamilyId,
              pOfsOrderBook->acExchUsrId,
              pOfsOrderBook->acBrokerId);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::OfsOrderHistoryEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OfsOrderHistoryEnd EchoBackData: %s |",
              (char *)pEchoBackData);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}


int CXXAPINorenClient::OfsOrderBookStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OfsOrderBookStart EchoBackData: %s |",
              (char *)pEchoBackData);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::OfsOrderBookResp(void *pEchoBackData,
                                      tsOfsOrderBook *pOfsOrdBookResp)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OfsOrderBookResp EchoBackData: %s | Exchange Segment: %s | AccountId: %s | Order Duration: %s | Customer Firm: %s |"
                                      "Product: %s | OrderType: %s | TrdSymbol: %s | TransType: %s | GuiOrdId: %s | GuiOrgOrdId: %s | Token: %s | Price: %f | Quantity: %ld | DiscQuantity: %ld |"
                                      "Pan: %s | User: %s | VendorCode: %s | OrdSrc: %s | OrdRemarks: %s | IpAddr: %s | NorenOrdNum: %s | ReqId: %s | ExchOrdId: %s | Status: %c | OrdStatus :%s |"
                                      "NorenUpdateTime: %s | NorenUpdateTimeEpoch: %ld | NorenUpdateTimeNanoSec: %ld | ExchTime: %s | ExchTimeEpoch: %ld | ExchTimeNanoSec: %ld | OrgExchTime: %s |"
                                      "RejectionBy: %s | NorenTimeSec: %s | NorenTimeSecEpoch: %ld | NorenTimeMiliSec: %s | NorenTimeNanoSec: %ld | ReportType: %s | RepTyp: %c| RejReason: %s |"
                                      "RejQty: %ld | RejOrdSrc: %s | RejPriceType: %s | Region: %s | FamilyId: %s | ExchUsrId: %s | BrokerId: %s |",
              (char *)pEchoBackData,
              pOfsOrdBookResp->acExchSeg,
              pOfsOrdBookResp->acAccountId,
              pOfsOrdBookResp->acOrdDuration,
              pOfsOrdBookResp->acCustomerFirm,
              pOfsOrdBookResp->acProduct,
              pOfsOrdBookResp->acOrderType,
              pOfsOrdBookResp->acTrdSymbol,
              pOfsOrdBookResp->acTransType,
              pOfsOrdBookResp->acGuiOrdId,
              pOfsOrdBookResp->acGuiOrgOrdId,
              pOfsOrdBookResp->acToken,
              pOfsOrdBookResp->dPrice,
              pOfsOrdBookResp->lQuantity,
              pOfsOrdBookResp->lDiscQuantity,
              pOfsOrdBookResp->acPan,
              pOfsOrdBookResp->acUser,
              pOfsOrdBookResp->acVendorCode,
              pOfsOrdBookResp->acOrdSrc,
              pOfsOrdBookResp->acOrdRemarks,
              pOfsOrdBookResp->acIpAddr,
              pOfsOrdBookResp->acNorenOrdNum,
              pOfsOrdBookResp->acReqId,
              pOfsOrdBookResp->acExchOrdId,
              pOfsOrdBookResp->cStatus,
              pOfsOrdBookResp->acOrdStatus,
              pOfsOrdBookResp->acNorenUpdateTime,
              pOfsOrdBookResp->lNorenUpdateTimeEpoch,
              pOfsOrdBookResp->lNorenUpdateTimeNanoSec,
              pOfsOrdBookResp->acExchTime,
              pOfsOrdBookResp->lExchTimeEpoch,
              pOfsOrdBookResp->lExchTimeNanoSec,
              pOfsOrdBookResp->acOrgExchTime,
              pOfsOrdBookResp->acRejectionBy,
              pOfsOrdBookResp->acNorenTimeSec,
              pOfsOrdBookResp->lNorenTimeSecEpoch,
              pOfsOrdBookResp->acNorenTimeMiliSec,
              pOfsOrdBookResp->lNorenTimeNanoSec,
              pOfsOrdBookResp->acReportType,
              pOfsOrdBookResp->cRepTyp,
              pOfsOrdBookResp->acRejReason,
              pOfsOrdBookResp->lRejQty,
              pOfsOrdBookResp->acRejOrdSrc,
              pOfsOrdBookResp->acRejPriceType,
              pOfsOrdBookResp->acRegion,
              pOfsOrdBookResp->acFamilyId,
              pOfsOrdBookResp->acExchUsrId,
              pOfsOrdBookResp->acBrokerId);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::OfsOrderBookEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "OfsOrderBookEnd EchoBackData: %s |",
              (char *)pEchoBackData);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetAllOfsOrdersStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllOfsOrdersStart EchoBackData: %s |",
              (char *)pEchoBackData);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetAllOfsOrders(void *pEchoBackData,
                                   tsOfsOrderBook *pOfsOrdBookResp)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
    char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllOfsOrders EchoBackData: %s | Exchange Segment: %s | AccountId: %s | Order Duration: %s | Customer Firm: %s |"
                                      "Product: %s | OrderType: %s | TrdSymbol: %s | TransType: %s | GuiOrdId: %s | GuiOrgOrdId: %s | Token: %s | Price: %f | Quantity: %ld | DiscQuantity: %ld |"
                                      "Pan: %s | User: %s | VendorCode: %s | OrdSrc: %s | OrdRemarks: %s | IpAddr: %s | NorenOrdNum: %s | ReqId: %s | ExchOrdId: %s | Status: %c | OrdStatus :%s |"
                                      "NorenUpdateTime: %s | NorenUpdateTimeEpoch: %ld | NorenUpdateTimeNanoSec: %ld | ExchTime: %s | ExchTimeEpoch: %ld | ExchTimeNanoSec: %ld | OrgExchTime: %s |"
                                      "RejectionBy: %s | NorenTimeSec: %s | NorenTimeSecEpoch: %ld | NorenTimeMiliSec: %s | NorenTimeNanoSec: %ld | ReportType: %s | RepTyp: %c| RejReason: %s |"
                                      "RejQty: %ld | RejOrdSrc: %s | RejPriceType: %s | Region: %s | FamilyId: %s | ExchUsrId: %s | BrokerId: %s |",
              (char *)pEchoBackData,
              pOfsOrdBookResp->acExchSeg,
              pOfsOrdBookResp->acAccountId,
              pOfsOrdBookResp->acOrdDuration,
              pOfsOrdBookResp->acCustomerFirm,
              pOfsOrdBookResp->acProduct,
              pOfsOrdBookResp->acOrderType,
              pOfsOrdBookResp->acTrdSymbol,
              pOfsOrdBookResp->acTransType,
              pOfsOrdBookResp->acGuiOrdId,
              pOfsOrdBookResp->acGuiOrgOrdId,
              pOfsOrdBookResp->acToken,
              pOfsOrdBookResp->dPrice,
              pOfsOrdBookResp->lQuantity,
              pOfsOrdBookResp->lDiscQuantity,
              pOfsOrdBookResp->acPan,
              pOfsOrdBookResp->acUser,
              pOfsOrdBookResp->acVendorCode,
              pOfsOrdBookResp->acOrdSrc,
              pOfsOrdBookResp->acOrdRemarks,
              pOfsOrdBookResp->acIpAddr,
              pOfsOrdBookResp->acNorenOrdNum,
              pOfsOrdBookResp->acReqId,
              pOfsOrdBookResp->acExchOrdId,
              pOfsOrdBookResp->cStatus,
              pOfsOrdBookResp->acOrdStatus,
              pOfsOrdBookResp->acNorenUpdateTime,
              pOfsOrdBookResp->lNorenUpdateTimeEpoch,
              pOfsOrdBookResp->lNorenUpdateTimeNanoSec,
              pOfsOrdBookResp->acExchTime,
              pOfsOrdBookResp->lExchTimeEpoch,
              pOfsOrdBookResp->lExchTimeNanoSec,
              pOfsOrdBookResp->acOrgExchTime,
              pOfsOrdBookResp->acRejectionBy,
              pOfsOrdBookResp->acNorenTimeSec,
              pOfsOrdBookResp->lNorenTimeSecEpoch,
              pOfsOrdBookResp->acNorenTimeMiliSec,
              pOfsOrdBookResp->lNorenTimeNanoSec,
              pOfsOrdBookResp->acReportType,
              pOfsOrdBookResp->cRepTyp,
              pOfsOrdBookResp->acRejReason,
              pOfsOrdBookResp->lRejQty,
              pOfsOrdBookResp->acRejOrdSrc,
              pOfsOrdBookResp->acRejPriceType,
              pOfsOrdBookResp->acRegion,
              pOfsOrdBookResp->acFamilyId,
              pOfsOrdBookResp->acExchUsrId,
              pOfsOrdBookResp->acBrokerId);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetAllOfsOrdersEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllOfsOrdersEnd EchoBackData: %s |",
              (char *)pEchoBackData);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetAllIpoOrdersStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllIpoOrdersStart EchoBackData: %s |",
              (char *)pEchoBackData);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetAllIpoOrders(void *pEchoBackData,
                                   tsIpoOrdBook *pIpoOrdBookResp)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllIpoOrders:pEchoBackData :%s| RejectionOrdSrc :%s | RejectionPriceType:%s |"
                                      " PurchaseType :%s | DpTrans:%s |FolioNum:%s | Euin:%s | Exch :%s | Act Id :%s| Ord Duration :%s|"
                                      " CustomFirm :%s | Product :%s | Ord Type :%s | Trd Symbol :%s | Trans Type :%s | acGuiOrdId :%s|"
                                      " Token :%s  |Price :%f  |TriggerPrice :%f |Quantity :%ld |DiscQuantity :%ld |CancelledSize :%ld|"
                                      " OrdSrc :%s |acOrdRemarks :%s  |BookProfitPrice :%d | BookLossPrice :%d |TrailingPrice :%d|"
                                      " iSnoOrdType :%d |ExternalRemarks :%s | AlgoName :%s | AlgoId :%s | AlgoCategory :%s |User :%s|"
                                      " VendorCode  :%s |  AvgPrice :%f | FilledShares :%ld | NorenOrdNum :%s|"
                                      "ReqId :%s | ExchOrdId :%s |Text :%s |OrdStatus :%s |Status :%c | ReportType :%s | RepTyp :%c|"
                                      " NorenTime Sec :%s|  NorenUpdateTime :%s | NorenUpdateTimeNanoSec :%ld | NorenUpdateTimeEpoch :%ld| ExchTime :%s | ExchTimeNanoSec :%ld|"
                                      " ExchOrdUpdateTime :%s| RejectionBy :%s | Rejection Reason :%s | OrderGenType :%s | NorenTime MiliSec :%s|"
                                      " lNorenTimeNanoSec :%ld | lRejQty :%ld| RejOrdSrc :%s| RejPriceType :%s| dRmsPrice :%f |BasketId :%ld |"
                                      " acIpAddr :%s| acChannel :%s |acUserAgent :%s |acAppInstallId :%s| iLocationId :%d| acExchUsrInfo :%s| acOrgOrdSrc :%s|"
                                      " acRegion :%s| acFamilyId :%s | FilledShares :%ld | UnfilledSize :%ld | NorenOrdNum:%s |acExchUsrId :%s|",
              (char *)pEchoBackData,
              pIpoOrdBookResp->acRejectionOrdSrc,
              pIpoOrdBookResp->acRejectionPriceType,
              pIpoOrdBookResp->acPurchaseType,
              pIpoOrdBookResp->acDpTrans,
              pIpoOrdBookResp->acFolioNum,
              pIpoOrdBookResp->acEuin,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acExchSeg,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acAccountId,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acOrdDuration,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acCustomerFirm,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acProduct,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acOrderType,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acTrdSymbol,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acTransType,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acGuiOrdId,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acToken,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.dPrice,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.dTriggerPrice,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.lQuantity,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.lDiscQuantity,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.lCancelledSize,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acOrdSrc,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acOrdRemarks,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.iBookProfitPrice,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.iBookLossPrice,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.iTrailingPrice,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.iSnoOrdType,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acExternalRemarks,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acAlgoName,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acAlgoId,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acAlgoCategory,
              //                    " Pan "
              //                    << pOrderUpdate->acPan <<

              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acUser,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acVendorCode,
              pIpoOrdBookResp->sOrderUpdate.dAvgPrice,
              pIpoOrdBookResp->sOrderUpdate.lFilledShares,
              pIpoOrdBookResp->sOrderUpdate.acNorenOrdNum,
              pIpoOrdBookResp->sOrderUpdate.acReqId,
              pIpoOrdBookResp->sOrderUpdate.acExchOrdId,
              pIpoOrdBookResp->sOrderUpdate.acText,
              pIpoOrdBookResp->sOrderUpdate.acOrdStatus,
              pIpoOrdBookResp->sOrderUpdate.cStatus,
              pIpoOrdBookResp->sOrderUpdate.acReportType,
              pIpoOrdBookResp->sOrderUpdate.cRepTyp,
              pIpoOrdBookResp->sOrderUpdate.acNorenTimeSec,
              pIpoOrdBookResp->sOrderUpdate.acNorenUpdateTime,
              pIpoOrdBookResp->sOrderUpdate.lNorenUpdateTimeNanoSec,
              pIpoOrdBookResp->sOrderUpdate.lNorenUpdateTimeEpoch,
              pIpoOrdBookResp->sOrderUpdate.acExchTime,
              pIpoOrdBookResp->sOrderUpdate.lExchTimeNanoSec,
              pIpoOrdBookResp->sOrderUpdate.acOrgExchTime,
              pIpoOrdBookResp->sOrderUpdate.acRejectionBy,
              pIpoOrdBookResp->sOrderUpdate.acRejReason,
              pIpoOrdBookResp->sOrderUpdate.acOrderGenType,
              pIpoOrdBookResp->sOrderUpdate.acNorenTimeMiliSec,
              pIpoOrdBookResp->sOrderUpdate.lNorenTimeNanoSec,
              pIpoOrdBookResp->sOrderUpdate.lRejQty,
              pIpoOrdBookResp->sOrderUpdate.acRejOrdSrc,
              pIpoOrdBookResp->sOrderUpdate.acRejPriceType,
              pIpoOrdBookResp->sOrderUpdate.dRmsPrice,
              pIpoOrdBookResp->sOrderUpdate.lBasketId,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acIpAddr,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acChannel,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acUserAgent,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.acAppInstallId,
              pIpoOrdBookResp->sOrderUpdate.sOrderParams.iLocationId,
              pIpoOrdBookResp->sOrderUpdate.acExchUsrInfo,
              pIpoOrdBookResp->sOrderUpdate.acOrgOrdSrc,
              pIpoOrdBookResp->sOrderUpdate.acRegion,
              pIpoOrdBookResp->sOrderUpdate.acFamilyId,
              pIpoOrdBookResp->sOrderUpdate.lFilledShares,
              pIpoOrdBookResp->sOrderUpdate.lUnfilledSize,
              pIpoOrdBookResp->sOrderUpdate.acNorenOrdNum,
              pIpoOrdBookResp->sOrderUpdate.acExchUsrId);
     logString += buffer;

     if (pIpoOrdBookResp->acIpAddr)
     {
          snprintf(buffer, sizeof(buffer), "acIpAddr :%s |", pIpoOrdBookResp->acIpAddr);
          logString += buffer;
     }
     if (pIpoOrdBookResp->sOrderUpdate.sOrderParams.acChannel)
     {
          snprintf(buffer, sizeof(buffer), "acChannel :%s |", pIpoOrdBookResp->sOrderUpdate.sOrderParams.acChannel);
          logString += buffer;
     }
     if (pIpoOrdBookResp->sOrderUpdate.sOrderParams.acUserAgent)
     {
          snprintf(buffer, sizeof(buffer), "acUserAgent :%s |", pIpoOrdBookResp->sOrderUpdate.sOrderParams.acUserAgent);
          logString += buffer;
     }
     if (pIpoOrdBookResp->sOrderUpdate.sOrderParams.acAppInstallId)
     {
          snprintf(buffer, sizeof(buffer), "acAppInstallId :%s |", pIpoOrdBookResp->sOrderUpdate.sOrderParams.acAppInstallId);
          logString += buffer;
     }
     std::clog << logString << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetAllIpoOrdersEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetAllIpoOrdersEnd EchoBackData: %s |",
              (char *)pEchoBackData);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::PauseSipOrderResp(void *pEchoBackData,
                                   char *pReqStatus,
                                   long lSipId)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "PauseSipOrderResp EchoBackData: %s | ReqStatus: %s | SipId: %ld |",
               (char *)pEchoBackData,
               pReqStatus,
               lSipId);
     
               std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::ResumeSipOrderResp(void *pEchoBackData,
                                   char *pReqStatus,
                                   long lSipId)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "ResumeSipOrderResp EchoBackData: %s | ReqStatus: %s | SipId: %ld |",
              (char *)pEchoBackData,
              pReqStatus,
              lSipId);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::ThresholdAlertUpdate(tsThresholdAlertParams *pThresholdAlertUpdate,void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer)," ThresholdAlertUpdate :EchoBackData: %s | Isin :%s | Exch :%s | Trd Symbol :%s | Token :%s |"
              " Ltp :%ld | Prev Close :%ld | BreachPerc :%.2f | AlertType :%d | Remarks :%s |",
              (char *)pEchoBackData,
              pThresholdAlertUpdate->acISIN,
              pThresholdAlertUpdate->acExchSeg,
              pThresholdAlertUpdate->acToken,
              pThresholdAlertUpdate->acTrdSymbol,
              pThresholdAlertUpdate->lPrevClose,
              pThresholdAlertUpdate->lTradePrice,
              pThresholdAlertUpdate->dBreachPerc,
              pThresholdAlertUpdate->iAlertType,
              pThresholdAlertUpdate->acRemarks);
     logString+=buffer;
     logString += '\n';

     std::clog<<logString<<std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime-starttime;
     std::clog <<"ENABLE_TIME_LOG|" << __FUNCTION__ << "|"<< endtime<<"|"<<starttime<< "|"<<res<<std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::DPRThresholdAlertUnSubscribeResponse(char *pStatus,
                                                            void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif

     char buffer[BUFFER_SIZE];
     snprintf(buffer,sizeof(buffer),"DPRThresholdAlertUnSubscribeResponse : EchoBackData: %s Status :%s",
              (char *)pEchoBackData,
              pStatus);
     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime-starttime;
     std::clog <<"ENABLE_TIME_LOG|" << __FUNCTION__ << "|"<< endtime<<"|"<<starttime<< "|"<<res<<std::endl;
#endif
     return 0;
}
int CXXAPINorenClient::GetMaxBlockAmtStart(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetMaxBlockAmtStart EchoBackData: %s |",
              (char *)pEchoBackData);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetMaxBlockAmtResponse(double MaxBlockAmt,
                                             void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     std::string logString;
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetMaxBlockAmtResponse:pEchoBackData :%s| MaxBlockAmt :%f|",
              (char *)pEchoBackData,MaxBlockAmt);
     logString += buffer;
     std::clog << logString << std::endl;

#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}

int CXXAPINorenClient::GetMaxBlockAmtEnd(void *pEchoBackData)
{
#ifdef ENABLE_TIME_LOG
     long starttime = s_get_time_in_micro_seconds();
#endif
     char buffer[BUFFER_SIZE];
     snprintf(buffer, sizeof(buffer), "GetMaxBlockAmtEnd EchoBackData: %s |",
              (char *)pEchoBackData);

     std::clog << buffer << std::endl;
#ifdef ENABLE_TIME_LOG
     long endtime = s_get_time_in_micro_seconds();
     long res = endtime - starttime;
     std::clog << "ENABLE_TIME_LOG|" << __FUNCTION__ << "|" << endtime << "|" << starttime << "|" << res << std::endl;
#endif
     return 0;
}